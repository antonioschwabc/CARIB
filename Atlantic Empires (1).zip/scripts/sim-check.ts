import { newGame } from "../src/game/state";
import { tickDay, beginVoyage } from "../src/game/sim/tick";
import { portDestination } from "../src/game/sim/position";
import { sightRangeNm, scanSeaEvents } from "../src/game/sim/seaEvents";
const s = newGame({ startPortId: "havana" });
const ship = s.ships[0]!;
ship.cargo = { water: 400, saltbeef: 400 };
ship.crew = 12;
beginVoyage(s, ship, portDestination("portobelo")!);
console.log("voyage", !!ship.voyage, ship.voyage?.distanceNm, "sight", sightRangeNm(ship));
for (let i = 0; i < 15; i++) {
  tickDay(s);
  const evs = s.seaEvents ?? [];
  console.log(i, "events", evs.length, "seen", evs.filter(e=>e.seen).length, "enc", s.encounter?.kind ?? "-", "progress", Math.round(ship.voyage?.progressNm ?? -1));
  if (s.encounter) delete s.encounter;
}
