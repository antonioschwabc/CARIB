import { PORTS } from "../src/game/data/ports";
import { seaRoute, isSea } from "../src/game/sim/seagrid";
let bad = 0, fail = 0, n = 0;
const badPairs: string[] = [];
for (let i = 0; i < PORTS.length; i++) for (let j = i + 1; j < PORTS.length; j++) {
  const a = PORTS[i]!, b = PORTS[j]!;
  const r = seaRoute(a, b); n++;
  if (!r.ok) { fail++; badPairs.push(`FAIL ${a.name}->${b.name}`); continue; }
  let cross = 0;
  for (let k = 1; k < r.points.length; k++) {
    const p = r.points[k-1]!, q = r.points[k]!;
    const steps = Math.max(2, Math.ceil(Math.hypot(q.lat-p.lat, q.lon-p.lon)/0.1));
    for (let s = 1; s < steps; s++) {
      const f = s/steps;
      if (!isSea(p.lat+(q.lat-p.lat)*f, p.lon+(q.lon-p.lon)*f)) cross++;
    }
  }
  if (cross > 0) { bad++; if (badPairs.length < 25) badPairs.push(`LAND ${a.name}->${b.name} (${cross})`); }
}
console.log({ n, fail, bad });
console.log(badPairs.join("\n"));
