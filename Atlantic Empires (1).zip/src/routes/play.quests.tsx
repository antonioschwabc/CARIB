import { createFileRoute } from "@tanstack/react-router";

import { QuestsPanel } from "@/components/game/QuestsPanel";

export const Route = createFileRoute("/play/quests")({ component: QuestsPanel });
