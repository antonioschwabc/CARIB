import { createFileRoute } from "@tanstack/react-router";

import { FinancePanel } from "@/components/game/FinancePanel";

export const Route = createFileRoute("/play/finance")({ component: FinancePanel });
