import { createFileRoute } from "@tanstack/react-router";

import { TavernPanel } from "@/components/game/TavernPanel";

export const Route = createFileRoute("/play/tavern")({ component: TavernPanel });
