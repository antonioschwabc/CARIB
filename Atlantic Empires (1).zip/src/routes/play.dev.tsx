import { createFileRoute } from "@tanstack/react-router";

import { DevPanel } from "@/components/game/DevPanel";

export const Route = createFileRoute("/play/dev")({ component: DevPanel });
