import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";

import { AUTOSAVE, loadGame } from "@/game/save";
import { formatDate, money } from "@/game/sim/util";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "CARIB — 17th Century Caribbean Trading Simulator" },
      {
        name: "description",
        content:
          "Begin as a small merchant in 1670 Bridgetown. Trade, smuggle, privateer and build a shipping empire across a living 17th-century Atlantic economy.",
      },
      { property: "og:title", content: "CARIB — A Merchant's Fortune in the Atlantic" },
      {
        property: "og:description",
        content: "A systems-driven Caribbean trading and empire simulator set in the 1670s.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Title,
});

function Title() {
  const navigate = useNavigate();
  const [existing, setExisting] = useState<{ day: number; cash: number; name: string } | null>(null);

  useEffect(() => {
    const s = loadGame(AUTOSAVE);
    if (s) setExisting({ day: s.day, cash: s.cash, name: s.merchantName });
  }, []);

  function start() {
    navigate({ to: "/new" });
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-background px-4 py-12">
      <div className="w-full max-w-2xl space-y-8 text-center">
        <header>
          <h1 className="font-serif text-6xl font-bold tracking-[0.3em] text-accent">CARIB</h1>
          <p className="mt-3 font-serif text-lg italic text-muted-foreground">
            A Merchant's Fortune in the Atlantic
          </p>
        </header>

        <p className="mx-auto max-w-xl text-sm leading-relaxed text-muted-foreground">
          January 1670. A hull bought on credit, four hundred gold, and not one man signed to your
          articles. Sugar, rum, hides, dyewood and contraband move between thirty-four ports whose prices
          rise and fall with harvests, hurricanes, wars and the ambitions of other merchants. Work the
          contract boards, sign a crew, clear your debt — then build whatever you like on top of it.
        </p>

        <div className="panel mx-auto max-w-sm space-y-3 p-5 text-left">
          <button
            type="button"
            onClick={start}
            className="w-full rounded-sm bg-primary px-4 py-2 font-semibold text-primary-foreground"
          >
            New voyage — fit out a vessel
          </button>
          {existing && (
            <button
              type="button"
              onClick={() => navigate({ to: "/play" })}
              className="numeric w-full rounded-sm border border-input px-4 py-2 text-sm"
            >
              Continue {existing.name} · {formatDate(existing.day)} · {money(existing.cash)}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
