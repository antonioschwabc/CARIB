import { createFileRoute } from "@tanstack/react-router";

import { PortDossier } from "@/components/game/PortDossier";
import { activeShip } from "@/game/actions";
import { inPort } from "@/game/sim/position";
import { useGame } from "@/game/store";

export const Route = createFileRoute("/play/port")({
  component: PortTab,
  head: () => ({
    meta: [
      { title: "Port — CARIB" },
      { name: "description", content: "The harbour you lie in: quay, contract board, tavern and shipwright's yard." },
      { property: "og:title", content: "Port — CARIB" },
      { property: "og:description", content: "Go ashore: market, contracts, tavern and yard." },
    ],
  }),
});

function PortTab() {
  const { state } = useGame();
  const ship = activeShip(state);
  const docked = !!ship && inPort(ship) && !!ship.portId;

  if (!docked) {
    return (
      <div className="p-4">
        <p className="panel p-4 text-sm text-muted-foreground">
          She is not lying at any harbour. Set a course from the Chart and make your landfall — the quay, the contract
          board, the tavern and the yard open once she is moored.
        </p>
      </div>
    );
  }

  return (
    <div className="p-4">
      <section className="panel p-4">
        <PortDossier portId={ship!.portId!} />
      </section>
    </div>
  );
}
