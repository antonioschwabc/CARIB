import { createFileRoute } from "@tanstack/react-router";

import { JournalPanel } from "@/components/game/JournalPanel";

export const Route = createFileRoute("/play/journal")({ component: JournalPanel });
