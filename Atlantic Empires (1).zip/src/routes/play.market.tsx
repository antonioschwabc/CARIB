import { createFileRoute } from "@tanstack/react-router";

import { MarketPanel } from "@/components/game/MarketPanel";

export const Route = createFileRoute("/play/market")({ component: MarketPanel });
