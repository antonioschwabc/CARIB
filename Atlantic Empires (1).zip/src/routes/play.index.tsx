import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";

import { ChartMap } from "@/components/game/ChartMap";
import { TravelGuide } from "@/components/game/TravelGuide";
import { activeShip } from "@/game/actions";
import { PORT_MAP, PORTS, portVisible } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { portDestination, seaDestination, shipPos, distanceBetween } from "@/game/sim/position";
import { seaRoute } from "@/game/sim/seagrid";
import { sightRangeNm, visibleSeaEvents } from "@/game/sim/seaEvents";
import { visibleNpcs } from "@/game/sim/world";
import { fortificationOf } from "@/game/sim/portIntel";
import { useGame } from "@/game/store";
import { MARK_NAME, MarkBadge } from "@/components/game/MarkIcons";
import { NpcCrewDialog } from "@/components/game/NpcCrewDialog";
import { SHIP_CLASS_MAP } from "@/game/data/ships";
import type { Destination, NpcShip, SeaEvent } from "@/game/types";

export const Route = createFileRoute("/play/")({
  component: MapTab,
});

function MapTab() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const [hovered, setHovered] = useState<string | undefined>();
  const [mark, setMark] = useState<Destination | undefined>();
  const [guide, setGuide] = useState<Destination | undefined>();
  const [event, setEvent] = useState<SeaEvent | undefined>();
  const [npc, setNpc] = useState<NpcShip | undefined>();

  const at = ship ? shipPos(ship) : { lat: 23.1, lon: -82.4 };
  const track = ship?.voyage?.path?.length
    ? ship.voyage.path
    : ship?.course
      ? seaRoute(at, ship.course).points
      : undefined;
  const sight = ship ? sightRangeNm(ship) : 0;
  // Only what is under the lookouts' eye this minute is on the sheet; the rest
  // falls off it again, so the chart is never littered.
  const marks = visibleSeaEvents(state, at, sight);
  const npcs = ship ? visibleNpcs(state, at, sight) : [];
  const tracked = state.quests.find((q) => q.id === state.trackedQuestId && q.accepted);
  const trackedPort = tracked?.targetPortId ? PORT_MAP[tracked.targetPortId] : undefined;
  const questMark = trackedPort
    ? { portId: trackedPort.id, lat: trackedPort.lat, lon: trackedPort.lon, label: trackedPort.name, note: `Contract · ${trackedPort.name}` }
    : undefined;

  return (
    <div className="relative h-full w-full">
      <ChartMap
        selected={mark}
        shipAt={at}
        {...(track ? { track } : {})}
        {...(ship?.course ? { course: ship.course } : {})}
        {...(questMark ? { questMark } : {})}
        seaEvents={marks}
        sightNm={sight}
        revealKey={(state.knownPorts ?? []).join(",")}
        npcShips={npcs}
        onSelectNpc={(id) => setNpc(npcs.find((n) => n.id === id))}
        npcBattles={(state.npcBattles ?? []).map((b) => ({
          ...b,
          crews: b.shipIds
            .map((id) => (state.npcShips ?? []).find((s) => s.id === id))
            .filter((s): s is NpcShip => !!s)
            .map((s) => ({
              name: s.name,
              captain: s.captain.name,
              power: s.power,
              className: SHIP_CLASS_MAP[s.classId]?.name,
            })),
        }))}
        day={state.day}
        onHoverPort={setHovered}
        onSelectPort={(id) => setMark(portDestination(id))}
        onSelectEvent={(ev) => setEvent(ev)}
        onSelectSea={(lat, lon) => setMark(seaDestination(lat, lon))}
        onSetCourse={(d) => {
          const dest = d.portId ? portDestination(d.portId) : seaDestination(d.lat, d.lon);
          if (!dest) return;
          setMark(undefined);
          dispatch({ type: "setCourse", dest });
          dispatch({ type: "setRudder", underway: true });
        }}


      />

      {/* the harbour report rides over the left of the sheet */}
      {hovered && (
        <div className="pointer-events-none absolute left-3 top-14 z-20 w-72 rounded-sm border border-[oklch(0.55_0.09_75)]/70 bg-[oklch(0.13_0.03_45)] p-3 text-xs text-[oklch(0.92_0.03_85)] shadow-xl">
          <HoverCard portId={hovered} from={at} />
        </div>
      )}

      {mark && (
        <MarkPopup
          mark={mark}
          from={at}
          onClose={() => setMark(undefined)}
          onSail={() => {
            setGuide(mark);
            setMark(undefined);
          }}

        />
      )}

      {event && (
        <EventPopup
          ev={event}
          from={at}
          onClose={() => setEvent(undefined)}
          onSail={() => {
            setGuide({ lat: event.lat, lon: event.lon, label: event.title });
            setEvent(undefined);
          }}
        />
      )}

      {npc && <NpcCrewDialog ship={npc} onClose={() => setNpc(undefined)} />}

      {guide && <TravelGuide dest={guide} onClose={() => setGuide(undefined)} />}
    </div>
  );
}

function HoverCard({ portId, from }: { portId: string; from: { lat: number; lon: number } }) {
  const port = PORT_MAP[portId];
  if (!port) return null;
  const fort = fortificationOf(port);
  return (
    <div className="space-y-1">
      <div className="flex items-baseline justify-between gap-2">
        <span className="font-serif text-base font-bold text-[oklch(0.90_0.12_85)]">{port.name}</span>
        <span className="numeric text-[10px] text-[oklch(0.80_0.09_82)]">
          {distanceBetween(from, port).toLocaleString("en-GB")} nm
        </span>
      </div>
      <p className="text-[11px] uppercase tracking-wide text-[oklch(0.78_0.06_80)]">
        {POWER_MAP[port.power]!.adjective} · {port.region}
      </p>
      <p className="leading-snug text-[oklch(0.86_0.03_85)]">{port.note}</p>
      <dl className="grid grid-cols-2 gap-x-3">
        <Cell label="Population" value={port.population.toLocaleString("en-GB")} />
        <Cell label="Prosperity" value={`${Math.round(port.prosperity * 100)}%`} />
        <Cell label="Piracy" value={`${Math.round(port.pirateRisk * 100)}%`} />
        <Cell label="Defences" value={fort.label} />
      </dl>
      <p className="pt-1 text-[10px] italic text-[oklch(0.78_0.06_80)]">Click for the passage brief.</p>
    </div>
  );
}

function Cell({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-1">
      <dt className="text-[10px] text-[oklch(0.76_0.05_80)]">{label}</dt>
      <dd className="numeric text-[11px] text-[oklch(0.93_0.03_85)]">{value}</dd>
    </div>
  );
}

/** Clicking a mark on the chart raises its report — sailing is a separate decision. */
function MarkPopup({
  mark,
  from,
  onClose,
  onSail,
}: {
  mark: Destination;
  from: { lat: number; lon: number };
  onClose: () => void;
  onSail: () => void;
}) {
  const port = mark.portId ? PORT_MAP[mark.portId] : undefined;
  const fort = port ? fortificationOf(port) : undefined;
  const near = port
    ? []
    : PORTS.filter(portVisible).map((p) => ({ p, d: distanceBetween(mark, p) }))
        .sort((a, b) => a.d - b.d)
        .slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label={port ? `${port.name} report` : "Open water"}
        onClick={(e) => e.stopPropagation()}
        className="panel w-full max-w-md space-y-3 bg-card p-5 text-card-foreground"
      >
        <header className="flex items-baseline justify-between gap-3 border-b border-border pb-2">
          <div>
            <h2 className="font-serif text-2xl font-bold">{port ? port.name : "Open water"}</h2>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              {port ? `${POWER_MAP[port.power]!.adjective} · ${port.region}` : mark.label}
            </p>
          </div>
          <button type="button" onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">
            Close ✕
          </button>
        </header>

        {port ? (
          <>
            <p className="text-sm leading-relaxed text-muted-foreground">{port.note}</p>
            <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
              <Cell label="Distance" value={`${distanceBetween(from, port).toLocaleString("en-GB")} nm`} />
              <Cell label="Population" value={port.population.toLocaleString("en-GB")} />
              <Cell label="Prosperity" value={`${Math.round(port.prosperity * 100)}%`} />
              <Cell label="Piracy" value={`${Math.round(port.pirateRisk * 100)}%`} />
              <Cell label="Defences" value={fort!.label} />
              <Cell label="Harbour security" value={`${Math.round(port.security * 100)}%`} />
            </dl>
          </>
        ) : (
          <div className="space-y-1 text-xs">
            <p className="text-muted-foreground">
              No harbour here — only sea room, to lie in wait or to work across in stages.
            </p>
            <Cell label="Distance" value={`${distanceBetween(from, mark).toLocaleString("en-GB")} nm`} />
            {near.map(({ p, d }) => (
              <Cell key={p.id} label={p.name} value={`${d.toLocaleString("en-GB")} nm`} />
            ))}
          </div>
        )}

        <footer className="grid gap-2 sm:grid-cols-2">
          <button type="button" onClick={onClose} className="rounded-sm border border-input px-3 py-2 text-sm">
            Back to the chart
          </button>
          <button
            type="button"
            onClick={onSail}
            className="rounded-sm bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"
          >
            Set sail for {port ? port.name : "this bearing"}
          </button>
        </footer>
      </div>
    </div>
  );
}

/** The report on a mark afloat: what the lookout has, and how far off it lies. */
function EventPopup({
  ev,
  from,
  onClose,
  onSail,
}: {
  ev: SeaEvent;
  from: { lat: number; lon: number };
  onClose: () => void;
  onSail: () => void;
}) {
  const nearest = PORTS.filter(portVisible).map((p) => ({ p, d: distanceBetween(ev, p) })).sort((a, b) => a.d - b.d)[0]!;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        onClick={(e) => e.stopPropagation()}
        className="panel w-full max-w-md space-y-3 bg-card p-5 text-card-foreground"
      >
        <header className="flex items-start gap-3 border-b border-border pb-2">
          <MarkBadge kind={ev.kind} size={34} />
          <div className="flex-1">
            <h2 className="font-serif text-xl font-bold">{ev.title}</h2>
            <p className="text-xs uppercase tracking-wide text-muted-foreground">{MARK_NAME[ev.kind]}</p>
          </div>
          <button type="button" onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">
            Close ✕
          </button>
        </header>

        <p className="text-sm leading-relaxed text-muted-foreground">{ev.text}</p>
        <dl className="grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
          <Cell label="Distance" value={`${distanceBetween(from, ev).toLocaleString("en-GB")} nm`} />
          <Cell label="Nearest port" value={`${nearest.p.name}, ${nearest.d.toLocaleString("en-GB")} nm`} />
        </dl>
        <p className="text-[11px] italic text-muted-foreground">
          Nothing is settled at this distance. Come up with her and the captain must give his word.
        </p>

        <footer className="grid gap-2 sm:grid-cols-2">
          <button type="button" onClick={onClose} className="rounded-sm border border-input px-3 py-2 text-sm">
            Leave it be
          </button>
          <button
            type="button"
            onClick={onSail}
            className="rounded-sm bg-primary px-3 py-2 text-sm font-medium text-primary-foreground"
          >
            Bear away for it
          </button>
        </footer>
      </div>
    </div>
  );
}
