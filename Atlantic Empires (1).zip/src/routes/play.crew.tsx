import { createFileRoute } from "@tanstack/react-router";

import { CrewPanel } from "@/components/game/CrewPanel";

export const Route = createFileRoute("/play/crew")({ component: CrewPanel });
