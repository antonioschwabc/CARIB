import { createFileRoute } from "@tanstack/react-router";

import { FleetPanel } from "@/components/game/FleetPanel";

export const Route = createFileRoute("/play/fleet")({ component: FleetPanel });
