import { createFileRoute } from "@tanstack/react-router";

import { YardPanel } from "@/components/game/YardPanel";

export const Route = createFileRoute("/play/yard")({ component: YardPanel });
