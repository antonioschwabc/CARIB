import { createFileRoute } from "@tanstack/react-router";

import { DiplomacyPanel } from "@/components/game/DiplomacyPanel";

export const Route = createFileRoute("/play/diplomacy")({ component: DiplomacyPanel });
