import { randomBannerName, randomVesselName } from "@/game/data/names";
import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";

import { BANNER_ICONS, BANNER_LAYOUTS, BANNER_PATTERNS, BannerFlag } from "@/components/game/BannerFlag";
import { CrewPortrait, frameTier } from "@/components/game/CrewPortrait";
import {
  FAITHS_BY_CULTURE,
  FAITH_NOTE,
  NATIONALITIES,
  SKILL_IDS,
  SKILL_LABEL,
  randomFirstName,
  randomSurname,
  traitSummary,
} from "@/game/data/crew";
import { TRAITS } from "@/game/data/traits";
import { SHIP_CLASSES, SHIP_CLASS_MAP } from "@/game/data/ships";
import type { BannerIcon, BannerLayout, BannerPattern, SkillId, Skills } from "@/game/types";
import { AUTOSAVE, saveGame } from "@/game/save";
import { DEFAULT_SETUP, SKILL_CEIL, SKILL_FLOOR, baseStats, newGame, skillPool, startingDebt } from "@/game/state";
import { money } from "@/game/sim/util";

export const Route = createFileRoute("/new")({
  head: () => ({
    meta: [
      { title: "CARIB — Make Your Captain and Fit Out Her Hull" },
      {
        name: "description",
        content:
          "Name your captain, choose his birthplace, faith, years and character, paint your own colours, then pick the hull you will spend years paying for.",
      },
      { property: "og:title", content: "CARIB — Make Your Captain" },
      { property: "og:description", content: "Name, birth, faith, traits, skills, colours and hull — all yours to choose." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: NewGame,
});

const STARTERS = ["sloop", "brigantine", "brig"];

const START_PORTS = [
  { id: "havana", name: "Havana", blurb: "Crown of Spain. Rich, tariffed, and watchful of foreigners." },
  { id: "recife", name: "Recife", blurb: "Crown of Portugal. Sugar coast, long crossings, few guns." },
  { id: "amsterdam", name: "Amsterdam", blurb: "Dutch Republic. Cheap credit, cheap freight, no questions asked." },
  { id: "london", name: "London", blurb: "Kingdom of England. Manufactures cheap, colonial goods dear." },
];

const PRESETS: { name: string; colors: [string, string, string] }[] = [
  { name: "House of the Main", colors: ["#1f3b57", "#c1502e", "#e8d8b0"] },
  { name: "Brethren", colors: ["#171717", "#7a1f1f", "#e6e2d3"] },
  { name: "Green Company", colors: ["#20402f", "#c9a227", "#f2ead6"] },
  { name: "Northern Trade", colors: ["#f0ece0", "#2b4a7d", "#b03a2e"] },
];

const FLAG_COLOURS = [
  "#171717", "#3a2412", "#7a1f1f", "#b03a2e", "#c1502e", "#c9a227", "#e8d8b0", "#f2ead6",
  "#f0ece0", "#1f3b57", "#2b4a7d", "#20402f", "#3f6b4c", "#4c2a52", "#8a6a2f", "#9c9a93",
];

const pick = <T,>(a: readonly T[]): T => a[Math.floor(Math.random() * a.length)]!;
const roll = (min: number, max: number) => min + Math.floor(Math.random() * (max - min + 1));

function randomSkills(age: number): Skills {
  const s = baseStats();
  let left = skillPool(age);
  const ids = [...SKILL_IDS].sort(() => Math.random() - 0.5);
  // Two disciplines he plainly favours, then the rest as it falls.
  const weights = ids.map((_, i) => (i < 2 ? 3 + Math.random() * 2 : 0.4 + Math.random()));
  const total = weights.reduce((a, b) => a + b, 0);
  ids.forEach((id, i) => {
    const want = Math.floor((weights[i]! / total) * left);
    const room = SKILL_CEIL - s[id];
    const give = Math.max(0, Math.min(want, room));
    s[id] += give;
  });
  left = skillPool(age) - (Object.values(s).reduce((a, b) => a + b, 0) - SKILL_FLOOR * 8);
  for (const id of ids) {
    if (left <= 0) break;
    const room = SKILL_CEIL - s[id];
    const give = Math.min(room, left);
    s[id] += give;
    left -= give;
  }
  return s;
}

function NewGame() {
  const navigate = useNavigate();
  const [dev, setDev] = useState(false);
  const [first, setFirst] = useState("Ambrose");
  const [last, setLast] = useState("Hale");
  const [shipName, setShipName] = useState(DEFAULT_SETUP.shipName);
  const [bannerName, setBannerName] = useState(DEFAULT_SETUP.bannerName);
  const [colors, setColors] = useState<[string, string, string]>(["#1f3b57", "#c1502e", "#e8d8b0"]);
  const [icon, setIcon] = useState<BannerIcon>("anchor");
  const [pattern, setPattern] = useState<BannerPattern>("band");
  const [layout, setLayout] = useState<BannerLayout>("centre");

  const [classId, setClassId] = useState("sloop");
  const [startPortId, setStartPortId] = useState("havana");
  const [nationality, setNationality] = useState<string>("English");
  const [age, setAge] = useState(28);
  const [faith, setFaith] = useState("Anglican");
  const [traits, setTraits] = useState<[string, string]>(["Steady", "Ambitious"]);
  const [stats, setStats] = useState<Skills>(() => randomSkills(28));
  const [portraitSeed, setPortraitSeed] = useState("hale-1");

  const purseCap = Math.round((SHIP_CLASS_MAP[classId]?.price ?? 0) * 0.1);
  const [purse, setPurse] = useState(0);
  const debt = startingDebt(classId) + Math.min(purse, purseCap);
  const captain = `${first} ${last}`.trim();
  const pool = skillPool(age);
  const spent = Object.values(stats).reduce((a, b) => a + b, 0) - SKILL_FLOOR * 8;
  const remaining = pool - spent;

  const faiths = useMemo(() => {
    const own = FAITHS_BY_CULTURE[nationality] ?? ["Catholic"];
    return Array.from(new Set([...own, ...Object.keys(FAITH_NOTE)]));
  }, [nationality]);

  function setSkill(id: SkillId, value: number) {
    const capped = Math.max(SKILL_FLOOR, Math.min(SKILL_CEIL, Math.round(value)));
    const others = spent - (stats[id] - SKILL_FLOOR);
    const allowed = Math.min(capped, SKILL_FLOOR + Math.max(0, pool - others));
    setStats({ ...stats, [id]: allowed });
  }

  function rollName(nat = nationality) {
    setFirst(randomFirstName(nat));
    setLast(randomSurname(nat));
  }
  function rollNationality() {
    const n = pick(NATIONALITIES);
    setNationality(n);
    rollName(n);
    setFaith(pick(FAITHS_BY_CULTURE[n] ?? ["Catholic"]));
  }
  function rollFlag() {
    const shuffled = [...FLAG_COLOURS].sort(() => Math.random() - 0.5);
    setColors([shuffled[0]!, shuffled[1]!, shuffled[2]!]);
    setPattern(pick(BANNER_PATTERNS).id);
    setLayout(pick(BANNER_LAYOUTS).id);
    setIcon(pick(BANNER_ICONS.filter((i) => i.id !== "none")).id);
  }

  function rollAge() {
    const a = roll(19, 55);
    setAge(a);
    setStats(randomSkills(a));
  }
  function rollFaith(nat = nationality) {
    setFaith(pick(FAITHS_BY_CULTURE[nat] ?? ["Catholic"]));
  }
  function rollTraits() {
    const a = pick(TRAITS).name;
    let b = pick(TRAITS).name;
    while (b === a) b = pick(TRAITS).name;
    setTraits([a, b]);
  }
  function rollBust() {
    setPortraitSeed(`bust-${Math.floor(Math.random() * 1e9).toString(36)}`);
  }
  function rollAll() {
    const n = pick(NATIONALITIES);
    const a = roll(19, 55);
    setNationality(n);
    rollName(n);
    rollFaith(n);
    setAge(a);
    setStats(randomSkills(a));
    rollTraits();
    rollFlag();
    rollBust();
    const sn = randomSurname(n);
    setShipName(randomVesselName(n));
    setBannerName(randomBannerName(n, sn));
  }

  function begin() {
    saveGame(
      AUTOSAVE,
      "Autosave",
      newGame({
        captain: captain || DEFAULT_SETUP.captain,
        shipName: shipName.trim() || DEFAULT_SETUP.shipName,
        bannerName: bannerName.trim() || DEFAULT_SETUP.bannerName,
        banner: { name: bannerName.trim() || DEFAULT_SETUP.bannerName, colors, icon, pattern, layout },
        classId,
        startPortId,
        nationality,
        age,
        faith,
        traits: [...traits],
        stats,
        startingCash: Math.min(purse, purseCap),
        portraitSeed,
        dev,
      }),
    );
    navigate({ to: "/play" });
  }

  return (
    <div className="min-h-screen bg-background px-4 py-10">
      <div className="mx-auto max-w-5xl space-y-6">
        <header className="text-center">
          <h1 className="font-serif text-4xl font-bold tracking-[0.25em] text-accent">CARIB</h1>
          <p className="mt-2 text-sm italic text-muted-foreground">
            January 1670. Sign the papers and the hull is yours — so is the note against it.
          </p>
          <button
            type="button"
            onClick={rollAll}
            className="mt-3 rounded-sm border border-accent px-4 py-1.5 text-xs uppercase tracking-wide text-accent"
          >
            Cast the dice for everything
          </button>
        </header>

        {/* ── the man ─────────────────────────────────────────── */}
        <section className="space-y-4">
          <LedgerCard title="The man himself">
            <div className="grid gap-5 sm:grid-cols-[auto_1fr]">
              <div className="w-40 space-y-2">
                <CrewPortrait
                  m={{ id: portraitSeed, seed: portraitSeed, name: captain, nationality, age, traits, skills: stats }}
                  className="h-52 w-40 shadow-lg"
                />
                <Roll label="Paint him again" onClick={rollBust} full />
                <p className="text-center text-[11px] italic text-[oklch(0.74_0.05_80)]">
                  Framed in {frameTier(stats)} — the frame follows his learning
                </p>
              </div>

              <div className="grid content-start gap-4 sm:grid-cols-2">
                <Field label="Given name" id="first" value={first} onChange={setFirst} onRoll={() => setFirst(randomFirstName(nationality))} />
                <Field label="Surname" id="last" value={last} onChange={setLast} onRoll={() => setLast(randomSurname(nationality))} />

                <Select
                  label="Where you were born"
                  value={nationality}
                  options={NATIONALITIES.map((n) => ({ value: n, label: n }))}
                  onChange={(v) => {
                    setNationality(v);
                    setFaith(pick(FAITHS_BY_CULTURE[v] ?? ["Catholic"]));
                  }}
                  onRoll={rollNationality}
                />

                <Select
                  label="What you swear by"
                  value={faith}
                  options={faiths.map((f) => ({ value: f, label: f }))}
                  onChange={setFaith}
                  onRoll={() => rollFaith()}
                  note={FAITH_NOTE[faith] ?? ""}
                />

                <p className="sm:col-span-2 border-t border-[oklch(0.45_0.05_60)]/40 pt-2 text-xs italic text-[oklch(0.74_0.05_80)]">
                  {captain || "A nameless man"} · {age} years · {nationality} · {faith}
                </p>
              </div>
            </div>
          </LedgerCard>

          <div className="panel grid gap-4 p-5">
            <div>
              <div className="mb-1.5 flex items-baseline justify-between">
                <span className="text-xs uppercase tracking-wide text-muted-foreground">
                  Your years — {age}. Older hands know more ({skillPool(age)} points); the young learn faster (
                  {Math.round(Math.max(0, (61 - age) * 2))}% quicker).
                </span>
                <Roll label="Roll years" onClick={rollAge} />
              </div>
              <input
                type="range"
                min={16}
                max={60}
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full accent-[var(--accent)]"
              />
            </div>

            <div>
              <div className="mb-1.5 flex items-baseline justify-between">
                <span className="text-xs uppercase tracking-wide text-muted-foreground">Your character — two traits</span>
                <Roll label="Roll traits" onClick={rollTraits} />
              </div>
              <div className="grid gap-2 sm:grid-cols-2">
                {[0, 1].map((i) => (
                  <div key={i}>
                    <select
                      aria-label={`Trait ${i + 1}`}
                      value={traits[i]}
                      onChange={(e) => {
                        const next = [...traits] as [string, string];
                        next[i] = e.target.value;
                        if (next[0] === next[1]) return;
                        setTraits(next);
                      }}
                      className="w-full rounded-sm border border-input bg-background px-3 py-2 text-sm"
                    >
                      {TRAITS.map((t) => (
                        <option key={t.name} value={t.name}>
                          {t.name}
                        </option>
                      ))}
                    </select>
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      {TRAITS.find((t) => t.name === traits[i])?.note} — {traitSummary(traits[i]!).join(", ") || "no effect"}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>


        {/* ── skills ──────────────────────────────────────────── */}
        <section className="panel space-y-3 p-5">
          <header className="flex flex-wrap items-baseline justify-between gap-2">
            <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
              Spend your years — what you learned before this morning
            </h2>
            <div className="flex items-center gap-3 text-xs">
              <span className="numeric">
                Pool {pool} · Spent {spent} ·{" "}
                <span className={remaining === 0 ? "text-muted-foreground" : remaining > 0 ? "text-accent" : "text-loss"}>
                  {remaining} left
                </span>
              </span>
              <Roll label="Roll skills" onClick={() => setStats(randomSkills(age))} />
              <Roll label="Clear" onClick={() => setStats(baseStats())} />
            </div>
          </header>
          <div className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
            {SKILL_IDS.map((id) => (
              <label key={id} className="block">
                <span className="flex justify-between text-xs">
                  <span className="text-muted-foreground">{SKILL_LABEL[id]}</span>
                  <span className="numeric">{stats[id]}</span>
                </span>
                <input
                  type="range"
                  aria-label={SKILL_LABEL[id]}
                  min={SKILL_FLOOR}
                  max={SKILL_CEIL}
                  value={stats[id]}
                  onChange={(e) => setSkill(id, Number(e.target.value))}
                  className="w-full accent-[var(--accent)]"
                />
              </label>
            ))}
          </div>
        </section>

        {/* ── colours ─────────────────────────────────────────── */}
        <section className="space-y-4">
          <LedgerCard title="Your colours and your names">
            <div className="grid gap-5 sm:grid-cols-[auto_1fr]">
              <div className="w-44 space-y-2">
                <BannerFlag
                  banner={{ name: bannerName, colors, icon, pattern, layout }}
                  className="h-40 w-44"
                  hoisted
                />
                <Roll label="Roll colours" onClick={() => rollFlag()} full />
              </div>
              <div className="grid content-start gap-4 sm:grid-cols-2">
                <Field label="Banner / trading house" id="banner" value={bannerName} onChange={setBannerName} onRoll={() => setBannerName(randomBannerName(nationality, last.trim() || randomSurname(nationality)))} />
                <Field label="Vessel name" id="ship" value={shipName} onChange={setShipName} onRoll={() => setShipName(randomVesselName(nationality))} />
                <div className="sm:col-span-2">
                  <span className="mb-1.5 block text-xs uppercase tracking-wide text-[oklch(0.74_0.05_80)]">Or take a known livery</span>
                  <div className="flex flex-wrap gap-2">
                    {PRESETS.map((p) => (
                      <button
                        key={p.name}
                        type="button"
                        onClick={() => setColors(p.colors)}
                        className="flex items-center gap-2 rounded-sm border border-[oklch(0.45_0.05_60)]/60 px-2 py-1 text-xs"
                      >
                        <BannerFlag banner={{ name: p.name, colors: p.colors, icon, pattern, layout }} className="h-4 w-6" />
                        {p.name}
                      </button>
                    ))}
                  </div>
                </div>
                <p className="sm:col-span-2 border-t border-[oklch(0.45_0.05_60)]/40 pt-2 text-xs italic text-[oklch(0.74_0.05_80)]">
                  {bannerName || "An unnamed house"} sails the {shipName || "unnamed"}.
                </p>
              </div>
            </div>
          </LedgerCard>

          <div className="panel space-y-4 p-5">
            <div>
              <span className="mb-1.5 block text-xs uppercase tracking-wide text-muted-foreground">Field, division and charge colours</span>
              <div className="flex flex-wrap items-center gap-3">
                {(["Field", "Division", "Charge"] as const).map((label, i) => (
                  <label key={label} className="flex items-center gap-2 text-xs">
                    <input
                      type="color"
                      aria-label={label}
                      value={colors[i]!}
                      onChange={(e) => {
                        const next = [...colors] as [string, string, string];
                        next[i] = e.target.value;
                        setColors(next);
                      }}
                      className="size-8 cursor-pointer rounded-sm border border-input bg-background"
                    />
                    {label}
                  </label>
                ))}
              </div>
            </div>
            <Chips
              label="How the field is divided"
              options={BANNER_PATTERNS}
              value={pattern}
              onChange={(v) => setPattern(v as BannerPattern)}
            />
            <Chips label="Charge" options={BANNER_ICONS} value={icon} onChange={(v) => setIcon(v as BannerIcon)} />
            <Chips
              label="Where the charge sits"
              options={BANNER_LAYOUTS}
              value={layout}
              onChange={(v) => setLayout(v as BannerLayout)}
            />
          </div>
        </section>


        <section className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">Choose your home port</h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {START_PORTS.map((p) => (
              <button
                key={p.id}
                type="button"
                onClick={() => setStartPortId(p.id)}
                className={`panel p-4 text-left transition-colors ${
                  startPortId === p.id ? "ring-2 ring-accent" : "hover:bg-secondary/40"
                }`}
              >
                <h3 className="font-semibold">{p.name}</h3>
                <p className="mt-1 text-xs text-muted-foreground">{p.blurb}</p>
              </button>
            ))}
          </div>
        </section>

        <section className="space-y-3">
          <h2 className="text-sm font-semibold uppercase tracking-wide text-muted-foreground">
            Choose your hull — it decides your debt
          </h2>
          <div className="grid gap-3 md:grid-cols-3">
            {SHIP_CLASSES.filter((c) => STARTERS.includes(c.id)).map((c) => {
              const active = c.id === classId;
              return (
                <button
                  key={c.id}
                  type="button"
                  onClick={() => setClassId(c.id)}
                  className={`panel space-y-2 p-4 text-left transition-colors ${
                    active ? "ring-2 ring-accent" : "hover:bg-secondary/40"
                  }`}
                >
                  <div className="flex items-baseline justify-between">
                    <h3 className="font-semibold">{c.name}</h3>
                    <span className="numeric text-xs text-loss">{money(startingDebt(c.id))} owed</span>
                  </div>
                  <p className="text-xs text-muted-foreground">{c.note}</p>
                  <dl className="grid grid-cols-2 gap-x-3 text-[11px]">
                    <Spec label="Hold" value={`${c.cargo} t`} />
                    <Spec label="Speed" value={`${c.speed} km/h`} />
                    <Spec label="Firepower" value={`${c.firepower}`} />
                    <Spec label="Rated crew" value={`${c.hands}`} />
                  </dl>
                </button>
              );
            })}
          </div>
        </section>

        <section className="panel space-y-2 p-5 text-sm">
          <h2 className="font-semibold">How you begin</h2>
          <div className="space-y-1 rounded-sm border border-border p-3">
            <div className="flex items-baseline justify-between">
              <span className="font-semibold">Coin drawn against the note</span>
              <span className="numeric">{money(Math.min(purse, purseCap))}</span>
            </div>
            <input
              type="range"
              min={0}
              max={purseCap}
              step={Math.max(1, Math.round(purseCap / 100))}
              value={Math.min(purse, purseCap)}
              onChange={(e) => setPurse(Number(e.target.value))}
              className="w-full accent-[oklch(0.62_0.16_42)]"
              aria-label="Starting coin"
            />
            <p className="text-xs text-muted-foreground">
              The chandler will advance up to a tenth of the hull's price in ready money — every piece of it added to
              what you owe.
            </p>
          </div>
          <ul className="space-y-1 text-muted-foreground">
            <li>· {money(Math.min(purse, purseCap))} in your pocket. No crew but yourself.</li>
            <li>
              · <span className="text-loss">{money(debt)}</span> owed on the hull, growing 5% every month until it is paid.
            </li>
            <li>· Take contracts at the port board for advances — that is your first capital.</li>
            <li>· Sign crew, buy low, sell high, and clear the note before it clears you.</li>
          </ul>

          {remaining > 0 && (
            <p className="text-xs text-accent">You still have {remaining} skill points unspent.</p>
          )}
          <label className="flex items-center gap-2 text-xs text-muted-foreground">
            <input type="checkbox" checked={dev} onChange={(e) => setDev(e.target.checked)} />
            Open this ledger with the shipwright&apos;s own tools (dev save)
          </label>
          <button
            type="button"
            onClick={begin}
            className="mt-2 w-full rounded-sm bg-primary px-4 py-2.5 font-semibold text-primary-foreground"
          >
            Sign the papers and begin
          </button>
        </section>
      </div>
    </div>
  );
}

function LedgerCard({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div
      className="rounded-sm border border-[oklch(0.45_0.05_60)]/60 p-5 shadow-[inset_0_1px_0_oklch(0.60_0.06_70/0.25),0_2px_10px_oklch(0.10_0.01_55/0.5)]"
      style={{
        background:
          "radial-gradient(120% 140% at 10% 0%, oklch(0.26 0.04 48), oklch(0.18 0.03 45) 70%)",
      }}
    >
      <h2 className="mb-3 text-[11px] font-semibold uppercase tracking-[0.18em] text-[oklch(0.78_0.08_82)]">{title}</h2>
      {children}
    </div>
  );
}

function Roll({ label, onClick, full = false }: { label: string; onClick: () => void; full?: boolean }) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-sm border border-input px-2 py-1 text-[11px] uppercase tracking-wide text-muted-foreground hover:border-accent hover:text-accent ${
        full ? "w-full" : ""
      }`}
    >
      {label}
    </button>
  );
}

function Chips({
  label,
  options,
  value,
  onChange,
}: {
  label: string;
  options: { id: string; label: string }[];
  value: string;
  onChange: (v: string) => void;
}) {
  return (
    <div>
      <span className="mb-1.5 block text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
      <div className="flex flex-wrap gap-2">
        {options.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => onChange(o.id)}
            className={`rounded-sm border px-2.5 py-1 text-xs ${
              value === o.id ? "border-accent text-accent" : "border-input text-muted-foreground"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>
    </div>
  );
}

function Select({
  label,
  value,
  options,
  onChange,
  onRoll,
  note,
}: {
  label: string;
  value: string;
  options: { value: string; label: string }[];
  onChange: (v: string) => void;
  onRoll: () => void;
  note?: string;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-2">
        <span className="text-xs uppercase tracking-wide text-muted-foreground">{label}</span>
        <Roll label="Roll" onClick={onRoll} />
      </div>
      <select
        aria-label={label}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-sm border border-input bg-background px-3 py-2 text-sm"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
      {note && <p className="mt-1 text-[11px] italic text-muted-foreground">{note}</p>}
    </div>
  );
}

function Field({
  label,
  id,
  value,
  onChange,
  onRoll,
}: {
  label: string;
  id: string;
  value: string;
  onChange: (v: string) => void;
  onRoll?: () => void;
}) {
  return (
    <div>
      <div className="mb-1.5 flex items-baseline justify-between gap-2">
        <label htmlFor={id} className="text-xs uppercase tracking-wide text-muted-foreground">
          {label}
        </label>
        {onRoll && <Roll label="Roll" onClick={onRoll} />}
      </div>
      <input
        id={id}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-sm border border-input bg-background px-3 py-2"
      />
    </div>
  );
}

function Spec({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-border/50 py-0.5">
      <dt className="text-muted-foreground">{label}</dt>
      <dd className="numeric">{value}</dd>
    </div>
  );
}
