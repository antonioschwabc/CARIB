import { createFileRoute } from "@tanstack/react-router";

import { ShipPanel } from "@/components/game/ShipPanel";
import type { ShipRegion } from "@/game/types";

const REGIONS = ["bow", "stern", "deck", "bridge", "mast", "hull", "ordnance", "warehouse"] as const;

export const Route = createFileRoute("/play/ship")({
  validateSearch: (search: Record<string, unknown>): { region?: ShipRegion } => {
    const r = search["region"];
    return typeof r === "string" && (REGIONS as readonly string[]).includes(r) ? { region: r as ShipRegion } : {};
  },
  component: ShipTab,
});

function ShipTab() {
  const { region } = Route.useSearch();
  return <ShipPanel {...(region ? { initialRegion: region } : {})} />;
}
