import { useEffect, useMemo, useRef, useState } from "react";
import { Link, Outlet, createFileRoute, useNavigate, useRouterState } from "@tanstack/react-router";

import barrelGold from "@/assets/barrel-gold.png";
import helmGold from "@/assets/helm-gold.png";
import parchmentTex from "@/assets/parchment.jpg";
import purseGold from "@/assets/purse-gold.png";
import ropeHang from "@/assets/rope-hang.png";
import shipIconGold from "@/assets/ship-icon-gold.png";
import tricornGold from "@/assets/tricorn-gold.png";
import { EncounterDialog } from "@/components/game/EncounterDialog";
import { OutcomeDialog } from "@/components/game/OutcomeDialog";
import { StoryDialog } from "@/components/game/StoryDialog";
import { CombatPanel } from "@/components/game/CombatPanel";
import { TravelGuide } from "@/components/game/TravelGuide";
import { activeShip } from "@/game/actions";
import { PORTS, PORT_MAP, portVisible } from "@/game/data/ports";
import { coordLabel, distanceBetween, inPort, portDestination, shipPos } from "@/game/sim/position";
import { overallCondition, regionCondition } from "@/game/sim/shipStats";
import { dailyAppetite, medicineAboard, salvageAboard, suppliesAboard } from "@/game/sim/stores";
import { fleetFinance } from "@/game/sim/finance";
import { gameDate, money } from "@/game/sim/util";
import { effectiveSpeed } from "@/game/sim/voyage";
import { GameProvider, useGame } from "@/game/store";
import type { Destination } from "@/game/types";

export const Route = createFileRoute("/play")({
  head: () => ({
    meta: [
      { title: "CARIB — Play: Caribbean Merchant Simulation" },
      {
        name: "description",
        content:
          "Command your fleet: trade 34 commodities across 34 Atlantic ports, plot voyages, refit ships, borrow, invest and bargain with the great powers.",
      },
      { property: "og:title", content: "CARIB — Play: Caribbean Merchant Simulation" },
      {
        property: "og:description",
        content: "Trade, sail and scheme across the 17th-century Atlantic in a living economic sandbox.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: PlayRoute,
});

function PlayRoute() {
  return (
    <GameProvider>
      <PlayLayout />
    </GameProvider>
  );
}

const TABS = [
  { to: "/play", label: "Chart", exact: true },
  { to: "/play/port", label: "Port" },
  { to: "/play/crew", label: "Crew" },
  { to: "/play/ship", label: "Ship" },
  { to: "/play/fleet", label: "Fleet" },
  { to: "/play/diplomacy", label: "Diplomacy" },
  { to: "/play/finance", label: "Finance" },
  { to: "/play/journal", label: "Journal" },
  { to: "/play/dev", label: "Dev", dev: true },
] as const;

/** Ledger themes: the stripe's leather, the ribbon drape and the wordmark ink. */
type Theme = {
  id: string;
  name: string;
  /** top, middle, bottom of the leather stripe */
  stripe: [string, string, string];
  /** edge and centre of the ribbon drape */
  ribbon: [string, string];
  /** wordmark ink */
  ink: string;
  /** tab bar backing */
  bar: string;
  /** thin vertical divider right of the title */
  lining: string;
};

const THEMES: Theme[] = [
  {
    id: "claret",
    name: "Deep claret",
    stripe: ["#3d0e10", "#320a0a", "#290808"],
    ribbon: ["#4a0d0d", "#631212"],
    ink: "#c5b358",
    bar: "#160d0d",
    lining: "#c5b358",
  },
  {
    id: "hardwood",
    name: "Oiled hardwood",
    stripe: ["#4a3018", "#3a2411", "#2a190b"],
    ribbon: ["#5a3a1c", "#7a5124"],
    ink: "#d8b877",
    bar: "#1a1109",
    lining: "#b8975b",
  },
  {
    id: "indigo",
    name: "Indigo dye",
    stripe: ["#1b2340", "#141a31", "#0e1225"],
    ribbon: ["#25305a", "#33417a"],
    ink: "#c8cfe6",
    bar: "#0b0e1a",
    lining: "#8f9bbd",
  },
  {
    id: "verdigris",
    name: "Verdigris brass",
    stripe: ["#183029", "#122620", "#0c1a16"],
    ribbon: ["#1f4438", "#2c6350"],
    ink: "#cbb46a",
    bar: "#0a1512",
    lining: "#a89552",
  },
  {
    id: "tar",
    name: "Tarred canvas",
    stripe: ["#2a2724", "#201e1b", "#161513"],
    ribbon: ["#3a352f", "#4d463d"],
    ink: "#cfc4ab",
    bar: "#121110",
    lining: "#8c7f68",
  },
  {
    id: "parchment",
    name: "Old parchment",
    stripe: ["#d9c8a2", "#cdb98f", "#bda77a"],
    ribbon: ["#8a5a2c", "#a8763c"],
    ink: "#42301a",
    bar: "#2b2013",
    lining: "#6b4a2a",
  },
  {
    id: "sable",
    name: "Sable & bone",
    stripe: ["#1a1a1a", "#121212", "#0a0a0a"],
    ribbon: ["#2a2a2a", "#3b3b3b"],
    ink: "#e5dcc7",
    bar: "#0a0a0a",
    lining: "#9e9482",
  },
  {
    id: "royal",
    name: "Royal purple",
    stripe: ["#2e1732", "#241228", "#190c1c"],
    ribbon: ["#3d1e44", "#552a5e"],
    ink: "#d5b96f",
    bar: "#150a17",
    lining: "#c5a55a",
  },
];

const THEME_KEY = "carib.ledgerTheme";
const LINING_KEY = "carib.ledgerLinings.v3";
const UNLOCK_KEY = "carib.ledgerUnlocked";
const POS_KEY = "carib.ledgerPositions.v2";
const ICON_KEY = "carib.ledgerIcons.v3";
const CONT_KEY = "carib.ledgerContinue.v1";
/** Where the Continue button and its calendar sit — free to move anywhere in the ledger. */
const DEFAULT_CONT = { x: 62, y: 44 };
const DEFAULT_LININGS: number[] = [165, 291, 386, 493, 600, 712];

type Positions = { anchor: number; drape: number; title: number; height: number };
const DEFAULT_POS: Positions = { anchor: 14, drape: 36, title: 66, height: 100 };


/** Fixed band the title and icons live in — the ledger grows below it, never moving them. */
const BAND = 40;
/** Minimum ledger height — the fixed line where the boards' iron footing bar sits.
 *  Set a few pixels taller than the icon band so the iron bar sits slightly below the icons,
 *  giving them breathing room while still marking the ledger's compact limit. */
const MIN_H = 46;
/** Maximum ledger height — enough room for a full helm parchment to unroll inside the ledger. */
const MAX_H = 170;

const ICON_ART = [
  { id: "helm", src: helmGold, alt: "Helm" },
  { id: "ship", src: shipIconGold, alt: "Ship" },
  { id: "tricorn", src: tricornGold, alt: "Captain's tricorn" },
  { id: "barrel", src: barrelGold, alt: "Barrel" },
  { id: "purse", src: purseGold, alt: "Coin purse" },
] as const;
type IconId = (typeof ICON_ART)[number]["id"];
const DEFAULT_ICONS: Record<IconId, number> = { helm: 206, ship: 314, tricorn: 414, barrel: 530, purse: 645 };

/** Every part of her the surveyor looks over, and what he calls it. */
const SHIP_PARTS: { id: string; label: string }[] = [
  { id: "bow", label: "Bow" },
  { id: "stern", label: "Stern" },
  { id: "deck", label: "Deck" },
  { id: "bridge", label: "Bridge" },
  { id: "mast", label: "Mast" },
  { id: "hull", label: "Hull" },
  { id: "ordnance", label: "Ordnance" },
  { id: "warehouse", label: "Warehouse" },
];

function PlayLayout() {
  const path = useRouterState({ select: (s) => s.location.pathname });
  const [themeId, setThemeId] = useState(THEMES[0]!.id);
  const [open, setOpen] = useState(false);
  const [linings, setLinings] = useState<number[]>(DEFAULT_LININGS);
  const [icons, setIcons] = useState<Record<string, number>>(DEFAULT_ICONS);
  const [pos, setPos] = useState<Positions>(DEFAULT_POS);
  const [cont, setCont] = useState<{ x: number; y: number }>(DEFAULT_CONT);
  /** Width of the wordmark, measured so the Continue plate spans drape to title exactly. */
  const titleRef = useRef<HTMLAnchorElement>(null);
  const [titleW, setTitleW] = useState(78);
  useEffect(() => {
    const el = titleRef.current;
    if (!el) return;
    const measure = () => setTitleW(Math.round(el.getBoundingClientRect().width));
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(el);
    return () => ro.disconnect();
  }, []);

  const [dragging, setDragging] = useState<number | null>(null);
  const [dragIcon, setDragIcon] = useState<string | null>(null);
  const [growing, setGrowing] = useState(false);
  const [unlocked, setUnlocked] = useState(false);
  const [helmOpen, setHelmOpen] = useState(false);
  /** A single hand-written note that follows the cursor, in front of everything. */
  const [tip, setTip] = useState<{ x: number; y: number; text: string } | undefined>();
  const [helmDest, setHelmDest] = useState<Destination | undefined>();
  const { state, dispatch } = useGame();
  const navigate = useNavigate();
  const ship = activeShip(state);
  const movedRef = useRef(false);
  const clickTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const theme = THEMES.find((t) => t.id === themeId) ?? THEMES[0]!;
  /** Stripe height — minimum sits just below the icons (46px), maximum 170px; resizable both ways while unlocked. */
  const stripeH = Math.max(MIN_H, Math.min(MAX_H, pos.height || DEFAULT_POS.height));
  /** Any board/lining/icon/edge drag in progress — makes the ropes swing. */
  const adjusting = dragging !== null || dragIcon !== null || growing;

  useEffect(() => {
    const saved = localStorage.getItem(THEME_KEY);
    if (saved) setThemeId(saved);
    const rawL = localStorage.getItem(LINING_KEY);
    if (rawL) {
      try {
        const parsed = JSON.parse(rawL) as number[];
        if (Array.isArray(parsed) && parsed.length >= 2 && parsed.every((n) => typeof n === "number")) {
          setLinings(parsed);
        }
      } catch {
        /* keep defaults */
      }
    }
    const rawI = localStorage.getItem(ICON_KEY);
    if (rawI) {
      try {
        const parsed = JSON.parse(rawI) as Record<string, number>;
        if (parsed && typeof parsed === "object") setIcons({ ...DEFAULT_ICONS, ...parsed });
      } catch {
        /* keep defaults */
      }
    }
    const rawP = localStorage.getItem(POS_KEY);
    if (rawP) {
      try {
        const parsed = JSON.parse(rawP) as Partial<Positions>;
          setPos({
            anchor: typeof parsed.anchor === "number" ? parsed.anchor : DEFAULT_POS.anchor,
            drape: typeof parsed.drape === "number" ? parsed.drape : DEFAULT_POS.drape,
            title: typeof parsed.title === "number" ? parsed.title : DEFAULT_POS.title,
            height: typeof parsed.height === "number" ? Math.max(MIN_H, Math.min(MAX_H, parsed.height)) : DEFAULT_POS.height,
          });
      } catch {
        /* keep defaults */
      }
    }
    const rawC = localStorage.getItem(CONT_KEY);
    if (rawC) {
      try {
        const parsed = JSON.parse(rawC) as { x?: number; y?: number };
        if (parsed && typeof parsed.x === "number" && typeof parsed.y === "number") setCont({ x: parsed.x, y: parsed.y });
      } catch {
        /* keep defaults */
      }
    }
    const rawU = localStorage.getItem(UNLOCK_KEY);
    if (rawU) setUnlocked(rawU === "true");
  }, []);

  /** Generic left/right drag for any ledger element. */
  const startMove = (key: keyof Positions, e: React.PointerEvent) => {
    if (!unlocked) return;
    e.preventDefault();
    e.stopPropagation();
    const stripe = (e.currentTarget as HTMLElement).closest("[data-stripe]") as HTMLElement | null;
    if (!stripe) return;
    const rect = stripe.getBoundingClientRect();
    const startX = e.clientX;
    const startVal = pos[key];
    movedRef.current = false;
    const move = (ev: PointerEvent) => {
      if (Math.abs(ev.clientX - startX) > 3) movedRef.current = true;
      const next = Math.max(0, Math.min(rect.width - 24, Math.round(startVal + (ev.clientX - startX))));
      setPos((prev) => ({ ...prev, [key]: next }));
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setPos((prev) => {
        localStorage.setItem(POS_KEY, JSON.stringify(prev));
        return prev;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  /** Free drag, left-right and up-down, for the Continue plate — kept inside the ledger. */
  const startContDrag = (e: React.PointerEvent) => {
    if (!unlocked) return;
    e.preventDefault();
    e.stopPropagation();
    const stripe = (e.currentTarget as HTMLElement).closest("[data-stripe]") as HTMLElement | null;
    if (!stripe) return;
    const rect = stripe.getBoundingClientRect();
    const box = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const startX = e.clientX;
    const startY = e.clientY;
    const start = { ...cont };
    movedRef.current = false;
    const move = (ev: PointerEvent) => {
      if (Math.hypot(ev.clientX - startX, ev.clientY - startY) > 3) movedRef.current = true;
      setCont({
        x: start.x,
        y: Math.max(0, Math.min(Math.max(0, rect.height - box.height), Math.round(start.y + (ev.clientY - startY)))),
      });
    };

    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setCont((prev) => {
        localStorage.setItem(CONT_KEY, JSON.stringify(prev));
        return prev;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  /** Left/right drag for an icon — on release it snaps to the centre of the board it lands on. */
  const startIconDrag = (id: string, e: React.PointerEvent) => {
    if (id !== "helm" && !unlocked) return;
    e.preventDefault();
    e.stopPropagation();
    const stripe = (e.currentTarget as HTMLElement).closest("[data-stripe]") as HTMLElement | null;
    if (!stripe) return;
    const rect = stripe.getBoundingClientRect();
    const startX = e.clientX;
    const startVal = icons[id] ?? 0;
    movedRef.current = false;
    setDragIcon(id);
    const move = (ev: PointerEvent) => {
      if (Math.abs(ev.clientX - startX) > 3) movedRef.current = true;
      const next = Math.max(0, Math.min(rect.width - 32, Math.round(startVal + (ev.clientX - startX))));
      setIcons((prev) => ({ ...prev, [id]: next }));
    };
    const up = () => {
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setDragIcon(null);
      setIcons((prev) => {
        const next = { ...prev };
        const x = next[id] ?? 0;
        const cx = x + 16;
        for (let i = 0; i < linings.length - 1; i++) {
          const left = linings[i]! + 8;
          const right = linings[i + 1]! - 8;
          if (cx >= left && cx <= right) {
            next[id] = Math.round((left + right) / 2 - 16);
            break;
          }
        }
        localStorage.setItem(ICON_KEY, JSON.stringify(next));
        return next;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  /** Drag the stripe's lower edge up or down to size the ledger (MIN_H–MAX_H). */
  const startGrow = (e: React.PointerEvent) => {
    if (!unlocked) return;
    e.preventDefault();
    e.stopPropagation();
    const startY = e.clientY;
    const startH = stripeH;
    setGrowing(true);
    const move = (ev: PointerEvent) => {
      const next = Math.max(MIN_H, Math.min(MAX_H, Math.round(startH + (ev.clientY - startY))));
      setPos((prev) => ({ ...prev, height: next }));
    };
    const up = () => {
      setGrowing(false);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setPos((prev) => {
        localStorage.setItem(POS_KEY, JSON.stringify(prev));
        return prev;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const startDrag = (index: number, e: React.PointerEvent) => {
    if (!unlocked) return;
    e.preventDefault();
    const stripe = (e.currentTarget as HTMLElement).closest("[data-stripe]") as HTMLElement | null;
    if (!stripe) return;
    setDragging(index);
    const rect = stripe.getBoundingClientRect();
    /** Icons currently glued to each board — a board may not shrink below what its icons need. */
    const countIn = (b: number) => Object.values(icons).filter((ix) => iconBoard(ix) === b).length;
    const needW = (b: number) => {
      const n = countIn(b);
      return n > 0 ? n * 36 - 4 + 16 : 0;
    };
    const move = (ev: PointerEvent) => {
      const raw = Math.round(ev.clientX - rect.left);
      setLinings((prev) => {
        const min = index === 0 ? 12 : prev[index - 1]! + 24;
        const max = index === prev.length - 1 ? rect.width - 12 : prev[index + 1]! - 24;
        let x = Math.max(min, Math.min(max, raw));
        const leftEdge = index === 0 ? 0 : prev[index - 1]!;
        const rightEdge = index === prev.length - 1 ? rect.width : prev[index + 1]!;
        if (index > 0) x = Math.max(x, leftEdge + 16 + needW(index - 1));
        if (index < prev.length - 1) x = Math.min(x, rightEdge - 16 - needW(index));
        const next = [...prev];
        next[index] = x;
        return next;
      });
    };
    const up = () => {
      setDragging(null);
      window.removeEventListener("pointermove", move);
      window.removeEventListener("pointerup", up);
      setLinings((prev) => {
        localStorage.setItem(LINING_KEY, JSON.stringify(prev));
        return prev;
      });
    };
    window.addEventListener("pointermove", move);
    window.addEventListener("pointerup", up);
  };

  const pick = (id: string) => {
    setThemeId(id);
    localStorage.setItem(THEME_KEY, id);
    setOpen(false);
  };

  /** Double-clicking the drape puts every plank, lining and icon back where it began. */
  const resetLayout = () => {
    setLinings(DEFAULT_LININGS);
    setIcons(DEFAULT_ICONS);
    setPos(DEFAULT_POS);
    setCont(DEFAULT_CONT);
    setOpen(false);
    localStorage.setItem(CONT_KEY, JSON.stringify(DEFAULT_CONT));
    localStorage.setItem(LINING_KEY, JSON.stringify(DEFAULT_LININGS));
    localStorage.setItem(ICON_KEY, JSON.stringify(DEFAULT_ICONS));
    localStorage.setItem(POS_KEY, JSON.stringify(DEFAULT_POS));
  };

  const toggleAnchor = () => {

    setUnlocked((u) => {
      const next = !u;
      localStorage.setItem(UNLOCK_KEY, String(next));
      return next;
    });
  };

  /** Double-clicking the anchor adds a fresh lining to the right of the last one. */
  const addLining = () => {
    setLinings((prev) => {
      const next = [...prev, Math.round((prev[prev.length - 1] ?? 120) + 100)];
      localStorage.setItem(LINING_KEY, JSON.stringify(next));
      return next;
    });
  };

  /** A board fills every gap between two consecutive linings. */
  const boards = linings.slice(0, -1).map((left, i) => ({
    left: left + 8,
    width: Math.max(0, linings[i + 1]! - left - 16),
  }));

  /** Which board an icon's centre rests on (-1 = off any board). */
  const iconBoard = (x: number): number => {
    const cx = x + 16;
    for (let i = 0; i < boards.length; i++) {
      const b = boards[i]!;
      if (cx >= b.left && cx <= b.left + b.width) return i;
    }
    return -1;
  };

  /** Icons glued per board, ordered left-to-right by their stored position. */
  const iconsByBoard = new Map<number, string[]>();
  for (const ic of ICON_ART) {
    const x = icons[ic.id] ?? DEFAULT_ICONS[ic.id];
    const b = iconBoard(x);
    if (b < 0) continue;
    const arr = iconsByBoard.get(b) ?? [];
    arr.push(ic.id);
    arr.sort((a, z) => (icons[a] ?? DEFAULT_ICONS[a as IconId] ?? 0) - (icons[z] ?? DEFAULT_ICONS[z as IconId] ?? 0));
    iconsByBoard.set(b, arr);
  }

  /** Glued icons render centred on their board; a group centres as a row. */
  const iconLeft = (id: IconId): number => {
    const x = icons[id] ?? DEFAULT_ICONS[id];
    if (dragIcon === id) return x;
    const b = iconBoard(x);
    if (b < 0) return x;
    const group = iconsByBoard.get(b) ?? [id];
    const board = boards[b]!;
    const total = group.length * 32 + (group.length - 1) * 4;
    return Math.round(board.left + (board.width - total) / 2 + group.indexOf(id) * 36);
  };

  // ---- Helm bay readout: plaque + course lines under the iron bar ----
  const helmBoard = iconBoard(icons["helm"] ?? DEFAULT_ICONS.helm);
  const helmBd = helmBoard >= 0 ? boards[helmBoard]! : undefined;
  const here = ship ? shipPos(ship) : { lat: 0, lon: 0 };
  const knots = ship ? effectiveSpeed(ship) : 5;
  const helmPorts = useMemo(
    () =>
      PORTS.filter((p) => portVisible(p) && !(ship && inPort(ship) && p.id === ship.portId))
        .map((p) => {
          const d = distanceBetween(here, p);
          return { p, d, days: Math.max(1, Math.ceil(d / (Math.max(0.5, knots) * 24))) };
        })
        .sort((a, b) => a.days - b.days || a.d - b.d),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [here.lat, here.lon, knots, ship?.portId, ship?.voyage, ship?.station],
  );

  /** Where she stands: under way, docked, or hove to on a sea tile. */
  /** Where she stands: just the mark's name, and an ETA when there is one. */
  const helmStatus = (() => {
    if (!ship) return undefined;
    if (ship.voyage) return { line1: `Bound for ${ship.voyage.label}`, line2: `ETA: ${ship.voyage.daysLeft} days` };
    if (ship.course) return { line1: `Course laid for ${ship.course.label}`, line2: "sails at dawn" };
    if (inPort(ship)) {
      const p = PORT_MAP[ship.portId];
      return { line1: `Docked at ${p?.name ?? ship.portId}` };
    }
    return { line1: `Sailing at ${coordLabel(here.lat, here.lon)}` };
  })();
  /** Helm motion: still in harbour, swaying on the waves when hove to, spinning under way. */
  const helmMotion = !ship || inPort(ship) ? "" : ship.voyage ? "helm-spin" : "rudder-sway";

  // ---- The surveyor's word on her timbers ----
  const roster = ship ? state.crew.filter((m) => m.shipId === ship.id) : [];
  const condition = ship ? Math.round(overallCondition(ship)) : 0;
  const ailing = ship
    ? SHIP_PARTS.map((p) => ({ ...p, pct: Math.round(regionCondition(ship, p.id)) })).filter((p) => p.pct < 51)
    : [];
  const shipTip =
    ailing.length === 0
      ? "All is well."
      : ailing.length > 2
        ? "Multiple ship parts are in need of repair"
        : ailing.map((p) => `${p.label} in need of repair — ${p.pct}%`).join(" · ");

  // ---- The people: health, temper, and who is struggling ----
  const avg = (pick: (m: (typeof roster)[number]) => number) =>
    roster.length ? Math.round(roster.reduce((s, m) => s + pick(m), 0) / roster.length) : 0;
  const health = avg((m) => m.health);
  const morale = avg((m) => m.morale);
  const struggling = roster.filter((m) => m.morale < 50 || m.health < 50);
  const crewTip =
    struggling.length === 0
      ? "All is well."
      : struggling.length > 2
        ? "Multiple crew members are struggling"
        : struggling.map((m) => `${m.name} is struggling`).join(" · ");

  // ---- The hold: what is aboard, and what the day eats ----
  const supply = ship ? suppliesAboard(ship) : 0;
  const medicine = ship ? medicineAboard(ship) : 0;
  const salvage = ship ? salvageAboard(ship) : 0;
  const supplyUse = ship ? dailyAppetite(state, ship) : 0;
  const medicineUse = Math.min(roster.filter((m) => m.health < 100).length * 0.4, 3);
  const salvageUse = ship ? Math.min(1.2, Math.max(0, 200 - ship.hull - ship.sails) / 25) : 0;
  const n1 = (v: number) => (Math.round(v * 10) / 10).toString();

  // ---- The purse: coin in hand, wages owing, and the notes against her ----
  const fin = fleetFinance(state);
  const purseTip =
    fin.totalDebt > 0
      ? `Debt owing: ${money(fin.totalDebt)} — interest of ${money(fin.weeklyDebtInterest + fin.weeklyLoanInterest)} a week`
      : "No debt owing — the purse is your own";

  /** What each icon does, says on hover, and writes on the parchment beneath it. */
  const BAYS: Record<IconId, { tip: string; onClick: () => void; lines?: { text: string; tip?: string; onClick?: () => void }[] }> = {
    helm: {
      tip: "Set course",
      onClick: () => {
        setHelmOpen((o) => !o);
        setTip(undefined);
      },
      lines: helmStatus
        ? [
            {
              text: helmStatus.line1,
              tip: "Centre the chart on the ship",
              onClick: () => {
                navigate({ to: "/play" });
                setTimeout(() => window.dispatchEvent(new Event("carib:center-ship")), 40);
              },
            },
            ...(helmStatus.line2 ? [{ text: helmStatus.line2 }] : []),
          ]
        : [],
    },
    ship: {
      tip: ship?.name ?? "No ship",
      onClick: () => void navigate({ to: "/play/ship" }),
      lines: [{ text: `Condition: ${condition}%`, tip: shipTip }],
    },
    tricorn: {
      tip: crewTip,
      onClick: () => void navigate({ to: "/play/crew" }),
      lines: [{ text: `Health: ${health}%` }, { text: `Morale: ${morale}%` }],
    },
    barrel: {
      tip: "Warehouse",
      onClick: () => void navigate({ to: "/play/ship", search: { region: "warehouse" } }),
      lines: [
        { text: `Supply: ${n1(supply)} (${n1(supplyUse)}/day)` },
        { text: `Medicine: ${n1(medicine)} (${n1(medicineUse)}/day)` },
        { text: `Salvage: ${n1(salvage)} (${n1(salvageUse)}/day)` },
      ],
    },
    purse: {
      tip: "Finance",
      onClick: () => void navigate({ to: "/play/finance" }),
      lines: [
        { text: `Coin: ${money(state.cash)}`, tip: purseTip },
        { text: `Wages: ${money(fin.weeklyWages)}/week` },
      ],
    },
  };


  return (
    <div className="flex h-screen flex-col bg-background text-foreground">
      <header className="z-20 shrink-0 overflow-visible shadow-md">
        {/* Leather stripe — grows downward only; the title and icon band stay put */}
        <div
          data-stripe
          className="relative shadow-inner"
          style={{
            height: stripeH,
            background: `linear-gradient(180deg, ${theme.stripe[0]} 0%, ${theme.stripe[1]} 45%, ${theme.stripe[2]} 100%)`,
          }}
        >
          {/* Lower-edge grip — drag down to expand the ledger while unlocked */}
          {unlocked && (
            <span
              role="separator"
              aria-label="Expand the ledger downward"
              title="Drag down to expand the ledger"
              onPointerDown={startGrow}
              className="absolute inset-x-0 bottom-0 z-40 h-2 cursor-ns-resize"
              style={{
                background: `linear-gradient(180deg, transparent 0%, ${theme.lining}44 100%)`,
              }}
            />
          )}
          {/* Anchor — click toggles the lock, double click adds a lining */}
          <button
            type="button"
            title={unlocked ? "Lock the ledger layout (double click to add a lining)" : "Unlock the ledger layout"}
            aria-label={unlocked ? "Lock the ledger layout" : "Unlock the ledger layout"}
            aria-pressed={unlocked}
            onPointerDown={(e) => startMove("anchor", e)}
            onDoubleClick={() => {
              if (clickTimer.current) clearTimeout(clickTimer.current);
              clickTimer.current = null;
              if (unlocked) addLining();
            }}
            onClick={() => {
              if (movedRef.current) return;
              if (clickTimer.current) clearTimeout(clickTimer.current);
              clickTimer.current = setTimeout(() => {
                clickTimer.current = null;
                toggleAnchor();
              }, 220);
            }}
            className={`absolute top-0 z-30 flex h-7 w-[18px] items-center justify-center border-x border-black/20 shadow-sm transition-all duration-300 ${
              unlocked ? "-translate-y-[14px] cursor-ew-resize" : "translate-y-0"
            }`}
            style={{
              left: pos.anchor,
              background: `linear-gradient(90deg, ${theme.ribbon[0]} 0%, ${theme.ribbon[1]} 50%, ${theme.ribbon[0]} 100%)`,
            }}
          >
            <svg
              viewBox="0 0 24 24"
              fill="none"
              stroke={theme.ink}
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="pointer-events-none h-4 w-4 opacity-90"
            >
              <circle cx="12" cy="5" r="3" />
              <line x1="12" y1="22" x2="12" y2="8" />
              <path d="M5 12H2a10 10 0 0 0 20 0h-3" />
            </svg>
          </button>

          {/* Ribbon drape — the theme switch */}
          <button
            type="button"
            title="Change the ledger theme — double click to restore the default ledger"
            aria-label="Change the ledger theme"
            aria-expanded={open}
            onPointerDown={(e) => startMove("drape", e)}
            onClick={() => {
              if (movedRef.current) return;
              setOpen((o) => !o);
            }}
            onDoubleClick={(e) => {
              e.preventDefault();
              resetLayout();
            }}

            className={`absolute top-0 z-20 h-7 w-[18px] border-x border-black/20 shadow-sm transition-[filter] hover:brightness-125 ${
              unlocked ? "cursor-ew-resize" : ""
            }`}
            style={{
              left: pos.drape,
              background: `linear-gradient(90deg, ${theme.ribbon[0]} 0%, ${theme.ribbon[1]} 50%, ${theme.ribbon[0]} 100%)`,
            }}
          />

          {open && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setOpen(false)} />
              <div
                className="absolute z-40 w-52 overflow-hidden rounded-sm border shadow-xl"
                style={{ top: stripeH, left: pos.drape, borderColor: "#00000066", background: theme.bar }}
              >
                {THEMES.map((t) => (
                  <button
                    key={t.id}
                    type="button"
                    onClick={() => pick(t.id)}
                    className="flex w-full items-center gap-2 px-2 py-1.5 text-left font-serif text-[11px] tracking-widest uppercase hover:bg-white/10"
                    style={{ color: t.id === theme.id ? t.ink : "#cbbfa8" }}
                  >
                    <span
                      className="inline-block h-3.5 w-6 rounded-[1px] border border-black/40"
                      style={{ background: `linear-gradient(180deg, ${t.stripe[0]}, ${t.stripe[2]})` }}
                    />
                    {t.name}
                  </button>
                ))}
              </div>
            </>
          )}

          {/* Darkwood boards — one between every pair of linings, lashed with hemp rope */}
          {boards.map((b, i) => (
            <span
              key={i}
              role={unlocked ? "button" : undefined}
              title={
                unlocked
                  ? (iconsByBoard.get(i)?.length ?? 0) > 0
                    ? "Board holds icons — move them away before removing it"
                    : "Right click to remove this board"
                  : undefined
              }
              onContextMenu={(e) => {
                if (!unlocked) return;
                e.preventDefault();
                if ((iconsByBoard.get(i)?.length ?? 0) > 0) return;
                setLinings((prev) => {
                  if (prev.length <= 2) return prev;
                  const next = [...prev];
                  next.splice(i + 1, 1);
                  localStorage.setItem(LINING_KEY, JSON.stringify(next));
                  return next;
                });
              }}
              className={`absolute top-0 z-0 h-full ${unlocked ? "cursor-context-menu" : "pointer-events-none"}`}
              style={{ left: b.left, width: b.width }}
              aria-hidden="true"
            >
              <span
                className="absolute inset-0 overflow-hidden"
                style={{
                  background:
                    "repeating-linear-gradient(0deg, rgba(0,0,0,0.30) 0 1px, transparent 1px 11px), linear-gradient(180deg, #3a2513 0%, #24160b 45%, #150c06 100%)",
                  boxShadow: "inset 0 1px 0 rgba(255,255,255,0.09), inset 0 -2px 5px rgba(0,0,0,0.65)",
                }}
              />
              {/* Iron footing bar — fixed at the minimum ledger line, never moves with expansion */}
              <span
                className="absolute right-0 left-0 z-[1] h-[5px]"
                style={{
                  top: MIN_H - 5,
                  background:
                    "linear-gradient(180deg, #6e6e74 0%, #3a3a40 30%, #17171b 55%, #45454c 80%, #0c0c0f 100%)",
                  boxShadow:
                    "inset 0 1px 0 rgba(255,255,255,0.28), inset 0 -1px 0 rgba(0,0,0,0.8), 0 1px 2px rgba(0,0,0,0.6)",
                }}
              >
                {/* Small black nail heads spaced across the bar */}
                {Array.from({ length: 3 }).map((_, nailIdx) => (
                  <span
                    key={nailIdx}
                    className="absolute top-1/2 h-[2px] w-[5px] -translate-x-1/2 -translate-y-1/2 rounded-[1px]"
                    style={{
                      left: `${20 + nailIdx * 30}%`,
                      background: "linear-gradient(180deg, #2a2a2a 0%, #0a0a0a 100%)",
                      boxShadow: "inset 0 1px 0 rgba(255,255,255,0.12), 0 1px 1px rgba(0,0,0,0.6)",
                    }}
                  />
                ))}
              </span>
              {/* Thick hemp ropes hugging both sides, hanging from the top border with the knot dragging past the bottom */}
              {["-left-3", "-right-3"].map((side) => (
                <img
                  key={side}
                  src={ropeHang}
                  alt=""
                  width={576}
                  height={1152}
                  draggable={false}
                  loading="lazy"
                  className={`pointer-events-none absolute top-0 ${side} z-[1] w-6 select-none ${
                    adjusting ? "ledger-rope-swing" : ""
                  }`}
                  style={{
                    height: BAND + 16,
                    objectFit: "fill",
                    filter: "drop-shadow(0 1px 1px rgba(0,0,0,0.55)) brightness(0.85)",
                  }}
                />
              ))}
            </span>
          ))}

          <Link
            ref={titleRef}
            to="/"

            onPointerDown={(e) => startMove("title", e)}
            onClick={(e) => {
              if (movedRef.current) e.preventDefault();
            }}
            className={`absolute z-10 flex items-center font-serif text-xl leading-none font-bold tracking-[0.15em] select-none ${
              unlocked ? "cursor-ew-resize" : ""
            }`}
            style={{ left: pos.title, top: 0, height: BAND, color: theme.ink }}
          >
            CARIB
          </Link>

          {/* Continue plate — darkwood like the boards, its calendar on the same parchment as the icon slips */}
          <div
            onPointerDown={startContDrag}
            className={`absolute z-30 flex flex-col items-stretch select-none ${unlocked ? "cursor-ns-resize" : ""}`}
            style={{ left: pos.drape, width: Math.max(84, pos.title + titleW - pos.drape), top: cont.y }}
          >
            <button
              type="button"
              onClick={() => {
                if (movedRef.current || unlocked) return;
                dispatch({ type: "advance", days: 1 });
              }}
              title="Sail on one day"
              className="w-full px-2 py-[4px] font-serif text-[11px] font-bold tracking-[0.16em] uppercase transition-transform active:translate-y-[1px]"
              style={{
                color: "#e8d9b6",
                border: "1px solid rgba(0,0,0,0.55)",
                borderRadius: "3px 3px 0 0",
                background:
                  "repeating-linear-gradient(0deg, rgba(0,0,0,0.30) 0 1px, transparent 1px 11px), linear-gradient(180deg, #3a2513 0%, #24160b 45%, #150c06 100%)",
                boxShadow: "inset 0 1px 0 rgba(255,255,255,0.09), inset 0 -2px 5px rgba(0,0,0,0.65)",
                textShadow: "0 1px 1px rgba(0,0,0,0.8)",
              }}
            >
              Continue
            </button>
            <span
              className="w-full overflow-hidden px-1 py-[2px] text-center font-serif text-[10px] leading-tight text-[#3b2a16]"
              style={{
                backgroundImage: `url(${parchmentTex})`,
                backgroundSize: "cover",
                backgroundPosition: "center",
                border: "1px solid rgba(120,90,50,0.55)",
                borderTop: "none",
                borderRadius: "0 0 8px 8px / 0 0 12px 12px",
                boxShadow: "inset 0 3px 4px rgba(0,0,0,0.18), 0 4px 10px rgba(0,0,0,0.35)",
              }}
            >
              {(() => {
                const d = gameDate(state.day);
                return `${d.day} ${d.month} ${d.year}`;
              })()}
            </span>
          </div>




          {/* Modular linings — drag left/right to size the boards between them */}
          {linings.map((x, i) => (
            <span
              key={i}
              role="separator"
              aria-label={unlocked ? `Move lining ${i + 1}` : `Lining ${i + 1}`}
              onPointerDown={(e) => startDrag(i, e)}
              className={`group absolute top-0 z-20 flex h-full w-4 items-center justify-center transition-opacity ${
                unlocked ? "cursor-ew-resize" : "cursor-default opacity-60"
              }`}
              style={{ left: x - 8 }}
            >
              <span
                className={`w-[1.5px] rounded-full opacity-80 ${unlocked ? "group-hover:opacity-100" : ""}`}
                style={{
                  height: Math.round(stripeH * 0.55),
                  background: `linear-gradient(180deg, transparent 0%, ${theme.lining} 25%, ${theme.lining} 75%, transparent 100%)`,
                  boxShadow: dragging === i ? `0 0 6px ${theme.lining}` : undefined,
                }}
              />
            </span>
          ))}

          {/* Painted icons — glued to a board's centre; drag them onto any board while unlocked */}
          {ICON_ART.map((ic) => {
            const isHelm = ic.id === "helm";
            const bay = BAYS[ic.id];
            return (
              <span
                key={ic.id}
                onPointerDown={(e) => startIconDrag(ic.id, e)}
                onClick={() => {
                  if (movedRef.current) return;
                  if (unlocked) return;
                  bay.onClick();
                }}
                onPointerMove={(e) => {
                  if (!unlocked && !(isHelm && helmOpen)) setTip({ x: e.clientX, y: e.clientY, text: bay.tip });
                }}
                onPointerLeave={() => setTip(undefined)}
                className={`group absolute top-0 z-10 flex items-center justify-center ${
                  unlocked ? "cursor-ew-resize" : "cursor-pointer"
                } ${dragIcon === ic.id ? "" : "transition-[left] duration-200"}`}
                style={{ left: iconLeft(ic.id), height: BAND, width: 32 }}
              >
                <img
                  src={ic.src}
                  alt={ic.alt}
                  width={32}
                  height={32}
                  draggable={false}
                  loading="lazy"
                  className={`h-8 w-8 object-contain opacity-95 drop-shadow-sm select-none ${isHelm ? helmMotion : ""}`}
                />
              </span>
            );
          })}

          {/* Parchments — one under each icon, hanging from the iron bar of the board it is glued to */}
          {stripeH > MIN_H + 14 &&
            ICON_ART.map((ic) => {
              const lines = BAYS[ic.id].lines ?? [];
              if (!lines.length) return null;
              const b = iconBoard(icons[ic.id] ?? DEFAULT_ICONS[ic.id]);
              if (b < 0) return null;
              const board = boards[b]!;
              const group = iconsByBoard.get(b) ?? [ic.id];
              const share = group.length;
              const idx = Math.max(0, group.indexOf(ic.id));
              const w = Math.max(24, (board.width - 16) / share - (share > 1 ? 4 : 0));
              return (
                <div
                  key={`p-${ic.id}`}
                  className="absolute z-20 overflow-hidden text-center"
                  style={{
                    left: board.left + 8 + idx * (w + (share > 1 ? 4 : 0)),
                    width: w,
                    top: MIN_H + 1,
                    maxHeight: stripeH - MIN_H - 8,
                    backgroundImage: `url(${parchmentTex})`,
                    backgroundSize: "cover",
                    backgroundPosition: "center",
                    border: "1px solid rgba(120,90,50,0.55)",
                    borderTop: "none",
                    borderRadius: "0 0 8px 8px / 0 0 12px 12px",
                    boxShadow: "inset 0 3px 4px rgba(0,0,0,0.18), 0 4px 10px rgba(0,0,0,0.35)",
                    padding: "3px 4px 4px",
                  }}
                >
                  {lines.map((ln, li) => (
                    <div
                      key={li}
                      onClick={ln.onClick}
                      onPointerMove={(e) => {
                        if (ln.tip) setTip({ x: e.clientX, y: e.clientY, text: ln.tip });
                      }}
                      onPointerLeave={() => {
                        if (ln.tip) setTip(undefined);
                      }}
                      className={`break-words font-serif leading-tight ${
                        li === 0 ? "text-[10px] font-bold" : "text-[9px]"
                      } ${ln.onClick ? "cursor-pointer hover:underline" : ""}`}
                      style={{ color: li === 0 ? "#241708" : "#3d2a14" }}
                    >
                      {ln.text}
                    </div>
                  ))}
                </div>
              );
            })}

          {/* A note in the captain's hand, riding the cursor above everything */}
          {tip && (
            <span
              className="pointer-events-none fixed z-[9999] max-w-[260px] rounded-[2px] border border-[#3a2a1a]/60 bg-[#2a1f15] px-1.5 py-0.5 font-serif text-[9px] font-bold tracking-widest text-[#d8cba8] uppercase shadow-lg"
              style={{ left: tip.x + 12, top: tip.y + 12 }}
            >
              {tip.text}
            </span>
          )}

          {/* Port list parchment — drops from the iron bar when the helm is clicked; shows 3, scrolls for more */}
          {helmOpen && helmBd && (
            <>
              <div className="fixed inset-0 z-30" onClick={() => setHelmOpen(false)} />
              <div
                className="no-scrollbar absolute z-40 overflow-y-auto"
                style={{
                  left: helmBd.left,
                  width: helmBd.width,
                  top: MIN_H + 1,
                  height: 68,
                  backgroundImage: `url(${parchmentTex})`,
                  backgroundSize: "cover",
                  backgroundPosition: "center",
                  border: "1px solid rgba(120,90,50,0.55)",
                  borderRadius: "2px 2px 10px 10px / 2px 2px 14px 14px",
                  boxShadow:
                    "inset 0 3px 4px rgba(0,0,0,0.18), inset 0 -1px 0 rgba(255,255,255,0.25), 0 6px 16px rgba(0,0,0,0.4)",
                  padding: "4px 4px 4px 6px",
                }}
              >
                {helmPorts.map(({ p, days }) => (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      const dest = portDestination(p.id);
                      setHelmDest(dest);
                      setHelmOpen(false);
                    }}
                    className="flex w-full items-baseline justify-between gap-2 rounded-[1px] px-1.5 py-[3px] text-left font-serif text-[10px] hover:bg-[#8b6f4a]/25"
                    style={{ color: "#241708" }}
                  >
                    <span className="truncate font-semibold">{p.name}</span>
                    <span className="numeric shrink-0 text-[9px] opacity-70">{days}d</span>
                  </button>
                ))}
              </div>
            </>
          )}

        </div>



        <nav
          className="flex gap-1 overflow-x-auto border-b-2 border-[oklch(0.28_0.04_50)] px-2"
          style={{ background: theme.bar }}
        >
          {TABS.filter((t) => !("dev" in t) || state.dev).map((t) => {
            const ashore = ["/play/market", "/play/tavern", "/play/yard", "/play/quests"];
            const active =
              t.to === "/play"
                ? path === "/play" || path === "/play/"
                : t.to === "/play/port"
                  ? path.startsWith("/play/port") || ashore.some((a) => path.startsWith(a))
                  : path.startsWith(t.to);
            return (
              <Link
                key={t.to}
                to={t.to}
                className={`border-b-2 px-3 py-2 text-sm ${
                  active ? "border-accent font-semibold text-accent" : "border-transparent text-muted-foreground"
                }`}
              >
                {t.label}
              </Link>
            );
          })}
        </nav>
      </header>

      <main className="relative min-h-0 flex-1 overflow-auto">
        <Outlet />
      </main>
      {helmDest && <TravelGuide dest={helmDest} onClose={() => setHelmDest(undefined)} />}
      <EncounterDialog />
      <StoryDialog />
      <OutcomeDialog />
      <CombatPanel />
    </div>
  );
}
