import { COMMODITY_MAP } from "../data/commodities";
import { SHIP_CLASS_MAP } from "../data/ships";
import type { Encounter, GameState } from "../types";
import { pushLog } from "./events";
import { clamp, rng } from "./util";
import { effectiveGuns, effectiveSpeed } from "./voyage";
import { shareGold, shareXp } from "./progress";
import { SALVAGE_IDS } from "./stores";

export type EncounterChoice =
  | "flee"
  | "fight"
  | "parley"
  | "surrender"
  | "ignore"
  | "investigate";

export const CHOICE_LABEL: Record<EncounterChoice, string> = {
  flee: "Crowd sail and run",
  fight: "Beat to quarters",
  parley: "Offer a bribe to be let pass",
  surrender: "Strike the colours",
  ignore: "Hold your course and pass by",
  investigate: "Heave to and look her over",
};

/** What the captain may reasonably do about this particular sail or mark. */
export function choicesFor(enc: Encounter): EncounterChoice[] {
  switch (enc.kind) {
    case "wreck":
    case "flotsam":
      return ["investigate", "ignore"];
    case "rumour":
      return ["investigate", "ignore"];
    case "squall":
      return ["flee", "ignore"];
    case "merchant":
      return ["investigate", "fight", "ignore"];
    case "patrol":
      return ["investigate", "parley", "flee", "fight"];
    default:
      return ["flee", "fight", "parley", "surrender"];
  }
}

const SALVAGE_PICK = SALVAGE_IDS;

export function resolveEncounter(state: GameState, enc: Encounter, choice: EncounterChoice) {
  const ship = state.ships.find((s) => s.id === enc.shipId);
  if (!ship) {
    delete state.encounter;
    return;
  }
  const cls = SHIP_CLASS_MAP[ship.classId]!;
  const rand = rng(state.seed + state.day * 104729 + choice.length);

  const power = effectiveGuns(ship) * 1.6 * (0.5 + ship.morale / 200) * (0.6 + ship.crew / Math.max(cls.hands, 1) * 0.4);
  const foe = enc.strength * 30;

  const settleEvent = () => {
    const mark = (state.seaEvents ?? []).find((e) => e.id === enc.eventId);
    if (mark) mark.done = true;
  };

  const loseCargo = (fraction: number) => {
    let value = 0;
    for (const [cid, qty] of Object.entries(ship.cargo)) {
      const take = qty * fraction;
      value += take * COMMODITY_MAP[cid]!.base;
      ship.cargo[cid] = qty - take;
      if (ship.cargo[cid]! < 0.5) delete ship.cargo[cid];
    }
    return Math.round(value);
  };

  // Marks that are not a fight: wreckage, drifting stores, gossip, weather.
  if (choice === "ignore") {
    settleEvent();
    pushLog(state, "voyage", `${ship.name} keeps her course and leaves it astern.`);
    delete state.encounter;
    return;
  }

  if (enc.kind === "wreck" || enc.kind === "flotsam") {
    settleEvent();
    if (ship.voyage) ship.voyage.daysLeft += 1;
    const luck = rand();
    const haul = 1 + Math.round(luck * (enc.kind === "wreck" ? 8 : 3));
    for (let i = 0; i < haul; i++) {
      const cid = SALVAGE_PICK[Math.floor(rand() * SALVAGE_PICK.length)]!;
      ship.cargo[cid] = (ship.cargo[cid] ?? 0) + 1;
    }
    const coin = enc.kind === "wreck" ? Math.round(luck * 900) : 0;
    if (coin > 0) shareGold(state, coin);
    shareXp(state, "scouting", 90);
    if (enc.kind === "wreck" && rand() < 0.18) {
      const hurt = 4 + rand() * 10;
      ship.hull = clamp(ship.hull - hurt, 0, 100);
      pushLog(state, "peril", `The boat is stove in against the wreck: ${Math.round(hurt)} points of damage for ${haul} units of salvage.`);
    } else {
      pushLog(state, "voyage", `${ship.name} works over the wreckage and takes off ${haul} units of stores${coin ? ` and ${coin} gold in coin` : ""}.`);
    }
    delete state.encounter;
    return;
  }

  if (enc.kind === "rumour") {
    settleEvent();
    shareXp(state, "charisma", 70);
    shareXp(state, "scouting", 70);
    state.reputation = clamp(state.reputation + 0.5, -100, 100);
    pushLog(state, "world", `Word taken aboard off the bearing: ${enc.text}`);
    delete state.encounter;
    return;
  }

  if (enc.kind === "squall") {
    settleEvent();
    if (choice === "flee") {
      if (ship.voyage) ship.voyage.daysLeft += 1;
      shareXp(state, "navigation", 80);
      pushLog(state, "voyage", `${ship.name} bears away and works round the squall line. A day lost, and nothing carried away.`);
    } else {
      const dmg = 3 + rand() * 14;
      ship.hull = clamp(ship.hull - dmg * 0.6, 0, 100);
      ship.sails = clamp(ship.sails - dmg, 0, 100);
      shareXp(state, "navigation", 140);
      pushLog(state, "peril", `${ship.name} drives straight through it: ${Math.round(dmg)} points off her canvas, but not an hour lost.`);
    }
    delete state.encounter;
    return;
  }

  if (enc.kind === "merchant" && choice === "investigate") {
    settleEvent();
    const gain = Math.round(120 + rand() * 700);
    shareGold(state, gain);
    shareXp(state, "charisma", 90);
    pushLog(state, "trade", `${ship.name} speaks the trader, swaps news and sells a little of nothing for ${gain} gold.`);
    delete state.encounter;
    return;
  }

  if (enc.kind === "patrol" && choice === "investigate") {
    settleEvent();
    state.reputation = clamp(state.reputation + 0.5, -100, 100);
    pushLog(state, "world", `${ship.name} shows her papers. The boarding officer finds nothing to fault and lets her pass.`);
    delete state.encounter;
    return;
  }

  settleEvent();

  if (choice === "flee") {
    const chance = clamp(0.25 + (effectiveSpeed(ship) - 7) * 0.16 - enc.strength * 0.15, 0.05, 0.92);
    if (rand() < chance) {
      ship.sails = clamp(ship.sails - 6, 0, 100);
      if (ship.voyage) ship.voyage.daysLeft += 1;
      shareXp(state, "navigation", 60);
      pushLog(state, "peril", `${ship.name} shakes out every rag and runs clear. A day lost and the sails the worse for it.`);
    } else {
      const dmg = 8 + rand() * 16;
      ship.hull = clamp(ship.hull - dmg, 0, 100);
      const taken = loseCargo(0.5);
      pushLog(state, "peril", `${ship.name} is run down. She loses ${dmg.toFixed(0)} points of hull and cargo worth roughly ${Math.round(taken)} gold.`);
    }
  } else if (choice === "fight") {
    const odds = clamp(power / (power + foe), 0.05, 0.95);
    if (rand() < odds) {
      const plunder = Math.round(400 + enc.strength * 4200 * (0.5 + rand()));
      shareGold(state, plunder);
      shareXp(state, "gunnery", 220 * enc.strength);
      shareXp(state, "all", 60);
      // Wreckage worth taking: timber, cordage, iron off the beaten hull.
      for (let i = 0; i < 3; i++) {
        const id = SALVAGE_IDS[Math.floor(rand() * SALVAGE_IDS.length)]!;
        ship.cargo[id] = (ship.cargo[id] ?? 0) + Math.round(1 + rand() * 6 * enc.strength);
      }
      ship.crew = Math.max(1, ship.crew - Math.round(1 + rand() * 4));
      ship.hull = clamp(ship.hull - (4 + rand() * 10), 0, 100);
      state.notoriety = clamp(state.notoriety + 3, 0, 100);
      state.reputation = clamp(state.reputation + 2, -100, 100);
      pushLog(state, "peril", `${ship.name} beats off her attacker and takes ${Math.round(plunder)} gold in plunder and salvage.`);
    } else {
      const dmg = 14 + rand() * 26;
      ship.hull = clamp(ship.hull - dmg, 0, 100);
      ship.crew = Math.max(1, ship.crew - Math.round(2 + rand() * 6));
      const taken = loseCargo(0.75);
      shareXp(state, "all", 40);
      for (const m of state.crew.filter((c) => c.shipId === ship.id)) {
        m.health = clamp(m.health - (6 + rand() * 18), 0, 100);
        m.morale = clamp(m.morale - 8, 0, m.health);
      }
      pushLog(state, "peril", `${ship.name} is beaten and boarded. Cargo worth some ${Math.round(taken)} gold is carried off and good men are dead.`);
    }
  } else if (choice === "parley") {
    const bribe = Math.round(600 + enc.strength * 2600);
    if (state.cash >= bribe && rand() < 0.72) {
      state.cash -= bribe;
      pushLog(state, "peril", `A purse of ${Math.round(bribe)} gold changes hands and ${ship.name} is waved on her way.`);
    } else {
      const taken = loseCargo(0.6);
      pushLog(state, "peril", `The parley fails. They take cargo worth about ${Math.round(taken)} gold instead.`);
    }
  } else {
    const taken = loseCargo(1);
    state.reputation = clamp(state.reputation - 4, -100, 100);
    pushLog(state, "peril", `${ship.name} strikes. The whole lading — some ${Math.round(taken)} gold — is taken, but not a man is lost.`);
  }

  if (ship.hull <= 0) {
    state.ships = state.ships.filter((s) => s.id !== ship.id);
    if (state.ships[0]) state.activeShipId = state.ships[0].id;
    pushLog(state, "peril", `${ship.name} goes down.`);
  }

  delete state.encounter;
}
