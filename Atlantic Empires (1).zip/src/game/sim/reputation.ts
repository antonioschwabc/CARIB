import { PORT_MAP } from "../data/ports";
import type { GameState, PowerId } from "../types";
import { pushLog } from "./events";
import { clamp, uid } from "./util";

/**
 * Standing. Every promise kept or broken is written down here, and the whole
 * Atlantic reads the same book: chandlers, consuls, factors and idle hands.
 */

export interface RepTier {
  id: string;
  /** lowest reputation that earns the name */
  min: number;
  name: string;
  note: string;
}

export const REP_TIERS: RepTier[] = [
  { id: "outcast", min: -100, name: "Outcast", note: "No honest house will take your paper." },
  { id: "faithless", min: -40, name: "Faithless", note: "Your word is worth nothing on the quay." },
  { id: "doubtful", min: -15, name: "Doubtful", note: "Factors want their money up front." },
  { id: "unknown", min: -4, name: "Unknown", note: "Nobody has heard of you either way." },
  { id: "sound", min: 12, name: "Sound", note: "Shippers will trust you with a parcel." },
  { id: "respected", min: 32, name: "Respected", note: "Consuls answer your letters." },
  { id: "eminent", min: 55, name: "Eminent", note: "Your name alone opens a counting house." },
  { id: "illustrious", min: 78, name: "Illustrious", note: "You are spoken of in London and Seville alike." },
];

export function repTier(rep: number): RepTier {
  let out = REP_TIERS[0]!;
  for (const t of REP_TIERS) if (rep >= t.min) out = t;
  return out;
}

/** What standing is actually worth, in coin and in men. */
export function repEffects(state: GameState) {
  const r = state.reputation;
  return {
    /** multiplier on quest rewards offered to you */
    contractPay: 1 + clamp(r, -60, 80) / 200,
    /** multiplier on the interest lenders ask */
    creditRate: 1 - clamp(r, -50, 60) / 250,
    /** multiplier on signing fees the tavern demands */
    signingFee: 1 - clamp(r, -40, 60) / 300,
    /** multiplier on how many hands drink at your table */
    recruitPool: 1 + clamp(r, -40, 60) / 150,
  };
}

/** Standing lost when a contract is thrown up or run out of time. */
export function contractPenalty(standing: number, ranOut: boolean) {
  return -(2 + standing * (ranOut ? 1.1 : 0.8));
}

/**
 * Move the needle and write the reason in the ledger. A crown whose port the
 * business touched takes note of it too, at half weight.
 */
export function adjustReputation(
  state: GameState,
  delta: number,
  reason: string,
  power?: PowerId,
) {
  if (!delta) return;
  state.reputation = clamp(state.reputation + delta, -100, 100);
  const ledger = (state.repLedger ??= []);
  ledger.unshift({ id: uid("rep", state.day + ledger.length), day: state.day, delta, reason });
  state.repLedger = ledger.slice(0, 60);
  if (power) {
    state.relations[power] = clamp(state.relations[power] + delta / 2, -100, 100);
  }
}

/** The crown that would hear of business done at a port. */
export function powerOfPort(portId: string | undefined) {
  return portId ? PORT_MAP[portId]?.power : undefined;
}

export function logStanding(state: GameState, text: string) {
  pushLog(state, "world", text);
}
