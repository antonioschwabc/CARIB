import { COMMODITIES, COMMODITY_MAP } from "../data/commodities";
import type { GameState, Port } from "../types";
import { priceOf } from "./economy";
import { rng } from "./util";

/**
 * The tap-room trade. No custom house, no paper, no bulk: a landlord buys
 * cheap, sells dear, and what he has on hand changes with the week. Now and
 * then something turns up that has no business being in a tavern at all.
 */

/** Things a tavern would sensibly have out the back. */
const HOUSE_GOODS = [
  "saltbeef",
  "saltfish",
  "flour",
  "water",
  "rum",
  "wine",
  "brandy",
  "beer",
  "tobacco",
  "medicine",
  "cloth",
  "linen",
  "tools",
  "coffee",
  "cocoa",
  "sugar",
  "spices",
].filter((id) => COMMODITY_MAP[id]);

/** Everything else — the odd chest that fell off a cart. */
const ODD_GOODS = COMMODITIES.filter((c) => !HOUSE_GOODS.includes(c.id)).map((c) => c.id);

export interface BarterOffer {
  cid: string;
  name: string;
  qty: number;
  /** gold a unit, landlord's asking price */
  unit: number;
  rare: boolean;
}

export const tavernWeek = (day: number) => Math.floor(day / 7);

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

/** What the landlord has to sell this week. Same week, same shelf. */
export function tavernOffers(state: GameState, port: Port): BarterOffer[] {
  const rand = rng(hash(`${port.id}:${tavernWeek(state.day)}`));
  const count = 4 + Math.floor(rand() * 4);
  const seen = new Set<string>();
  const offers: BarterOffer[] = [];

  for (let i = 0; i < count * 3 && offers.length < count; i++) {
    const rare = rand() < 0.16;
    const pool = rare ? ODD_GOODS : HOUSE_GOODS;
    const cid = pool[Math.floor(rand() * pool.length)];
    if (!cid || seen.has(cid)) continue;
    seen.add(cid);
    const c = COMMODITY_MAP[cid];
    if (!c) continue;
    const p = priceOf(state, port.id, cid, port);
    const markup = rare ? 1.45 + rand() * 0.4 : 1.12 + rand() * 0.25;
    const stocked = Math.max(2, Math.round((rare ? 3 : 14) * (0.5 + rand())));
    const taken = state.tavernTaken?.[`${port.id}:${cid}`] ?? 0;
    offers.push({
      cid,
      name: c.name,
      qty: Math.max(0, stocked - taken),
      unit: Math.round(p.unit * markup * 100) / 100,
      rare,
    });
  }
  return offers;
}

/** What the landlord will pay for what is in your hold — always too little. */
export function tavernBid(state: GameState, port: Port, cid: string) {
  return Math.round(priceOf(state, port.id, cid, port).sell * 0.78 * 100) / 100;
}

/** What a whispered word costs at this port, and how far it carries. */
export function rumourPrice(port: Port) {
  return Math.round(120 + port.population / 320 + port.prosperity * 260);
}

export const RUMOUR_RANGE_NM = 420;
