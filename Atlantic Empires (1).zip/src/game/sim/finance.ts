import { HAND_WEEKLY_WAGE } from "../data/crew";
import { PORT_MAP } from "../data/ports";
import { BUSINESS_MAP, SHIP_CLASS_MAP } from "../data/ships";
import type { GameState } from "../types";

export interface ShipFinance {
  id: string;
  name: string;
  className: string;
  /** named officers plus common hands */
  hands: number;
  officers: number;
  /** gold paid out every seventh day */
  weeklyWages: number;
  /** gold bled every day for her keep */
  dailyUpkeep: number;
}

export interface VentureFinance {
  id: string;
  name: string;
  portName: string;
  level: number;
  dailyIncome: number;
  dailyUpkeep: number;
}

export interface FleetFinance {
  ships: ShipFinance[];
  ventures: VentureFinance[];
  weeklyWages: number;
  dailyUpkeep: number;
  venturesDailyNet: number;
  /** what the hull note swells by in a week */
  weeklyDebtInterest: number;
  /** what the money-lenders' notes swell by in a week */
  weeklyLoanInterest: number;
  totalDebt: number;
  /** gold in and out over a seven-day week, and their difference */
  weeklyIncome: number;
  weeklyOutgoings: number;
  weeklyNet: number;
  /** days of cash left at this rate, when the week runs at a loss */
  runwayDays?: number;
}

/** The counting-house view of the whole concern: who is paid, what is earned, what is owed. */
export function fleetFinance(state: GameState): FleetFinance {
  const ships: ShipFinance[] = state.ships.map((s) => {
    const cls = SHIP_CLASS_MAP[s.classId];
    const named = state.crew.filter((m) => m.shipId === s.id);
    const hands = Math.max(0, s.crew - named.length);
    return {
      id: s.id,
      name: s.name,
      className: cls?.name ?? "Vessel",
      hands,
      officers: named.length,
      weeklyWages: Math.round(hands * HAND_WEEKLY_WAGE + named.reduce((sum, m) => sum + m.wage, 0)),
      dailyUpkeep: Math.round((cls?.upkeep ?? 0) * 0.35),
    };
  });

  const ventures: VentureFinance[] = state.businesses.map((b) => {
    const type = BUSINESS_MAP[b.typeId];
    const port = PORT_MAP[b.portId];
    const income =
      type && port ? type.yield * b.level * (0.55 + port.prosperity) * (0.6 + port.security * 0.5) : 0;
    return {
      id: b.id,
      name: type?.name ?? "Venture",
      portName: port?.name ?? "—",
      level: b.level,
      dailyIncome: Math.round(income),
      dailyUpkeep: Math.round((type?.upkeep ?? 0) * b.level),
    };
  });

  const weeklyWages = ships.reduce((s, x) => s + x.weeklyWages, 0);
  const dailyUpkeep = ships.reduce((s, x) => s + x.dailyUpkeep, 0);
  const venturesDailyNet = ventures.reduce((s, v) => s + v.dailyIncome - v.dailyUpkeep, 0);
  const weeklyDebtInterest = Math.round(state.debt * state.debtRate);
  const weeklyLoanInterest = Math.round(state.loans.reduce((s, l) => s + l.principal * l.rate, 0));
  const totalDebt = Math.round(state.debt + state.loans.reduce((s, l) => s + l.principal, 0));

  const venturesWeekly = venturesDailyNet * 7;
  const weeklyIncome = Math.max(0, venturesWeekly);
  const weeklyOutgoings = weeklyWages + dailyUpkeep * 7 + Math.max(0, -venturesWeekly);
  const weeklyNet = weeklyIncome - weeklyOutgoings;

  const out: FleetFinance = {
    ships,
    ventures,
    weeklyWages,
    dailyUpkeep,
    venturesDailyNet,
    weeklyDebtInterest,
    weeklyLoanInterest,
    totalDebt,
    weeklyIncome,
    weeklyOutgoings,
    weeklyNet,
  };
  if (weeklyNet < 0) out.runwayDays = Math.max(0, Math.floor(state.cash / (-weeklyNet / 7)));
  return out;
}

/** Cash as it would stand each week ahead if nothing changed but the standing bills. */
export function cashProjection(state: GameState, fin: FleetFinance, weeks = 12): number[] {
  const out: number[] = [];
  let cash = state.cash;
  let debt = state.debt;
  for (let w = 0; w < weeks; w++) {
    debt += debt * state.debtRate;
    cash += fin.weeklyNet;
    out.push(Math.round(cash));
  }
  return out;
}
