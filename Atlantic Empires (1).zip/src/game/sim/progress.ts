import { POSITION_SKILL, SKILL_IDS } from "../data/crew";
import { effSkill } from "../data/crew";
import { traitMult } from "../data/traits";
import type { CrewMember, GameState, Ship, SkillId, Skills } from "../types";
import { clamp } from "./util";
import { postOf } from "./shipStats";

export const XP_PER_LEVEL = 100;
/** No hand, and no captain, is ever better than a hundred at anything. */
export const MAX_SKILL = 100;
export const BASE_DAILY_XP = 5;
export const POST_DAILY_XP = 5;
export const RETIREMENT_AGE = 61;

/** Youth learns fastest: a lad of sixteen gains 90% more than a man of sixty. */
export function youthMultiplier(age: number) {
  return 1 + Math.max(0, (RETIREMENT_AGE - age) * 2) / 100;
}

/** The first mate drills the watches; his charisma lifts everyone's learning. */
export function mateBonus(state: GameState, ship: Ship | undefined) {
  if (!ship) return 1;
  const id = ship.assignments?.firstMate;
  const mate = id ? state.crew.find((m) => m.id === id) : undefined;
  if (!mate) return 1;
  const quarterLevel = (ship.quarters ?? []).includes("firstMate") ? 1 : 0;
  return 1 + (effSkill(mate, "charisma") / 400) * (1 + quarterLevel * 0.5);
}

function levelUp(skills: Skills, xp: Skills, key: SkillId, ceiling: number) {
  while (xp[key] >= XP_PER_LEVEL && skills[key] < ceiling) {
    xp[key] -= XP_PER_LEVEL;
    skills[key] = Math.min(ceiling, skills[key] + 1);
  }
  if (skills[key] >= ceiling) xp[key] = Math.min(xp[key], XP_PER_LEVEL - 1);
}

/** Bank experience in one discipline (or all of them) for a crew member. */
export function giveXp(m: CrewMember, key: SkillId | "all", amount: number, mult = 1) {
  const gain = amount * mult * youthMultiplier(m.age) * traitMult(m.traits, "xp");
  const keys: SkillId[] = key === "all" ? SKILL_IDS : [key];
  const ceiling = Math.min(MAX_SKILL, m.potential);
  for (const k of keys) {
    m.xp[k] += gain;
    levelUp(m.skills, m.xp, k, ceiling);
  }
}

/** The player learns by the same rules, but his ceiling is the highest there is. */
export function givePlayerXp(state: GameState, key: SkillId | "all", amount: number, mult = 1) {
  const p = state.player;
  const gain = amount * mult * youthMultiplier(p.age);
  const keys: SkillId[] = key === "all" ? SKILL_IDS : [key];
  for (const k of keys) {
    p.xp[k] += gain;
    levelUp(p.stats, p.xp, k, MAX_SKILL);
  }
  p.level = 1 + Math.floor(SKILL_IDS.reduce((sum, k) => sum + p.stats[k], 0) / 80);
}

/**
 * Prize experience from a fight, a contract or an event, divided by the articles.
 * Trade profits are not shared this way — that is the house's business.
 */
export function shareXp(state: GameState, key: SkillId | "all", amount: number) {
  const crewCut = clamp(state.laws.crewShare, 0, 100) / 100;
  givePlayerXp(state, key, amount * (1 - crewCut));
  const roster = state.crew.filter((m) => m.shipId === state.activeShipId);
  if (!roster.length) return;
  const each = (amount * crewCut) / roster.length;
  for (const m of roster) giveXp(m, key, each);
}

/** Prize gold divided by the same articles. A generous captain is a popular one. */
export function shareGold(state: GameState, amount: number) {
  const crewCut = clamp(state.laws.crewShare, 0, 100) / 100;
  state.cash += Math.round(amount * (1 - crewCut));
  const roster = state.crew.filter((m) => m.shipId === state.activeShipId);
  const lift = 2 + crewCut * 8;
  for (const m of roster) m.morale = clamp(m.morale + lift * traitMult(m.traits, "moraleGain"), 0, m.health);
  return Math.round(amount * crewCut);
}

/** Every soul aboard learns a little every day; the posted men learn their trade. */
export function dailyLearning(state: GameState) {
  for (const m of state.crew) {
    const ship = state.ships.find((s) => s.id === m.shipId);
    const mult = mateBonus(state, ship);
    giveXp(m, "all", BASE_DAILY_XP, mult);
    const post = postOf(ship, m.id);
    if (post) giveXp(m, POSITION_SKILL[post], POST_DAILY_XP, mult);
  }
  const flag = state.ships.find((s) => s.id === state.activeShipId);
  givePlayerXp(state, "all", BASE_DAILY_XP, mateBonus(state, flag));
  givePlayerXp(state, "navigation", POST_DAILY_XP, mateBonus(state, flag));
}
