import { PORT_MAP } from "../data/ports";
import { pointAlong } from "./seagrid";
import type { Destination, Ship } from "../types";

const R_NM = 3440.065;

/** Great-circle distance, with the same fudge the chart uses for islands in the way. */
export function distanceBetween(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const s =
    Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return Math.round(2 * R_NM * Math.asin(Math.sqrt(s)) * 1.15);
}

/** Where she actually is: interpolated on passage, else her station or her port. */
export function shipPos(ship: Ship): { lat: number; lon: number } {
  if (ship.voyage) {
    const v = ship.voyage;
    if (v.path?.length) {
      const p = pointAlong(v.path, v.progressNm ?? 0);
      return { lat: p.lat, lon: p.lon };
    }
    const f = 1 - v.daysLeft / Math.max(1, v.totalDays);
    const frac = Math.max(0, Math.min(1, f));
    return {
      lat: v.fromLat + (v.toLat - v.fromLat) * frac,
      lon: v.fromLon + (v.toLon - v.fromLon) * frac,
    };
  }
  if (ship.station) return { lat: ship.station.lat, lon: ship.station.lon };
  const p = PORT_MAP[ship.portId];
  return p ? { lat: p.lat, lon: p.lon } : { lat: 18, lon: -70 };
}

/** True when she is riding at anchor in a harbour and shore business is possible. */
export function inPort(ship: Ship) {
  return !ship.voyage && !ship.station;
}

export function portDestination(portId: string): Destination | undefined {
  const p = PORT_MAP[portId];
  if (!p) return undefined;
  return { portId: p.id, lat: p.lat, lon: p.lon, label: p.name };
}

export function coordLabel(lat: number, lon: number) {
  const ns = lat >= 0 ? "N" : "S";
  const ew = lon >= 0 ? "E" : "W";
  return `${Math.abs(lat).toFixed(1)}°${ns} ${Math.abs(lon).toFixed(1)}°${ew}`;
}

export function seaDestination(lat: number, lon: number): Destination {
  return { lat, lon, label: coordLabel(lat, lon) };
}

export function sameDestination(a?: Destination, b?: Destination) {
  if (!a || !b) return false;
  if (a.portId || b.portId) return a.portId === b.portId;
  return Math.abs(a.lat - b.lat) < 0.05 && Math.abs(a.lon - b.lon) < 0.05;
}
