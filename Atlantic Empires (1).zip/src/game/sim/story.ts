import { LIFE_EVENTS, LIFE_EVENT_MAP, type LifeEventDef, type LifeOption } from "../data/lifeEvents";
import { PORT_MAP } from "../data/ports";
import type { GameState, Ship, StoryPrompt } from "../types";
import { applyEffects } from "./encounters";
import { pushLog } from "./events";
import { readBooks, tally } from "./outcome";
import { oddsFor } from "./skillcheck";
import { clamp } from "./util";

function fill(text: string, crew?: string, port?: string) {
  return text.replace(/\{crew\}/g, crew ?? "A hand").replace(/\{port\}/g, port ?? "the port");
}

function pick(defs: LifeEventDef[], rand: () => number) {
  const total = defs.reduce((s, d) => s + d.weight, 0);
  let r = rand() * total;
  for (const d of defs) {
    r -= d.weight;
    if (r <= 0) return d;
  }
  return defs[0]!;
}

/**
 * Roll the day's small human weather. Only one such moment at a time, and
 * never while there is a mark or an action already wanting an answer.
 */
export function rollStory(state: GameState, ship: Ship, rand: () => number) {
  if (state.story || state.encounter || state.combat) return;
  const atSea = !!ship.voyage || ship.underway;
  const chance = atSea ? 0.13 : 0.16;
  if (rand() > chance) return;

  const scenes = atSea ? ["sea"] : ["port", "quay"];
  const roster = state.crew.filter((m) => m.shipId === ship.id);
  const pool = LIFE_EVENTS.filter(
    (d) => scenes.includes(d.scene) && (!d.needsCrew || roster.length > 0),
  );
  if (!pool.length) return;

  const def = pick(pool, rand);
  const man = def.needsCrew ? roster[Math.floor(rand() * roster.length)] : undefined;
  const portName = PORT_MAP[ship.portId ?? ""]?.name;
  const line = def.lines[Math.floor(rand() * def.lines.length)]!;

  const prompt: StoryPrompt = {
    id: `sty${state.day}-${def.id}`,
    defId: def.id,
    title: fill(def.title, man?.name, portName),
    text: fill(line, man?.name, portName),
    scene: def.scene,
    ...(man ? { crewId: man.id, crewName: man.name } : {}),
    ...(portName ? { portName } : {}),
  };
  state.story = prompt;
}

export function storyOptions(defId: string): LifeOption[] {
  return LIFE_EVENT_MAP[defId]?.options ?? [];
}

export function storyOdds(state: GameState, opt: LifeOption) {
  if (!opt.skill || opt.dc === undefined) return undefined;
  return oddsFor(state, opt.skill, opt.dc);
}

function touchMan(state: GameState, crewId: string | undefined, fx?: { health?: number; morale?: number }) {
  if (!crewId || !fx) return;
  const m = state.crew.find((c) => c.id === crewId);
  if (!m) return;
  if (fx.health) m.health = clamp(m.health + fx.health, 1, 100);
  if (fx.morale) m.morale = clamp(m.morale + fx.morale, 0, m.health);
}

/** The captain's word, and what comes of it. */
export function resolveStory(state: GameState, optionId: string, rand: () => number) {
  const st = state.story;
  if (!st) return;
  const ship = state.ships.find((s) => s.id === state.activeShipId);
  const opt = storyOptions(st.defId).find((o) => o.id === optionId);
  if (!ship || !opt) {
    delete state.story;
    return;
  }

  const before = readBooks(state, ship);
  const rolled = opt.skill && opt.dc !== undefined ? oddsFor(state, opt.skill, opt.dc) : undefined;
  const won = !rolled || rand() < rolled.chance;

  if (won) {
    applyEffects(state, ship, opt.gain, rand, 1);
    if (!rolled) applyEffects(state, ship, opt.loss, rand, -1);
    touchMan(state, st.crewId, opt.crewOk);
    pushLog(state, "world", `${st.title}: ${opt.ok}`);
  } else {
    applyEffects(state, ship, opt.loss, rand, -1);
    touchMan(state, st.crewId, opt.crewBad);
    pushLog(state, "world", `${st.title}: ${opt.bad ?? "It goes badly."}`);
  }
  state.outcome = {
    title: st.title,
    choice: opt.label,
    text: won ? opt.ok : (opt.bad ?? "It goes badly."),
    verdict: rolled ? (won ? "won" : "lost") : "done",
    ...(rolled && opt.skill && opt.dc !== undefined
      ? { roll: { skill: opt.skill, score: rolled.score, dc: opt.dc, chance: rolled.chance } }
      : {}),
    lines: tally(before, readBooks(state, ship)),
  };
  delete state.story;
}
