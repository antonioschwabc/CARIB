import { COMMODITY_MAP, CATEGORY_LABEL } from "../data/commodities";
import type { CommodityCategory, Ship } from "../types";

/** Every hull is built with these three holds already fitted out. */
export const BASE_HOLDS: CommodityCategory[] = ["food", "naval", "agricultural"];

export interface HoldDef {
  category: CommodityCategory;
  name: string;
  price: number;
  note: string;
}

/** The stowage a shipwright can add so she may legally, safely carry a kind of goods. */
export const HOLD_TYPES: HoldDef[] = [
  { category: "food", name: "Provisions Hold", price: 0, note: "Bread room, water casks and the beef tier. Fitted in every hull." },
  { category: "naval", name: "Naval Stores Hold", price: 0, note: "Sail room, cable tier and the boatswain's stores. Fitted in every hull." },
  { category: "agricultural", name: "Agricultural Hold", price: 0, note: "Dunnage and mats for hogsheads of sugar and leaf. Fitted in every hull." },
  { category: "raw", name: "Raw Materials Hold", price: 6800, note: "Heavy skids and lashings for logwood, hides and other rough cargo." },
  { category: "alcohol", name: "Spirit Room", price: 7400, note: "Chocked casks kept cool and away from the galley fire." },
  { category: "manufactured", name: "Dry Goods Hold", price: 8200, note: "Lined and battened against damp so cloth and ironmongery arrive saleable." },
  { category: "metals", name: "Bullion Vault", price: 14500, note: "An iron-bound strongroom amidships for specie, bar and ingot." },
  { category: "luxury", name: "Strongroom", price: 12800, note: "Locked cabinets under the great cabin for pearls, silk and spice." },
  { category: "contraband", name: "False Bulkhead", price: 16000, note: "Hidden stowage a searching officer must be clever to find." },
];

export const HOLD_MAP: Record<string, HoldDef> = Object.fromEntries(
  HOLD_TYPES.map((h) => [h.category, h]),
);

export const OPTIONAL_HOLDS = HOLD_TYPES.filter((h) => h.price > 0);

export function holdsOf(ship: Ship): CommodityCategory[] {
  return Array.from(new Set([...BASE_HOLDS, ...(ship.holds ?? [])]));
}

export function hasHold(ship: Ship, category: CommodityCategory) {
  return holdsOf(ship).includes(category);
}

/** Can this commodity be stowed aboard her at all? */
export function canStow(ship: Ship, cid: string) {
  const c = COMMODITY_MAP[cid];
  return !c || hasHold(ship, c.category);
}

export function holdNameFor(cid: string) {
  const c = COMMODITY_MAP[cid];
  if (!c) return "hold";
  return HOLD_MAP[c.category]?.name ?? `${CATEGORY_LABEL[c.category]} hold`;
}
