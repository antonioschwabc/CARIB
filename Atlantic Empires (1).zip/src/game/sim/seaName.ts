import { MAP_REGIONS } from "../data/regions";

/** The nearest engraved water name to a position on the chart. */
export function seaNameAt(lat: number, lon: number): string {
  let best = "Open sea";
  let bestD = Infinity;
  for (const r of MAP_REGIONS) {
    for (const s of r.seas ?? []) {
      const d = (s.lat - lat) ** 2 + (s.lon - lon) ** 2;
      if (d < bestD) {
        bestD = d;
        best = s.name;
      }
    }
  }
  return best.replace(/\b([A-ZÁÉÍÓÚ]{2,})\b/g, (w) => w.charAt(0) + w.slice(1).toLowerCase());
}
