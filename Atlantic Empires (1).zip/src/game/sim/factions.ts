import { POWERS, POWER_MAP } from "../data/powers";
import type { GameState, PowerId } from "../types";
import { pushLog } from "./events";
import { clamp, rng } from "./util";

/**
 * The crowns keep books on each other as well as on the captain. Standing runs
 * −100 to 100; at −50 they are at war, at +50 they will fight side by side.
 * Events shove the figure about month by month, and every New Year the weight
 * of habit drags it half-way back to where history says it belongs.
 */

export const WAR_AT = -50;
export const ALLIED_AT = 50;

export function pairKey(a: PowerId, b: PowerId) {
  return [a, b].sort().join("|");
}

/** Where each pair sits when nothing has happened: the status quo of 1670. */
export const STATUS_QUO: Record<string, number> = {
  "england|spain": -20,
  "france|spain": -10,
  "dutch|spain": 10,
  "portugal|spain": -30,
  "england|france": 15,
  "dutch|england": -25,
  "england|portugal": 45,
  "dutch|france": -20,
  "france|portugal": 5,
  "dutch|portugal": -15,
  "pirate|spain": -85,
  "england|pirate": -75,
  "france|pirate": -35,
  "dutch|pirate": -40,
  "pirate|portugal": -70,
};

export function initFactionRelations(): Record<string, number> {
  const out: Record<string, number> = {};
  for (const key of Object.keys(STATUS_QUO)) out[key] = STATUS_QUO[key]!;
  return out;
}

export function factionRel(state: GameState, a: PowerId, b: PowerId) {
  if (a === b) return 100;
  const key = pairKey(a, b);
  return state.factionRelations?.[key] ?? STATUS_QUO[key] ?? 0;
}

export function setFactionRel(state: GameState, a: PowerId, b: PowerId, value: number) {
  state.factionRelations = { ...(state.factionRelations ?? {}), [pairKey(a, b)]: clamp(value, -100, 100) };
}

export function shiftFactionRel(state: GameState, a: PowerId, b: PowerId, delta: number) {
  setFactionRel(state, a, b, factionRel(state, a, b) + delta);
}

export function factionsAtWar(state: GameState, a: PowerId, b: PowerId) {
  if (a === b) return false;
  if (a === "pirate" || b === "pirate") return true;
  return factionRel(state, a, b) <= WAR_AT;
}

export function factionsAllied(state: GameState, a: PowerId, b: PowerId) {
  return a !== b && factionRel(state, a, b) >= ALLIED_AT;
}

export function relationTone(v: number) {
  if (v <= WAR_AT) return { label: "At war", color: "oklch(0.52 0.19 25)" };
  if (v < -20) return { label: "Hostile", color: "oklch(0.58 0.14 40)" };
  if (v < 10) return { label: "Cool", color: "oklch(0.62 0.04 80)" };
  if (v < ALLIED_AT) return { label: "Cordial", color: "oklch(0.66 0.11 145)" };
  return { label: "Allied", color: "oklch(0.72 0.16 150)" };
}

// ------------------------------------------------------------------ dispatches

interface Dispatch {
  text: (a: string, b: string) => string;
  delta: number;
}

const DISPATCHES: Dispatch[] = [
  { delta: -14, text: (a, b) => `${a} guarda-costas have seized three ${b} bottoms on a pretext of contraband. The ${b} consul has left his post.` },
  { delta: -10, text: (a, b) => `A ${a} squadron fired into a ${b} convoy off the banks, claiming a salute was refused.` },
  { delta: -8, text: (a, b) => `Pamphlets printed in ${a} accuse the ${b} of arming the Brethren. The ambassador denies it, badly.` },
  { delta: -18, text: (a, b) => `${a} troops have burned a ${b} settlement ashore. Both courts speak of satisfaction; neither offers it.` },
  { delta: -6, text: (a, b) => `A quarrel over fishing rights sours the ${a} and ${b} courts through the whole month.` },
  { delta: 12, text: (a, b) => `${a} and ${b} plenipotentiaries have signed a convention on prizes and shipwrecked goods.` },
  { delta: 9, text: (a, b) => `A ${a} squadron escorted ${b} merchantmen clear of a corsair. The courtesy is noted in both capitals.` },
  { delta: 16, text: (a, b) => `A marriage has been arranged between the houses of ${a} and ${b}. The Indies will feel it slowly.` },
  { delta: 7, text: (a, b) => `${a} has opened one harbour a year to ${b} shipping in ballast — a small door, but a door.` },
  { delta: -12, text: (a, b) => `${a} privateers took a ${b} sugar ship and the prize court would not restore her.` },
];

const REAL: PowerId[] = POWERS.filter((p) => p.id !== "pirate").map((p) => p.id);

/** Once a month, one dispatch reaches the Indies — or none does. */
export function monthlyDispatch(state: GameState) {
  const rand = rng(((state.seed >>> 0) ^ (Math.floor(state.day / 30) * 40503)) >>> 0);
  if (rand() < 0.35) return;
  const a = REAL[Math.floor(rand() * REAL.length)]!;
  let b = REAL[Math.floor(rand() * REAL.length)]!;
  if (a === b) b = REAL[(REAL.indexOf(a) + 1) % REAL.length]!;
  const d = DISPATCHES[Math.floor(rand() * DISPATCHES.length)]!;
  const before = factionRel(state, a, b);
  shiftFactionRel(state, a, b, d.delta);
  const after = factionRel(state, a, b);
  pushLog(state, "world", `${d.text(POWER_MAP[a]!.adjective, POWER_MAP[b]!.adjective)} (${POWER_MAP[a]!.adjective}–${POWER_MAP[b]!.adjective} standing ${Math.round(before)} → ${Math.round(after)}.)`);
  if (before > WAR_AT && after <= WAR_AT) {
    pushLog(state, "world", `War is declared between ${POWER_MAP[a]!.name} and ${POWER_MAP[b]!.name}. Their ships will fight on sight.`);
  }
  if (before < ALLIED_AT && after >= ALLIED_AT) {
    pushLog(state, "world", `${POWER_MAP[a]!.name} and ${POWER_MAP[b]!.name} are now allied, and will make common cause at sea.`);
  }
}

/** New Year: the weight of habit drags every pair half-way home. */
export function annualStatusQuo(state: GameState) {
  for (const key of Object.keys({ ...STATUS_QUO, ...(state.factionRelations ?? {}) })) {
    const quo = STATUS_QUO[key] ?? 0;
    const now = state.factionRelations?.[key] ?? quo;
    state.factionRelations = { ...(state.factionRelations ?? {}), [key]: Math.round((now + quo) / 2) };
  }
  pushLog(state, "world", "The New Year's dispatches arrive from Europe. Old habits reassert themselves between the courts.");
}
