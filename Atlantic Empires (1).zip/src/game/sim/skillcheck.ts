import type { GameState, SkillId } from "../types";
import { bannerStats } from "./crewStats";
import { clamp } from "./util";

/**
 * A captain's skill check. The difficulty class is a number on the same
 * 0-100 scale as a man's skill: meet it and the odds are even, beat it and
 * they climb. Nothing is ever certain either way.
 */
export const DC_LABEL: { at: number; label: string }[] = [
  { at: 20, label: "Trifling" },
  { at: 35, label: "Easy" },
  { at: 50, label: "Fair" },
  { at: 65, label: "Hard" },
  { at: 80, label: "Severe" },
  { at: 999, label: "Desperate" },
];

export function dcLabel(dc: number) {
  return DC_LABEL.find((d) => dc <= d.at)!.label;
}

/** The skill actually brought to bear: the captain, plus the best man in that trade. */
export function checkSkill(state: GameState, skill: SkillId) {
  return Math.round(bannerStats(state)[skill]);
}

/** Odds of carrying it off, 5% to 95%. */
export function successChance(skill: number, dc: number) {
  return clamp(0.5 + (skill - dc) * 0.02, 0.05, 0.95);
}

export interface CheckOdds {
  skill: SkillId;
  dc: number;
  label: string;
  score: number;
  chance: number;
  failChance: number;
}

export function oddsFor(state: GameState, skill: SkillId, dc: number): CheckOdds {
  const score = checkSkill(state, skill);
  const chance = successChance(score, dc);
  return { skill, dc, label: dcLabel(dc), score, chance, failChance: 1 - chance };
}
