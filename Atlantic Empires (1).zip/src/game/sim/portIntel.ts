import { COMMODITY_MAP } from "../data/commodities";
import { PORT_MAP } from "../data/ports";
import { priceOf } from "./economy";
import type { GameState, Port } from "../types";

/** Fortification is not stored per port: it follows from garrison wealth and harbour security. */
export function fortificationOf(port: Port): { score: number; label: string; guns: number } {
  const score = Math.min(
    1,
    port.security * 0.7 + Math.min(1, port.population / 20000) * 0.25 + port.prosperity * 0.1,
  );
  const label =
    score > 0.85
      ? "Great stone castle"
      : score > 0.68
        ? "Regular fort with water battery"
        : score > 0.5
          ? "Earthwork fort and a few guns"
          : score > 0.32
            ? "A palisade and a watch-house"
            : "Open roadstead, undefended";
  return { score, label, guns: Math.round(4 + score * 76) };
}

export interface PortIntelLine {
  cid: string;
  name: string;
  price: number;
  ratio: number;
}

/** What a captain hears in the harbour: the two goods going cheap and the two the town lacks. */
export function portIntel(state: GameState, portId: string) {
  const port = PORT_MAP[portId]!;
  const market = state.markets[portId];
  const rows: PortIntelLine[] = [];
  if (market) {
    for (const cid of Object.keys(market.stock)) {
      const c = COMMODITY_MAP[cid];
      if (!c) continue;
      const p = priceOf(state, portId, cid, port);
      rows.push({ cid, name: c.name, price: p.unit, ratio: p.ratio });
    }
  }
  const byRatio = [...rows].sort((a, b) => a.ratio - b.ratio);
  return {
    lacking: byRatio.slice(0, 2),
    surplus: byRatio.slice(-2).reverse(),
  };
}
