import { COASTLINES } from "../data/coastlines";
import { PORTS } from "../data/ports";

/**
 * A navigable chart: the coastlines rasterised into a grid of sea and land cells,
 * so a course can be worked round a headland instead of straight through it.
 */
export const LON_MIN = -101;
export const LON_MAX = 24;
export const LAT_MIN = -32;
export const LAT_MAX = 63;
export const STEP = 0.125;

export const COLS = Math.round((LON_MAX - LON_MIN) / STEP);
export const ROWS = Math.round((LAT_MAX - LAT_MIN) / STEP);

const R_NM = 3440.065;

let landMask: Uint8Array | undefined;

/**
 * Waters shut to the trade — the South Sea beyond the isthmus and the Adriatic.
 * Each box is [lonMin, latMin, lonMax, latMax].
 */
export const CLOSED_WATERS: [number, number, number, number][] = [
  [-101, 5, -92, 17],
  [-101, 17, -97, 20],
  [-92, 5, -84, 11.2],
  [-92, 11.2, -85.5, 12.9],
  [-92, 12.9, -89, 15.4],
  [-84, 5, -78.4, 8.6],
  [12.2, 39.8, 20, 46],
];

function buildMask(): Uint8Array {
  const land = new Uint8Array(COLS * ROWS);
  // Each ring is filled on its own: the regional sheets overlap, so one shared
  // parity test across all of them would put land in the middle of the ocean.
  for (const rings of Object.values(COASTLINES)) {
    for (const ring of rings) {
      if (ring.length < 3) continue;
      let minLat = 90;
      let maxLat = -90;
      for (const p of ring) {
        if (p[1] < minLat) minLat = p[1];
        if (p[1] > maxLat) maxLat = p[1];
      }
      const rowFrom = Math.max(0, Math.floor((minLat - LAT_MIN) / STEP));
      const rowTo = Math.min(ROWS - 1, Math.ceil((maxLat - LAT_MIN) / STEP));
      for (let row = rowFrom; row <= rowTo; row++) {
        const y = LAT_MIN + (row + 0.5) * STEP;
        const xs: number[] = [];
        for (let i = 0; i < ring.length; i++) {
          const a = ring[i]!;
          const b = ring[(i + 1) % ring.length]!;
          if (a[1] > y === b[1] > y) continue;
          const t = (y - a[1]) / (b[1] - a[1]);
          xs.push(a[0] + t * (b[0] - a[0]));
        }
        if (xs.length < 2) continue;
        xs.sort((m, n) => m - n);
        for (let i = 0; i + 1 < xs.length; i += 2) {
          const from = Math.max(0, Math.ceil((xs[i]! - LON_MIN) / STEP - 0.5));
          const to = Math.min(COLS - 1, Math.floor((xs[i + 1]! - LON_MIN) / STEP - 0.5));
          for (let c = from; c <= to; c++) land[row * COLS + c] = 1;
        }
      }
    }
  }

  // The scanline test only sees a cell by its centre, so a narrow cay or a thin
  // spit slips between the rows. Stamp every coastline edge onto the grid too:
  // where the shore runs, no hull passes.
  for (const rings of Object.values(COASTLINES)) {
    for (const ring of rings) {
      if (ring.length < 2) continue;
      for (let i = 0; i < ring.length; i++) {
        const a = ring[i]!;
        const b = ring[(i + 1) % ring.length]!;
        const steps = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (STEP * 0.4)));
        for (let s = 0; s <= steps; s++) {
          const f = s / steps;
          const { col, row } = cellOf(a[1] + (b[1] - a[1]) * f, a[0] + (b[0] - a[0]) * f);
          land[row * COLS + col] = 1;
        }
      }
    }
  }

  // Straits too narrow for the grid to hold open, kept navigable by hand:
  // the Sound into the Baltic, and the Dover narrows.
  const CHANNELS: [number, number][][] = [
    [
      [57.6, 10.6],
      [56.6, 11.9],
      [56.1, 12.5],
      [55.7, 12.75],
      [55.3, 12.9],
      [54.9, 12.6],
    ],
    [
      [51.2, 1.5],
      [50.9, 1.4],
      [50.6, 0.8],
    ],
  ];
  for (const line of CHANNELS) {
    for (let i = 1; i < line.length; i++) {
      const a = line[i - 1]!;
      const b = line[i]!;
      const steps = Math.max(1, Math.ceil(Math.hypot(b[0] - a[0], b[1] - a[1]) / (STEP * 0.4)));
      for (let s = 0; s <= steps; s++) {
        const f = s / steps;
        const { col, row } = cellOf(a[0] + (b[0] - a[0]) * f, a[1] + (b[1] - a[1]) * f);
        for (let dr = -1; dr <= 1; dr++)
          for (let dc = -1; dc <= 1; dc++) {
            const r = row + dr;
            const c = col + dc;
            if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
            land[r * COLS + c] = 0;
          }
      }
    }
  }


  // Waters beyond the world of this trade: the South Sea past the isthmus, and
  // the Adriatic deep inside the Mediterranean. They are sea, but no ship of
  // ours may work them, so the chart holds them shut.
  for (const [lonA, latA, lonB, latB] of CLOSED_WATERS) {
    const c0 = cellOf(latA, lonA);
    const c1 = cellOf(latB, lonB);
    for (let row = c0.row; row <= c1.row; row++)
      for (let col = c0.col; col <= c1.col; col++) land[row * COLS + col] = 1;
  }

  // Harbours sit on the shore, and some of them well up a river. Join each mark
  // to the nearest water already present in the coastline mask; never tunnel
  // across an island merely in search of a broad patch of ocean.
  for (const p of PORTS) {
    const { col, row } = cellOf(p.lat, p.lon);
    dredge(land, col, row);
    for (let dr = -1; dr <= 1; dr++)
      for (let dc = -1; dc <= 1; dc++) {
        const r = row + dr;
        const c = col + dc;
        if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
        land[r * COLS + c] = 0;
      }
  }
  return land;
}

/** How much open water lies about a cell, counted over a 5x5 square. */
function openness(land: Uint8Array, col: number, row: number) {
  let n = 0;
  for (let dr = -2; dr <= 2; dr++)
    for (let dc = -2; dc <= 2; dc++) {
      const r = row + dr;
      const c = col + dc;
      if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
      if (land[r * COLS + c] === 0) n++;
    }
  return n;
}

/** Cut the shortest possible channel from a harbour mark to existing water. */
function dredge(land: Uint8Array, col: number, row: number) {
  const start = row * COLS + col;
  if (land[start] === 0) return;
  const seen = new Int32Array(COLS * ROWS).fill(-2);
  const queue = [start];
  seen[start] = -1;
  for (let head = 0; head < queue.length && head < 20000; head++) {
    const idx = queue[head]!;
    const r = Math.floor(idx / COLS);
    const c = idx % COLS;
    if (idx !== start && land[idx] === 0) {
      for (let cur = idx; cur !== -1; cur = seen[cur]!) land[cur] = 0;
      return;
    }
    for (const [dr, dc] of [[1, 0], [-1, 0], [0, 1], [0, -1]] as const) {
      const nr = r + dr;
      const nc = c + dc;
      if (nr < 0 || nc < 0 || nr >= ROWS || nc >= COLS) continue;
      const n = nr * COLS + nc;
      if (seen[n] !== -2) continue;
      seen[n] = idx;
      queue.push(n);
    }
  }
}

function mask(): Uint8Array {
  return (landMask ??= buildMask());
}

export function cellOf(lat: number, lon: number) {
  return {
    col: Math.max(0, Math.min(COLS - 1, Math.floor((lon - LON_MIN) / STEP))),
    row: Math.max(0, Math.min(ROWS - 1, Math.floor((lat - LAT_MIN) / STEP))),
  };
}

export function centreOf(col: number, row: number) {
  return { lon: LON_MIN + (col + 0.5) * STEP, lat: LAT_MIN + (row + 0.5) * STEP };
}

/** True when there is water enough here to float a hull. */
export function isSea(lat: number, lon: number) {
  if (lat < LAT_MIN || lat > LAT_MAX || lon < LON_MIN || lon > LON_MAX) return true;
  const { col, row } = cellOf(lat, lon);
  return mask()[row * COLS + col] === 0;
}

function nearestSea(lat: number, lon: number) {
  const start = cellOf(lat, lon);
  const m = mask();
  if (m[start.row * COLS + start.col] === 0) return start;
  const seen = new Uint8Array(COLS * ROWS);
  const queue = [start.row * COLS + start.col];
  seen[queue[0]!] = 1;
  for (let head = 0; head < queue.length && head < 40000; head++) {
    const idx = queue[head]!;
    const row = Math.floor(idx / COLS);
    const col = idx % COLS;
    if (m[idx] === 0) return { col, row };
    for (let dr = -1; dr <= 1; dr++)
      for (let dc = -1; dc <= 1; dc++) {
        const r = row + dr;
        const c = col + dc;
        if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
        const n = r * COLS + c;
        if (seen[n]) continue;
        seen[n] = 1;
        queue.push(n);
      }
  }
  return start;
}

let coastCache: Uint8Array | undefined;

/** 1 for a sea cell that touches land — a berth worth giving where there is room. */
function coastMap(): Uint8Array {
  if (coastCache) return coastCache;
  const m = mask();
  const out = new Uint8Array(COLS * ROWS);
  for (let row = 0; row < ROWS; row++)
    for (let col = 0; col < COLS; col++) {
      const idx = row * COLS + col;
      if (m[idx] === 1) continue;
      let near = 0;
      for (let dr = -1; dr <= 1 && !near; dr++)
        for (let dc = -1; dc <= 1; dc++) {
          const r = row + dr;
          const c = col + dc;
          if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
          if (m[r * COLS + c] === 1) {
            near = 1;
            break;
          }
        }
      out[idx] = near;
    }
  coastCache = out;
  return out;
}

export function nmBetween(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const s = Math.sin(dLat / 2) ** 2 + Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  return 2 * R_NM * Math.asin(Math.sqrt(s));
}

export interface SeaRoute {
  /** waypoints from her present position to the mark, all of them on water */
  points: { lat: number; lon: number }[];
  /** length of the whole track in sea miles */
  distanceNm: number;
  /** false when no water road could be found at all */
  ok: boolean;
}

const cache = new Map<string, SeaRoute>();

/** Work a course round the land: A* across the sea cells of the chart. */
export function seaRoute(
  from: { lat: number; lon: number },
  to: { lat: number; lon: number },
): SeaRoute {
  const key = `${from.lat.toFixed(2)},${from.lon.toFixed(2)}>${to.lat.toFixed(2)},${to.lon.toFixed(2)}`;
  const hit = cache.get(key);
  if (hit) return hit;

  const m = mask();
  const coast = coastMap();
  const start = nearestSea(from.lat, from.lon);
  const goal = nearestSea(to.lat, to.lon);
  const startIdx = start.row * COLS + start.col;
  const goalIdx = goal.row * COLS + goal.col;

  const total = COLS * ROWS;
  const g = new Float32Array(total).fill(Infinity);
  const cameFrom = new Int32Array(total).fill(-1);
  const closed = new Uint8Array(total);
  const h = (idx: number) => {
    const row = Math.floor(idx / COLS);
    const col = idx % COLS;
    return nmBetween(centreOf(col, row), centreOf(goal.col, goal.row));
  };

  // Simple binary heap of [f, idx]
  const heap: [number, number][] = [];
  const push = (f: number, idx: number) => {
    heap.push([f, idx]);
    let i = heap.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (heap[p]![0] <= heap[i]![0]) break;
      [heap[p], heap[i]] = [heap[i]!, heap[p]!];
      i = p;
    }
  };
  const pop = () => {
    const top = heap[0]!;
    const last = heap.pop()!;
    if (heap.length) {
      heap[0] = last;
      let i = 0;
      for (;;) {
        const l = i * 2 + 1;
        const r = l + 1;
        let s = i;
        if (l < heap.length && heap[l]![0] < heap[s]![0]) s = l;
        if (r < heap.length && heap[r]![0] < heap[s]![0]) s = r;
        if (s === i) break;
        [heap[s], heap[i]] = [heap[i]!, heap[s]!];
        i = s;
      }
    }
    return top;
  };

  g[startIdx] = 0;
  push(h(startIdx), startIdx);
  let found = false;
  let guard = 0;
  while (heap.length && guard++ < 400000) {
    const [, idx] = pop();
    if (closed[idx]) continue;
    closed[idx] = 1;
    if (idx === goalIdx) {
      found = true;
      break;
    }
    const row = Math.floor(idx / COLS);
    const col = idx % COLS;
    const here = centreOf(col, row);
    for (let dr = -1; dr <= 1; dr++)
      for (let dc = -1; dc <= 1; dc++) {
        if (!dr && !dc) continue;
        const r = row + dr;
        const c = col + dc;
        if (r < 0 || c < 0 || r >= ROWS || c >= COLS) continue;
        const n = r * COLS + c;
        if (m[n] === 1 || closed[n]) continue;
        // do not cut a corner between two points of land
        if (dr && dc && (m[row * COLS + c] === 1 || m[r * COLS + col] === 1)) continue;
        const step = nmBetween(here, centreOf(c, r));
        // Give the land a berth when there is sea room to do it.
        const cost = g[idx]! + step * (coast[n] === 1 ? 1.25 : 1);
        if (cost < g[n]!) {
          g[n] = cost;
          cameFrom[n] = idx;
          push(cost + h(n), n);
        }
      }
  }

  let route: SeaRoute;
  if (!found) {
    route = { points: [from, to], distanceNm: nmBetween(from, to) * 1.2, ok: false };
  } else {
    const cells: number[] = [];
    for (let idx = goalIdx; idx !== -1; idx = cameFrom[idx]!) cells.push(idx);
    cells.reverse();
    const raw = cells.map((idx) => centreOf(idx % COLS, Math.floor(idx / COLS)));
    const points = simplify([from, ...raw, to]);
    let distanceNm = 0;
    for (let i = 1; i < points.length; i++) distanceNm += nmBetween(points[i - 1]!, points[i]!);
    route = { points, distanceNm, ok: true };
  }
  if (cache.size > 200) cache.clear();
  cache.set(key, route);
  return route;
}

/** True only when the complete visible segment remains on navigable water. */
function clearSeaLeg(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const samples = Math.max(1, Math.ceil(nmBetween(a, b) / 3));
  for (let i = 1; i < samples; i++) {
    const f = i / samples;
    if (!isSea(a.lat + (b.lat - a.lat) * f, a.lon + (b.lon - a.lon) * f)) return false;
  }
  return true;
}

/** Drop redundant waypoints only when the resulting chart leg remains at sea. */
function simplify(points: { lat: number; lon: number }[]) {
  const out = [points[0]!];
  for (let i = 1; i < points.length - 1; i++) {
    const a = out[out.length - 1]!;
    const b = points[i]!;
    const c = points[i + 1]!;
    const cross = (b.lon - a.lon) * (c.lat - a.lat) - (b.lat - a.lat) * (c.lon - a.lon);
    if (Math.abs(cross) > 0.002 || !clearSeaLeg(a, c)) out.push(b);
  }
  out.push(points[points.length - 1]!);
  return out;
}

/** The point a given number of sea miles along a track, and the heading there. */
export function pointAlong(points: { lat: number; lon: number }[], nm: number) {
  if (!points.length) return { lat: 0, lon: 0, heading: 0 };
  let left = Math.max(0, nm);
  for (let i = 1; i < points.length; i++) {
    const a = points[i - 1]!;
    const b = points[i]!;
    const leg = nmBetween(a, b);
    if (left <= leg || i === points.length - 1) {
      const f = leg > 0 ? Math.min(1, left / leg) : 1;
      return {
        lat: a.lat + (b.lat - a.lat) * f,
        lon: a.lon + (b.lon - a.lon) * f,
        heading: (Math.atan2(b.lon - a.lon, b.lat - a.lat) * 180) / Math.PI,
      };
    }
    left -= leg;
  }
  const last = points[points.length - 1]!;
  return { lat: last.lat, lon: last.lon, heading: 0 };
}
