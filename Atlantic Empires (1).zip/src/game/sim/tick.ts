import { COMMODITY_MAP } from "../data/commodities";
import { PORTS, PORT_MAP } from "../data/ports";
import { BUSINESS_MAP, SHIP_CLASS_MAP } from "../data/ships";
import type { Destination, GameState, Port, Ship } from "../types";
import { PERMIT_KIND_MAP } from "../data/permits";
import { dockBlocked } from "../data/permits";
import { addFactionStanding, addInfamy, addPortStanding, banFine, portBanned, portStanding } from "./standing";
import { demandDepth, priceOf } from "./economy";
import { pushLog, rollEvents } from "./events";
import { refreshQuests } from "./quests";
import { adjustReputation, contractPenalty } from "./reputation";
import { refreshRecruits } from "../state";
import { applyPortEvents, rollPortEvents } from "../data/portEvents";
import { clamp, hurricaneFactor, rng, uid } from "./util";
import { SUPPLY_IDS } from "./stores";
import { HAND_WEEKLY_WAGE, effSkill } from "../data/crew";
import { traitMult } from "../data/traits";
import { postOf } from "./shipStats";
const SUPPLY_ORDER = SUPPLY_IDS;
import { bannerStats } from "./crewStats";
import { dailyLearning } from "./progress";
import {
  MEDICINE_IDS,
  SALVAGE_IDS,
  crewOfShip,
  dailyAppetite,
  drawStores,
  releaseLocked,
  spiritsAboard,
  suppliesAboard,
} from "./stores";
import { effectiveSpeed, planVoyage } from "./voyage";
import { encounterFromEvent, rollSeaEvents, scanSeaEvents, sightRangeNm } from "./seaEvents";
import { shipPos } from "./position";
import { annualStatusQuo, monthlyDispatch } from "./factions";
import { nmBetween } from "./seagrid";
import { rollStory } from "./story";
import { tickWorld, visibleNpcs } from "./world";

/**
 * The Brethren's harbours are on no chart. A masthead that passes close enough
 * sees the smoke of the careening fires, and after that the place is known.
 */
function discoverHavens(state: GameState) {
  const known = new Set(state.knownPorts ?? []);
  let found = false;
  for (const ship of state.ships) {
    if (ship.portId) continue;
    const here = shipPos(ship);
    const range = sightRangeNm(ship) * 1.1;
    for (const port of PORTS) {
      if (!port.hidden || known.has(port.id)) continue;
      if (nmBetween(here, port) > range) continue;
      known.add(port.id);
      found = true;
      pushLog(
        state,
        "world",
        `Smoke over an anchorage that is on no chart of yours. ${port.name} — a harbour of the Brethren of the Coast — is now marked in your own hand.`,
      );
    }
  }
  if (found) state.knownPorts = [...known];
}

/** Advance the world exactly one day, mutating a draft state. */
export function tickDay(state: GameState) {
  state.day += 1;
  const rand = rng(state.seed + state.day * 7919);

  simulateMarkets(state);
  rollEvents(state, rand);
  rollSeaEvents(state, rand);
  simulateNpcTrade(state, rand);
  simulateBusinesses(state);
  simulateLoans(state);
  simulateDebt(state);
  simulateCrew(state, rand);
  if (state.day % 7 === 0) {
    state.tavernTaken = {};
    refreshQuests(state, rand);
    rollPortEvents(state, rand);
  }
  // Hands drift in and out of the tap-rooms slowly: a new muster every three weeks.
  if (state.day % 21 === 0) refreshRecruits(state, rand);
  if (state.day % 30 === 0) monthlyDispatch(state);
  if (state.day > 0 && state.day % 365 === 0) annualStatusQuo(state);
  discoverHavens(state);
  tickWorld(state, rand);
  // What passes within the glass is known thereafter.
  for (const ship of state.ships) {
    for (const npc of visibleNpcs(state, shipPos(ship), sightRangeNm(ship))) npc.seen = true;
  }
  applyPortEvents(state);
  expireQuests(state);
  expirePermits(state);
  simulateShips(state, rand);

  // The small human weather of the day, once the ships have moved.
  const active = state.ships.find((s) => s.id === state.activeShipId);
  if (active) rollStory(state, active, rand);

  snapshotPrices(state);
}

/** Paper lapses. The clerks do not remind you. */
function expirePermits(state: GameState) {
  const live = [];
  for (const p of state.permits ?? []) {
    if (p.expiresDay > state.day) {
      live.push(p);
      const left = p.expiresDay - state.day;
      if (left === 30 || left === 7)
        pushLog(state, "world", `Your ${PERMIT_KIND_MAP[p.kind].name} of the ${p.power} crown lapses in ${left} days.`);
    } else {
      pushLog(state, "world", `Your ${PERMIT_KIND_MAP[p.kind].name} of the ${p.power} crown has lapsed. Renew it, or keep out of their harbours.`);
    }
  }
  state.permits = live;
}

function simulateMarkets(state: GameState) {
  for (const port of PORTS) {
    const m = state.markets[port.id]!;
    const scale = 0.5 + port.prosperity;
    for (const cid of Object.keys(m.stock)) {
      const c = COMMODITY_MAP[cid];
      if (!c) continue;
      const produced = (port.produces[cid] ?? 0) * scale;
      const consumed = (port.consumes[cid] ?? 0) * scale;
      let stock = m.stock[cid]! + produced - consumed;

      // Spoilage in a hot climate
      stock *= 1 - c.perish * (port.region === "Europe" ? 0.5 : 1);

      // Outside traders drift stock back toward equilibrium depth
      const depth = demandDepth(port, cid);
      stock += (depth - stock) * 0.012;

      m.stock[cid] = Math.max(0, stock);

      // Shocks decay
      const shock = m.shock[cid] ?? 0;
      if (shock !== 0) {
        const next = shock * 0.965;
        m.shock[cid] = Math.abs(next) < 0.005 ? 0 : next;
      }
    }
    // Prosperity and unrest drift back toward the port's natural level
    port.prosperity = clamp(port.prosperity + (0.55 - port.prosperity) * 0.002, 0.12, 1);
  }
}

/** NPC firms arbitrage the same price model the player uses. */
function simulateNpcTrade(state: GameState, rand: () => number) {
  for (let i = 0; i < 6; i++) {
    const from = PORTS[Math.floor(rand() * PORTS.length)]!;
    const to = PORTS[Math.floor(rand() * PORTS.length)]!;
    if (from.id === to.id) continue;
    const cids = Object.keys(from.produces);
    if (!cids.length) continue;
    const cid = cids[Math.floor(rand() * cids.length)]!;
    const buy = priceOf(state, from.id, cid, from);
    const sell = priceOf(state, to.id, cid, to);
    if (sell.sell < buy.buy * 1.25) continue;
    const qty = Math.min(30, (state.markets[from.id]!.stock[cid] ?? 0) * 0.05);
    if (qty < 1) continue;
    state.markets[from.id]!.stock[cid] = Math.max(0, state.markets[from.id]!.stock[cid]! - qty);
    state.markets[to.id]!.stock[cid] = (state.markets[to.id]!.stock[cid] ?? 0) + qty * 0.9;
  }
}

function simulateBusinesses(state: GameState) {
  for (const b of state.businesses) {
    const type = BUSINESS_MAP[b.typeId]!;
    const port = PORT_MAP[b.portId]!;
    const income = type.yield * b.level * (0.55 + port.prosperity) * (0.6 + port.security * 0.5);
    state.cash += Math.round(income - type.upkeep * b.level);
  }
}

function simulateLoans(state: GameState) {
  for (const loan of state.loans) {
    loan.principal = Math.round(loan.principal * (1 + loan.rate / 365));
    if (state.day === loan.dueDay) {
      pushLog(state, "money", `A loan of ${Math.round(loan.principal)} gold falls due today. The lender's clerk is waiting.`);
    }
    if (state.day > loan.dueDay && (state.day - loan.dueDay) % 30 === 0) {
      state.reputation = clamp(state.reputation - 3, -100, 100);
      pushLog(state, "money", `Your overdue debt is talked of on the exchange. Your credit suffers.`);
    }
  }
}

/** The chandler's note compounds every week (a fifth of the monthly rate) and nobody forgets it. */
function simulateDebt(state: GameState) {
  if (state.debt <= 0) return;
  if (state.day % 7 !== 0) return;
  const interest = Math.round(state.debt * state.debtRate);
  state.debt += interest;
  state.reputation = clamp(state.reputation - 0.4, -100, 100);
  pushLog(state, "money", `The note against your hull swells by ${interest} gold. ${Math.round(state.debt)} now owing.`);
}

function simulateCrew(state: GameState, rand: () => number) {
  dailyLearning(state);

  for (const m of state.crew) {
    const ship = state.ships.find((x) => x.id === m.shipId);
    const atSea = !!ship?.voyage;

    // Men off the watch bill rest: they mend and steady faster than the posted hands.
    const idle = ship ? !postOf(ship, m.id) : true;
    const rest = idle ? 1.8 : 1;

    // Health mends of its own accord — faster in harbour, slower in a wet berth.
    m.health = clamp(m.health + (atSea ? 0.25 : 1.1) * rest * traitMult(m.traits, "healthRegen"), 0, 100);

    // A quiet berth recovers a man's temper.
    m.morale = clamp(m.morale + (atSea ? 0.2 : 0.8) * rest * traitMult(m.traits, "moraleGain"), 0, 100);
    // Temperament: a marginal daily drift up or down.
    m.morale = clamp(m.morale + (traitMult(m.traits, "morale") - 1) * 1.2, 0, 100);

    // A man's spirits can never outrun his body.
    m.morale = clamp(Math.min(m.morale, m.health), 0, 100);
  }

  // Nobody serves a captain who keeps every piece of eight.
  const share = clamp(state.laws.crewShare, 0, 100);
  const articleDrift = (share - 30) / 60;
  for (const m of state.crew) m.morale = clamp(m.morale + articleDrift * 0.35, 0, m.health);

  // Departures and deaths.
  for (const m of [...state.crew]) {
    if (m.health <= 0) {
      state.crew = state.crew.filter((x) => x.id !== m.id);
      unpost(state, m.id);
      pushLog(state, "peril", `${m.name} is dead. He is sewn into his hammock and put over the side.`);
    } else if (m.morale <= 0 && !state.ships.find((x) => x.id === m.shipId)?.voyage) {
      state.crew = state.crew.filter((x) => x.id !== m.id);
      unpost(state, m.id);
      pushLog(state, "world", `${m.name} takes his chest ashore and does not come back.`);
    } else if (m.morale <= 0 && rand() < 0.08) {
      state.crew = state.crew.filter((x) => x.id !== m.id);
      unpost(state, m.id);
      pushLog(state, "peril", `${m.name} deserts at the first boat, sick of your articles.`);
    }
  }
}

function unpost(state: GameState, memberId: string) {
  for (const ship of state.ships) {
    for (const [pos, id] of Object.entries(ship.assignments ?? {})) {
      if (id === memberId) delete ship.assignments[pos as keyof typeof ship.assignments];
    }
  }
}

function posted(state: GameState, ship: Ship, position: keyof Ship["assignments"]) {
  const id = ship.assignments?.[position];
  return id ? state.crew.find((m) => m.id === id) : undefined;
}

/** Feeding, physicking and mending, done by the men whose trade it is. */
function simulateStores(state: GameState, ship: Ship, rand: () => number) {
  const roster = crewOfShip(state, ship);
  const cook = posted(state, ship, "cook");
  const surgeon = posted(state, ship, "surgeon");
  const carpenter = posted(state, ship, "carpenter");

  // A good cook stretches the barrels.
  const thrift = cook ? 1 - Math.min(0.3, cook.skills.cooking / 330) : 1;
  const want = dailyAppetite(state, ship) * thrift;
  const had = drawStores(ship, [...MEDICINE_IDS.filter((id) => id === "rum"), ...suppliesOrder()], want);
  const ratio = want > 0 ? had / want : 1;

  if (ratio >= 0.99) {
    ship.hunger = 0;
    const fed = cook ? 0.5 + effSkill(cook, "cooking") / 220 : 0.15;
    for (const m of roster) m.morale = clamp(m.morale + fed, 0, m.health);
    ship.morale = clamp(ship.morale + fed * 0.6, 0, 100);
  } else {
    // Short commons bite harder each day they last.
    ship.hunger = (ship.hunger ?? 0) + 1;
    const bite = (1 - ratio) * (1.5 + ship.hunger * 1.2);
    for (const m of roster) {
      m.morale = clamp(m.morale - bite, 0, m.health);
      if (ship.hunger > 2) m.health = clamp(m.health - bite * 0.5, 0, 100);
    }
    ship.morale = clamp(ship.morale - bite, 0, 100);
    if (ship.hunger === 1 || ship.hunger % 3 === 0) {
      pushLog(state, "peril", `${ship.name}: the stores will not stretch. ${Math.round((1 - ratio) * 100)}% of the mess went hungry.`);
    }
  }

  // Drink aboard is worth a point of temper.
  if (spiritsAboard(ship) > 2) for (const m of roster) m.morale = clamp(m.morale + 0.3, 0, m.health);

  // The surgeon works his stores into the sick.
  const hurt = roster.filter((m) => m.health < 100);
  if (surgeon && hurt.length) {
    const used = drawStores(ship, MEDICINE_IDS, Math.min(hurt.length * 0.4, 3));
    if (used > 0) {
      const cure = (0.6 + effSkill(surgeon, "medicine") / 60) * (used / Math.max(0.1, hurt.length * 0.4));
      for (const m of hurt) m.health = clamp(m.health + cure, 0, 100);
    }
  }

  // The carpenter works his stores into the ship.
  const damage = 200 - ship.hull - ship.sails;
  if (carpenter && damage > 0.5) {
    const used = drawStores(ship, SALVAGE_IDS, Math.min(1.2, damage / 25));
    if (used > 0) {
      const mend = used * (2.5 + effSkill(carpenter, "craftsmanship") / 22);
      const toSails = ship.sails < ship.hull ? mend * 0.65 : mend * 0.35;
      ship.sails = clamp(ship.sails + toSails, 0, 100);
      ship.hull = clamp(ship.hull + (mend - toSails), 0, 100);
    }
  }

  if (rand() < 0.02 && roster.length) {
    const victim = roster[Math.floor(rand() * roster.length)]!;
    victim.health = clamp(victim.health - (4 + rand() * 12) / traitMult(victim.traits, "healthRegen"), 0, 100);
    pushLog(state, "peril", `${victim.name} is taken bad with fever aboard ${ship.name}.`);
  }
}

function suppliesOrder() {
  return SUPPLY_ORDER;
}

/** Days a shipper will wait past the day named before he writes you off. */
export const CONTRACT_GRACE = 12;

function expireQuests(state: GameState) {
  for (const q of state.quests) {
    if (!q.accepted) continue;
    if (state.day === q.dueDay + 1) {
      pushLog(state, "world", `The contract "${q.title}" is past its day. It will pay less now, and in ${CONTRACT_GRACE} days it will not pay at all.`);
    }
    if (state.day === q.dueDay + CONTRACT_GRACE) {
      // Time run out: the seal is broken, the goods fall to you, and your name
      // is worse for it than if you had said so honestly at the outset.
      if (q.kind === "cargo" && q.cid && q.qty) {
        for (const ship of state.ships) {
          if (ship.locked?.[q.cid]) {
            releaseLocked(ship, q.cid, q.qty, false);
            if (ship.contraband?.[q.cid]) {
              const left = (ship.contraband[q.cid] ?? 0) - q.qty;
              if (left > 0.01) ship.contraband[q.cid] = left;
              else delete ship.contraband[q.cid];
            }
            break;
          }
        }
      }
      {
        const hit = contractPenalty(q.standing, true);
        adjustReputation(state, hit, `Let "${q.title}" run out of time`, PORT_MAP[q.portId]?.power);
        addPortStanding(state, q.portId, hit * 2, `let "${q.title}" run out of time`);
        const power = q.faction ?? PORT_MAP[q.portId]?.power;
        if (power) addFactionStanding(state, power, hit, "Let a contract lapse");
      }
      pushLog(
        state,
        "world",
        `The shipper at ${PORT_MAP[q.portId]?.name ?? "the quay"} has written off "${q.title}". No gold will be paid, and the goods are yours by default — as is the talk.`,
      );
      if (state.trackedQuestId === q.id) delete state.trackedQuestId;
    }
  }
  state.quests = state.quests.filter(
    (q) => (q.accepted ? state.day < q.dueDay + CONTRACT_GRACE : q.dueDay > state.day),
  );
}

function simulateShips(state: GameState, rand: () => number) {
  for (const ship of state.ships) {
    const cls = SHIP_CLASS_MAP[ship.classId]!;
    // Wages and upkeep
    // Wages are settled weekly; upkeep is a daily bleed.
    if (state.day % 7 === 0) {
      const named = state.crew.filter((m) => m.shipId === ship.id);
      const hands = Math.max(0, ship.crew - named.length);
      const wages = hands * HAND_WEEKLY_WAGE + named.reduce((sum, m) => sum + m.wage, 0);
      if (wages > 0) {
        state.cash -= Math.round(wages);
        pushLog(state, "money", `Wages paid aboard ${ship.name}: ${Math.round(wages)} gold for the week.`);
      }
    }
    state.cash -= Math.round(cls.upkeep * 0.35);

    if (!ship.voyage) {
      ship.morale = clamp(ship.morale + 0.4, 0, 100);
      dockRepairs(state, ship);
      // The rudder is spinning and a course is set: she weighs anchor.
      if (ship.underway && ship.course) {
        const plan = planVoyage(state, ship, ship.course);
        if (plan.blocked) {
          ship.underway = false;
          pushLog(state, "voyage", `${ship.name} cannot sail: ${plan.blocked.toLowerCase()}`);
        } else {
          beginVoyage(state, ship, ship.course);
        }
      }
      continue;
    }

    // At sea: the day's wind decides how much water she puts under her.
    const wind = 0.62 + rand() * 0.72;
    ship.voyage.wind = wind;
    const runNm = effectiveSpeed(ship) * 24 * wind;
    ship.voyage.progressNm = (ship.voyage.progressNm ?? 0) + runNm;
    const leftNm = Math.max(0, ship.voyage.distanceNm - ship.voyage.progressNm);
    ship.voyage.daysLeft = Math.max(0, Math.ceil(leftNm / Math.max(1, effectiveSpeed(ship) * 24)));
    simulateStores(state, ship, rand);
    // Working wear: a good carpenter keeps ahead of it.
    const wear = 1 - Math.min(0.55, bannerStats(state).craftsmanship / 160);
    ship.hull = clamp(ship.hull - 0.35 * wear, 0, 100);
    ship.sails = clamp(ship.sails - 0.55 * wear, 0, 100);

    if (suppliesAboard(ship) <= 0 && rand() < 0.1) {
      ship.crew = Math.max(1, ship.crew - 1);
      pushLog(state, "peril", `${ship.name}: a hand is dead of want and the rest are muttering.`);
    }

    // Cargo spoilage
    for (const [cid, qty] of Object.entries(ship.cargo)) {
      const c = COMMODITY_MAP[cid]!;
      if (c.perish > 0) {
        const left = qty * (1 - c.perish * 2);
        ship.cargo[cid] = left < 0.5 ? 0 : left;
        if (ship.cargo[cid] === 0) delete ship.cargo[cid];
      }
    }

    // Storms
    const stormChance = 0.012 + hurricaneFactor(state.day) * 0.02;
    if (rand() < stormChance) {
      const dmg = 4 + rand() * 18;
      ship.hull = clamp(ship.hull - dmg, 0, 100);
      ship.sails = clamp(ship.sails - dmg * 1.2, 0, 100);
      ship.voyage.progressNm = Math.max(0, ship.voyage.progressNm - runNm * 0.5);
      ship.voyage.daysLeft += 1;
      ship.morale = clamp(ship.morale - 5, 0, 100);
      pushLog(state, "peril", `${ship.name} runs into heavy weather: ${Math.round(dmg)} points of damage and a day lost.`);
      if (ship.hull <= 0) {
        pushLog(state, "peril", `${ship.name} founders with all her cargo. Boats picked up what men they could.`);
      }
    }

    // The lookout's bubble only raises marks; nothing is settled until the
    // captain steers for one and comes up with it.
    const raised = scanSeaEvents(state, ship, rand);
    if (raised)
      pushLog(state, "voyage", `${ship.name}: ${raised.text} The master marks it on the chart.`);

    if (ship.voyage.progressNm >= ship.voyage.distanceNm) {
      arrive(state, ship);
    }
  }

  // Remove sunk ships
  const sunk = state.ships.filter((s) => s.hull <= 0);
  if (sunk.length) {
    state.ships = state.ships.filter((s) => s.hull > 0);
    if (!state.ships.some((s) => s.id === state.activeShipId) && state.ships[0]) {
      state.activeShipId = state.ships[0].id;
    }
  }
}

/** Lay her on a course and get her under way this day. */
export function beginVoyage(state: GameState, ship: Ship, dest: Destination) {
  const plan = planVoyage(state, ship, dest);
  if (plan.blocked) return;
  ship.voyage = {
    from: ship.voyage || ship.station ? "" : ship.portId,
    to: dest.portId ?? "",
    fromLat: plan.from.lat,
    fromLon: plan.from.lon,
    toLat: dest.lat,
    toLon: dest.lon,
    label: dest.label,
    totalDays: plan.days,
    daysLeft: plan.days,
    distanceNm: plan.distanceNm,
    path: plan.path,
    progressNm: 0,
  };
  pushLog(
    state,
    "voyage",
    `${ship.name} weighs anchor for ${dest.label} — ${plan.distanceNm} sea miles, some ${plan.days} days.`,
  );
}

function arrive(state: GameState, ship: Ship) {
  const v = ship.voyage!;
  const to = v.to ? PORT_MAP[v.to] : undefined;
  delete ship.voyage;
  delete ship.course;
  ship.underway = false;
  if (to && portBanned(state, to.id)) {
    const fine = state.fines?.[to.id] ?? banFine(to);
    state.fines = { ...(state.fines ?? {}), [to.id]: fine };
    ship.station = { lat: v.toLat, lon: v.toLon, label: `Roadstead off ${to.name}` };
    pushLog(
      state,
      "voyage",
      `${ship.name} raises ${to.name}, and the guard boat turns her back: you are not welcome here until a fine of ${fine} gold is paid. She lies off in the roadstead.`,
    );
  } else if (to && dockBlocked(state, to.power)) {
    ship.station = { lat: v.toLat, lon: v.toLon, label: `Roadstead off ${to.name}` };
    pushLog(state, "voyage", `${ship.name} reaches ${to.name}, but without a permit to dock the harbour refuses her. She lies in the roadstead offshore.`);
  } else if (to) {
    ship.portId = to.id;
    delete ship.station;
    state.cash -= to.portFee;
    ship.morale = clamp(ship.morale + 4, 0, 100);
    pushLog(state, "voyage", `${ship.name} comes to anchor at ${to.name}. Port dues of ${to.portFee} gold paid.`);
    inspectAtDock(state, ship, to);
  } else {
    ship.station = { lat: v.toLat, lon: v.toLon, label: v.label };
    pushLog(state, "voyage", `${ship.name} raises her mark at ${v.label} and lies to under easy sail.`);
    // Coming up with a mark on the water is the whole of the business.
    const mark = (state.seaEvents ?? [])
      .filter((e) => !e.done && nmBetween({ lat: v.toLat, lon: v.toLon }, e) < 25)
      .sort((a, b) => nmBetween({ lat: v.toLat, lon: v.toLon }, a) - nmBetween({ lat: v.toLat, lon: v.toLon }, b))[0];
    if (mark) {
      mark.seen = true;
      encounterFromEvent(state, ship, mark);
    }
  }
}

/**
 * The customs house takes an interest in strangers it does not like. Sealed
 * contraband in the hold of a poorly regarded captain is found, taken, and paid
 * for twice: once in gold, once in the ruin of the contract.
 */
function inspectAtDock(state: GameState, ship: Ship, port: Port) {
  const sealed = Object.entries(ship.contraband ?? {}).filter(([, q]) => q > 0.01);
  if (!sealed.length) return;
  const standing = portStanding(state, port.id);
  if (standing >= 0) return;
  const chance = clamp(0.12 + (-standing / 100) * 0.55, 0, 0.75);
  if (Math.random() >= chance) return;

  let value = 0;
  for (const [cid, qty] of sealed) {
    value += (COMMODITY_MAP[cid]?.base ?? 20) * qty;
    releaseLocked(ship, cid, qty, true);
    delete ship.contraband![cid];
  }
  const fine = Math.round(value * 0.6 + 200);
  state.cash -= fine;
  const lost = state.quests.filter((q) => q.accepted && q.black);
  state.quests = state.quests.filter((q) => !(q.accepted && q.black));
  for (const q of lost) if (state.trackedQuestId === q.id) delete state.trackedQuestId;
  addPortStanding(state, port.id, -5, "caught landing contraband");
  addFactionStanding(state, port.power, -4, "Caught with contraband");
  addInfamy(state, 8, `Taken with contraband at ${port.name}`);
  pushLog(
    state,
    "world",
    `Customs officers at ${port.name} put a boat alongside and open your hatches. The sealed goods are condemned and carried off, a fine of ${fine} gold is levied, and ${lost.length ? `${lost.length} black contract${lost.length === 1 ? "" : "s"} come${lost.length === 1 ? "s" : ""} to nothing` : "your name is the worse for it"}.`,
  );
}

function snapshotPrices(state: GameState) {
  for (const port of PORTS) {
    const m = state.markets[port.id]!;
    for (const cid of Object.keys(m.stock)) {
      const p = priceOf(state, port.id, cid, port);
      const h = (m.history[cid] ??= []);
      h.push(Math.round(p.unit));
      if (h.length > 120) h.shift();
    }
  }
}

/** In harbour the hands work on her, consuming timber, canvas, cordage and pitch from the hold. */
const REPAIR_STORES: Record<string, "hull" | "sails"> = {
  timber: "hull",
  pitch: "hull",
  canvas: "sails",
  cordage: "sails",
};

function dockRepairs(state: GameState, ship: Ship) {
  if (ship.hull >= 100 && ship.sails >= 100) return;
  const skill = 0.6 + bannerStats(state).craftsmanship / 90;
  for (const [cid, target] of Object.entries(REPAIR_STORES)) {
    const have = ship.cargo[cid] ?? 0;
    if (have < 0.2) continue;
    const need = target === "hull" ? 100 - ship.hull : 100 - ship.sails;
    if (need <= 0.1) continue;
    const used = Math.min(have, 0.6, need / 6);
    ship.cargo[cid] = have - used;
    if (ship.cargo[cid]! < 0.05) delete ship.cargo[cid];
    const gain = used * 6 * skill;
    if (target === "hull") ship.hull = clamp(ship.hull + gain, 0, 100);
    else ship.sails = clamp(ship.sails + gain, 0, 100);
  }
}
