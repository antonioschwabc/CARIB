import { COMMODITY_MAP } from "../data/commodities";
import type { GameState, MarketState, Port } from "../types";
import { clamp, money as money2 } from "./util";
import { portEdge } from "./standing";
import { commodityPolicy } from "./policy";

/** Baseline stock a port wants on hand: 40 days of throughput. */
export function demandDepth(port: Port, cid: string): number {
  const flow = (port.produces[cid] ?? 0) + (port.consumes[cid] ?? 0);
  const base = flow > 0 ? flow * 40 : 12;
  const c = COMMODITY_MAP[cid];
  // Small measures mean more pieces on the quay for the same tonnage.
  const unitScale = clamp(0.5 / Math.max(0.02, c?.tons ?? 0.2), 1, 8);
  // A great entrepôt keeps far deeper stocks on the quay than a fishing station.
  const levelScale = 0.45 + (port.level ?? 3) * 0.22;
  return Math.max(8, base * (0.6 + port.prosperity) * unitScale * levelScale);
}

export interface PriceBreakdown {
  unit: number;
  buy: number;
  sell: number;
  scarcity: number;
  shock: number;
  tariff: number;
  ratio: number;
  reasons: string[];
  /** The quotation worked out step by step, for the player to read. */
  steps: { label: string; text: string }[];
  /** The same, for what the buyer will actually hand over. No duty is charged on an export. */
  sellSteps: { label: string; text: string }[];
  legal: boolean;
}

export function priceOf(state: GameState, portId: string, cid: string, port: Port): PriceBreakdown {
  const c = COMMODITY_MAP[cid]!;
  const market = state.markets[portId]!;
  const stock = market.stock[cid] ?? 0;
  const depth = demandDepth(port, cid);
  const ratio = clamp(stock / depth, 0.05, 4);

  // Scarcity curve: half stock ~ +45% price, double stock ~ −30%.
  const scarcity = Math.pow(1 / ratio, 0.55 * c.volatility);
  const shock = market.shock[cid] ?? 0;
  const prosperityLift = 0.85 + port.prosperity * 0.3;
  const producer = port.produces[cid] ? 0.82 : 1;
  const consumer = port.consumes[cid] ? 1.08 : 1;

  const unit = c.base * scarcity * (1 + shock) * prosperityLift * producer * consumer;

  const policy = commodityPolicy(state, port, cid);
  const legal = !(c.illegalFor ?? []).includes(port.power);
  const smuggleDiscount = legal ? 1 : 0.78;

  // A known face is quoted a little kinder; a disliked one, a little harder.
  const edge = portEdge(state, portId).price;
  const reasons: string[] = [];
  if (Math.abs(edge) > 0.004) {
    reasons.push(
      `${edge > 0 ? "Your standing here" : "Your poor standing here"} moves the quotation by ${edge > 0 ? "" : "+"}${Math.round(-edge * 100)}% on purchases`,
    );
  }
  if (ratio < 0.6)
    reasons.push(
      `Short supply: only ${Math.round(ratio * 100)}% of normal stock (+${Math.round((scarcity - 1) * 100)}%)`,
    );
  else if (ratio > 1.6)
    reasons.push(
      `Glutted market: ${Math.round(ratio * 100)}% of normal stock (${Math.round((scarcity - 1) * 100)}%)`,
    );
  if (Math.abs(shock) > 0.03)
    reasons.push(
      `${shock > 0 ? "Disruption" : "Windfall"} in this market: ${shock > 0 ? "+" : ""}${Math.round(shock * 100)}%`,
    );
  if (port.produces[cid]) reasons.push("Produced locally (−18%)");
  if (port.consumes[cid]) reasons.push("Consumed locally (+8%)");
  if (!legal) reasons.push("Contraband here — sold below the counter and taxed by risk");
  for (const n of policy.notes) reasons.push(n);
  if (port.tariff > 0.15)
    reasons.push(`Heavy tariff on purchases (+${Math.round(port.tariff * 100)}%)`);

  const pc = (m: number) => `${m >= 1 ? "+" : ""}${Math.round((m - 1) * 100)}%`;
  const steps: { label: string; text: string }[] = [
    { label: "Standing price", text: money2(c.base) },
    { label: `Supply ${Math.round(ratio * 100)}% of normal`, text: pc(scarcity) },
  ];
  if (Math.abs(shock) > 0.005) steps.push({ label: shock > 0 ? "Disruption" : "Windfall", text: pc(1 + shock) });
  steps.push({ label: `Prosperity of the port`, text: pc(prosperityLift) });
  if (port.produces[cid]) steps.push({ label: "Produced here", text: pc(producer) });
  if (port.consumes[cid]) steps.push({ label: "Eaten here", text: pc(consumer) });
  if (port.tariff > 0) steps.push({ label: "Harbour tariff", text: pc(1 + port.tariff) });
  if (Math.abs(policy.mult - 1) > 0.005)
    steps.push({ label: policy.notes[0] ?? "Crown policy", text: pc(policy.mult) });
  if (!legal) steps.push({ label: "Contraband risk", text: pc(1.1) });
  if (Math.abs(edge) > 0.004) steps.push({ label: "Your standing here", text: pc(1 - edge) });
  steps.push({ label: "Chandler's margin", text: pc(1.04) });

  // What the buyer hands over. Duty, tariff and crown edicts are levied on
  // goods coming ashore, never on goods going out — they cannot flatter a sale.
  const sellSteps: { label: string; text: string }[] = [
    { label: "Standing price", text: money2(c.base) },
    { label: `Supply ${Math.round(ratio * 100)}% of normal`, text: pc(scarcity) },
  ];
  if (Math.abs(shock) > 0.005) sellSteps.push({ label: shock > 0 ? "Disruption" : "Windfall", text: pc(1 + shock) });
  sellSteps.push({ label: "Prosperity of the port", text: pc(prosperityLift) });
  if (port.produces[cid]) sellSteps.push({ label: "Produced here", text: pc(producer) });
  if (port.consumes[cid]) sellSteps.push({ label: "Eaten here", text: pc(consumer) });
  if (!legal) sellSteps.push({ label: "Sold below the counter", text: pc(smuggleDiscount) });
  if (Math.abs(edge) > 0.004) sellSteps.push({ label: "Your standing here", text: pc(1 + edge) });
  sellSteps.push({ label: "Buyer's margin", text: pc(0.93) });

  return {
    unit,
    steps,
    sellSteps,
    buy: Math.max(
      1,
      Math.round(unit * (1 + port.tariff) * 1.04 * policy.mult * (legal ? 1 : 1.1) * (1 - edge)),
    ),
    sell: Math.max(1, Math.round(unit * 0.93 * smuggleDiscount * (1 + edge))),
    scarcity,
    shock,
    tariff: port.tariff,
    ratio,
    reasons,
    legal,
  };
}

export type Trend = "up" | "down" | "flat";

export function trendOf(market: MarketState, cid: string): Trend {
  const h = market.history[cid];
  if (!h || h.length < 2) return "flat";
  const a = h[h.length - 2]!;
  const b = h[h.length - 1]!;
  if (b > a * 1.04) return "up";
  if (b < a * 0.96) return "down";
  return "flat";
}

export function supplyLabel(ratio: number): string {
  if (ratio < 0.35) return "Famine";
  if (ratio < 0.7) return "Scarce";
  if (ratio < 1.4) return "Adequate";
  if (ratio < 2.2) return "Plentiful";
  return "Glutted";
}

/** Marginal price impact of moving `qty` units: large trades move the market. */
export function tradeImpact(port: Port, cid: string, qty: number, stock: number) {
  const depth = demandDepth(port, cid);
  return clamp(qty / Math.max(depth, 1), 0, 3) * (stock >= 0 ? 1 : 1);
}
