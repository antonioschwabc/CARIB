import { makeRecruit } from "../data/crew";
import { PORTS } from "../data/ports";
import type { GameState, SeaEventKind, Ship, SkillId } from "../types";
import { pushLog } from "./events";
import { shareGold, shareXp } from "./progress";
import { lodgings } from "./shipStats";
import { oddsFor } from "./skillcheck";
import { MEDICINE_IDS, SALVAGE_IDS, SUPPLY_IDS, drawStores } from "./stores";
import { readBooks, tally } from "./outcome";
import { clamp } from "./util";


/**
 * Everything afloat that is not a fight. Combat is a module of its own and is
 * not written yet — nothing here draws a gun.
 */

export interface EncEffects {
  /** coin, before the articles take their share */
  gold?: [number, number];
  /** units of carpenter's stores taken aboard */
  salvage?: [number, number];
  /** units of victuals */
  supplies?: [number, number];
  /** units of physic */
  medicine?: [number, number];
  /** hull / canvas points lost */
  hull?: [number, number];
  sails?: [number, number];
  /** days added to the passage */
  days?: [number, number];
  /** points of health across the company */
  health?: [number, number];
  /** points of temper across the company */
  morale?: [number, number];
  /** standing with the world */
  reputation?: number;
  /** experience shared out, in one discipline or all */
  xp?: { skill: SkillId | "all"; amount: number };
  /** hands taken aboard, if there is a berth */
  recruits?: number;
}

export interface EncOption {
  id: string;
  label: string;
  /** the trade the attempt is judged by; absent means no roll at all */
  skill?: SkillId;
  /** difficulty class, 0-100 */
  dc?: number;
  ok: string;
  bad?: string;
  gain?: EncEffects;
  loss?: EncEffects;
}

export interface EncDef {
  kind: SeaEventKind;
  weight: number;
  title: string;
  lines: string[];
  life: [number, number];
  options: EncOption[];
}

const IGNORE: EncOption = {
  id: "ignore",
  label: "Hold your course and leave it astern",
  ok: "She keeps her course and leaves it astern.",
};

export const ENCOUNTERS: EncDef[] = [
  {
    kind: "wreck",
    weight: 1.1,
    title: "Wreckage on the water",
    lines: [
      "Broken spars and a swamped boat turn slowly in the swell.",
      "A hull lies low and abandoned, her masts gone by the board.",
      "Casks and canvas drift in a long slick — something went down here.",
    ],
    life: [8, 24],
    options: [
      IGNORE,
      {
        id: "boat",
        label: "Send the boat and take off what floats",
        ok: "The boat comes back low in the water with cordage, canvas and good timber.",
        gain: { salvage: [3, 9], xp: { skill: "craftsmanship", amount: 90 }, days: [0, 1] },
      },
      {
        id: "dive",
        label: "Dive the hull for her strongbox",
        skill: "craftsmanship",
        dc: 55,
        ok: "A man goes down twice and comes up with the master's box, still locked and still heavy.",
        bad: "The wreck shifts on the swell and the boat is stove in against her side.",
        gain: { gold: [400, 1600], salvage: [1, 4], xp: { skill: "craftsmanship", amount: 140 } },
        loss: { hull: [3, 10], health: [2, 8], days: [1, 1] },
      },
      {
        id: "chart",
        label: "Read the set of the drift and log the reef that took her",
        skill: "navigation",
        dc: 45,
        ok: "You fix the shoal that killed her and lay it on your chart. The passage runs cleaner for it.",
        bad: "Two hours are lost sounding and nothing certain comes of it.",
        gain: { xp: { skill: "navigation", amount: 160 }, reputation: 0.5 },
        loss: { days: [1, 1] },
      },
    ],
  },
  {
    kind: "flotsam",
    weight: 1,
    title: "Flotsam",
    lines: [
      "Barrels ride the swell, lashed together and still sound.",
      "A raft of shattered timber and cordage drifts past.",
    ],
    life: [6, 16],
    options: [
      IGNORE,
      {
        id: "hook",
        label: "Boat-hook what you can from the rail",
        ok: "A few casks come over the side without so much as backing a topsail.",
        gain: { salvage: [1, 3], supplies: [0, 2] },
      },
      {
        id: "sort",
        label: "Heave to and sort the lot properly",
        skill: "logistics",
        dc: 40,
        ok: "Everything sound is struck below and stowed where it belongs.",
        bad: "Half of it is rotten through and the hour is wasted.",
        gain: { salvage: [2, 5], supplies: [1, 3], xp: { skill: "logistics", amount: 100 } },
        loss: { days: [1, 1] },
      },
      {
        id: "broach",
        label: "Broach a cask and see what the sea has sent",
        skill: "cooking",
        dc: 35,
        ok: "Salt pork in good pickle — the mess eats well tonight.",
        bad: "Spoiled. The smell alone sours the whole watch.",
        gain: { supplies: [2, 5], morale: [1, 3] },
        loss: { morale: [1, 4] },
      },
    ],
  },
  {
    kind: "derelict",
    weight: 0.8,
    title: "A derelict, abandoned",
    lines: [
      "A brig lies to with her helm lashed and no soul on deck.",
      "An empty hull rolls with her boats gone and her hatches open.",
    ],
    life: [6, 16],
    options: [
      IGNORE,
      {
        id: "strip",
        label: "Board her and strip what stores remain",
        ok: "Her cable tier and bread room give up a good deal before you leave her.",
        gain: { salvage: [3, 8], supplies: [1, 5], xp: { skill: "logistics", amount: 90 }, days: [1, 1] },
      },
      {
        id: "physic",
        label: "Search the cabin for the surgeon's chest",
        skill: "medicine",
        dc: 50,
        ok: "The chest is under the cot: bandage, spirit and a fair stock of physic.",
        bad: "There is fever in that cabin, and one of the party carries it back aboard.",
        gain: { medicine: [2, 6], xp: { skill: "medicine", amount: 130 } },
        loss: { health: [4, 12], morale: [1, 4] },
      },
      {
        id: "tow",
        label: "Rig a tow and work her toward the nearest road",
        skill: "craftsmanship",
        dc: 65,
        ok: "You get a hawser to her and sell the hull on for what a hull is worth.",
        bad: "The tow parts in the night and she goes down astern of you.",
        gain: { gold: [900, 3200], xp: { skill: "craftsmanship", amount: 180 }, days: [2, 3] },
        loss: { sails: [3, 9], days: [2, 2], morale: [1, 4] },
      },
    ],
  },
  {
    kind: "castaways",
    weight: 0.8,
    title: "Men on a raft",
    lines: [
      "Three men wave a shirt from a raft of hatch-covers.",
      "A ship's boat pulls toward you, low and full of burnt, silent men.",
    ],
    life: [4, 10],
    options: [
      IGNORE,
      {
        id: "take",
        label: "Take them aboard and give them water",
        ok: "They come over the side on their hands and knees, and they remember it.",
        gain: { recruits: 1, reputation: 2, morale: [1, 3], xp: { skill: "charisma", amount: 90 } },
        loss: { supplies: [1, 3] },
      },
      {
        id: "physick",
        label: "Physic the worst of them before they are moved",
        skill: "medicine",
        dc: 45,
        ok: "Two are saved who would not have lived the night, and they say so ashore.",
        bad: "One dies on the deck under your hands, and the watch is quiet after.",
        gain: { recruits: 1, reputation: 3, xp: { skill: "medicine", amount: 150 } },
        loss: { medicine: [1, 3], morale: [2, 5] },
      },
      {
        id: "question",
        label: "Question them about what sank them",
        skill: "charisma",
        dc: 40,
        ok: "They talk freely: a bearing, a name, and where the cargo went.",
        bad: "They are past talking sense, and the hour is lost.",
        gain: { gold: [120, 600], xp: { skill: "charisma", amount: 120 }, reputation: 1 },
        loss: { days: [1, 1] },
      },
    ],
  },
  {
    kind: "merchant",
    weight: 1.2,
    title: "A merchantman under easy sail",
    lines: [
      "A deep-laden merchantman stands along, showing her colours plainly.",
      "A fat trader wallows under topsails, in no hurry at all.",
    ],
    life: [4, 10],
    options: [
      IGNORE,
      {
        id: "speak",
        label: "Speak her and swap the news",
        ok: "Colours dipped both ways, a shouted word on prices, and each stands on.",
        gain: { xp: { skill: "charisma", amount: 70 }, reputation: 0.5 },
      },
      {
        id: "trade",
        label: "Heave to and deal across the rail",
        skill: "charisma",
        dc: 50,
        ok: "Her master is short of what you carry and long on coin. A tidy piece of business.",
        bad: "He knows the market better than you do and you come off worse.",
        gain: { gold: [200, 900], xp: { skill: "charisma", amount: 140 } },
        loss: { gold: [-300, -80], days: [1, 1] },
      },
      {
        id: "beg",
        label: "Ask her for stores against a note of hand",
        skill: "logistics",
        dc: 45,
        ok: "Bread, water and a keg of physic come across for paper he trusts.",
        bad: "He looks at your paper, then at your rigging, and declines.",
        gain: { supplies: [2, 6], medicine: [0, 2], xp: { skill: "logistics", amount: 110 } },
        loss: { reputation: -1, days: [1, 1] },
      },
    ],
  },
  {
    kind: "patrol",
    weight: 0.9,
    title: "A patrol on station",
    lines: [
      "A guard frigate quarters the sea lane, stopping every hull she meets.",
      "Two revenue sloops work the coast, boarding as they please.",
    ],
    life: [6, 18],
    options: [
      {
        id: "ignore",
        label: "Stand on and hope she has other business",
        ok: "She holds her station and lets you go by without a signal.",
      },
      {
        id: "papers",
        label: "Heave to and show your papers",
        ok: "The boarding officer reads, sniffs, and hands them back.",
        gain: { reputation: 1, xp: { skill: "charisma", amount: 60 } },
        loss: { days: [0, 1] },
      },
      {
        id: "outsail",
        label: "Crowd sail and put her under the horizon",
        skill: "navigation",
        dc: 55,
        ok: "You weather her in the squall line and she is hull-down by dusk.",
        bad: "She holds you all day and you lose the wind entirely.",
        gain: { xp: { skill: "navigation", amount: 150 } },
        loss: { sails: [2, 7], days: [1, 2], reputation: -1 },
      },
      {
        id: "sweeten",
        label: "Sweeten the boarding officer",
        skill: "charisma",
        dc: 60,
        ok: "A civil word, a small purse, and the hold is never opened at all.",
        bad: "He takes offence, and the search that follows is thorough.",
        gain: { xp: { skill: "charisma", amount: 160 } },
        loss: { gold: [-600, -150], days: [1, 1], reputation: -2 },
      },
    ],
  },
  {
    kind: "fishing",
    weight: 1,
    title: "Fishing boats on the bank",
    lines: [
      "A scatter of open boats works a shoal of fish, gulls screaming over them.",
      "Two shallops lie to their nets in the shallow green water.",
    ],
    life: [5, 14],
    options: [
      IGNORE,
      {
        id: "buy",
        label: "Buy fish off the boats",
        ok: "Fresh fish for the mess, cheap, and the men bless you for it.",
        gain: { supplies: [2, 5], morale: [1, 3] },
        loss: { gold: [-90, -20] },
      },
      {
        id: "net",
        label: "Put over your own lines while the shoal holds",
        skill: "cooking",
        dc: 40,
        ok: "The cook has them salted down before the shoal moves off.",
        bad: "Hours over the side for three small fish and a torn line.",
        gain: { supplies: [3, 7], xp: { skill: "cooking", amount: 130 } },
        loss: { days: [1, 1] },
      },
      {
        id: "pilot",
        label: "Ask the fishermen for the local water",
        skill: "scouting",
        dc: 35,
        ok: "They give you the reefs, the sets and where the guarda-costa lies. Worth a barrel of rum.",
        bad: "They will not speak to a stranger's ship, and pull away.",
        gain: { xp: { skill: "scouting", amount: 140 }, gold: [60, 300] },
      },
    ],
  },
  {
    kind: "reef",
    weight: 0.9,
    title: "Broken water ahead",
    lines: [
      "Pale green water and a line of breakers lie across the bearing.",
      "The leadsman calls shoaling water and coral shows to leeward.",
    ],
    life: [10, 30],
    options: [
      {
        id: "ignore",
        label: "Stand well off and go the long way round",
        ok: "She works round the broken water and loses only a little ground.",
        loss: { days: [0, 1] },
      },
      {
        id: "sound",
        label: "Send the boat ahead to sound the channel",
        ok: "The boat leads her through by the lead line, slowly, and safely.",
        gain: { xp: { skill: "navigation", amount: 90 } },
        loss: { days: [1, 1] },
      },
      {
        id: "thread",
        label: "Thread the reef under topsails",
        skill: "navigation",
        dc: 60,
        ok: "She goes through with coral a fathom under her keel and a day saved by it.",
        bad: "She touches, grinds, and comes off with her garboards weeping.",
        gain: { days: [-1, -1], xp: { skill: "navigation", amount: 180 } },
        loss: { hull: [6, 18], days: [1, 2], morale: [2, 6] },
      },
      {
        id: "dive",
        label: "Dive the coral heads for what earlier ships left",
        skill: "scouting",
        dc: 55,
        ok: "Iron, a fouled anchor and a scatter of coin among the coral.",
        bad: "Nothing but coral cuts and a frightened boat's crew.",
        gain: { salvage: [2, 6], gold: [100, 800], xp: { skill: "scouting", amount: 140 } },
        loss: { health: [3, 9], days: [1, 1] },
      },
    ],
  },
  {
    kind: "squall",
    weight: 0.9,
    title: "A line of squalls",
    lines: [
      "Black water and torn cloud: a squall line marches across the bearing.",
      "The glass is falling and the sea is making up ahead.",
    ],
    life: [3, 8],
    options: [
      {
        id: "ignore",
        label: "Shorten sail and ride it out",
        ok: "Reefed down, she takes it green over the bow and comes through wet but whole.",
        loss: { days: [1, 1], sails: [1, 4] },
      },
      {
        id: "bear",
        label: "Bear away and work round the weather",
        skill: "navigation",
        dc: 45,
        ok: "You skirt the black edge of it and never feel more than a heavy shower.",
        bad: "The line outruns you and catches her badly trimmed.",
        gain: { xp: { skill: "navigation", amount: 120 } },
        loss: { sails: [4, 12], hull: [2, 7], days: [1, 2] },
      },
      {
        id: "drive",
        label: "Drive her straight through",
        skill: "navigation",
        dc: 65,
        ok: "She is buried to the rail and comes out the far side with the day still in hand.",
        bad: "Canvas splits and a spar goes. It is a long night on deck.",
        gain: { days: [-1, -1], xp: { skill: "navigation", amount: 190 }, morale: [1, 3] },
        loss: { sails: [8, 20], hull: [3, 10], health: [2, 7] },
      },
      {
        id: "water",
        label: "Catch the rain and fill the water casks",
        skill: "logistics",
        dc: 40,
        ok: "Every cask and cauldron on deck: the water butt is full again by morning.",
        bad: "Awnings carry away and the casks stay half empty.",
        gain: { supplies: [2, 5], xp: { skill: "logistics", amount: 110 } },
        loss: { sails: [2, 6] },
      },
    ],
  },
  {
    kind: "becalmed",
    weight: 0.7,
    title: "A flat calm",
    lines: [
      "The sea goes to oil and the sails slat against the masts.",
      "Not a breath: she lies with her head anywhere it pleases.",
    ],
    life: [3, 7],
    options: [
      {
        id: "ignore",
        label: "Wait it out and let the men rest",
        ok: "A quiet day. Nothing done, and nothing lost but time.",
        loss: { days: [1, 1] },
        gain: { morale: [1, 2] },
      },
      {
        id: "tow",
        label: "Put the boats out and tow her head round",
        skill: "charisma",
        dc: 50,
        ok: "The boats find a cat's-paw of wind by afternoon and she draws ahead.",
        bad: "The men pull all day for nothing and hate you for it.",
        gain: { xp: { skill: "charisma", amount: 130 } },
        loss: { morale: [3, 8], days: [1, 1] },
      },
      {
        id: "mend",
        label: "Set the hands to mending while she lies still",
        skill: "craftsmanship",
        dc: 40,
        ok: "Seams payed, canvas patched, rigging set up: she is the better for the calm.",
        bad: "Little is done and the stores go into it anyway.",
        gain: { xp: { skill: "craftsmanship", amount: 140 } },
        loss: { salvage: [1, 3], days: [1, 1] },
      },
      {
        id: "read",
        label: "Read the sky for where the wind has gone",
        skill: "scouting",
        dc: 45,
        ok: "Cloud to the south-east: you have her under way hours before anyone expects it.",
        bad: "The sky tells you nothing you did not already fear.",
        gain: { days: [-1, -1], xp: { skill: "scouting", amount: 150 } },
        loss: { days: [1, 1] },
      },
    ],
  },
  {
    kind: "rumour",
    weight: 1,
    title: "Word from a passing boat",
    lines: [
      "Fishermen speak of a squadron burning plantations to leeward.",
      "A pinnace hails you with talk of a rich convoy gone by two days since.",
      "Word of raiders ashore: smoke was seen on the headland at dawn.",
    ],
    life: [6, 16],
    options: [
      IGNORE,
      {
        id: "listen",
        label: "Hear them out",
        ok: "Nothing you can act on today, but it is worth knowing.",
        gain: { xp: { skill: "scouting", amount: 70 }, reputation: 0.5 },
      },
      {
        id: "press",
        label: "Press them for the particulars",
        skill: "charisma",
        dc: 45,
        ok: "Names, bearings and a date. A man could make money out of that.",
        bad: "They close up entirely and pull away from your side.",
        gain: { gold: [150, 700], xp: { skill: "charisma", amount: 130 } },
        loss: { reputation: -0.5, days: [1, 1] },
      },
      {
        id: "verify",
        label: "Stand toward the bearing and see for yourself",
        skill: "scouting",
        dc: 50,
        ok: "The smoke is real, and so is what has been left behind on the beach.",
        bad: "An empty bearing and a day gone out of the passage.",
        gain: { salvage: [1, 4], gold: [100, 500], xp: { skill: "scouting", amount: 150 }, days: [1, 1] },
        loss: { days: [2, 2], morale: [1, 3] },
      },
    ],
  },
  {
    kind: "whales",
    weight: 0.6,
    title: "Whales on the surface",
    lines: [
      "A pod blows lazily across the bow, close enough to smell.",
      "Great backs roll alongside, keeping pace with the ship.",
    ],
    life: [3, 8],
    options: [
      IGNORE,
      {
        id: "watch",
        label: "Let the watch come up and look",
        ok: "The whole ship is on the rail, grinning like children.",
        gain: { morale: [2, 5] },
      },
      {
        id: "hunt",
        label: "Lower a boat and try for one",
        skill: "gunnery",
        dc: 65,
        ok: "A long, ugly business, but the oil alone is worth the day.",
        bad: "The boat is smashed and the men are lucky to be picked up.",
        gain: { gold: [400, 1800], supplies: [2, 6], xp: { skill: "gunnery", amount: 170 }, days: [1, 2] },
        loss: { health: [5, 14], morale: [2, 6], days: [1, 1] },
      },
      {
        id: "follow",
        label: "Follow them — they know where the bank is",
        skill: "scouting",
        dc: 45,
        ok: "They lead you over a bank thick with fish and clean water beyond.",
        bad: "They sound, and take your afternoon with them.",
        gain: { supplies: [2, 5], xp: { skill: "scouting", amount: 120 } },
        loss: { days: [1, 1] },
      },
    ],
  },

  // ---- Friendly sail ----
  {
    kind: "convoy",
    weight: 0.9,
    title: "Countrymen in company",
    lines: [
      "Three sail under colours you know stand along in loose company, and make your private signal.",
      "A convoy plods east under easy canvas, and their commodore backs a topsail for you.",
    ],
    life: [4, 9],
    options: [
      {
        id: "company",
        label: "Keep company with them a while",
        ok: "You run in their wake for a day. Nothing troubles a crowd of sail.",
        gain: { morale: [2, 4], xp: { skill: "navigation", amount: 90 } },
        loss: { days: [1, 1] },
      },
      {
        id: "trade",
        label: "Send a boat across to trade news and stores",
        skill: "charisma",
        dc: 40,
        ok: "Their purser is generous, and their master has the whole coast's gossip.",
        bad: "They have little to spare and less patience, and the boat comes back empty.",
        gain: { supplies: [2, 6], medicine: [0, 2], xp: { skill: "charisma", amount: 110 } },
        loss: { days: [0, 1] },
      },
      {
        id: "physic",
        label: "Ask their surgeon aboard",
        ok: "A capable man, and he leaves your sick berth in better order than he found it.",
        gain: { health: [4, 10], xp: { skill: "medicine", amount: 90 } },
        loss: { days: [1, 1], gold: [-160, -40] },
      },
      IGNORE,
    ],
  },
  {
    kind: "smuggler",
    weight: 0.85,
    title: "Free traders on the coast",
    lines: [
      "A low black sloop shows no colours at all and edges down toward you, very sure of herself.",
      "Two boats work a beach with no customs house in sight, and their master hails you civilly.",
    ],
    life: [3, 8],
    options: [
      {
        id: "buy",
        label: "Buy what they are carrying, no questions",
        skill: "charisma",
        dc: 48,
        ok: "A quick bargain over the gunwale, and the goods come aboard cheap.",
        bad: "He names a price for fools and will not move off it.",
        gain: { salvage: [2, 6], supplies: [1, 4], xp: { skill: "charisma", amount: 130 } },
        loss: { gold: [-900, -260] },
      },
      {
        id: "sell",
        label: "Sell them your spare stores at their price",
        ok: "They pay in old coin of three countries, and it all spends the same.",
        gain: { gold: [200, 900] },
        loss: { salvage: [1, 4] },
      },
      {
        id: "news",
        label: "Take their news of the customs houses",
        ok: "Which harbours are keen and which are asleep — worth knowing.",
        gain: { xp: { skill: "scouting", amount: 130 }, morale: [0, 2] },
      },
      IGNORE,
    ],
  },

  // ---- Hostile sail: these are settled with the guns, not with words ----
  {
    kind: "corsair",
    weight: 0.7,
    title: "A corsair bearing down",
    lines: [
      "A rakish sail alters course the moment she sees you, and there are too many men on her deck.",
      "She shows no colours until she is within two miles, and then she shows the wrong ones.",
    ],
    life: [3, 7],
    options: [],
  },
  {
    kind: "privateer",
    weight: 0.5,
    title: "A commissioned privateer",
    lines: [
      "A heavy sail with a commission aboard and a grudge against your colours runs down on you.",
      "Gun ports open along her side as she comes, and she does not answer your signal.",
    ],
    life: [3, 7],
    options: [],
  },
];


export const ENCOUNTER_MAP: Record<string, EncDef> = Object.fromEntries(
  ENCOUNTERS.map((d) => [d.kind, d]),
);

export function optionsFor(kind: SeaEventKind): EncOption[] {
  return ENCOUNTER_MAP[kind]?.options ?? [IGNORE];
}

export function optionOdds(state: GameState, opt: EncOption) {
  if (!opt.skill || opt.dc === undefined) return undefined;
  return oddsFor(state, opt.skill, opt.dc);
}

function span(rand: () => number, range: [number, number]) {
  return range[0] + rand() * (range[1] - range[0]);
}

function addCargo(ship: Ship, ids: string[], units: number, rand: () => number) {
  let left = Math.round(units);
  const taken: string[] = [];
  while (left > 0) {
    const cid = ids[Math.floor(rand() * ids.length)]!;
    ship.cargo[cid] = (ship.cargo[cid] ?? 0) + 1;
    taken.push(cid);
    left--;
  }
  return taken.length;
}

/**
 * Work one outcome into the world. `sign` is +1 for what is gained and -1 for
 * what is lost; hull, canvas and health are always harm however they are written.
 */
export function applyEffects(
  state: GameState,
  ship: Ship,
  fx: EncEffects | undefined,
  rand: () => number,
  sign: 1 | -1 = 1,
) {
  if (!fx) return;
  if (fx.gold) {
    const coin = Math.round(Math.abs(span(rand, fx.gold)));
    if (sign > 0) shareGold(state, coin);
    else state.cash = Math.max(0, state.cash - coin);
  }
  const stores = (ids: string[], range: [number, number]) => {
    const units = Math.abs(span(rand, range));
    if (sign > 0) addCargo(ship, ids, units, rand);
    else drawStores(ship, ids, units);
  };
  if (fx.salvage) stores(SALVAGE_IDS, fx.salvage);
  if (fx.supplies) stores(SUPPLY_IDS, fx.supplies);
  if (fx.medicine) stores(MEDICINE_IDS, fx.medicine);
  if (fx.hull) ship.hull = clamp(ship.hull - Math.abs(span(rand, fx.hull)), 0, 100);
  if (fx.sails) ship.sails = clamp(ship.sails - Math.abs(span(rand, fx.sails)), 0, 100);
  if (fx.days && ship.voyage)
    ship.voyage.daysLeft = Math.max(1, ship.voyage.daysLeft + Math.round(span(rand, fx.days)));
  if (fx.health) {
    const hurt = Math.abs(span(rand, fx.health));
    for (const m of state.crew.filter((c) => c.shipId === ship.id))
      m.health = clamp(m.health - hurt, 1, 100);
  }
  if (fx.morale) {
    const shift = Math.abs(span(rand, fx.morale)) * sign;
    for (const m of state.crew.filter((c) => c.shipId === ship.id))
      m.morale = clamp(m.morale + shift, 0, m.health);
    ship.morale = clamp(ship.morale + shift, 0, 100);
  }
  if (fx.reputation) state.reputation = clamp(state.reputation + fx.reputation, -100, 100);
  if (fx.xp) shareXp(state, fx.xp.skill, fx.xp.amount);
  if (fx.recruits && sign > 0) takeAboard(state, ship, fx.recruits, rand);
}

/** Men picked out of the water sign on, if there is a berth for them. */
function takeAboard(state: GameState, ship: Ship, count: number, rand: () => number) {
  const berths = lodgings(ship) - state.crew.filter((m) => m.shipId === ship.id).length;
  const port = PORTS[Math.floor(rand() * PORTS.length)]!;
  for (let i = 0; i < Math.min(count, Math.max(0, berths)); i++) {
    const m = makeRecruit(port, rand, state.day * 31 + i);
    m.shipId = ship.id;
    m.health = 45 + Math.round(rand() * 25);
    m.morale = 70;
    state.crew.push(m);
    ship.crew += 1;
    pushLog(state, "world", `${m.name} is taken out of the water and signs on aboard ${ship.name}.`);
  }
}

/** Resolve the captain's word on a mark. */
export function resolveSeaEncounter(state: GameState, optionId: string, rand: () => number) {
  const enc = state.encounter;
  if (!enc) return;
  const ship = state.ships.find((s) => s.id === enc.shipId);
  const mark = (state.seaEvents ?? []).find((e) => e.id === enc.eventId);
  if (mark) mark.done = true;
  if (!ship) {
    delete state.encounter;
    return;
  }

  const opt = optionsFor(enc.kind).find((o) => o.id === optionId);
  if (!opt) {
    delete state.encounter;
    return;
  }

  const title = enc.title ?? "A mark on the water";
  const before = readBooks(state, ship);

  if (!opt.skill || opt.dc === undefined) {
    applyEffects(state, ship, opt.gain, rand, 1);
    applyEffects(state, ship, opt.loss, rand, -1);
    pushLog(state, "voyage", `${ship.name}: ${opt.ok}`);
    state.outcome = {
      title,
      choice: opt.label,
      text: opt.ok,
      verdict: "done",
      lines: tally(before, readBooks(state, ship)),
    };
    delete state.encounter;
    return;
  }

  const odds = oddsFor(state, opt.skill, opt.dc);
  const won = rand() < odds.chance;
  if (won) {
    applyEffects(state, ship, opt.gain, rand, 1);
    pushLog(state, "voyage", `${ship.name}: ${opt.ok} (${opt.skill} ${odds.score} against a class of ${opt.dc})`);
  } else {
    applyEffects(state, ship, opt.loss, rand, -1);
    pushLog(
      state,
      "peril",
      `${ship.name}: ${opt.bad ?? "It does not come off."} (${opt.skill} ${odds.score} against a class of ${opt.dc})`,
    );
  }
  state.outcome = {
    title,
    choice: opt.label,
    text: won ? opt.ok : (opt.bad ?? "It does not come off."),
    verdict: won ? "won" : "lost",
    roll: { skill: opt.skill, score: odds.score, dc: opt.dc, chance: odds.chance },
    lines: tally(before, readBooks(state, ship)),
  };
  delete state.encounter;
}

