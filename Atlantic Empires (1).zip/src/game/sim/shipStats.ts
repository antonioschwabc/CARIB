import { COMPONENT_MAP } from "../data/shipParts";
import { SHIP_CLASS_MAP } from "../data/ships";
import { POSITION_SKILL, effSkill } from "../data/crew";
import type { CrewMember, Ship, ShipStatKey } from "../types";

export interface ShipStats {
  hull: number;
  firepower: number;
  maneuverability: number;
  scouting: number;
  cargo: number;
  speed: number;
  crewCapacity: number;
  slots: number;
  slotsUsed: number;
}

/**
 * The men aboard are worth as much as her timbers. Every skill lifts the figure
 * it belongs to by skill ÷ 2.25 percent, applied on top of the archetype base
 * and whatever is fitted. A man in his proper post lends his whole weight; the
 * rest of the hands lend three-fifths of theirs.
 */
let CREW_BY_SHIP: Record<string, CrewMember[]> = {};

/** The captain himself stands on every ship he commands, and counts in full. */
let CAPTAIN: { shipId?: string; skills: Record<string, number> } | undefined;

/** Keep the muster to hand, so any call for a ship's figures counts her crew. */
export function registerCrew(crew: CrewMember[] = []) {
  const out: Record<string, CrewMember[]> = {};
  for (const m of crew) {
    if (!m.shipId) continue;
    (out[m.shipId] ??= []).push(m);
  }
  CREW_BY_SHIP = out;
}

/** The captain's own hand, counted aboard whichever ship he walks. */
export function registerCaptain(skills: Record<string, number>, shipId?: string) {
  CAPTAIN = { skills, ...(shipId ? { shipId } : {}) };
}

const SKILLS = [
  "navigation",
  "charisma",
  "scouting",
  "craftsmanship",
  "gunnery",
  "logistics",
  "cooking",
  "medicine",
] as const;

export type CrewSkill = (typeof SKILLS)[number];

/** The ship's combined figure in each discipline, 0–99. */
export function crewSkills(ship: Ship, crew: CrewMember[]): Record<CrewSkill, number> {
  const out = Object.fromEntries(SKILLS.map((s) => [s, 0])) as Record<CrewSkill, number>;
  const posted = new Map<string, string>();
  for (const [pos, id] of Object.entries(ship.assignments ?? {})) if (id) posted.set(id, pos);
  for (const m of crew) {
    for (const s of SKILLS) {
      const post = posted.get(m.id);
      const full = post ? POSITION_SKILL[post as keyof typeof POSITION_SKILL] === s : false;
      const v = effSkill(m, s) * (full ? 1 : 0.6);
      if (v > out[s]) out[s] = v;
    }
  }
  if (CAPTAIN && (!CAPTAIN.shipId || CAPTAIN.shipId === ship.id)) {
    for (const s of SKILLS) {
      const v = CAPTAIN.skills[s] ?? 0;
      if (v > out[s]) out[s] = v;
    }
  }
  return out;
}


/** Each discipline as a fraction added to the figure it serves: skill ÷ 2.25 %. */
export function crewBoons(ship: Ship, crew: CrewMember[]) {
  const s = crewSkills(ship, crew);
  const pct = (v: number) => v / 2.25 / 100;
  return {
    speed: pct(s.navigation),
    maneuverability: pct(s.navigation * 0.5 + s.scouting * 0.5),
    scouting: pct(s.scouting),
    hull: pct(s.craftsmanship),
    firepower: pct(s.gunnery),
    cargo: pct(s.logistics),
    /** these bite on prices, morale and stores rather than on the hull */
    charisma: pct(s.charisma),
    cooking: pct(s.cooking),
    medicine: pct(s.medicine),
    skills: s,
  };
}

export function componentBonuses(ship: Ship): Record<ShipStatKey, number> {
  const out: Record<ShipStatKey, number> = {
    hull: 0,
    firepower: 0,
    maneuverability: 0,
    scouting: 0,
    cargo: 0,
    speed: 0,
  };
  for (const fitted of ship.components ?? []) {
    const def = COMPONENT_MAP[fitted.defId];
    if (!def) continue;
    out[def.stat] += def.steps[Math.min(def.steps.length, Math.max(1, fitted.level)) - 1] ?? 0;
  }
  return out;
}

/** Full derived statistics: archetype base × fitted components × the men aboard. */
export function shipStats(ship: Ship, crew?: CrewMember[]): ShipStats {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const hands = crew && crew.length ? crew : (CREW_BY_SHIP[ship.id] ?? []);
  const bonus = componentBonuses(ship);
  const boon = crewBoons(ship, hands);

  const stat = (key: ShipStatKey, base: number) =>
    base * (1 + bonus[key]) * (1 + ((boon[key as keyof typeof boon] as number) ?? 0));

  return {
    hull: Math.round(stat("hull", cls.hull)),
    firepower: Math.round(gunRating(ship) * (1 + bonus.firepower) * (1 + boon.firepower)),
    maneuverability: Math.round(stat("maneuverability", cls.maneuverability)),
    scouting: Math.round(stat("scouting", cls.scouting)),
    cargo: Math.round(stat("cargo", cls.cargo)),
    speed: Math.round(stat("speed", cls.speed) * 10) / 10,
    crewCapacity: cls.crewCapacity,
    slots: cls.componentSlots,
    slotsUsed: (ship.components ?? []).length,
  };
}

export interface StatBreakdown {
  base: number;
  fitted: number;
  crew: number;
  crewSkill: string;
  crewValue: number;
  total: number;
}

const BOON_SOURCE: Record<ShipStatKey, string> = {
  hull: "Craftsmanship",
  firepower: "Gunnery",
  maneuverability: "Navigation & Scouting",
  scouting: "Scouting",
  cargo: "Logistics",
  speed: "Navigation",
};

/** Where a figure came from: her timbers, her fittings, and the men aboard. */
export function statBreakdown(ship: Ship, key: ShipStatKey, crew?: CrewMember[]): StatBreakdown {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const hands = crew && crew.length ? crew : (CREW_BY_SHIP[ship.id] ?? []);
  const bonus = componentBonuses(ship);
  const boon = crewBoons(ship, hands);
  const base = key === "firepower" ? gunRating(ship) : (cls[key] as number);
  const crewPct = (boon[key as keyof typeof boon] as number) ?? 0;
  const s = boon.skills;
  const crewValue =
    key === "maneuverability" ? Math.round(s.navigation * 0.5 + s.scouting * 0.5) : Math.round(
      key === "hull" ? s.craftsmanship
      : key === "firepower" ? s.gunnery
      : key === "cargo" ? s.logistics
      : key === "scouting" ? s.scouting
      : s.navigation,
    );
  return {
    base,
    fitted: bonus[key],
    crew: crewPct,
    crewSkill: BOON_SOURCE[key],
    crewValue,
    total: base * (1 + bonus[key]) * (1 + crewPct),
  };

}

/**
 * Firepower is nothing but the guns she actually carries. A bare hull throws no
 * shot at all; every mounted piece adds weight of metal by its mark.
 */
export function gunRating(ship: Ship): number {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  let total = 0;
  for (const mark of ship.guns ?? []) {
    const level = Math.min(5, Math.max(1, mark));
    total += cls.gunPower * (1 + 0.25 * (level - 1));
  }
  return total;
}

/** Guns mounted and gun ports still empty. */
export function gunPorts(ship: Ship) {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const mounted = (ship.guns ?? []).length;
  return { mounted, ports: cls.gunPorts, free: Math.max(0, cls.gunPorts - mounted) };
}

export function quartersUsed(ship: Ship) {
  return (ship.quarters ?? []).filter((q) => q !== "captain").length;
}

/** Berths in the lower deck: twice the quarters she can carry. */
export function lodgings(ship: Ship) {
  const cls = SHIP_CLASS_MAP[ship.classId];
  return cls?.hands ?? 4;
}

/** The post a named man currently holds aboard her, if any. */
export function postOf(ship: Ship | undefined, memberId: string) {
  if (!ship) return undefined;
  const found = Object.entries(ship.assignments ?? {}).find(([, id]) => id === memberId);
  return found ? (found[0] as keyof typeof POSITION_SKILL) : undefined;
}

export function hasQuarter(ship: Ship, position: keyof typeof POSITION_SKILL) {
  return position === "captain" || (ship.quarters ?? []).includes(position);
}

/** Condition of one region of the ship, in percent. */
export function regionCondition(ship: Ship, region: string): number {
  const hull = Math.max(0, Math.min(100, ship.hull));
  const sails = Math.max(0, Math.min(100, ship.sails));
  switch (region) {
    case "mast":
      return sails;
    case "hull":
    case "bow":
    case "stern":
      return hull;
    default:
      return (hull + sails) / 2;
  }
}

const CONDITION_REGIONS = [
  "bow",
  "stern",
  "deck",
  "bridge",
  "mast",
  "hull",
  "ordnance",
  "warehouse",
];

/** Her overall condition: the mean of every part aboard. */
export function overallCondition(ship: Ship): number {
  const sum = CONDITION_REGIONS.reduce((t, r) => t + regionCondition(ship, r), 0);
  return sum / CONDITION_REGIONS.length;
}
