/**
 * The reckoning after a decision: what the captain's word actually cost him,
 * and what it brought in. Nothing is guessed — the books are read before the
 * business and read again after, and the difference is what is shown.
 */

import type { GameState, Ship } from "../types";
import { medicineAboard, salvageAboard, suppliesAboard } from "./stores";

export interface OutcomeLine {
  label: string;
  /** the change, already worded for the ledger */
  text: string;
  tone: "good" | "bad" | "plain";
}

export interface Outcome {
  title: string;
  /** what the captain chose to do */
  choice: string;
  /** the narrator's word on how it went */
  text: string;
  verdict: "won" | "lost" | "done";
  /** the skill it turned on, when it turned on one */
  roll?: { skill: string; score: number; dc: number; chance: number };
  lines: OutcomeLine[];
}

interface Books {
  cash: number;
  debt: number;
  hull: number;
  sails: number;
  morale: number;
  supplies: number;
  medicine: number;
  salvage: number;
  hands: number;
  health: number;
  reputation: number;
  days: number;
}

export function readBooks(state: GameState, ship: Ship): Books {
  const crew = state.crew.filter((c) => c.shipId === ship.id);
  return {
    cash: state.cash,
    debt: state.debt ?? 0,
    hull: ship.hull,
    sails: ship.sails,
    morale: ship.morale,
    supplies: suppliesAboard(ship),
    medicine: medicineAboard(ship),
    salvage: salvageAboard(ship),
    hands: crew.length,
    health: crew.length ? crew.reduce((a, c) => a + c.health, 0) / crew.length : 0,
    reputation: state.reputation,
    days: ship.voyage?.daysLeft ?? 0,
  };
}

const round = (n: number) => Math.round(n * 10) / 10;

function line(label: string, delta: number, unit: string, goodUp = true): OutcomeLine | undefined {
  if (Math.abs(delta) < 0.5) return undefined;
  const up = delta > 0;
  return {
    label,
    text: `${up ? "+" : "−"}${round(Math.abs(delta))}${unit ? ` ${unit}` : ""}`,
    tone: up === goodUp ? "good" : "bad",
  };
}

/** Compare the books either side of the business and say what moved. */
export function tally(before: Books, after: Books): OutcomeLine[] {
  const out: (OutcomeLine | undefined)[] = [
    line("Coin", after.cash - before.cash, "gold"),
    line("Debt", after.debt - before.debt, "gold", false),
    line("Hull", after.hull - before.hull, "points"),
    line("Canvas", after.sails - before.sails, "points"),
    line("Temper", after.morale - before.morale, ""),
    line("Stores", after.supplies - before.supplies, "units"),
    line("Physic", after.medicine - before.medicine, "units"),
    line("Salvage", after.salvage - before.salvage, "units"),
    line("Hands", after.hands - before.hands, "aboard"),
    line("Crew health", after.health - before.health, ""),
    line("Standing", after.reputation - before.reputation, ""),
    line("Passage", after.days - before.days, "days", false),
  ];
  return out.filter((l): l is OutcomeLine => !!l);
}
