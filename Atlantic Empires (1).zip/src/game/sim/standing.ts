import { PORT_MAP } from "../data/ports";
import { POWER_MAP } from "../data/powers";
import type { GameState, PowerId, Port } from "../types";
import { pushLog } from "./events";
import { clamp, uid } from "./util";

/**
 * Three books are kept on a captain, and they are not the same book.
 *
 *  · Port standing   — what one harbour thinks of him, earned quay by quay.
 *  · Faction standing — what a crown thinks of him, which is much harder won.
 *  · Reputation / Infamy — what his banner is worth in the whole Atlantic,
 *    twenty ranks apiece, from bare wood to gilded gold.
 *
 * Everything here is deliberately marginal: many small pressures, no lever
 * that can be pulled twice for free money.
 */

// ---------------------------------------------------------------- banner rank

export const RANK_LEVELS = 20;

/** Points wanted to reach a level. Level 1 is free; level 20 is a life's work. */
export function rankThreshold(level: number) {
  if (level <= 1) return 0;
  return Math.round(80 * Math.pow(level, 1.6));
}

export function levelOf(points: number) {
  let lvl = 1;
  for (let i = 2; i <= RANK_LEVELS; i++) if (points >= rankThreshold(i)) lvl = i;
  return lvl;
}

export type RankMetal = "wood" | "copper" | "silver" | "gold";

export function rankMetal(level: number): RankMetal {
  if (level >= 16) return "gold";
  if (level >= 11) return "silver";
  if (level >= 6) return "copper";
  return "wood";
}

export const METAL_COLOR: Record<RankMetal, string> = {
  wood: "oklch(0.52 0.06 60)",
  copper: "oklch(0.62 0.13 48)",
  silver: "oklch(0.78 0.02 250)",
  gold: "oklch(0.82 0.14 88)",
};

const REPUTATION_RANKS = [
  "Unknown Sail", "Noted Sail", "Trusted Bottom", "Fair Dealer", "Sound House",
  "Named Trader", "Respected Master", "Merchant of Standing", "Consul's Guest", "Bonded House",
  "Great Trader", "Sea Lord's Peer", "Prince of Cargoes", "Admiral of Commerce", "Crown's Confidant",
  "Illustrious House", "Master of the Trades", "Sovereign Merchant", "Legend of the Atlantic", "Gilded Banner",
];

const INFAMY_RANKS = [
  "Nobody's Fear", "Whispered Of", "Petty Rogue", "Marked Sail", "Wanted Man",
  "Coast Raider", "Sea Wolf", "Terror of the Lane", "Bloody Colours", "Named Devil",
  "Scourge", "Dread of the Isles", "Black Admiral", "Crown's Enemy", "Nightmare of the Main",
  "Lord of Rogues", "King of the Black", "Curse of Two Oceans", "Legend of the Gallows", "Gilded Skull",
];

export function reputationRank(level: number) {
  return REPUTATION_RANKS[clamp(level, 1, RANK_LEVELS) - 1]!;
}

export function infamyRank(level: number) {
  return INFAMY_RANKS[clamp(level, 1, RANK_LEVELS) - 1]!;
}

export function prestigeLevel(state: GameState) {
  return levelOf(state.prestige ?? 0);
}

export function infamyLevel(state: GameState) {
  return levelOf(state.infamyPoints ?? 0);
}

/** How far along the present rank the banner stands, 0-1. */
export function rankProgress(points: number) {
  const lvl = levelOf(points);
  if (lvl >= RANK_LEVELS) return 1;
  const from = rankThreshold(lvl);
  const to = rankThreshold(lvl + 1);
  return clamp((points - from) / Math.max(1, to - from), 0, 1);
}

// ----------------------------------------------------------- faction standing

/** An independent captain is nobody's friend until he proves otherwise. */
export const INDEPENDENT_BASE = -20;
export const PIRATE_BASE = -70;

/** The standing a crown actually acts on: the book, plus what the banner is worth. */
export function factionStanding(state: GameState, power: PowerId) {
  const base = state.relations[power] ?? 0;
  // Rank 1 is simply "unknown": the bonus starts to tell from rank 2.
  let bonus = ((power === "pirate" ? infamyLevel(state) : prestigeLevel(state)) - 1) * 2;
  // The English hang pirates; the French court flatters a famous name.
  if (power === "england") bonus -= (infamyLevel(state) - 1) * 4;
  if (power === "france") bonus += (prestigeLevel(state) - 1) * 2;
  return clamp(base + bonus, -100, 100);
}

export const HOSTILE_AT = -50;

export function factionHostile(state: GameState, power: PowerId) {
  return factionStanding(state, power) <= HOSTILE_AT;
}

export const FACTION_TIERS: { min: number; name: string }[] = [
  { min: -100, name: "Enemy" },
  { min: -49, name: "Hostile" },
  { min: -24, name: "Distrusted" },
  { min: -9, name: "Neutral" },
  { min: 10, name: "Tolerated" },
  { min: 30, name: "Friendly" },
  { min: 55, name: "Trusted" },
  { min: 78, name: "Favored" },
];

export function tierName(value: number, tiers = FACTION_TIERS) {
  let out = tiers[0]!.name;
  for (const t of tiers) if (value >= t.min) out = t.name;
  return out;
}

export const PORT_TIERS: { min: number; name: string }[] = [
  { min: -100, name: "Hated" },
  { min: -59, name: "Loathed" },
  { min: -29, name: "Distrusted" },
  { min: -9, name: "Neutral" },
  { min: 10, name: "Welcome" },
  { min: 35, name: "Esteemed" },
  { min: 65, name: "Favored" },
];

// -------------------------------------------------------------- port standing

/** Days the homestead's goodwill lasts. */
export const HOME_BONUS_DAYS = 365;
export const HOME_BONUS = 10;

export function homeBonus(state: GameState, portId: string) {
  if (state.homePortId !== portId) return 0;
  return state.day < HOME_BONUS_DAYS ? HOME_BONUS : 0;
}

/** What this harbour makes of you: its own book, half the crown's, plus home. */
export function portStanding(state: GameState, portId: string) {
  const port = PORT_MAP[portId];
  if (!port) return 0;
  const own = state.portStanding?.[portId] ?? 0;
  const crown = factionStanding(state, port.power) / 2;
  return clamp(own + crown + homeBonus(state, portId), -100, 100);
}

export function portStandingParts(state: GameState, portId: string) {
  const port = PORT_MAP[portId]!;
  return {
    own: state.portStanding?.[portId] ?? 0,
    crown: factionStanding(state, port.power) / 2,
    home: homeBonus(state, portId),
    total: portStanding(state, portId),
  };
}

/** Below this the harbour master turns you away until a fine is paid. */
export const BAN_AT = -60;

export function banFine(port: Port) {
  return Math.round(600 + port.population / 40 + port.prosperity * 900);
}

export function portBanned(state: GameState, portId: string) {
  if (state.fines?.[portId]) return true;
  return portStanding(state, portId) <= BAN_AT;
}

/** Marginal effects of standing. Nothing here is ever a money pump. */
export function portEdge(state: GameState, portId: string) {
  const e = portStanding(state, portId) / 100;
  return {
    standing: portStanding(state, portId),
    /** market prices shift by at most 5% either way */
    price: 0.05 * e,
    /** hands at the tavern table */
    recruits: Math.round(e * 2),
    /** postings on the board */
    postings: Math.round(e * 2),
    /** what a shipper will add to his fee for a known man */
    pay: 1 + 0.1 * e,
    /** chance of an unfriendly visit from the customs house */
    scrutiny: clamp(-e, 0, 1),
  };
}

// ------------------------------------------------------------------- ledgers

function note(state: GameState, delta: number, reason: string) {
  const ledger = (state.repLedger ??= []);
  ledger.unshift({ id: uid("rep", state.day + ledger.length), day: state.day, delta, reason });
  state.repLedger = ledger.slice(0, 80);
}

export function addPortStanding(state: GameState, portId: string, delta: number, reason?: string) {
  if (!delta) return;
  const book = (state.portStanding ??= {});
  const before = book[portId] ?? 0;
  book[portId] = clamp(before + delta, -100, 100);
  if (reason) note(state, delta, `${PORT_MAP[portId]?.name ?? portId}: ${reason}`);
  if (portStanding(state, portId) <= BAN_AT && !state.fines?.[portId]) {
    const port = PORT_MAP[portId];
    if (port) {
      state.fines = { ...(state.fines ?? {}), [portId]: banFine(port) };
      pushLog(
        state,
        "world",
        `${port.name} closes its harbour to you. The master of the port will hear nothing until a fine of ${state.fines[portId]} gold is paid.`,
      );
    }
  }
}

export function addFactionStanding(state: GameState, power: PowerId, delta: number, reason?: string) {
  if (!delta) return;
  state.relations[power] = clamp((state.relations[power] ?? 0) + delta, -100, 100);
  if (reason) note(state, delta, `${POWER_MAP[power]!.adjective}: ${reason}`);
}

export function addPrestige(state: GameState, points: number, reason?: string) {
  if (points <= 0) return;
  const before = prestigeLevel(state);
  state.prestige = Math.max(0, (state.prestige ?? 0) + points);
  const after = prestigeLevel(state);
  // The old aggregate figure is kept in step so permits and titles read true.
  state.reputation = clamp((after - 1) * 5, -100, 100);
  if (reason) note(state, points, `Prestige: ${reason}`);
  if (after > before) {
    pushLog(
      state,
      "world",
      `Your banner is spoken of higher: rank ${after}, ${reputationRank(after)}. Every crown but the black flag thinks a little better of you.`,
    );
  }
}

export function addInfamy(state: GameState, points: number, reason?: string) {
  if (points <= 0) return;
  const before = infamyLevel(state);
  state.infamyPoints = Math.max(0, (state.infamyPoints ?? 0) + points);
  const after = infamyLevel(state);
  state.notoriety = clamp((after - 1) * 5, 0, 100);
  if (reason) note(state, points, `Infamy: ${reason}`);
  if (after > before) {
    pushLog(
      state,
      "world",
      `Your name blackens: infamy ${after}, ${infamyRank(after)}. The rogues of the Main drink to it; honest men bolt their doors.`,
    );
  }
}

/** Starting goodwill: a stranger with one hull, helped a little by birth and faith. */
export function startingRelations(nationality: string, faith: string): Record<PowerId, number> {
  const out = {} as Record<PowerId, number>;
  for (const p of Object.values(POWER_MAP)) {
    if (p.id === "pirate") {
      out.pirate = PIRATE_BASE;
      continue;
    }
    let v = INDEPENDENT_BASE;
    if (POWER_CULTURE[p.id]?.includes(nationality)) v += 5;
    if (POWER_FAITH[p.id]?.includes(faith)) v += 5;
    // Each crown's own prejudice, over and above ordinary suspicion.
    const ownCulture = POWER_CULTURE[p.id]?.includes(nationality) ?? false;
    const ownFaith = POWER_FAITH[p.id]?.includes(faith) ?? false;
    if (p.id === "spain") {
      if (!ownCulture) v -= 5;
      if (!ownFaith) v -= 12;
    }
    if (p.id === "portugal" && !ownFaith) v -= 5;
    if (p.id === "france" && !ownCulture) v -= 5;
    out[p.id] = v;
  }
  return out;
}

const POWER_CULTURE: Partial<Record<PowerId, string[]>> = {
  spain: ["Spanish", "Basque", "Catalan", "Creole"],
  england: ["English", "Irish", "Scottish", "Welsh"],
  france: ["French", "Breton", "Norman"],
  dutch: ["Dutch", "Flemish", "Frisian"],
  portugal: ["Portuguese", "Brazilian"],
};

const POWER_FAITH: Partial<Record<PowerId, string[]>> = {
  spain: ["Catholic"],
  france: ["Catholic"],
  portugal: ["Catholic"],
  england: ["Anglican", "Protestant", "Puritan"],
  dutch: ["Calvinist", "Protestant", "Reformed"],
};
