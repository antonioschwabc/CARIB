/**
 * The world beyond the player: crown squadrons, free traders, and the actions
 * they fight among themselves while his back is turned.
 *
 * Nothing here is drawn frame by frame. Hulls creep across the chart day by
 * day, lookouts raise one another, and an action once joined takes a week to
 * settle. Only the result reaches the journal.
 */

import { COMPONENT_DEFS } from "../data/shipParts";
import { PORTS, PORT_MAP } from "../data/ports";
import { POWERS, POWER_MAP } from "../data/powers";
import { SHIP_CLASSES, SHIP_CLASS_MAP } from "../data/ships";
import { randomFirstName, randomSurname } from "../data/crew";
import { randomBannerName, randomVesselName } from "../data/names";
import type { Banner, BannerIcon, GameState, NpcBattle, NpcFleet, NpcShip, Port, PowerId } from "../types";
import { pushLog } from "./events";
import { factionsAtWar, shiftFactionRel } from "./factions";
import { fortificationOf } from "./portIntel";
import { priceOf } from "./economy";
import { clamp, uid } from "./util";

const CULTURE: Record<PowerId, string> = {
  spain: "Spanish",
  england: "English",
  france: "French",
  dutch: "Dutch",
  portugal: "Portuguese",
  pirate: "Creole",
};

const CAPITAL: Record<PowerId, string> = {
  spain: "havana",
  england: "portroyal",
  france: "petitgoave",
  dutch: "willemstad",
  portugal: "recife",
  pirate: "tortuga",
};

const FLEET_NAMES: Record<PowerId, string[]> = {
  spain: ["The Armada de Barlovento", "The Flota de Tierra Firme", "The Guarda Costa of Havana"],
  england: ["The Jamaica Squadron", "The Leeward Islands Station", "The Barbados Squadron"],
  france: ["L'Escadre du Ponant", "The Saint-Domingue Squadron", "L'Escadre des Îles"],
  dutch: ["The Zeeland Squadron", "The West India Company Fleet", "The Curaçao Station"],
  portugal: ["The Brazil Squadron", "The Armada do Brasil", "The Guinea Station"],
  pirate: ["The Brethren of the Coast", "The Black Consort", "The Free Companions"],
};

const MERCHANT_TARGET = 5;

/** A harbour's true master: the crown that holds it today. */
export function portOwner(state: GameState, portId: string): PowerId {
  return state.portControl?.[portId] ?? PORT_MAP[portId]?.power ?? "spain";
}

export function isPillaged(state: GameState, portId: string) {
  return (state.pillaged?.[portId] ?? -1) > state.day;
}

/** A harbour's guns and walls, in the same coin ships are measured in. */
export function fortStats(port: Port) {
  const level = port.level ?? 2;
  const guns = fortificationOf(port).guns;
  return {
    guns,
    defensiveness: Math.round(320 + level * 430 + guns * 9),
    firepower: Math.round(guns * 5.5 * (0.8 + level * 0.14)),
    /** how far the watchtowers see */
    sightNm: 40 + level * 22,
  };
}

// ---- generation ---------------------------------------------------------

function skillsFor(rand: () => number, floor: number): Record<string, number> {
  const keys = [
    "navigation",
    "charisma",
    "scouting",
    "craftsmanship",
    "gunnery",
    "logistics",
    "cooking",
    "medicine",
  ];
  const out: Record<string, number> = {};
  for (const k of keys) out[k] = Math.round(floor + rand() * (95 - floor));
  return out;
}

function captainWorth(s: Record<string, number>) {
  return Object.values(s).reduce((a, b) => a + b, 0);
}

function makeCaptain(culture: string, rand: () => number) {
  const first = randomFirstName(culture, rand);
  const last = randomSurname(culture, rand);
  return {
    name: `${first} ${last}`,
    nationality: culture,
    age: 26 + Math.floor(rand() * 30),
    portraitSeed: `${first}-${last}-${Math.floor(rand() * 9999)}`,
    skills: skillsFor(rand, 25),
  };
}

const ICONS: BannerIcon[] = ["anchor", "star", "cross", "sun", "lion", "eagle", "swords", "key"];

function makeBanner(culture: string, surname: string, rand: () => number): Banner {
  const hues = [12, 42, 90, 145, 210, 250, 300];
  const pick = () => hues[Math.floor(rand() * hues.length)]!;
  return {
    name: randomBannerName(culture, surname, rand),
    colors: [
      `oklch(0.35 0.06 ${pick()})`,
      `oklch(0.62 0.15 ${pick()})`,
      `oklch(0.88 0.05 ${pick()})`,
    ] as [string, string, string],
    icon: ICONS[Math.floor(rand() * ICONS.length)] ?? "anchor",
  };
}

function randomComponents(rand: () => number) {
  const out: string[] = [];
  const pool = COMPONENT_DEFS.slice();
  const n = 2 + Math.floor(rand() * 4);
  for (let i = 0; i < n && pool.length; i++) {
    const idx = Math.floor(rand() * pool.length);
    const def = pool.splice(idx, 1)[0]!;
    out.push(def.id);
  }
  return out;
}

function hullFrom(classId: string, rand: () => number, culture: string, captainSkills: Record<string, number>) {
  const cls = SHIP_CLASS_MAP[classId]!;
  const gun = 1 + (captainSkills["gunnery"] ?? 40) / 225;
  const nav = 1 + (captainSkills["navigation"] ?? 40) / 225;
  return {
    classId,
    name: randomVesselName(culture, rand),
    hull: cls.hull,
    maxHull: cls.hull,
    firepower: Math.round(cls.gunPower * cls.guns * gun),
    speed: Math.round(cls.speed * nav * 10) / 10,
    maneuver: Math.round(cls.maneuverability * nav),
    sightNm: Math.round(cls.scouting * 1.4),
  };
}

function makeNpcShip(
  rand: () => number,
  opts: { culture: string; power?: PowerId; fleetId?: string; classId: string; port: Port; merchant?: boolean },
): NpcShip {
  const captain = makeCaptain(opts.culture, rand);
  const base = hullFrom(opts.classId, rand, opts.culture, captain.skills);
  const crewNames = Array.from({ length: 3 + Math.floor(rand() * 4) }, () =>
    `${randomFirstName(opts.culture, rand)} ${randomSurname(opts.culture, rand)}`,
  );
  return {
    id: uid("npc", Math.floor(rand() * 1e6)),
    ...base,
    ...(opts.power ? { power: opts.power } : {}),
    ...(opts.fleetId ? { fleetId: opts.fleetId } : {}),
    banner: makeBanner(opts.culture, captain.name.split(" ")[1] ?? "", rand),
    captain,
    crewNames,
    components: randomComponents(rand),
    lat: opts.port.lat,
    lon: opts.port.lon,
    toLat: opts.port.lat,
    toLon: opts.port.lon,
    toPortId: opts.port.id,
    ...(opts.merchant
      ? { gold: 1000, cargo: {}, wits: (rand() < 0.5 ? "shrewd" : "poor") as "shrewd" | "poor" }
      : {}),
  };
}

/** Five sail to every crown, and five free traders, cut fresh for this save. */
export function initWorld(state: GameState, rand: () => number) {
  const ships: NpcShip[] = [];
  const fleets: NpcFleet[] = [];

  for (const power of POWERS) {
    const culture = CULTURE[power.id];
    const names = FLEET_NAMES[power.id];
    const fleet: NpcFleet = {
      id: uid("flt", Math.floor(rand() * 1e6)),
      name: names[Math.floor(rand() * names.length)]!,
      power: power.id,
    };
    fleets.push(fleet);
    const home = capitalOf(state, power.id);
    const built = SHIP_CLASSES.map((cls) =>
      makeNpcShip(rand, { culture, power: power.id, fleetId: fleet.id, classId: cls.id, port: home }),
    );
    // The best officer gets the heaviest hull.
    const captains = built.map((s) => s.captain).sort((a, b) => captainWorth(b.skills) - captainWorth(a.skills));
    built
      .slice()
      .sort((a, b) => b.maxHull - a.maxHull)
      .forEach((s, i) => {
        s.captain = captains[i]!;
      });
    ships.push(...built);
  }

  for (let i = 0; i < MERCHANT_TARGET; i++) ships.push(makeMerchant(state, rand));

  state.npcFleets = fleets;
  state.npcShips = ships;
  state.npcBattles = [];
  state.portControl = {};
  state.pillaged = {};
}

function capitalOf(state: GameState, power: PowerId): Port {
  const own = openPorts(state).filter((p) => portOwner(state, p.id) === power);
  return PORT_MAP[CAPITAL[power]] ?? own[0] ?? PORTS[0]!;
}

function openPorts(state: GameState): Port[] {
  const extra = state.extraPorts ?? [];
  return [...PORTS, ...extra.filter((p) => !PORTS.some((q) => q.id === p.id))];
}

function makeMerchant(state: GameState, rand: () => number): NpcShip {
  const cultures = ["English", "Dutch", "French", "Portuguese", "Spanish", "Irish"];
  const culture = cultures[Math.floor(rand() * cultures.length)]!;
  const pool = openPorts(state).filter((p) => !p.hidden);
  const port = pool[Math.floor(rand() * pool.length)]!;
  const classId = ["sloop", "brigantine", "brig"][Math.floor(rand() * 3)]!;
  return makeNpcShip(rand, { culture, classId, port, merchant: true });
}

// ---- the daily turn -----------------------------------------------------

const DEG = (nm: number) => nm / 60;

function moveToward(s: NpcShip, rand: () => number) {
  const perDay = s.speed * 24 * 0.55;
  const dLat = s.toLat - s.lat;
  const dLon = (s.toLon - s.lon) * Math.cos((s.lat * Math.PI) / 180);
  const distNm = Math.hypot(dLat, dLon) * 60;
  if (distNm < 20) {
    s.lat = s.toLat;
    s.lon = s.toLon;
    return true;
  }
  const k = Math.min(1, DEG(perDay) * 60 / Math.max(1, distNm));
  s.lat += (s.toLat - s.lat) * k;
  s.lon += (s.toLon - s.lon) * k;
  // A little sea-room wandering, so tracks are not ruler-straight.
  s.lat += (rand() - 0.5) * 0.06;
  return false;
}

function nmBetweenPts(a: { lat: number; lon: number }, b: { lat: number; lon: number }) {
  const dLat = b.lat - a.lat;
  const dLon = (b.lon - a.lon) * Math.cos((((a.lat + b.lat) / 2) * Math.PI) / 180);
  return Math.hypot(dLat, dLon) * 60;
}

function force(ships: NpcShip[]) {
  return ships.reduce((sum, s) => sum + s.hull * 0.5 + s.firepower * 3, 0);
}

function setPatrol(state: GameState, s: NpcShip, rand: () => number) {
  const owned = openPorts(state).filter((p) => portOwner(state, p.id) === s.power);
  const port = owned.length ? owned[Math.floor(rand() * owned.length)]! : capitalOf(state, s.power!);
  s.toPortId = port.id;
  s.toLat = port.lat + (rand() - 0.5) * 0.8;
  s.toLon = port.lon + (rand() - 0.5) * 0.8;
}

/** A free trader's book: good sense, or none at all. */
function tradeAtPort(state: GameState, s: NpcShip, port: Port, rand: () => number) {
  const market = state.markets[port.id];
  if (!market) return;
  const cargo = s.cargo ?? (s.cargo = {});
  // Sell everything in the hold at what the town will pay.
  for (const [cid, qty] of Object.entries(cargo)) {
    if (qty <= 0) continue;
    const p = priceOf(state, port.id, cid, port);
    s.gold = Math.round((s.gold ?? 0) + p.sell * qty);
    delete cargo[cid];
  }
  // Then take on a lading for the next town.
  const candidates = Object.keys(port.produces);
  if (!candidates.length) return;
  let cid: string;
  if (s.wits === "shrewd") {
    // The careful sort buys where the stuff is made and cheap.
    cid = candidates
      .map((c) => ({ c, p: priceOf(state, port.id, c, port).buy }))
      .sort((a, b) => a.p - b.p)[0]!.c;
  } else {
    cid = candidates[Math.floor(rand() * candidates.length)]!;
  }
  const unit = priceOf(state, port.id, cid, port).buy;
  const purse = (s.gold ?? 0) * (s.wits === "shrewd" ? 0.7 : 0.95);
  const qty = Math.floor(purse / Math.max(1, unit));
  if (qty <= 0) return;
  cargo[cid] = (cargo[cid] ?? 0) + qty;
  s.gold = Math.round((s.gold ?? 0) - qty * unit);
}

function setMerchantCourse(state: GameState, s: NpcShip, rand: () => number) {
  const pool = openPorts(state).filter((p) => !p.hidden && p.id !== s.toPortId);
  if (!pool.length) return;
  let port: Port;
  if (s.wits === "shrewd") {
    // A short leg to a town that wants what is in the hold.
    const want = Object.keys(s.cargo ?? {})[0];
    const near = pool
      .filter((p) => nmBetweenPts(s, p) < 1400)
      .sort(
        (a, b) =>
          (want ? (b.consumes[want] ?? 0) - (a.consumes[want] ?? 0) : 0) ||
          nmBetweenPts(s, a) - nmBetweenPts(s, b),
      );
    port = near[0] ?? pool[Math.floor(rand() * pool.length)]!;
  } else {
    port = pool[Math.floor(rand() * pool.length)]!;
  }
  s.toPortId = port.id;
  s.toLat = port.lat;
  s.toLon = port.lon;
}

function hostile(state: GameState, a: NpcShip, b: NpcShip) {
  if (a.power && b.power) return a.power !== b.power && factionsAtWar(state, a.power, b.power);
  // Pirates prey on free traders; nobody else troubles them.
  if (a.power === "pirate" && !b.power) return true;
  if (b.power === "pirate" && !a.power) return true;
  return false;
}

/** Sack a harbour, with the consequences its size earns. */
export function sackPort(state: GameState, portId: string, victor: PowerId) {
  const port = PORT_MAP[portId];
  if (!port) return;
  const level = port.level ?? 2;
  const owner = portOwner(state, portId);
  state.pillaged = state.pillaged ?? {};
  const market = state.markets[portId];
  if (market) for (const cid of Object.keys(market.stock)) market.stock[cid] = (market.stock[cid] ?? 0) * 0.15;
  // Ventures in a sacked town are broken up.
  state.businesses = state.businesses.filter((b) => b.portId !== portId);
  if (level >= 3) {
    state.pillaged[portId] = state.day + 14;
    pushLog(
      state,
      "world",
      `${port.name} is sacked. ${POWER_MAP[victor].adjective} colours flew over the wharves for a day and a night; the warehouses are empty, the walls broken, and the town will be a fortnight coming back to itself. It remains ${POWER_MAP[owner].adjective}.`,
    );
  } else {
    state.pillaged[portId] = state.day + 7;
    state.portControl = state.portControl ?? {};
    state.portControl[portId] = victor;
    pushLog(
      state,
      "world",
      `${port.name} has changed hands. The ${POWER_MAP[owner].adjective} garrison is gone and ${POWER_MAP[victor].adjective} colours are up over the fort. The town is sacked and will be a week in ruins.`,
    );
  }
  if (owner !== victor) shiftFactionRel(state, owner, victor, -12);
}

function resolveBattle(state: GameState, b: NpcBattle, rand: () => number) {
  const all = state.npcShips ?? [];
  const involved = all.filter((s) => b.shipIds.includes(s.id));
  const attackers = involved.filter((s) => (s.power ?? "none") === b.attacker || (!s.power && b.attacker === "pirate"));
  const defenders = involved.filter((s) => !attackers.includes(s));
  const port = b.portId ? PORT_MAP[b.portId] : undefined;

  const aF = force(attackers);
  const dF = port ? (() => { const f = fortStats(port); return f.defensiveness * 0.5 + f.firepower * 3; })() : force(defenders);
  const odds = clamp(aF / Math.max(1, aF + dF), 0.05, 0.95);
  const attackerWins = rand() < odds;

  const losers = attackerWins ? defenders : attackers;
  const sunk: NpcShip[] = [];
  for (const s of losers) {
    if (rand() < 0.6) sunk.push(s);
    else s.hull = Math.max(20, Math.round(s.hull * 0.5));
  }
  for (const s of attackerWins ? attackers : defenders) s.hull = Math.max(15, Math.round(s.hull * (0.6 + rand() * 0.3)));

  state.npcShips = all.filter((s) => !sunk.includes(s));
  for (const s of state.npcShips) if (s.battleId === b.id) delete s.battleId;

  const place = port ? port.name : `${Math.abs(b.lat).toFixed(1)}°${b.lat >= 0 ? "N" : "S"} ${Math.abs(b.lon).toFixed(1)}°${b.lon >= 0 ? "E" : "W"}`;
  if (port) {
    if (attackerWins) sackPort(state, port.id, b.attacker);
    else
      pushLog(
        state,
        "world",
        `Word from ${place}: a ${POWER_MAP[b.attacker].adjective} squadron stood in against the batteries and was beaten off with loss.`,
      );
  } else {
    const winner = attackerWins ? b.attacker : b.defender;
    pushLog(
      state,
      "world",
      `An action off ${place} is decided after a week's manoeuvring. The ${POWER_MAP[winner].adjective} have the day; ${sunk.length ? `${sunk.map((s) => s.name).join(", ")} went down with ${sunk.length > 1 ? "their captains" : `Captain ${sunk[0]!.captain.name}`}` : "both parties drew off battered but afloat"}.`,
    );
    shiftFactionRel(state, b.attacker, b.defender, -4);
  }
}

/** One day of the world's own business. */
export function tickWorld(state: GameState, rand: () => number) {
  if (!state.npcShips) return;
  const battles = (state.npcBattles = state.npcBattles ?? []);

  // 1. Actions already joined burn their week down.
  for (const b of battles.slice()) {
    if (state.day >= b.endsDay) {
      resolveBattle(state, b, rand);
      state.npcBattles = (state.npcBattles ?? []).filter((x) => x.id !== b.id);
    }
  }

  const ships = state.npcShips;

  // 2. Everyone not locked in an action sails her course.
  for (const s of ships) {
    if (s.battleId) continue;
    const arrived = moveToward(s, rand);
    if (!arrived) continue;
    if (s.power) {
      setPatrol(state, s, rand);
    } else {
      const port = s.toPortId ? PORT_MAP[s.toPortId] : undefined;
      if (port) tradeAtPort(state, s, port, rand);
      if ((s.gold ?? 0) <= 0 && !Object.keys(s.cargo ?? {}).length) {
        pushLog(state, "world", `The free trader ${s.name} is broken up for debt at ${port?.name ?? "sea"}. Captain ${s.captain.name} is ashore and looking for a berth.`);
        state.npcShips = ships.filter((x) => x.id !== s.id);
        continue;
      }
      setMerchantCourse(state, s, rand);
    }
  }

  // 3. Lookouts raise one another: bubbles touching means an action.
  const live = state.npcShips.filter((s) => !s.battleId);
  for (let i = 0; i < live.length; i++) {
    for (let j = i + 1; j < live.length; j++) {
      const a = live[i]!;
      const b = live[j]!;
      if (a.battleId || b.battleId) continue;
      if (!hostile(state, a, b)) continue;
      if (nmBetweenPts(a, b) > a.sightNm + b.sightNm) continue;
      const id = uid("nbt", state.day * 1000 + i * 31 + j);
      a.battleId = id;
      b.battleId = id;
      battles.push({
        id,
        lat: (a.lat + b.lat) / 2,
        lon: (a.lon + b.lon) / 2,
        endsDay: state.day + 7,
        shipIds: [a.id, b.id],
        attacker: a.power ?? "pirate",
        defender: b.power ?? "pirate",
      });
    }
  }

  // 4. And a harbour whose watchtowers see an enemy sail may be stood against.
  for (const s of state.npcShips) {
    if (s.battleId || !s.power) continue;
    for (const port of openPorts(state)) {
      const owner = portOwner(state, port.id);
      if (owner === s.power || !factionsAtWar(state, s.power, owner)) continue;
      const f = fortStats(port);
      if (nmBetweenPts(s, port) > s.sightNm + f.sightNm) continue;
      if (rand() > 0.25) continue;
      const id = uid("nbt", state.day * 7919 + port.id.length);
      s.battleId = id;
      s.toLat = port.lat;
      s.toLon = port.lon;
      battles.push({
        id,
        lat: port.lat,
        lon: port.lon,
        endsDay: state.day + 7,
        shipIds: [s.id],
        portId: port.id,
        attacker: s.power,
        defender: owner,
      });
      pushLog(
        state,
        "world",
        `A ${POWER_MAP[s.power].adjective} sail is standing in against ${port.name}. The batteries are manned; the business will be a week in the settling.`,
      );
      break;
    }
  }

  // 5. New year: one hull to each crown, and the free traders made up to five.
  if (state.day > 0 && state.day % 365 === 0) replenish(state, rand);
}

function replenish(state: GameState, rand: () => number) {
  const ships = state.npcShips ?? [];
  for (const fleet of state.npcFleets ?? []) {
    const owned = openPorts(state).filter((p) => portOwner(state, p.id) === fleet.power);
    const weight = owned.reduce((a, p) => a + (p.level ?? 2), 0);
    const allowed =
      weight >= 22 ? "galleon" : weight >= 16 ? "frigate" : weight >= 10 ? "brig" : weight >= 5 ? "brigantine" : "sloop";
    const home = capitalOf(state, fleet.power);
    ships.push(
      makeNpcShip(rand, {
        culture: CULTURE[fleet.power],
        power: fleet.power,
        fleetId: fleet.id,
        classId: allowed,
        port: home,
      }),
    );
    pushLog(
      state,
      "world",
      `${fleet.name} has a new ${SHIP_CLASS_MAP[allowed]!.name} off the stocks at ${home.name}.`,
    );
  }
  let merchants = ships.filter((s) => !s.power).length;
  while (merchants < MERCHANT_TARGET) {
    ships.push(makeMerchant(state, rand));
    merchants++;
  }
  state.npcShips = ships;
}

/** Hulls the player's own lookouts can see today. */
export function visibleNpcs(state: GameState, at: { lat: number; lon: number }, sightNm: number) {
  return (state.npcShips ?? []).filter((s) => nmBetweenPts(at, s) <= sightNm);
}
