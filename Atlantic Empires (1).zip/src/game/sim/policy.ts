import { COMMODITIES, COMMODITY_MAP } from "../data/commodities";
import type { CommodityCategory, GameState, PowerId, Port } from "../types";
import { rng } from "./util";

/**
 * Each crown keeps its own idea of what a colony is for, and the custom house
 * is where that idea is felt. Two sorts of rule live here:
 *
 *  · standing rules — silver taxed by Spain for ever, naval stores cheap in
 *    Portugal, muskets dear in England.
 *  · the month's edict — one good chosen anew each month and taxed (or, in
 *    England, relieved). It is derived from the save's own seed, so it is the
 *    same for everyone reading the same ledger and different in every game.
 */

export const MONTH_DAYS = 30;

export function monthIndex(day: number) {
  return Math.floor(day / MONTH_DAYS);
}

export interface Edict {
  power: PowerId;
  cid: string;
  /** +0.25 is a quarter added; −0.10 is a tenth struck off */
  rate: number;
  text: string;
}

const POOLS: Partial<Record<PowerId, CommodityCategory[]>> = {
  spain: ["agricultural"],
  portugal: ["agricultural"],
  england: ["manufactured"],
  france: ["luxury", "alcohol"],
};

function poolFor(power: PowerId) {
  const cats = POOLS[power];
  if (!cats) return [];
  return COMMODITIES.filter((c) => cats.includes(c.category));
}

/** The good this crown has singled out this month, if it keeps such a custom. */
export function monthlyEdict(state: GameState, power: PowerId): Edict | undefined {
  const pool = poolFor(power);
  if (!pool.length) return undefined;
  const month = monthIndex(state.day);
  const rand = rng(((state.seed >>> 0) ^ (month * 2654435761)) >>> 0);
  // burn one draw so neighbouring months do not rhyme
  rand();
  const c = pool[Math.floor(rand() * pool.length)]!;
  if (power === "england") {
    return {
      power,
      cid: c.id,
      rate: -0.1,
      text: `Parliament has struck a tenth off ${c.name} for the month — English ports sell it cheap.`,
    };
  }
  return {
    power,
    cid: c.id,
    rate: 0.25,
    text: `The month's edict lays a quarter on ${c.name} in every ${power === "spain" ? "Spanish" : power === "portugal" ? "Portuguese" : "French"} harbour.`,
  };
}

export interface PolicyEffect {
  /** multiplier applied to the purchase price */
  mult: number;
  notes: string[];
}

/** Standing rules plus the month's edict, as they bear on one good in one port. */
export function commodityPolicy(state: GameState, port: Port, cid: string): PolicyEffect {
  const c = COMMODITY_MAP[cid];
  const notes: string[] = [];
  let mult = 1;
  if (!c) return { mult, notes };

  switch (port.power) {
    case "spain":
      if (c.category === "metals") {
        mult *= 1.25;
        notes.push("Spanish royal fifth on bullion and wrought metal (+25%)");
      }
      break;
    case "portugal":
      if (c.category === "naval") {
        mult *= 0.9;
        notes.push("Portuguese shipbuilding: naval stores sold cheap (−10%)");
      }
      break;
    case "england":
      if (c.category === "contraband" || c.category === "naval") {
        mult *= 1.25;
        notes.push("English anti-piracy acts on military and naval goods (+25%)");
      }
      break;
    default:
      break;
  }

  const edict = monthlyEdict(state, port.power);
  if (edict && edict.cid === cid) {
    mult *= 1 + edict.rate;
    notes.push(
      edict.rate > 0
        ? `This month's edict taxes ${c.name} (+${Math.round(edict.rate * 100)}%)`
        : `This month's tariff break on ${c.name} (${Math.round(edict.rate * 100)}%)`,
    );
  }

  return { mult, notes };
}

/** What a crown adds to, or strikes off, the cost of building in its ports. */
export function investmentCostMult(power: PowerId) {
  if (power === "portugal") return 1.25;
  if (power === "england") return 0.85;
  return 1;
}

export function investmentNote(power: PowerId) {
  if (power === "portugal") return "Portuguese duty on colonial investment (+25%)";
  if (power === "england") return "English encouragement of the plantations (−15%)";
  return "";
}
