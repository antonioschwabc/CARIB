import { COMMODITY_MAP, unitLabel } from "../data/commodities";
import { PORTS, PORT_MAP, distanceNm } from "../data/ports";
import { POWER_MAP } from "../data/powers";
import type { GameState, Port, Quest, Ship } from "../types";
import { holdNameFor, canStow } from "./holds";
import { clamp, uid } from "./util";
import { infamyLevel, portEdge } from "./standing";

/**
 * Work from the board by the tavern door. Nothing here asks a man to fight:
 * letters to carry, goods to land, goods to find and land. Cargo taken under
 * contract is locked in the hold — it is not yours to sell, eat or burn.
 */

export function questCount(port: Port, standingPostings = 0) {
  return clamp(
    Math.round(
      1 +
        (port.level ?? 3) * 0.9 +
        Math.log10(Math.max(port.population, 200)) * 0.8 +
        port.prosperity * 2,
    ) + standingPostings,
    1,
    9,
  );
}

function nearbyPorts(port: Port, maxNm: number) {
  return PORTS.filter((p) => p.id !== port.id && distanceNm(port, p) < maxNm);
}

/**
 * Sea miles a plain sloop makes good in a day, allowing for foul wind and a
 * thin watch. Every deadline on the board is written against this figure, so
 * no shipper ever names a day that cannot be kept.
 */
export const PLAIN_DAY_RUN_NM = 100;

/** Days a decent passage of this length wants, one way. */
export function passageDays(distNm: number) {
  return Math.max(2, Math.ceil(distNm / PLAIN_DAY_RUN_NM));
}

/** Days a shipper will wait past his day before the contract dies for good. */
export const CONTRACT_GRACE = 7;

/** Paid early: a fifth more standing and a twentieth more coin. */
export const EARLY_COIN = 1.05;
export const EARLY_STANDING = 1.2;

/**
 * An honest shipper does not consign his sugar to a careening beach. Lawful
 * work is only ever directed at a harbour with a custom house — never at a
 * black anchorage, and never at one the captain has not even found yet.
 */
function lawfulPorts(port: Port, maxNm: number) {
  return nearbyPorts(port, maxNm).filter((p) => p.power !== "pirate" && !p.hidden);
}

const LETTER_ERRANDS = [
  "Sealed dispatches",
  "A bill of exchange",
  "A packet of private letters",
  "Deeds and a will",
  "A factor's ledger and instructions",
  "A chart case, sealed",
];

export function makeQuest(state: GameState, port: Port, rand: () => number): Quest | undefined {
  const near = lawfulPorts(port, 2600);
  const target = near[Math.floor(rand() * near.length)];
  const edge = portEdge(state, port.id);
  // Great harbours post longer, richer commissions; a hamlet posts errands.
  const pay = edge.pay * (0.7 + (port.level ?? 3) * 0.12);
  const roll = rand();

  // The brotherhood keeps its own board in the corner of every tavern where
  // the watch is thin. Black work pays better and stains the man who takes it.
  // Only black work knows where the black harbours are.
  const blackChance = 0.1 + port.pirateRisk * 0.35 + infamyLevel(state) * 0.01;
  if (roll < blackChance) {
    const dark = nearbyPorts(port, 2600);
    const darkTarget = dark[Math.floor(rand() * dark.length)];
    if (darkTarget) {
      const dDist = distanceNm(port, darkTarget);
      const black = makeBlackQuest(
        state,
        port,
        darkTarget,
        dDist,
        Math.max(2, Math.round(dDist / 150)),
        pay,
        rand,
      );
      if (black) return black;
    }
  }

  if (!target) return undefined;
  const dist = distanceNm(port, target);
  const legDays = Math.max(2, Math.round(dist / 150));

  // Letters: no weight, no hold, only speed.
  if (roll < 0.32) {
    const errand = LETTER_ERRANDS[Math.floor(rand() * LETTER_ERRANDS.length)]!;
    const reward = Math.round((180 + dist * 1.05 + rand() * 380) * pay);
    return {
      id: uid("qst", state.day + Math.floor(rand() * 1e6)),
      kind: "letter",
      portId: port.id,
      targetPortId: target.id,
      reward,
      advance: Math.round(reward * (0.25 + rand() * 0.25)),
      standing: 1 + Math.round(rand() * 2),
      dueDay: state.day + legDays + 10,
      title: `${errand} for ${target.name}`,
      text: `${errand} to be put into the right hands at ${target.name}, under ${POWER_MAP[target.power]!.adjective} law. Paper weighs nothing: no hold space is wanted. Part of the fee is paid here on the quay.`,
    };
  }

  // Carriage: the goods come aboard at once and are locked under contract.
  if (roll < 0.78) {
    const wanted = Object.keys(target.consumes).length
      ? Object.keys(target.consumes)
      : Object.keys(port.produces);
    const cid = wanted[Math.floor(rand() * wanted.length)];
    const c = cid ? COMMODITY_MAP[cid] : undefined;
    if (!c) return undefined;
    // Keep the parcel small enough that a sloop can take it: 3-14 tons.
    const tons = 3 + rand() * 11;
    const qty = Math.max(1, Math.round(tons / Math.max(0.05, c.tons)));
    const value = c.base * qty;
    const reward = Math.round((value * (0.28 + rand() * 0.22) + dist * 0.85 + 120) * pay);
    const advance = rand() < 0.55 ? Math.round(reward * (0.15 + rand() * 0.2)) : 0;
    return {
      id: uid("qst", state.day + Math.floor(rand() * 1e6)),
      kind: "cargo",
      portId: port.id,
      targetPortId: target.id,
      cid: c.id,
      qty,
      reward,
      advance,
      standing: 2 + Math.round(rand() * 3),
      dueDay: state.day + legDays * 2 + 12,
      title: `Carry ${unitLabel(c.id, qty)} of ${c.name} to ${target.name}`,
      text: `A shipper at ${port.name} has ${unitLabel(c.id, qty)} of ${c.name} on the quay for ${target.name}. Take the work and it is struck below at once — you will want a ${holdNameFor(c.id)} and the room for it. The parcel stays sealed until it is landed.`,
    };
  }

  // Procurement: find the goods yourself, wherever they are cheap.
  const wanted = Object.keys(target.consumes).length
    ? Object.keys(target.consumes)
    : Object.keys(port.produces);
  const cid = wanted[Math.floor(rand() * wanted.length)];
  const c = cid ? COMMODITY_MAP[cid] : undefined;
  if (!c) return undefined;
  const qty = Math.max(1, Math.round((4 + rand() * 12) / Math.max(0.05, c.tons)));
  const reward = Math.round((c.base * qty * (1.5 + rand() * 0.55) + dist * 0.5) * pay);
  return {
    id: uid("qst", state.day + Math.floor(rand() * 1e6)),
    kind: "procure",
    portId: port.id,
    targetPortId: target.id,
    cid: c.id,
    qty,
    reward,
    advance: rand() < 0.35 ? Math.round(reward * 0.15) : 0,
    standing: 2 + Math.round(rand() * 3),
    dueDay: state.day + legDays * 2 + 18,
    title: `${unitLabel(c.id, qty)} of ${c.name} wanted at ${target.name}`,
    text: `A factor at ${target.name} will pay well above the market for ${unitLabel(c.id, qty)} of ${c.name}, landed on his quay. Buying the goods is your own affair — find them cheap and the difference is yours.`,
  };
}

/**
 * Black work: the same carriage, but the parcel is contraband and the men who
 * pay for it keep no books. Better money, worse company.
 */
function makeBlackQuest(
  state: GameState,
  port: Port,
  target: Port,
  dist: number,
  legDays: number,
  pay: number,
  rand: () => number,
): Quest | undefined {
  const pool = Object.keys(COMMODITY_MAP).filter(
    (id) => (COMMODITY_MAP[id]?.illegalFor ?? []).length > 0,
  );
  const cid = (pool.length ? pool : Object.keys(target.consumes))[
    Math.floor(rand() * Math.max(1, pool.length))
  ];
  const c = cid ? COMMODITY_MAP[cid] : undefined;
  if (!c) return undefined;
  const tons = 2 + rand() * 8;
  const qty = Math.max(1, Math.round(tons / Math.max(0.05, c.tons)));
  const reward = Math.round((c.base * qty * (0.55 + rand() * 0.35) + dist * 1.4 + 200) * pay * 1.7);
  return {
    id: uid("qst", state.day + Math.floor(rand() * 1e6)),
    kind: "cargo",
    black: true,
    faction: "pirate",
    portId: port.id,
    targetPortId: target.id,
    cid: c.id,
    qty,
    reward,
    advance: Math.round(reward * (0.1 + rand() * 0.2)),
    standing: 2 + Math.round(rand() * 3),
    dueDay: state.day + legDays * 2 + 10,
    title: `Run ${unitLabel(c.id, qty)} of ${c.name} into ${target.name}`,
    text: `A man with no name and good coin wants ${unitLabel(c.id, qty)} of ${c.name} landed quietly at ${target.name}. It comes aboard sealed as contraband: it cannot be sold, eaten or broken up, and if a guarda costa or a suspicious harbour master opens your hatches you will lose the lot and pay for the privilege.`,
  };
}

/** Refill the boards of every port, keeping accepted contracts. */
export function refreshQuests(state: GameState, rand: () => number) {
  const kept = state.quests.filter((q) => q.accepted);
  const fresh: Quest[] = [];
  for (const port of PORTS) {
    const want = questCount(port, portEdge(state, port.id).postings);
    const existing = state.quests.filter(
      (q) => q.portId === port.id && !q.accepted && q.dueDay > state.day + 3,
    );
    const carry = existing.slice(0, Math.max(0, want - 2));
    fresh.push(...carry);
    for (let i = carry.length; i < want; i++) {
      const q = makeQuest(state, port, rand);
      if (q) fresh.push(q);
    }
  }
  state.quests = [...kept, ...fresh];
}

export function questProgressNote(state: GameState, q: Quest): string {
  const to = q.targetPortId ? PORT_MAP[q.targetPortId]!.name : "—";
  const days = q.dueDay - state.day;
  return `${to} · ${days > 0 ? `${days} days left` : "overdue"}`;
}

/** Tons the contract will take out of the hold when it is accepted. */
export function questTons(q: Quest) {
  if (q.kind !== "cargo" || !q.cid || !q.qty) return 0;
  return (COMMODITY_MAP[q.cid]?.tons ?? 0.2) * q.qty;
}

/** Why the captain cannot take this work — or nothing, if he can. */
export function questBlocker(q: Quest, ship: Ship, freeTons: number): string | undefined {
  if (q.kind !== "cargo") return undefined;
  if (!q.cid) return undefined;
  if (!canStow(ship, q.cid)) return `No ${holdNameFor(q.cid)} fitted`;
  const need = questTons(q);
  if (need > freeTons) return `Wants ${need.toFixed(1)} t of hold, ${freeTons.toFixed(1)} t free`;
  return undefined;
}
