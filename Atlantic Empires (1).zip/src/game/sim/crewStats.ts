import { POSITION_SKILL, SKILL_IDS, effSkill, emptySkills } from "../data/crew";
import { traitSkillMult } from "../data/traits";
import type { GameState, Skills } from "../types";

/**
 * Player skills plus the best of the crew in each discipline. Only a man in his
 * proper post lends his full weight.
 */
export function bannerStats(state: GameState): Skills {
  const out: Skills = { ...state.player.stats };
  // The captain's own character tells on his work, same as any man's.
  const own = state.player.traits ?? [];
  for (const k of SKILL_IDS) out[k] = Math.round(out[k] * traitSkillMult(own, k));
  const best: Skills = emptySkills();
  for (const ship of state.ships) {
    for (const [pos, id] of Object.entries(ship.assignments ?? {})) {
      const m = state.crew.find((c) => c.id === id);
      if (!m) continue;
      const key = POSITION_SKILL[pos as keyof typeof POSITION_SKILL];
      const v = effSkill(m, key);
      if (v > best[key]) best[key] = v;
    }
  }
  for (const k of SKILL_IDS) out[k] = Math.round(out[k] + best[k] * 0.6);
  return out;
}

export function crewOf(state: GameState, shipId: string) {
  return state.crew.filter((m) => m.shipId === shipId);
}

/** Officers' pay, settled every seventh day. The captain takes no wage. */
export function weeklyWages(state: GameState) {
  const captains = new Set<string>();
  for (const ship of state.ships) {
    const id = (ship.assignments ?? {})["captain"];
    if (id) captains.add(id);
  }
  return state.crew.reduce((sum, m) => sum + (captains.has(m.id) ? 0 : m.wage), 0);
}

/** Charisma and logistics shave the merchant's spread; 0 → none, high → ~12%. */
export function bargainEdge(state: GameState) {
  const s = bannerStats(state);
  return Math.min(0.12, (s.charisma + s.logistics) / 1700);
}
