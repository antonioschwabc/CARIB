import { PORT_MAP } from "../data/ports";
import { POWER_MAP } from "../data/powers";
import { dockBlocked } from "../data/permits";
import { banFine, portBanned } from "./standing";
import { SHIP_CLASS_MAP } from "../data/ships";
import type { Destination, GameState, Ship } from "../types";
import { clamp, hurricaneFactor } from "./util";
import { shipStats } from "./shipStats";
import { dailyAppetite, suppliesAboard } from "./stores";
import { shipPos } from "./position";
import { seaRoute } from "./seagrid";

export interface VoyagePlan {
  from: { lat: number; lon: number };
  dest: Destination;
  distanceNm: number;
  /** the water road, worked round the land */
  path: { lat: number; lon: number }[];
  days: number;
  provisionsNeeded: number;
  wages: number;
  portFee: number;
  stormRisk: number;
  pirateRisk: number;
  patrolRisk: number;
  notes: string[];
  blocked?: string;
}


/** Tons of cargo she can lift, given her condition. */
export function shipCapacity(ship: Ship) {
  return Math.round(shipStats(ship).cargo * (0.7 + (ship.hull / 100) * 0.3));
}

export function effectiveGuns(ship: Ship) {
  return shipStats(ship).firepower;
}

export function cargoUsed(ship: Ship, volumeOf: (cid: string) => number) {
  return Object.entries(ship.cargo).reduce((sum, [cid, q]) => sum + q * volumeOf(cid), 0);
}

/** Knots actually made good, from her km/h rating and her state. */
export function effectiveSpeed(ship: Ship) {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const knots = shipStats(ship).speed / 1.852;
  const sailFactor = 0.55 + (ship.sails / 100) * 0.45;
  const hullFactor = 0.75 + (ship.hull / 100) * 0.25;
  const crewRatio = clamp(ship.crew / cls.hands, 0.4, 1.2);
  const crewFactor = crewRatio < 0.7 ? 0.7 + crewRatio * 0.3 : 1;
  const moraleFactor = 0.85 + (ship.morale / 100) * 0.15;
  return knots * sailFactor * hullFactor * crewFactor * moraleFactor;
}

export function planVoyage(state: GameState, ship: Ship, dest: Destination): VoyagePlan {
  const from = shipPos(ship);
  const here = PORT_MAP[ship.portId];
  const to = dest.portId ? PORT_MAP[dest.portId] : undefined;
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const stats = shipStats(ship);
  const route = seaRoute(from, dest);
  const dist = Math.round(route.distanceNm);
  const knots = effectiveSpeed(ship);
  const days = Math.max(1, Math.ceil(dist / (knots * 24)));
  const provisionsNeeded = Math.ceil(days * dailyAppetite(state, ship) * 10) / 10;
  const wages = Math.round((days / 7) * ship.crew * 11);

  const season = hurricaneFactor(state.day);
  const oceanCrossing = Math.abs(from.lon - dest.lon) > 30 || dist > 2200;
  const stormRisk = clamp(
    (0.03 + season * 0.1) * (days / 6) * (1.4 - ship.hull / 200) * (oceanCrossing ? 1.4 : 1)
      * (1 - clamp(stats.maneuverability / 400, 0, 0.25)),
    0.01,
    0.75,
  );
  const localRisk = ((here?.pirateRisk ?? 0.15) + (to?.pirateRisk ?? 0.2)) / 2;
  const pirateRisk = clamp(
    localRisk * (days / 5)
      * (1 - clamp(stats.firepower / 260, 0, 0.45))
      * (1 - clamp(stats.scouting / 500, 0, 0.2)),
    0.01,
    0.7,
  );
  const hostile = !!to && state.relations[to.power]! < -25 && !state.letters.includes(to.power);
  const patrolRisk = clamp(hostile ? 0.12 + (days / 30) : 0.02, 0, 0.6);

  const notes: string[] = [];
  if (season > 0.5) notes.push("Hurricane season — the odds of heavy weather are high.");
  if (oceanCrossing) notes.push("An ocean passage: long, and far from any friendly road.");
  if (suppliesAboard(ship) < provisionsNeeded)
    notes.push(
      `Stores are short: ${Math.round(suppliesAboard(ship))} units in the hold against ${provisionsNeeded} needed.`,
    );
  if (ship.crew < 3) notes.push("Only you and a hand or two aboard — she will crawl, and every watch will tell.");
  else if (ship.crew < cls.hands * 0.7) notes.push("Undermanned — she will not make her best speed.");
  if (hostile) notes.push(`${to!.name} flies a flag that currently regards you as an enemy.`);
  if (to && to.tariff > 0.2) notes.push(`Purchases at ${to.name} bear a ${Math.round(to.tariff * 100)}% duty.`);
  if (!route.ok) notes.push("No clear water road could be found to that mark.");
  if (!to) notes.push("Open water: she will lie to at the mark until you set a fresh course.");

  const plan: VoyagePlan = {
    from,
    dest,
    distanceNm: dist,
    path: route.points,
    days,
    provisionsNeeded,
    wages,
    portFee: to?.portFee ?? 0,
    stormRisk,
    pirateRisk,
    patrolRisk,
    notes,
  };
  if (!route.ok) plan.blocked = "There is no sea road to that mark — she cannot sail over land.";
  if (ship.hull < 12) plan.blocked = "The hull will not survive open water — repair her first.";
  if (to) {
    if (portBanned(state, to.id)) {
      const fine = state.fines?.[to.id] ?? banFine(to);
      notes.push(`${to.name} is closed to you — a fine of ${fine} gold must be paid before her boats will land you.`);
    }
    const denied = dockBlocked(state, to.power);
    if (denied)
      notes.push(`No ${POWER_MAP[to.power]!.adjective} permit to dock — she may approach, but the harbour will not admit her.`);
  }

  return plan;
}
