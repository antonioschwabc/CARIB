import { SHIP_CLASSES, SHIP_CLASS_MAP } from "../data/ships";
import { COMPONENT_DEFS } from "../data/shipParts";
import { PORT_MAP } from "../data/ports";
import type {
  BattleArena,
  BattleFrame,
  BattleShip,
  CombatResult,
  CombatState,
  Encounter,
  FoeEstimate,
  GameState,
  Port,
  Ship,
} from "../types";
import { pushLog } from "./events";
import { shareGold, shareXp } from "./progress";
import { shipStats } from "./shipStats";
import { addInfamy, addPrestige } from "./standing";
import { SALVAGE_IDS } from "./stores";
import { clamp, rng, uid } from "./util";
import { bannerStats } from "./crewStats";
import { fortStats, portOwner, sackPort } from "./world";
import { BATTLEGROUNDS, BATTLEGROUND_MAP, LAND, isOpenSea, nearestSea, tileAt } from "../data/battlegrounds";
import type { Battleground } from "../data/battlegrounds";

/** Days of quiet water granted after every action, won or lost. */
export const PEACE_DAYS = 7;

/** A shore battery stands on land, with deep water under its guns. */
function fortSite(arena: BattleArena, bg: Battleground) {
  let best = { x: arena.w - 6, y: arena.h / 2, score: -1 };
  for (let y = 4; y < arena.h - 4; y += bg.tile) {
    for (let x = arena.w / 2; x < arena.w - 3; x += bg.tile) {
      if (tileAt(bg, x, y) !== LAND) continue;
      let open = 0;
      for (let a = 0; a < 8; a++) {
        const th = (a / 8) * Math.PI * 2;
        if (isOpenSea(bg, x + Math.cos(th) * 6, y + Math.sin(th) * 6)) open++;
      }
      if (!open) continue;
      const score = open - Math.abs(y - arena.h / 2) / arena.h;
      if (score > best.score) best = { x, y, score };
    }
  }
  return { x: best.x, y: best.y };
}


function crewOf(state: GameState, ship: Ship) {
  return state.crew.filter((m) => m.shipId === ship.id);
}

/** The player's hull as a combatant. */
export function friendShip(state: GameState, ship: Ship): BattleShip {
  const st = shipStats(ship, crewOf(state, ship));
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const hull = Math.max(1, Math.round((cls.hull * ship.hull) / 100));
  return {
    id: ship.id,
    name: ship.name,
    side: "friend",
    className: cls.name,
    hull,
    maxHull: cls.hull,
    firepower: Math.max(1, st.firepower),
    speed: st.speed * (0.6 + ship.sails / 250),
    maneuver: st.maneuverability,
  };
}

/** Build the party on the other side from the mark that raised the alarm. */
export function foeShips(enc: Encounter, rand: () => number): BattleShip[] {
  const heavy = enc.kind === "privateer" ? 1 : 0;
  const pool = SHIP_CLASSES.filter((c) =>
    heavy ? ["brig", "frigate", "galleon"].includes(c.id) : ["sloop", "brigantine", "brig"].includes(c.id),
  );
  const count = rand() < 0.24 + enc.strength * 0.2 ? 2 : 1;
  const out: BattleShip[] = [];
  for (let i = 0; i < count; i++) {
    const cls = pool[Math.floor(rand() * pool.length)]!;
    const wear = 0.55 + rand() * 0.45;
    out.push({
      id: `foe${i}`,
      name: `${enc.title ?? "Strange sail"}${count > 1 ? ` (${i + 1})` : ""}`,
      side: "foe",
      className: cls.name,
      hull: Math.round(cls.hull * wear),
      maxHull: cls.hull,
      firepower: Math.round(cls.gunPower * cls.guns * (0.6 + rand() * 0.6)),
      speed: cls.speed * (0.8 + rand() * 0.3),
      maneuver: Math.round(cls.maneuverability * (0.8 + rand() * 0.35)),
    });
  }
  return out;
}

/** What the lookouts report: a range, narrowed by the Scout's eye. */
export function estimate(state: GameState, foes: BattleShip[]): FoeEstimate[] {
  const scouting = bannerStats(state).scouting;
  const m = clamp(0.5 - scouting / 260, 0.04, 0.45);
  const band = (v: number): [number, number] => [
    Math.round(v * (1 - m)),
    Math.round(v * (1 + m)),
  ];
  return foes.map((f) => ({
    id: f.id,
    name: f.name,
    className: scouting > 45 ? f.className : "rig uncertain",
    hull: band(f.hull),
    firepower: band(f.firepower),
    speed: band(Math.round(f.speed * 10) / 10),
    maneuver: band(f.maneuver),
  }));
}

function force(list: BattleShip[]) {
  return list.reduce((s, b) => s + b.firepower * (0.4 + b.hull / Math.max(1, b.maxHull)), 0);
}

/** Odds of shaking her off: canvas and helm against theirs. */
export function evadeChance(friends: BattleShip[], foes: BattleShip[]) {
  const mine = friends[0];
  if (!mine) return 0;
  const best = foes.reduce((a, b) => (b.speed > a.speed ? b : a), foes[0]!);
  const speed = (mine.speed - best.speed) * 0.12;
  const helm = (mine.maneuver - best.maneuver) * 0.004;
  return clamp(0.42 + speed + helm, 0.05, 0.93);
}

export function winChance(friends: BattleShip[], foes: BattleShip[]) {
  const a = force(friends);
  const b = force(foes);
  return clamp(a / Math.max(1, a + b), 0.03, 0.97);
}

/** Draw one of the dozen pregenerated stretches of water out of the hat. */
function makeArena(rand: () => number, groundId?: string): BattleArena {
  const bg =
    (groundId ? BATTLEGROUND_MAP[groundId] : undefined) ??
    BATTLEGROUNDS[Math.floor(rand() * BATTLEGROUNDS.length)]!;
  const lights: BattleArena["light"][] = ["day", "day", "day", "dawn", "dusk", "night"];
  const light = lights[Math.floor(rand() * lights.length)] ?? "day";
  return {
    w: bg.cols * bg.tile,
    h: bg.rows * bg.tile,
    islands: [],
    light,
    wind: rand() * Math.PI * 2,
    groundId: bg.id,
    groundName: bg.name,
  };
}

/** The chart of the water this action is fought on. */
export function groundOf(arena: BattleArena) {
  return (arena.groundId ? BATTLEGROUND_MAP[arena.groundId] : undefined) ?? BATTLEGROUNDS[0]!;
}



interface Agent extends BattleShip {
  x: number;
  y: number;
  h: number;
  reload: number;
}

/**
 * Fight the whole action out ahead of time. The player watches the record of
 * it; nothing is decided while he watches.
 */
export function simulate(
  friends: BattleShip[],
  foes: BattleShip[],
  arena: BattleArena,
  rand: () => number,
): { frames: BattleFrame[]; victory: boolean; drawn: boolean; survivors: BattleShip[] } {
  const bg = groundOf(arena);
  // Only the open sea counts: a pond behind a bar is no place for an action.
  const sea = (x: number, y: number) => isOpenSea(bg, x, y);
  // Both parties are laid on open water at their own end of the ground.
  const place = (i: number, fromLeft: boolean) => {
    const x = fromLeft ? 8 : arena.w - 8;
    const y = 8 + ((i * 13) % Math.max(1, arena.h - 16));
    return nearestSea(bg, x, y);
  };
  const agents: Agent[] = [
    ...friends.map((s, i) => ({ ...s, ...place(i, true), h: 0, reload: 2 + i })),
    ...foes.map((s, i) => ({
      ...s,
      ...(s.fort ? fortSite(arena, bg) : place(i, false)),
      h: Math.PI,
      reload: 3 + i,
    })),
  ];


  const frames: BattleFrame[] = [];
  const RANGE = 22;
  const STEP = 420;
  const BEAM = 2.8;

  // Round shot in flight, and the smoke it leaves at the muzzle.
  interface Ball {
    x0: number;
    y0: number;
    x1: number;
    y1: number;
    wait: number;
    t: number;
    dur: number;
    f: 0 | 1;
  }
  let balls: Ball[] = [];
  let smoke: { x: number; y: number; a: number }[] = [];

  for (let t = 0; t < STEP; t++) {
    const shots: BattleShot[] = [];
    for (const a of agents) {
      if (a.hull <= 0) continue;
      const enemies = agents.filter((b) => b.side !== a.side && b.hull > 0);
      if (!enemies.length) continue;
      const target = enemies.reduce((best, e) =>
        dist(a, e) < dist(a, best) ? e : best,
      );
      const d = dist(a, target);
      const bearing = Math.atan2(target.y - a.y, target.x - a.x);

      if (!a.fort) {
        // Close to gun range, then lay alongside on a parallel course.
        const want = d > RANGE * 0.75 ? bearing : bearing + Math.PI / 2;
        const diff = ((want - a.h + Math.PI * 3) % (Math.PI * 2)) - Math.PI;
        const turn = clamp(diff, -a.maneuver / 900, a.maneuver / 900);
        a.h += turn;
        const pace = (a.speed / 60) * (0.35 + a.hull / Math.max(1, a.maxHull));
        // A hull draws water: she may not cross the land. Blocked, she sheers off.
        const nx = clamp(a.x + Math.cos(a.h) * pace, 2, arena.w - 2);
        const ny = clamp(a.y + Math.sin(a.h) * pace, 2, arena.h - 2);
        if (sea(nx, ny)) {
          a.x = nx;
          a.y = ny;
        } else if (sea(nx, a.y)) {
          a.x = nx;
          a.h += 0.12;
        } else if (sea(a.x, ny)) {
          a.y = ny;
          a.h -= 0.12;
        } else {
          a.h += 0.22;
        }
      }


      a.reload -= 1;
      if (a.reload <= 0 && d <= RANGE) {
        a.reload = 8 + Math.floor(rand() * 5);
        const chance = clamp(
          0.62 - d / (RANGE * 3) + (a.maneuver - target.maneuver) * 0.0009,
          0.15,
          0.9,
        );
        const hit = rand() < chance;
        if (hit) {
          const dmg = a.firepower * (0.6 + rand() * 0.8);
          target.hull = Math.max(0, target.hull - dmg);
        }
        shots.push({ from: a.id, to: target.id, hit });

        // A broadside is not one ball: the guns speak down the side in turn.
        const n = 3 + Math.floor(rand() * 3);
        const flight = Math.max(3, Math.round(d * 0.55));
        const beam = a.h + Math.PI / 2;
        for (let g = 0; g < n; g++) {
          const off = (g - (n - 1) / 2) * 0.7;
          const x0 = a.x + Math.cos(a.h) * off;
          const y0 = a.y + Math.sin(a.h) * off;
          const spread = hit ? (rand() - 0.5) * 1.6 : (rand() - 0.5) * 5.5;
          balls.push({
            x0,
            y0,
            x1: target.x + Math.cos(beam) * spread,
            y1: target.y + Math.sin(beam) * spread,
            wait: g,
            t: 0,
            dur: flight,
            f: a.side === "friend" ? 1 : 0,
          });
          smoke.push({ x: x0, y: y0, a: 1 });
        }
      }
    }

    // Two hulls cannot occupy one patch of water — nor be shoved ashore.
    const shove = (a: Agent, x: number, y: number) => {
      if (a.fort) return;
      const nx = clamp(x, 2, arena.w - 2);
      const ny = clamp(y, 2, arena.h - 2);
      if (sea(nx, ny)) {
        a.x = nx;
        a.y = ny;
      }
    };
    for (let i = 0; i < agents.length; i++) {
      for (let j = i + 1; j < agents.length; j++) {
        const a = agents[i]!;
        const b = agents[j]!;
        if (a.hull <= 0 || b.hull <= 0) continue;
        const dx = b.x - a.x;
        const dy = b.y - a.y;
        const dd = Math.hypot(dx, dy) || 0.001;
        if (dd < BEAM * 2) {
          const push = (BEAM * 2 - dd) / 2;
          const ux = dx / dd;
          const uy = dy / dd;
          shove(a, a.x - ux * push, a.y - uy * push);
          shove(b, b.x + ux * push, b.y + uy * push);
        }
      }
    }


    // Advance the shot and thin the smoke.
    balls = balls.filter((b) => {
      if (b.wait > 0) {
        b.wait -= 1;
        return true;
      }
      b.t += 1;
      return b.t <= b.dur;
    });
    smoke = smoke.map((s) => ({ ...s, a: s.a - 0.14 })).filter((s) => s.a > 0);

    frames.push({
      ships: agents.map((a) => ({
        id: a.id,
        x: Math.round(a.x * 10) / 10,
        y: Math.round(a.y * 10) / 10,
        h: Math.round(a.h * 100) / 100,
        hull: Math.round(a.hull),
      })),
      shots,
      balls: balls
        .filter((b) => b.wait <= 0)
        .map((b) => {
          const k = b.t / b.dur;
          return {
            x: Math.round((b.x0 + (b.x1 - b.x0) * k) * 10) / 10,
            y: Math.round((b.y0 + (b.y1 - b.y0) * k) * 10) / 10,
            f: b.f,
          };
        }),
      smoke: smoke.map((s) => ({
        x: Math.round(s.x * 10) / 10,
        y: Math.round(s.y * 10) / 10,
        a: Math.round(s.a * 100) / 100,
      })),

    });

    const friendsAlive = agents.some((a) => a.side === "friend" && a.hull > 0);
    const foesAlive = agents.some((a) => a.side === "foe" && a.hull > 0);
    if (!friendsAlive || !foesAlive) break;
  }

  const friendsAlive = agents.some((a) => a.side === "friend" && a.hull > 0);
  const foesAlive = agents.some((a) => a.side === "foe" && a.hull > 0);
  // She is only lost if she is beaten to pieces. A long, indecisive action ends
  // with both parties drawing off, and the day counted to the survivor.
  const victory = friendsAlive && !foesAlive;

  return {
    frames,
    victory,
    drawn: friendsAlive && foesAlive,
    survivors: agents.map(({ x: _x, y: _y, h: _h, reload: _r, ...rest }) => rest),
  };
}

type BattleShot = { from: string; to: string; hit: boolean };

function dist(a: { x: number; y: number }, b: { x: number; y: number }) {
  return Math.hypot(a.x - b.x, a.y - b.y);
}

/** A harbour's batteries as a combatant: they do not move, and cannot be boarded. */
export function fortShip(port: Port): BattleShip {
  const f = fortStats(port);
  return {
    id: `fort-${port.id}`,
    name: `The batteries of ${port.name}`,
    side: "foe",
    className: `Fort (level ${port.level ?? 2})`,
    hull: f.defensiveness,
    maxHull: f.defensiveness,
    firepower: f.firepower,
    speed: 0,
    maneuver: 0,
    fort: true,
  };
}

/** Stand in and engage the shore. */
export function openPortAssault(state: GameState, ship: Ship, portId: string) {
  const port = PORT_MAP[portId];
  if (!port) return;
  const rand = rng(Math.floor(Math.random() * 1e9) + state.day * 4463);
  const friends = [friendShip(state, ship)];
  const foes = [fortShip(port)];
  state.combat = {
    phase: "preview",
    shipId: ship.id,
    encounterKind: "patrol",
    power: portOwner(state, portId),
    portId,
    title: `The batteries of ${port.name}`,
    text: `${port.name} lies under your guns. Her walls will not come to you — but they will not run, either, and they throw a heavier weight of metal than any hull afloat.`,
    friends,
    foes,
    estimates: estimate(state, foes),
    evadeChance: 0.95,
    winChance: winChance(friends, foes),
    arena: makeArena(rand),
  };
}

/** Beat to quarters: lay out the action before the first gun is fired. */
export function openCombat(state: GameState, ship: Ship, enc: Encounter) {
  const rand = rng(state.seed + state.day * 6151 + ship.name.length);
  const friends = [friendShip(state, ship)];
  const foes = foeShips(enc, rand);
  const combat: CombatState = {
    phase: "preview",
    shipId: ship.id,
    encounterKind: enc.kind,
    power: enc.power,
    title: enc.title ?? "A hostile sail",
    text: enc.text,
    ...(enc.eventId ? { eventId: enc.eventId } : {}),
    friends,
    foes,
    estimates: estimate(state, foes),
    evadeChance: evadeChance(friends, foes),
    winChance: winChance(friends, foes),
    arena: makeArena(rand),
  };
  state.combat = combat;
}

/** A yard exercise: pick a class, fight it on paper, and nothing carries over. */
export function openMockCombat(
  state: GameState,
  ship: Ship,
  classId: string,
  howMany = 1,
  fortLevel?: number,
) {
  if (fortLevel) return openMockFort(state, ship, fortLevel);
  // An exercise is drawn fresh every time: a new ground, a new light, new luck.
  const rand = rng(Math.floor(Math.random() * 1e9) + state.day * 9157 + classId.length * 131);
  const cls = SHIP_CLASS_MAP[classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const count = Math.max(1, Math.min(6, Math.round(howMany)));
  const foes: BattleShip[] = [];
  for (let i = 0; i < count; i++) {
    const wear = 0.55 + rand() * 0.45;
    foes.push({
      id: `foe${i}`,
      name: `${cls.name} (mock)${count > 1 ? ` ${i + 1}` : ""}`,
      side: "foe",
      className: cls.name,
      hull: Math.round(cls.hull * wear),
      maxHull: cls.hull,
      firepower: Math.round(cls.gunPower * cls.guns * (0.6 + rand() * 0.6)),
      speed: cls.speed * (0.8 + rand() * 0.3),
      maneuver: Math.round(cls.maneuverability * (0.8 + rand() * 0.35)),
    });
  }
  const friends = [friendShip(state, ship)];
  state.combat = {
    phase: "preview",
    mock: true,
    shipId: ship.id,
    encounterKind: "privateer",
    power: "pirate",
    title: `A mock action against a ${cls.name}`,
    text: "Guns run out with powder but no shot. The fleet tests her mettle against a phantom of the class chosen — the hull, the men and the strongbox are in no true danger.",
    friends,
    foes,
    estimates: estimate(state, foes),
    evadeChance: evadeChance(friends, foes),
    winChance: winChance(friends, foes),
    arena: makeArena(rand),
  };
}

/** A paper fort of the chosen size, raised for the exercise and nothing more. */
export function mockPort(level: number): Port {
  const lv = Math.max(1, Math.min(5, Math.round(level)));
  const name = ["A fishing station", "An outpost", "A colonial town", "A royal harbour", "A great stone citadel"][lv - 1]!;
  return {
    id: `mockfort${lv}`,
    name,
    level: lv,
    security: 0.18 + lv * 0.16,
    population: lv * 4200,
    prosperity: 0.2 + lv * 0.12,
  } as unknown as Port;
}

/** A yard exercise against the shore: stand in and try the batteries. */
export function openMockFort(state: GameState, ship: Ship, level: number) {
  const rand = rng(Math.floor(Math.random() * 1e9) + state.day * 3301 + level * 97);
  const port = mockPort(level);
  const friends = [friendShip(state, ship)];
  const foes = [fortShip(port)];
  state.combat = {
    phase: "preview",
    mock: true,
    shipId: ship.id,
    encounterKind: "patrol",
    power: "pirate",
    title: `A mock action against ${port.name.toLowerCase()} (level ${port.level})`,
    text: "The gunners lay their pieces at a fort of chalk and imagination. The walls will not fall and the ship will not bleed — but the weight of metal is reckoned true.",
    friends,
    foes,
    estimates: estimate(state, foes),
    evadeChance: 0.95,
    winChance: winChance(friends, foes),
    arena: makeArena(rand),
  };
}

/** The exercise's reckoning: drawn from the record, applied to nothing. */
function mockOutcome(before: number, c: CombatState, victory: boolean, drawn: boolean, hullAfter: number): CombatResult {
  const hullLost = Math.round(clamp((before - hullAfter) / Math.max(1, c.friends[0]!.maxHull), 0, 1) * 100);
  return {
    victory,
    hullLost,
    sailsLost: Math.round(hullLost * 0.7),
    gold: 0,
    prestige: 0,
    reputation: 0,
    goods: [],
    dead: [],
    hurt: [],
    note: drawn
      ? "Neither side would close again. The exercise is called; her true hull, crew and purse are untouched."
      : victory
        ? `The phantom is beaten. Had this been earnest, ${c.friends[0]!.name} would have lost ${hullLost}% of her hull doing it.`
        : `The phantom carries the day. Had this been earnest, ${c.friends[0]!.name} would be a wreck. Take the lesson for free.`,
  };
}

/** Try to run. Failing, the action begins anyway. */
export function tryEvade(state: GameState) {
  const c = state.combat;
  if (!c) return;
  const ship = state.ships.find((s) => s.id === c.shipId);
  if (!ship) {
    delete state.combat;
    return;
  }
  if (c.mock) {
    const randMock = rng(state.seed + state.day * 3571 + ship.hull);
    if (randMock() < c.evadeChance) {
      pushLog(state, "peril", `${ship.name} crowds sail and runs clear of the phantom. The exercise is over.`);
      delete state.combat;
      return;
    }
    beginBattle(state);
    return;
  }
  const rand = rng(state.seed + state.day * 3571 + ship.hull);
  if (rand() < c.evadeChance) {
    ship.sails = clamp(ship.sails - (3 + rand() * 6), 0, 100);
    if (ship.voyage) ship.voyage.daysLeft += 1;
    shareXp(state, "navigation", 120);
    settleMark(state, c.eventId);
    state.peaceUntil = state.day + PEACE_DAYS;
    pushLog(state, "peril", `${ship.name} crowds sail and runs clear of ${c.title}. A day lost and the canvas the worse for it.`);
    delete state.combat;
  } else {
    pushLog(state, "peril", `${ship.name} cannot shake her off. ${c.title} closes, and the drums beat to quarters.`);
    beginBattle(state);
  }
}

function settleMark(state: GameState, eventId?: string) {
  const mark = (state.seaEvents ?? []).find((e) => e.id === eventId);
  if (mark) mark.done = true;
}

/** Fight it, reckon it up, and store the record for the player to watch. */
export function beginBattle(state: GameState) {
  const c = state.combat;
  if (!c) return;
  const ship = state.ships.find((s) => s.id === c.shipId);
  if (!ship) {
    delete state.combat;
    return;
  }
  const rand = rng(state.seed + state.day * 8221 + Math.round(ship.hull * 7));
  const before = c.friends[0]!.hull;
  const { frames, victory, drawn, survivors } = simulate(c.friends, c.foes, c.arena, rand);
  const mine = survivors.find((s) => s.side === "friend")!;

  c.frames = frames;
  c.phase = "battle";
  if (c.mock) {
    c.result = mockOutcome(before, c, victory, drawn, mine.hull);
    return;
  }
  c.result = applyOutcome(state, ship, c, victory, drawn, before, mine.hull, rand);
  if (c.portId && victory) sackPort(state, c.portId, ship.allegiance ?? "pirate");
  settleMark(state, c.eventId);
  state.peaceUntil = state.day + PEACE_DAYS;
}

/**
 * The reckoning. Damage stands after the action, and a share of it is paid in
 * the flesh of the men: the hull she lost, spread at random across the company.
 */
function applyOutcome(
  state: GameState,
  ship: Ship,
  c: CombatState,
  victory: boolean,
  drawn: boolean,
  hullBefore: number,
  hullAfter: number,
  rand: () => number,
): CombatResult {
  const lostFrac = clamp((hullBefore - hullAfter) / Math.max(1, c.friends[0]!.maxHull), 0, 1);
  const hullLost = Math.round(lostFrac * 100);
  const sailsLost = Math.round(hullLost * (0.5 + rand() * 0.6));
  const dead: string[] = [];
  const hurt: { name: string; health: number }[] = [];

  if (hullAfter <= 0) {
    // She goes down. The captain is put ashore at his home port with a wreck.
    const home = PORT_MAP[state.homePortId ?? ""] ?? PORT_MAP["havana"]!;
    ship.hull = 0;
    ship.sails = 0;
    ship.cargo = {};
    delete ship.locked;
    delete ship.contraband;
    delete ship.voyage;
    delete ship.course;
    delete ship.station;
    ship.underway = false;
    ship.portId = home.id;
    state.cash = 0;
    ship.morale = clamp(ship.morale - 25, 0, 100);
    for (const m of state.crew.filter((x) => x.shipId === ship.id)) {
      m.health = clamp(m.health - (20 + rand() * 45), 0, 100);
      m.morale = clamp(m.morale - 25, 0, m.health);
    }
    reapCrew(state, ship, dead);
    state.reputation = clamp(state.reputation - 3, -100, 100);
    pushLog(
      state,
      "peril",
      `${ship.name} is beaten to a wreck by ${c.title}. What is left of her is towed into ${home.name}: the hold is empty and the strongbox with it.`,
    );
    return {
      victory: false,
      hullLost: 100,
      sailsLost: 100,
      gold: 0,
      prestige: 0,
      reputation: -3,
      goods: [],
      dead,
      hurt,
      note: `Struck and sunk. You come to yourself in ${home.name} with a hull fit for firewood, no cargo and no coin.`,
    };
  }

  // Won or drawn: the damage stands, and the company pays for it in blood.
  ship.hull = clamp(ship.hull - hullLost, 1, 100);
  ship.sails = clamp(ship.sails - sailsLost, 0, 100);

  const roster = state.crew.filter((m) => m.shipId === ship.id);
  let pool = hullLost * (0.7 + rand() * 0.8);
  while (pool > 1 && roster.length) {
    const victim = roster[Math.floor(rand() * roster.length)]!;
    const bite = Math.min(pool, 4 + rand() * 24);
    pool -= bite;
    victim.health = Math.round(victim.health - bite);
  }
  reapCrew(state, ship, dead);
  for (const m of state.crew.filter((x) => x.shipId === ship.id)) {
    m.health = clamp(m.health, 1, 100);
    m.morale = clamp(m.morale, 0, m.health);
    if (m.health < 55) hurt.push({ name: m.name, health: Math.round(m.health) });
  }
  ship.crew = Math.max(1, ship.crew - Math.round(rand() * 3));

  if (drawn) {
    for (const m of state.crew.filter((x) => x.shipId === ship.id)) {
      m.health = clamp(m.health, 1, 100);
      m.morale = clamp(m.morale - 4, 0, m.health);
    }
    shareXp(state, "gunnery", 120);
    pushLog(
      state,
      "peril",
      `${ship.name} and ${c.title} batter each other until neither will close again, and both draw off.`,
    );
    return {
      victory: false,
      hullLost,
      sailsLost,
      gold: 0,
      prestige: 0,
      reputation: 0,
      goods: [],
      dead,
      hurt,
      note: "Neither would close again. Both ships drew off, torn about and no richer for it.",
    };
  }

  const weight = c.foes.reduce((s, f) => s + f.maxHull, 0) / 400;
  const gold = Math.round((900 + rand() * 3400) * weight);
  shareGold(state, gold);
  shareXp(state, "gunnery", 260 * weight);
  shareXp(state, "all", 70);

  const goods: { cid: string; qty: number }[] = [];
  for (let i = 0; i < 2 + Math.floor(rand() * 3); i++) {
    const cid = SALVAGE_IDS[Math.floor(rand() * SALVAGE_IDS.length)]!;
    const qty = 1 + Math.round(rand() * 6 * weight);
    ship.cargo[cid] = (ship.cargo[cid] ?? 0) + qty;
    goods.push({ cid, qty });
  }

  let part: string | undefined;
  if (rand() < 0.16) {
    const def = COMPONENT_DEFS[Math.floor(rand() * COMPONENT_DEFS.length)];
    if (def) part = def.name;
  }

  const prestige = Math.round(4 + weight * 6);
  addPrestige(state, prestige, `Took ${c.title}`);
  if (c.encounterKind === "privateer") addInfamy(state, 2, "Fought a crown privateer");
  state.reputation = clamp(state.reputation + 1.5, -100, 100);

  pushLog(
    state,
    "peril",
    `${ship.name} beats ${c.title} into silence and takes ${gold} gold out of her before she goes down.`,
  );

  return {
    victory: true,
    hullLost,
    sailsLost,
    gold,
    prestige,
    reputation: 1.5,
    goods,
    ...(part ? { part } : {}),
    dead,
    hurt,
    note: dead.length
      ? `The day is yours, and ${dead.length} good ${dead.length > 1 ? "men are" : "man is"} sewn into a hammock for it.`
      : "The day is yours, and every man answers his name at muster.",
  };
}

/** Anyone whose health has run out is dead, and gone for good. */
function reapCrew(state: GameState, ship: Ship, dead: string[]) {
  for (const m of [...state.crew]) {
    if (m.shipId !== ship.id || m.health > 0) continue;
    dead.push(m.name);
    state.crew = state.crew.filter((x) => x.id !== m.id);
    for (const [pos, id] of Object.entries(ship.assignments ?? {}))
      if (id === m.id) delete ship.assignments[pos as keyof typeof ship.assignments];
    pushLog(state, "peril", `${m.name} is killed in the action and put over the side.`);
  }
}

/** Move from the record of the action to the reckoning, and then away. */
export function advanceCombat(state: GameState) {
  const c = state.combat;
  if (!c) return;
  if (c.phase === "preview") beginBattle(state);
  else if (c.phase === "battle") c.phase = "result";
  else delete state.combat;
}

export function newBattleId() {
  return uid("bat", Date.now() % 1e6);
}
