/** Deterministic small-state PRNG so saves replay identically. */
export function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s >>>= 0;
    s ^= s >> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

export const clamp = (v: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, v));

export const round2 = (v: number) => Math.round(v * 100) / 100;

export function uid(prefix: string, seed: number) {
  return `${prefix}_${seed.toString(36)}_${Math.floor(Math.random() * 1e6).toString(36)}`;
}

/** Gold -> "1,204 gold" / "4.24 gold" */
export function money(gold: number): string {
  const neg = gold < 0;
  const abs = Math.abs(gold);
  const rounded = Math.round(abs * 100) / 100;
  const str = `${rounded.toLocaleString("en-GB", { maximumFractionDigits: 2 })} gold`;
  return neg ? `−${str}` : str;
}

const MONTHS = ["January","February","March","April","May","June","July","August","September","October","November","December"];
const DAYS_IN = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

export function gameDate(day: number, startYear = 1670) {
  let d = day;
  let year = startYear;
  for (;;) {
    const len = 365;
    if (d < len) break;
    d -= len;
    year++;
  }
  let m = 0;
  while (d >= DAYS_IN[m]!) {
    d -= DAYS_IN[m]!;
    m++;
  }
  return { day: d + 1, month: MONTHS[m]!, monthIndex: m, year };
}

export function formatDate(day: number) {
  const d = gameDate(day);
  return `${d.day} ${d.month} ${d.year}`;
}

/** June–November hurricane season weighting, 0-1. */
export function hurricaneFactor(day: number) {
  const m = gameDate(day).monthIndex;
  const table = [0.02, 0.02, 0.03, 0.05, 0.1, 0.3, 0.55, 0.85, 1, 0.75, 0.35, 0.08];
  return table[m]!;
}
