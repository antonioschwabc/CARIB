import { COMMODITIES, COMMODITY_MAP } from "../data/commodities";
import { POSITION_SKILL, effSkill } from "../data/crew";
import type { CrewMember, GameState, Ship } from "../types";

/**
 * Stores are ordinary cargo put to a purpose. Nothing is a special resource:
 * salt beef in the hold is supper, canvas is a patch, rum is both physic and pay.
 */

/** Anything the people will eat or drink. */
export const SUPPLY_IDS = COMMODITIES.filter(
  (c) => c.category === "food" || c.category === "alcohol",
).map((c) => c.id);

/** What a surgeon works with. */
export const MEDICINE_IDS = ["rum", "brandy", "wine", "cloth", "linen", "cordage"];

/** What a carpenter works with, and what is worth taking off a wreck. */
export const SALVAGE_IDS = ["timber", "pitch", "canvas", "cordage", "iron", "tools", "copper"];

export const ALCOHOL_IDS = COMMODITIES.filter((c) => c.category === "alcohol").map((c) => c.id);

/** What is actually the captain's to use: contract goods are sealed. */
export function freeOf(ship: Ship, cid: string) {
  return Math.max(0, (ship.cargo[cid] ?? 0) - (ship.locked?.[cid] ?? 0));
}

export function lockedOf(ship: Ship, cid: string) {
  return ship.locked?.[cid] ?? 0;
}

function total(ship: Ship, ids: string[]) {
  return ids.reduce((sum, id) => sum + freeOf(ship, id), 0);
}

/**
 * A good cook makes more meals out of the same barrel; a good carpenter more
 * repairs out of the same timber; a good surgeon more doses out of the same
 * chest. Skill turns raw goods into usable stores.
 */
export function storeYield(
  state: { crew: CrewMember[] },
  ship: Ship,
  position: "cook" | "carpenter" | "surgeon",
) {
  const id = (ship.assignments ?? {})[position];
  const m = id ? state.crew.find((c) => c.id === id) : undefined;
  const skill = m ? effSkill(m, POSITION_SKILL[position]) : 0;
  return 1 + skill / 150;
}

export function effectiveSupplies(state: { crew: CrewMember[] }, ship: Ship) {
  return suppliesAboard(ship) * storeYield(state, ship, "cook");
}
export function effectiveMedicine(state: { crew: CrewMember[] }, ship: Ship) {
  return medicineAboard(ship) * storeYield(state, ship, "surgeon");
}
export function effectiveSalvage(state: { crew: CrewMember[] }, ship: Ship) {
  return salvageAboard(ship) * storeYield(state, ship, "carpenter");
}

export function suppliesAboard(ship: Ship) {
  return total(ship, SUPPLY_IDS);
}
export function medicineAboard(ship: Ship) {
  return total(ship, MEDICINE_IDS);
}
export function salvageAboard(ship: Ship) {
  return total(ship, SALVAGE_IDS);
}
export function spiritsAboard(ship: Ship) {
  return total(ship, ALCOHOL_IDS);
}

export function crewOfShip(state: GameState, ship: Ship): CrewMember[] {
  return state.crew.filter((m) => m.shipId === ship.id);
}

/** Units of stores the whole company eats in a day at sea. */
/** Rations a man's appetite score buys: 50 rations empty one unit of stores. */
export const RATIONS_PER_UNIT = 50;

/** Units of stores (barrels, casks) the whole company eats in a day at sea. */
export function dailyAppetite(state: GameState, ship: Ship) {
  const named = crewOfShip(state, ship);
  const anonymous = Math.max(0, ship.crew - named.length);
  const rations = named.reduce((sum, m) => sum + m.appetite, 0) + anonymous * 5 + 6;
  return rations / RATIONS_PER_UNIT;
}

/** Draw `want` units from the hold, cheapest stores first. Returns units taken. */
export function drawStores(ship: Ship, ids: string[], want: number) {
  let left = want;
  const order = [...ids].sort(
    (a, b) => (COMMODITY_MAP[a]?.base ?? 0) - (COMMODITY_MAP[b]?.base ?? 0),
  );
  for (const id of order) {
    if (left <= 0.001) break;
    const have = freeOf(ship, id);
    if (have <= 0) continue;
    const take = Math.min(have, left);
    const rest = (ship.cargo[id] ?? 0) - take;
    if (rest < 0.02 && !lockedOf(ship, id)) delete ship.cargo[id];
    else ship.cargo[id] = rest;
    left -= take;
  }
  return want - left;
}

/** Break the seal on contract goods: hand them over, or put them ashore. */
export function releaseLocked(ship: Ship, cid: string, qty: number, remove: boolean) {
  const locked = ship.locked?.[cid] ?? 0;
  const freed = Math.min(locked, qty);
  if (ship.locked) {
    const rest = locked - freed;
    if (rest <= 0.001) delete ship.locked[cid];
    else ship.locked[cid] = rest;
  }
  if (remove) {
    const rest = (ship.cargo[cid] ?? 0) - qty;
    if (rest < 0.02) delete ship.cargo[cid];
    else ship.cargo[cid] = rest;
  }
}
