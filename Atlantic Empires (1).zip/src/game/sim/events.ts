import { COMMODITIES } from "../data/commodities";
import { PORTS, PORT_MAP } from "../data/ports";
import { POWER_MAP } from "../data/powers";
import type { GameState, LogEntry, PowerId } from "../types";
import { clamp, hurricaneFactor, uid } from "./util";

function log(state: GameState, kind: LogEntry["kind"], text: string) {
  state.log.unshift({ id: uid("ev", state.day), day: state.day, kind, text });
  if (state.log.length > 300) state.log.length = 300;
}

/** Roll world events for one day. Events mutate simulation state, never just text. */
export function rollEvents(state: GameState, rand: () => number) {
  // Hurricanes
  if (rand() < 0.012 * (0.3 + hurricaneFactor(state.day))) {
    const caribbean = PORTS.filter((p) => p.region !== "Europe" && p.region !== "West Africa" && p.lat > 8 && p.lat < 30);
    const hit = caribbean[Math.floor(rand() * caribbean.length)]!;
    const market = state.markets[hit.id]!;
    for (const cid of Object.keys(hit.produces)) {
      market.stock[cid] = (market.stock[cid] ?? 0) * 0.45;
      market.shock[cid] = (market.shock[cid] ?? 0) + 0.35;
    }
    hit.prosperity = clamp(hit.prosperity - 0.06, 0.15, 1);
    // Regional price echo
    for (const p of caribbean) {
      const m = state.markets[p.id]!;
      for (const cid of Object.keys(hit.produces)) m.shock[cid] = (m.shock[cid] ?? 0) + 0.08;
    }
    log(state, "world", `A hurricane strikes ${hit.name}. Plantations flattened, shipping driven ashore; her exports will be scarce for weeks.`);
  }

  // Crop failure / bumper harvest
  if (rand() < 0.03) {
    const port = PORTS[Math.floor(rand() * PORTS.length)]!;
    const goods = Object.keys(port.produces);
    if (goods.length) {
      const cid = goods[Math.floor(rand() * goods.length)]!;
      const bad = rand() < 0.55;
      const m = state.markets[port.id]!;
      m.shock[cid] = (m.shock[cid] ?? 0) + (bad ? 0.3 : -0.22);
      m.stock[cid] = (m.stock[cid] ?? 0) * (bad ? 0.6 : 1.5);
      const name = COMMODITIES.find((c) => c.id === cid)!.name.toLowerCase();
      log(state, "world", bad
        ? `Blight and drought at ${port.name}: the ${name} crop fails, supply down sharply.`
        : `A bumper ${name} harvest at ${port.name} floods the warehouses.`);
    }
  }

  // Epidemic
  if (rand() < 0.008) {
    const port = PORTS[Math.floor(rand() * PORTS.length)]!;
    port.prosperity = clamp(port.prosperity - 0.08, 0.12, 1);
    const m = state.markets[port.id]!;
    m.shock["flour"] = (m.shock["flour"] ?? 0) + 0.25;
    m.shock["wine"] = (m.shock["wine"] ?? 0) + 0.2;
    log(state, "world", `Yellow fever sweeps ${port.name}. Trade slackens; provisions and wine grow dear.`);
  }

  // War & peace
  if (rand() < 0.01) {
    const ids: PowerId[] = ["spain", "england", "france", "dutch", "portugal"];
    const a = ids[Math.floor(rand() * ids.length)]!;
    const b = ids[Math.floor(rand() * ids.length)]!;
    if (a !== b) {
      const war = rand() < 0.5;
      for (const p of PORTS.filter((x) => x.power === a || x.power === b)) {
        const m = state.markets[p.id]!;
        for (const cid of ["muskets", "powder", "saltbeef", "canvas", "cordage"]) {
          m.shock[cid] = (m.shock[cid] ?? 0) + (war ? 0.3 : -0.12);
        }
        p.pirateRisk = clamp(p.pirateRisk + (war ? 0.06 : -0.04), 0.03, 0.6);
      }
      log(state, "world", war
        ? `News from Europe: ${POWER_MAP[a]!.name} declares war on ${POWER_MAP[b]!.name}. Arms and naval stores climb; the sea lanes grow dangerous.`
        : `A peace is concluded between ${POWER_MAP[a]!.name} and ${POWER_MAP[b]!.name}. Privateers are called in and war stores slump.`);
    }
  }

  // Embargo / free port
  if (rand() < 0.012) {
    const port = PORTS[Math.floor(rand() * PORTS.length)]!;
    const tighten = rand() < 0.5;
    port.tariff = clamp(port.tariff + (tighten ? 0.08 : -0.06), 0.01, 0.4);
    log(state, "world", tighten
      ? `${port.name}'s governor raises the duties to ${Math.round(port.tariff * 100)}% — smugglers rejoice.`
      : `${port.name} lowers its duties to ${Math.round(port.tariff * 100)}% to draw shipping.`);
  }

  // Speculative demand
  if (rand() < 0.02) {
    const c = COMMODITIES[Math.floor(rand() * COMMODITIES.length)]!;
    const region = ["Europe", "Greater Antilles", "Lesser Antilles", "Spanish Main"][Math.floor(rand() * 4)]!;
    for (const p of PORTS.filter((x) => x.region === region)) {
      state.markets[p.id]!.shock[c.id] = (state.markets[p.id]!.shock[c.id] ?? 0) + 0.22;
    }
    log(state, "world", `${region}: a sudden fashion for ${c.name.toLowerCase()} sends buyers scrambling.`);
  }

  // Pirate surge near a port
  if (rand() < 0.015) {
    const port = PORTS[Math.floor(rand() * PORTS.length)]!;
    port.pirateRisk = clamp(port.pirateRisk + 0.1, 0.02, 0.7);
    log(state, "peril", `Sails without colours reported off ${port.name}. Underwriters raise their rates.`);
  }
}

export { log as pushLog };
export const portName = (id: string) => PORT_MAP[id]?.name ?? id;
