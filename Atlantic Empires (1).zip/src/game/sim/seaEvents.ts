import { PORTS, PORT_MAP } from "../data/ports";
import { POWER_MAP } from "../data/powers";
import { HOSTILE_KINDS, type GameState, type PowerId, type SeaEvent, type Ship } from "../types";
import { openCombat } from "./battle";
import { isSea, nmBetween, pointAlong } from "./seagrid";
import { shipPos } from "./position";
import { shipStats } from "./shipStats";
import { ENCOUNTERS } from "./encounters";
import { uid } from "./util";

/** How many marks the whole ocean carries at once. The sea is mostly empty. */
const MAX_EVENTS = 55;

/**
 * After a captain has had his hands full with one mark, the lookouts are given
 * a quiet stretch of water before the next is allowed to stop the ship.
 */
export const ENCOUNTER_GRACE_DAYS = 9;

const DEFS = ENCOUNTERS;

const TOTAL_WEIGHT = DEFS.reduce((s, d) => s + d.weight, 0);

function pickDef(rand: () => number) {
  let r = rand() * TOTAL_WEIGHT;
  for (const d of DEFS) {
    r -= d.weight;
    if (r <= 0) return d;
  }
  return DEFS[0]!;
}

/**
 * True only for water with water all round it. A single sea cell hemmed in by
 * headlands is where marks used to appear to sit on dry land.
 */
function openWater(lat: number, lon: number) {
  if (!isSea(lat, lon)) return false;
  for (const [dLat, dLon] of [
    [0.25, 0],
    [-0.25, 0],
    [0, 0.25],
    [0, -0.25],
    [0.18, 0.18],
    [-0.18, -0.18],
  ] as const) {
    if (!isSea(lat + dLat, lon + dLon)) return false;
  }
  return true;
}

/** A bearing on open water, biased toward the sea lanes near harbours. */
function seaSpot(rand: () => number): { lat: number; lon: number } | undefined {
  for (let attempt = 0; attempt < 40; attempt++) {
    const anchor = PORTS[Math.floor(rand() * PORTS.length)]!;
    const spread = 1 + rand() * 7;
    const lat = anchor.lat + (rand() - 0.5) * 2 * spread;
    const lon = anchor.lon + (rand() - 0.5) * 2.4 * spread;
    if (openWater(lat, lon)) return { lat, lon };
  }
  return undefined;
}

function nearestPower(lat: number, lon: number): PowerId {
  let best = PORTS[0]!;
  let bestD = Infinity;
  for (const p of PORTS) {
    const d = nmBetween({ lat, lon }, p);
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  return best.power;
}

/** Sow the chart with fresh marks and let the stale ones fade. */
export function rollSeaEvents(state: GameState, rand: () => number) {
  const list = (state.seaEvents ??= []);
  for (let i = list.length - 1; i >= 0; i--) {
    const e = list[i]!;
    if (e.done || e.expiresDay <= state.day) list.splice(i, 1);
  }

  const room = MAX_EVENTS - list.length;
  const want = Math.min(room, 1 + Math.floor(rand() * 3));

  // A few of the day's marks are sown along the water ahead of the ship at sea,
  // so a passage is never an empty fortnight.
  const sailing = state.ships.find((sh) => sh.id === state.activeShipId && sh.voyage);
  const ahead: { lat: number; lon: number }[] = [];
  if (sailing?.voyage) {
    const v = sailing.voyage;
    const done = v.progressNm ?? 0;
    for (let i = 0; i < 2; i++) {
      // somewhere on the water road still to run, a little off the track
      const along = done + (0.15 + rand() * 0.85) * Math.max(60, v.distanceNm - done);
      const on = v.path?.length ? pointAlong(v.path, Math.min(along, v.distanceNm)) : shipPos(sailing);
      for (let attempt = 0; attempt < 24; attempt++) {
        const lat = on.lat + (rand() - 0.5) * 1.4;
        const lon = on.lon + (rand() - 0.5) * 1.6;
        if (openWater(lat, lon)) {
          ahead.push({ lat, lon });
          break;
        }
      }
    }
  }

  for (let i = 0; i < want; i++) {
    const spot = ahead[i] ?? seaSpot(rand);
    if (!spot) continue;
    const def = pickDef(rand);
    const power = def.kind === "pirate" ? "pirate" : nearestPower(spot.lat, spot.lon);
    const life = def.life[0] + rand() * (def.life[1] - def.life[0]);
    list.push({
      id: uid("sea", state.day * 100 + i),
      kind: def.kind,
      lat: Number(spot.lat.toFixed(3)),
      lon: Number(spot.lon.toFixed(3)),
      power,
      strength: 0,
      title: def.kind === "patrol" ? `${POWER_MAP[power]!.adjective} patrol` : def.title,
      text: def.lines[Math.floor(rand() * def.lines.length)]!,
      expiresDay: state.day + Math.round(life),
    });
  }
}

/** How far the lookouts see, in sea miles — the Scout's own eye included. */
export function sightRangeNm(ship: Ship) {
  // A masthead lookout sees little: a modest bubble that good Scouting widens.
  return Math.round(12 + shipStats(ship).scouting * 0.28);
}

/**
 * Sweep the bubble round the ship: raise what is in sight, and stop her when
 * something demands the captain's word.
 */
export function scanSeaEvents(state: GameState, ship: Ship, rand: () => number): SeaEvent | undefined {
  const list = state.seaEvents ?? [];
  if (!list.length) return undefined;
  // A quiet stretch of water after the last affair: marks are still raised and
  // drawn on the chart, but none of them heaves her to.
  const quiet = (state.calmUntil ?? -1) >= state.day;
  const here = shipPos(ship);
  const range = sightRangeNm(ship);
  let closest: { e: SeaEvent; d: number } | undefined;
  for (const e of list) {
    if (e.done) continue;
    const d = nmBetween(here, e);
    if (d > range) continue;
    e.seen = true;
    // Only what she runs close aboard actually stops her.
    if (d <= range * 0.55 && (!closest || d < closest.d)) closest = { e, d };
  }
  // Not every sail sighted is worth heaving to for.
  if (quiet) return undefined;
  return closest && rand() < 0.35 ? closest.e : undefined;
}

export function encounterFromEvent(state: GameState, ship: Ship, e: SeaEvent) {
  const enc = {
    id: uid("enc", state.day),
    shipId: ship.id,
    kind: e.kind,
    power: e.power ?? "pirate",
    strength: e.strength,
    text: e.text,
    title: e.title,
    eventId: e.id,
    lat: e.lat,
    lon: e.lon,
  };

  // A hostile sail is not settled by words: she beats to quarters instead.
  if (HOSTILE_KINDS.includes(e.kind)) {
    if ((state.peaceUntil ?? -1) >= state.day) {
      e.done = true;
      return;
    }
    openCombat(state, ship, enc);
    return;
  }

  state.encounter = enc;
}


/**
 * What the lookouts have under their eye at this moment. A mark once passed by
 * drops off the sheet again until she runs close enough to raise it afresh.
 */
export function visibleSeaEvents(
  state: GameState,
  at?: { lat: number; lon: number },
  rangeNm?: number,
) {
  const list = (state.seaEvents ?? []).filter((e) => e.seen && !e.done);
  if (!at || !rangeNm) return list;
  return list.filter((e) => nmBetween(at, e) <= rangeNm);
}

export function nearestPortName(lat: number, lon: number) {
  let best = PORTS[0]!;
  let bestD = Infinity;
  for (const p of PORTS) {
    const d = nmBetween({ lat, lon }, p);
    if (d < bestD) {
      bestD = d;
      best = p;
    }
  }
  return `${Math.round(bestD)} nm from ${PORT_MAP[best.id]!.name}`;
}
