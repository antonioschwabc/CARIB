import { createContext, useCallback, useContext, useEffect, useMemo, useState, type Context, type ReactNode } from "react";

import { reduce, type Action } from "./actions";
import { AUTOSAVE, DAILY_SAVE, loadGame, saveGame } from "./save";
import { hydrateWorld, newGame, syncCrewContext } from "./state";
import type { GameState } from "./types";

interface GameContextValue {
  state: GameState;
  dispatch: (action: Action) => void;
  restart: (name?: string) => void;
  /** Write the present state into a named slot of the log book. */
  saveTo: (slot: string, label: string) => void;
  /** Read a slot back in, replacing the running game. */
  loadFrom: (slot: string) => boolean;
  ready: boolean;
}

// Keep a single context instance even if this module is evaluated twice
// (HMR / route code-splitting can otherwise create two distinct contexts).
const globalStore = globalThis as typeof globalThis & {
  __caribGameContext?: Context<GameContextValue | undefined>;
};
const GameContext =
  globalStore.__caribGameContext ??
  (globalStore.__caribGameContext = createContext<GameContextValue | undefined>(undefined));

export function GameProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<GameState | undefined>(undefined);

  useEffect(() => {
    setState(hydrateWorld(loadGame(AUTOSAVE) ?? newGame()));
  }, []);

  // The captain and his muster stand behind every derived figure.
  if (state) syncCrewContext(state);

  useEffect(() => {
    if (!state) return;
    const id = window.setTimeout(() => saveGame(AUTOSAVE, "Autosave", state), 400);
    return () => window.clearTimeout(id);
  }, [state]);

  const dispatch = useCallback((action: Action) => {
    setState((prev) => (prev ? reduce(prev, action) : prev));
  }, []);

  const restart = useCallback((name?: string) => setState(hydrateWorld(newGame(name ? { captain: name } : {}))), []);

  const saveTo = useCallback(
    (slot: string, label: string) => {
      if (state) saveGame(slot, label, state);
    },
    [state],
  );

  const loadFrom = useCallback((slot: string) => {
    const loaded = loadGame(slot);
    if (loaded) hydrateWorld(loaded);
    if (!loaded) return false;
    setState(loaded);
    return true;
  }, []);

  // A fresh keepsake of every dawn, so a bad day can always be sailed again.
  const day = state?.day;
  useEffect(() => {
    if (!state || day === undefined) return;
    saveGame(DAILY_SAVE, `Dawn of day ${day}`, state);
    // Only when the calendar turns, not on every trade.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [day]);

  const value = useMemo<GameContextValue | undefined>(
    () => (state ? { state, dispatch, restart, saveTo, loadFrom, ready: true } : undefined),
    [state, dispatch, restart, saveTo, loadFrom],
  );

  if (!value) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-background">
        <p className="font-serif text-lg text-muted-foreground">Unrolling the charts…</p>
      </div>
    );
  }

  return <GameContext.Provider value={value}>{children}</GameContext.Provider>;
}

export function useGame() {
  const ctx = useContext(GameContext);
  if (!ctx) throw new Error("useGame must be used inside GameProvider");
  return ctx;
}
