import { unitLabel, COMMODITY_MAP } from "./data/commodities";
import { signingFee } from "./data/crew";
import { PORT_MAP, PORTS, setRevealedPorts } from "./data/ports";
import { BUSINESS_MAP, SHIP_CLASS_MAP } from "./data/ships";
import { COMPONENT_MAP, QUARTER_MAP, componentCost, gunCost, yardMaxMark } from "./data/shipParts";
import { hydrateWorld, makeShip } from "./state";
import { shipStats, quartersUsed, lodgings } from "./sim/shipStats";
import { POWERS } from "./data/powers";
import {
  PERMIT_KINDS,
  PERMIT_TERM,
  permitEligible,
  permitGrant,
  permitPrice,
  PERMIT_KIND_MAP,
  permitBlocked,
  type PermitKind,
} from "./data/permits";
import { beginVoyage } from "./sim/tick";
import { portDestination, sameDestination } from "./sim/position";
import { priceOf } from "./sim/economy";
import { RUMOUR_RANGE_NM, rumourPrice, tavernBid, tavernOffers } from "./sim/tavern";
import { nmBetween } from "./sim/seagrid";
import { pushLog } from "./sim/events";
import { giveXp, givePlayerXp, shareGold, shareXp } from "./sim/progress";
import { tickDay } from "./sim/tick";
import { bargainEdge } from "./sim/crewStats";
import { clamp, uid } from "./sim/util";
import { cargoUsed, planVoyage, shipCapacity } from "./sim/voyage";
import { HOLD_MAP, canStow, holdNameFor } from "./sim/holds";
import { questBlocker } from "./sim/quests";
import { releaseLocked } from "./sim/stores";
import { adjustReputation, contractPenalty, powerOfPort, repEffects } from "./sim/reputation";
import {
  addFactionStanding,
  addInfamy,
  addPortStanding,
  addPrestige,
  banFine,
  portBanned,
  portStanding,
} from "./sim/standing";
import { resolveSeaEncounter } from "./sim/encounters";
import { resolveStory } from "./sim/story";
import { beginBattle, openMockCombat, openPortAssault, tryEvade } from "./sim/battle";
import { rng } from "./sim/util";
import type { Banner, CrewPosition, Destination, GameState, PowerId, Ship } from "./types";

export type Action =
  | { type: "advance"; days: number }
  | { type: "buy"; cid: string; qty: number }
  | { type: "tavernBuy"; cid: string; qty: number }
  | { type: "tavernBarterBuy"; cid: string; qty: number }
  | { type: "tavernBarterSell"; cid: string; qty: number }
  | { type: "buyRumours" }
  | { type: "sell"; cid: string; qty: number }
  | { type: "sail"; dest: Destination }
  | { type: "setCourse"; dest: Destination | undefined }
  | { type: "skip"; maxDays?: number }
  | { type: "setRudder"; underway: boolean }
  | { type: "selectShip"; shipId: string }
  | { type: "renameShip"; shipId: string; name: string }
  | { type: "repair" }
  | { type: "provision"; units: number }
  | { type: "hire"; count: number }
  | { type: "dismiss"; count: number }
  | { type: "buyShip"; classId: string }
  | { type: "sellShip"; shipId: string }
  | { type: "takeLoan"; amount: number }
  | { type: "repayLoan"; loanId: string }
  | { type: "buyBusiness"; typeId: string }
  | { type: "upgradeBusiness"; id: string }
  | { type: "sellBusiness"; id: string }
  | { type: "gift"; power: import("./types").PowerId; amount: number }
  | { type: "letterOfMarque"; power: import("./types").PowerId }
  | { type: "recruit"; memberId: string }
  | { type: "dismissMember"; memberId: string }
  | { type: "acceptQuest"; questId: string }
  | { type: "abandonQuest"; questId: string }
  | { type: "deliverQuest"; questId: string }
  | { type: "trackQuest"; questId: string | undefined }
  | { type: "payDebt"; amount: number }
  | { type: "payFine"; portId: string }
  | { type: "installComponent"; shipId: string; defId: string }
  | { type: "upgradeComponent"; shipId: string; componentId: string }
  | { type: "removeComponent"; shipId: string; componentId: string }
  | { type: "buyGun"; shipId: string }
  | { type: "upgradeGun"; shipId: string; index: number }
  | { type: "sellGun"; shipId: string; index: number }
  | { type: "installHold"; shipId: string; category: import("./types").CommodityCategory }
  | { type: "removeHold"; shipId: string; category: import("./types").CommodityCategory }
  | { type: "installQuarter"; shipId: string; position: CrewPosition }
  | { type: "removeQuarter"; shipId: string; position: CrewPosition }
  | { type: "assignCrew"; shipId: string; position: CrewPosition; memberId: string | undefined }
  | { type: "buyPermit"; power: PowerId; kind: PermitKind }
  | { type: "setShipBanner"; shipId: string; banner: Banner | undefined }
  | { type: "setAllegiance"; shipId: string; power: PowerId | undefined }
  | { type: "setLaws"; crewShare: number }
  | { type: "encounter"; choice: string }
  | { type: "story"; choice: string }
  | { type: "dismissOutcome" }
  | { type: "combat"; move: "evade" | "engage" | "watched" | "close" }
  | { type: "mockBattle"; classId: string; count?: number; fortLevel?: number }
  | { type: "assaultPort"; portId: string }
  | { type: "devCheat"; what: "gold" | "prestige" | "infamy" | "reveal" | "permits" | "clear" };

export const volumeOf = (cid: string) => COMMODITY_MAP[cid]?.tons ?? 0.2;

/** Market price after the captain's (and quartermaster's) haggling. */
export function dealPrice(state: GameState, p: { buy: number; sell: number }) {
  const edge = bargainEdge(state);
  return {
    buy: Math.max(1, Math.round(p.buy * (1 - edge))),
    sell: Math.round(p.sell * (1 + edge)),
  };
}

export function activeShip(state: GameState): Ship | undefined {
  return state.ships.find((s) => s.id === state.activeShipId) ?? state.ships[0];
}

/** Pure-ish reducer: takes a state, returns a new state (structural clone then mutate). */
export function reduce(prev: GameState, action: Action): GameState {
  const state: GameState = structuredClone(prev);
  hydrateWorld(state);
  const ship = activeShip(state);

  switch (action.type) {
    case "advance": {
      for (let i = 0; i < action.days; i++) {
        tickDay(state);
        if (state.encounter || state.story || state.combat) break;
      }
      break;
    }

    case "skip": {
      const limit = Math.max(1, Math.min(60, action.maxDays ?? 30));
      const before = state.log.length;
      for (let i = 0; i < limit; i++) {
        const wasVoyaging = !!activeShip(state)?.voyage;
        tickDay(state);
        if (state.encounter || state.story || state.combat) break;
        if (wasVoyaging && !activeShip(state)?.voyage) break;
        const fresh = state.log.slice(before).some((e) => e.kind === "peril" || e.kind === "world");
        if (fresh) break;
      }
      break;
    }

    case "selectShip":
      state.activeShipId = action.shipId;
      break;

    case "renameShip": {
      const s = state.ships.find((x) => x.id === action.shipId);
      if (s) s.name = action.name.slice(0, 40) || s.name;
      break;
    }

    case "buy": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const market = state.markets[port.id]!;
      const p = {
        ...priceOf(state, port.id, action.cid, port),
        ...dealPrice(state, priceOf(state, port.id, action.cid, port)),
      };
      const blocked = permitBlocked(state, port.power, action.cid);
      if (blocked) break;
      if (!canStow(ship, action.cid)) {
        pushLog(
          state,
          "trade",
          `${ship.name} has no ${holdNameFor(action.cid)} fitted; the goods stay on the quay.`,
        );
        break;
      }
      const stock = market.stock[action.cid] ?? 0;
      const spaceLeft = shipCapacity(ship) - cargoUsed(ship, volumeOf);
      const maxByHold = Math.floor(spaceLeft / volumeOf(action.cid));
      const qty = Math.max(
        0,
        Math.min(action.qty, Math.floor(stock), maxByHold, Math.floor(state.cash / p.buy)),
      );
      if (qty <= 0) break;
      const cost = qty * p.buy;
      state.cash -= cost;
      market.stock[action.cid] = stock - qty;
      ship.cargo[action.cid] = (ship.cargo[action.cid] ?? 0) + qty;
      if (!p.legal) addInfamy(state, 0.6, "Bought under the counter");
      // Coin over the counter makes a face familiar on the quay.
      addPortStanding(state, port.id, Math.min(0.4, cost / 5000));
      addPrestige(state, cost / 4000);
      givePlayerXp(state, "logistics", Math.min(60, cost / 60));
      tradeLearning(state, ship.id, Math.min(60, cost / 90));
      pushLog(
        state,
        "trade",
        `Bought ${unitLabel(action.cid, qty)} of ${COMMODITY_MAP[action.cid]!.name} at ${port.name} for ${Math.round(cost)} gold.`,
      );
      break;
    }

    // The tap-room sells small parcels of victuals at a landlord's price. No paperwork asked.
    case "tavernBuy": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const market = state.markets[port.id]!;
      if (!canStow(ship, action.cid)) break;
      const p = priceOf(state, port.id, action.cid, port);
      const unit = Math.round(p.unit * 1.3 * 100) / 100;
      const stock = market.stock[action.cid] ?? 0;
      const spaceLeft = shipCapacity(ship) - cargoUsed(ship, volumeOf);
      const maxByHold = Math.floor(spaceLeft / volumeOf(action.cid));
      const qty = Math.max(
        0,
        Math.min(
          action.qty,
          10,
          Math.floor(stock),
          maxByHold,
          Math.floor(state.cash / Math.max(1, unit)),
        ),
      );
      if (qty <= 0) break;
      const cost = Math.round(qty * unit);
      state.cash -= cost;
      market.stock[action.cid] = stock - qty;
      ship.cargo[action.cid] = (ship.cargo[action.cid] ?? 0) + qty;
      pushLog(
        state,
        "trade",
        `Bought ${unitLabel(action.cid, qty)} of ${COMMODITY_MAP[action.cid]!.name} over the tavern counter at ${port.name} for ${cost} gold.`,
      );
      break;
    }

    // The landlord's shelf: no paper asked, small parcels, his price.
    case "tavernBarterBuy": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const offer = tavernOffers(state, port).find((o) => o.cid === action.cid);
      if (!offer) break;
      const spaceLeft = shipCapacity(ship) - cargoUsed(ship, volumeOf);
      const maxByHold = Math.floor(spaceLeft / volumeOf(action.cid));
      const qty = Math.max(
        0,
        Math.min(
          action.qty,
          offer.qty,
          maxByHold,
          Math.floor(state.cash / Math.max(1, offer.unit)),
        ),
      );
      if (qty <= 0) break;
      const cost = Math.round(qty * offer.unit);
      state.cash -= cost;
      ship.cargo[action.cid] = (ship.cargo[action.cid] ?? 0) + qty;
      state.tavernTaken ??= {};
      state.tavernTaken[`${port.id}:${action.cid}`] =
        (state.tavernTaken[`${port.id}:${action.cid}`] ?? 0) + qty;
      pushLog(
        state,
        "trade",
        `Bartered for ${unitLabel(action.cid, qty)} of ${COMMODITY_MAP[action.cid]!.name} in the tavern at ${port.name}, ${cost} gold.`,
      );
      break;
    }

    case "tavernBarterSell": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const held = ship.cargo[action.cid] ?? 0;
      // Goods sealed under contract are not the captain's to sell.
      const sellable = held - (ship.locked?.[action.cid] ?? 0);
      const qty = Math.min(action.qty, Math.floor(sellable));
      if (qty <= 0) break;
      const bid = tavernBid(state, port, action.cid);
      const revenue = Math.round(qty * bid);
      state.cash += revenue;
      ship.cargo[action.cid] = held - qty;
      if (ship.cargo[action.cid]! < 0.5 && !ship.locked?.[action.cid])
        delete ship.cargo[action.cid];
      pushLog(
        state,
        "trade",
        `Sold ${unitLabel(action.cid, qty)} of ${COMMODITY_MAP[action.cid]!.name} across the tavern table at ${port.name} for ${revenue} gold.`,
      );
      break;
    }

    // A few coins loosen tongues: what is afloat nearby is marked on the chart.
    case "buyRumours": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const price = rumourPrice(port);
      if (state.cash < price) break;
      state.cash -= price;
      let raised = 0;
      for (const e of state.seaEvents ?? []) {
        if (e.done || e.seen) continue;
        if (nmBetween({ lat: port.lat, lon: port.lon }, e) > RUMOUR_RANGE_NM) continue;
        e.seen = true;
        raised += 1;
      }
      // Standing a round is how a stranger stops being one.
      addPortStanding(state, port.id, 0.3);
      pushLog(
        state,
        "world",
        raised
          ? `Drink bought and tongues loosened at ${port.name}: ${raised} report${raised === 1 ? "" : "s"} of what lies off this coast are marked on your chart.`
          : `Drink bought at ${port.name}, and nothing learned. The sea off this coast is quiet.`,
      );
      break;
    }

    case "sell": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      const market = state.markets[port.id]!;
      if (permitBlocked(state, port.power, action.cid)) break;
      const held = ship.cargo[action.cid] ?? 0;
      // Goods sealed under contract are not the captain's to sell.
      const sellable = held - (ship.locked?.[action.cid] ?? 0);
      const qty = Math.min(action.qty, Math.floor(sellable));
      if (qty <= 0) break;
      const p = priceOf(state, port.id, action.cid, port);
      // Selling into a market depresses the price as you go.
      const revenue = Math.round(qty * p.sell * 0.98);
      state.cash += revenue;
      ship.cargo[action.cid] = held - qty;
      if (ship.cargo[action.cid]! < 0.5 && !ship.locked?.[action.cid])
        delete ship.cargo[action.cid];
      market.stock[action.cid] = (market.stock[action.cid] ?? 0) + qty;
      if (!p.legal) {
        addInfamy(state, 1.2, `Ran ${COMMODITY_MAP[action.cid]!.name} ashore at ${port.name}`);
        addFactionStanding(state, port.power, -1, "Smuggling");
        addPortStanding(state, port.id, -0.6);
      } else {
        addPortStanding(state, port.id, Math.min(0.5, revenue / 5000), undefined);
        addPrestige(state, revenue / 3500);
      }
      givePlayerXp(state, "charisma", Math.min(80, revenue / 50));
      tradeLearning(state, ship.id, Math.min(80, revenue / 80));
      pushLog(
        state,
        "trade",
        `Sold ${unitLabel(action.cid, qty)} of ${COMMODITY_MAP[action.cid]!.name} at ${port.name} for ${Math.round(revenue)} gold.`,
      );
      break;
    }

    case "setCourse": {
      if (!ship) break;
      const here = portDestination(ship.portId);
      if (!action.dest || (!ship.station && !ship.voyage && sameDestination(action.dest, here))) {
        delete ship.course;
        delete ship.voyage;
        ship.underway = false;
        break;
      }
      ship.course = action.dest;
      // Already at sea: the helm goes over at once and the old track is dropped.
      if (ship.voyage) beginVoyage(state, ship, action.dest);
      break;
    }

    case "setRudder": {
      if (!ship) break;
      if (!action.underway) {
        ship.underway = false;
        break;
      }
      if (!ship.course) break;
      const plan = planVoyage(state, ship, ship.course);
      if (plan.blocked) {
        ship.underway = false;
        pushLog(state, "voyage", `${ship.name} cannot sail: ${plan.blocked.toLowerCase()}`);
        break;
      }
      ship.underway = true;
      // She does not slip her moorings the instant the order is given: the
      // course is laid, and she weighs anchor on the next day.
      if (ship.voyage) beginVoyage(state, ship, ship.course);
      else
        pushLog(
          state,
          "voyage",
          `${ship.name} is ordered for ${ship.course.label}; she sails on the next tide.`,
        );
      break;
    }

    case "sail": {
      if (!ship) break;
      const plan = planVoyage(state, ship, action.dest);
      if (plan.blocked) break;
      ship.course = action.dest;
      ship.underway = true;
      if (ship.voyage) beginVoyage(state, ship, action.dest);
      break;
    }

    case "repair": {
      if (!ship || ship.voyage) break;
      const port = PORT_MAP[ship.portId]!;
      if (port.shipyard === 0) break;
      const need = 200 - ship.hull - ship.sails;
      const cost = Math.round(need * 46 * (1.3 - port.shipyard * 0.1));
      if (cost <= 0 || state.cash < cost) break;
      state.cash -= cost;
      ship.hull = 100;
      ship.sails = 100;
      pushLog(
        state,
        "money",
        `${ship.name} careened and refitted at ${port.name} for ${Math.round(cost)} gold.`,
      );
      break;
    }

    case "provision": {
      if (!ship || ship.voyage) break;
      const cost = Math.round(action.units * 3);
      if (state.cash < cost) break;
      const room = shipCapacity(ship) - cargoUsed(ship, volumeOf);
      if (action.units * 0.6 * volumeOf("water") + action.units * 0.4 * volumeOf("saltbeef") > room)
        break;
      state.cash -= cost;
      // Water and salt provision, casked and struck down into the hold.
      ship.cargo["water"] = (ship.cargo["water"] ?? 0) + action.units * 0.6;
      ship.cargo["saltbeef"] = (ship.cargo["saltbeef"] ?? 0) + action.units * 0.4;
      ship.morale = clamp(ship.morale + 2, 0, 100);
      for (const m of state.crew.filter((c) => c.shipId === ship.id)) {
        m.morale = clamp(m.morale + 2, 0, m.health);
      }
      break;
    }

    case "hire": {
      if (!ship || ship.voyage) break;
      const cls = SHIP_CLASS_MAP[ship.classId]!;
      const room = Math.max(0, cls.hands - ship.crew);
      const count = Math.min(action.count, room);
      const cost = count * 40;
      if (count <= 0 || state.cash < cost) break;
      state.cash -= cost;
      ship.crew += count;
      break;
    }

    case "dismiss": {
      if (!ship || ship.voyage) break;
      const count = Math.min(action.count, Math.max(0, ship.crew - 1));
      ship.crew -= count;
      if (count > 0) ship.morale = clamp(ship.morale - count * 0.6, 0, 100);
      break;
    }

    case "buyShip": {
      const cls = SHIP_CLASS_MAP[action.classId]!;
      const port = ship ? PORT_MAP[ship.portId]! : undefined;
      if (!port || port.shipyard < 1 || state.cash < cls.price) break;
      state.cash -= cls.price;
      const bought: Ship = makeShip(cls.id, `${cls.name} of ${port.name}`, port.id);
      bought.crew = Math.round(cls.hands * 0.8);
      // Enough water and beef to put to sea, never more than her hold will lift.
      const holdRoom = shipCapacity(bought) * 0.35;
      const perSet = volumeOf("water") + 0.5 * volumeOf("saltbeef");
      const sets = Math.max(0, Math.min(cls.hands, Math.floor(holdRoom / perSet)));
      bought.cargo = sets > 0 ? { water: sets, saltbeef: Math.round(sets * 0.5) } : {};
      state.ships.push(bought);
      pushLog(
        state,
        "money",
        `A ${cls.name} bought at ${port.name} for ${Math.round(cls.price)} gold.`,
      );
      break;
    }

    case "sellShip": {
      if (state.ships.length <= 1) break;
      const s = state.ships.find((x) => x.id === action.shipId);
      if (!s || s.voyage) break;
      const cls = SHIP_CLASS_MAP[s.classId]!;
      const value = Math.round(cls.price * 0.55 * ((s.hull + s.sails) / 200));
      state.cash += value;
      state.ships = state.ships.filter((x) => x.id !== s.id);
      if (state.activeShipId === s.id && state.ships[0]) state.activeShipId = state.ships[0].id;
      pushLog(state, "money", `${s.name} sold out of the fleet for ${Math.round(value)} gold.`);
      break;
    }

    case "takeLoan": {
      const base = state.reputation > 20 ? 0.14 : state.reputation < -10 ? 0.34 : 0.22;
      const rate = Math.max(0.06, Number((base * repEffects(state).creditRate).toFixed(3)));
      state.cash += action.amount;
      state.loans.push({
        id: uid("loan", state.day),
        principal: action.amount,
        rate,
        dueDay: state.day + 180,
      });
      pushLog(
        state,
        "money",
        `Borrowed ${Math.round(action.amount)} gold at ${Math.round(rate * 100)}% per annum, due in six months.`,
      );
      break;
    }

    case "repayLoan": {
      const loan = state.loans.find((l) => l.id === action.loanId);
      if (!loan || state.cash < loan.principal) break;
      state.cash -= loan.principal;
      state.loans = state.loans.filter((l) => l.id !== loan.id);
      state.reputation = clamp(state.reputation + 4, -100, 100);
      pushLog(state, "money", `A debt of ${Math.round(loan.principal)} gold discharged in full.`);
      break;
    }

    case "buyBusiness": {
      if (!ship) break;
      const type = BUSINESS_MAP[action.typeId]!;
      if (state.cash < type.price) break;
      state.cash -= type.price;
      state.businesses.push({
        id: uid("biz", state.day),
        typeId: type.id,
        portId: ship.portId,
        level: 1,
      });
      pushLog(state, "money", `${type.name} established at ${PORT_MAP[ship.portId]!.name}.`);
      break;
    }

    case "upgradeBusiness": {
      const b = state.businesses.find((x) => x.id === action.id);
      if (!b) break;
      const type = BUSINESS_MAP[b.typeId]!;
      const cost = Math.round(type.price * 0.7 * b.level);
      if (state.cash < cost || b.level >= 5) break;
      state.cash -= cost;
      b.level += 1;
      break;
    }

    case "sellBusiness": {
      const b = state.businesses.find((x) => x.id === action.id);
      if (!b) break;
      const type = BUSINESS_MAP[b.typeId]!;
      state.cash += Math.round(type.price * 0.6 * b.level);
      state.businesses = state.businesses.filter((x) => x.id !== b.id);
      break;
    }

    case "gift": {
      if (state.cash < action.amount) break;
      state.cash -= action.amount;
      state.relations[action.power] = clamp(
        state.relations[action.power] + Math.round(action.amount / 400),
        -100,
        100,
      );
      pushLog(state, "money", `A handsome present is made to the ${action.power} interest.`);
      break;
    }

    case "letterOfMarque": {
      const cost = 12000;
      if (state.cash < cost || state.letters.includes(action.power)) break;
      if (state.relations[action.power] < 0) break;
      state.cash -= cost;
      state.letters.push(action.power);
      state.notoriety = clamp(state.notoriety + 6, 0, 100);
      pushLog(
        state,
        "world",
        `A letter of marque is issued in your name. You may now take prizes lawfully — from someone.`,
      );
      break;
    }

    case "setLaws": {
      state.laws.crewShare = clamp(Math.round(action.crewShare), 0, 100);
      break;
    }

    case "recruit": {
      if (!ship || ship.voyage) break;
      const pool = state.recruits[ship.portId] ?? [];
      const m = pool.find((x) => x.id === action.memberId);
      if (!m) break;
      const fee = signingFee(m);
      if (state.cash < fee) break;
      // He needs a berth in the lodgings; a post can be given him later.
      const aboard = state.crew.filter((c) => c.shipId === ship.id).length;
      if (aboard >= lodgings(ship)) break;
      state.cash -= fee;
      state.recruits[ship.portId] = pool.filter((x) => x.id !== m.id);
      state.crew.push({ ...m, shipId: ship.id });
      ship.crew += 1;
      ship.morale = clamp(ship.morale + 1, 0, 100);
      pushLog(
        state,
        "world",
        `${m.name} signs the articles at ${PORT_MAP[ship.portId]!.name} for ${fee} gold.`,
      );
      break;
    }

    case "dismissMember": {
      const m = state.crew.find((x) => x.id === action.memberId);
      if (!m || !ship || ship.voyage) break;
      state.crew = state.crew.filter((x) => x.id !== m.id);
      for (const sh of state.ships) {
        for (const [pos, id] of Object.entries(sh.assignments ?? {})) {
          if (id === m.id) delete sh.assignments[pos as CrewPosition];
        }
      }
      ship.crew = Math.max(1, ship.crew - 1);
      ship.morale = clamp(ship.morale - 2, 0, 100);
      pushLog(state, "world", `${m.name} is paid off at ${PORT_MAP[ship.portId]!.name}.`);
      break;
    }

    case "acceptQuest": {
      if (!ship || ship.voyage) break;
      const q = state.quests.find((x) => x.id === action.questId);
      if (!q || q.accepted || q.portId !== ship.portId) break;
      if (q.kind === "cargo" && q.cid && q.qty) {
        // The goods come aboard on the spot, and are sealed under contract.
        const free = shipCapacity(ship) - cargoUsed(ship, volumeOf);
        if (questBlocker(q, ship, free)) break;
        ship.cargo[q.cid] = (ship.cargo[q.cid] ?? 0) + q.qty;
        ship.locked = { ...(ship.locked ?? {}) };
        ship.locked[q.cid] = (ship.locked[q.cid] ?? 0) + q.qty;
        if (q.black) {
          ship.contraband = { ...(ship.contraband ?? {}) };
          ship.contraband[q.cid] = (ship.contraband[q.cid] ?? 0) + q.qty;
        }
      }
      q.accepted = true;
      state.cash += q.advance;
      pushLog(
        state,
        "money",
        `Contract taken at ${PORT_MAP[q.portId]!.name}: ${q.title}.${q.advance ? ` An advance of ${q.advance} gold is paid on the quay.` : ""}${q.kind === "cargo" ? (q.black ? " The parcel is struck below, sealed, and marked in your own books as contraband." : " The parcel is struck below and sealed.") : ""}`,
      );
      break;
    }

    case "trackQuest": {
      if (!action.questId) {
        delete state.trackedQuestId;
        break;
      }
      const q = state.quests.find((x) => x.id === action.questId && x.accepted);
      if (!q) break;
      if (state.trackedQuestId === q.id) delete state.trackedQuestId;
      else state.trackedQuestId = q.id;
      break;
    }

    case "abandonQuest": {
      const q = state.quests.find((x) => x.id === action.questId);
      if (!q || !q.accepted) break;
      // The parcel stays in your hold — the seal is broken and the goods are
      // yours to sell. The shipper keeps his advance and tells everyone why.
      let kept = "";
      if (q.kind === "cargo" && q.cid && q.qty && ship) {
        releaseLocked(ship, q.cid, q.qty, false);
        if (ship.contraband?.[q.cid]) {
          const left = (ship.contraband[q.cid] ?? 0) - q.qty;
          if (left > 0.01) ship.contraband[q.cid] = left;
          else delete ship.contraband[q.cid];
        }
        kept = ` The ${unitLabel(q.cid, q.qty)} of ${COMMODITY_MAP[q.cid]?.name ?? "goods"} stay below, unsealed and yours.`;
      }
      state.quests = state.quests.filter((x) => x.id !== q.id);
      if (state.trackedQuestId === q.id) delete state.trackedQuestId;
      {
        const hit = contractPenalty(q.standing, false);
        adjustReputation(state, hit, `Threw up the contract "${q.title}"`, powerOfPort(q.portId));
        addPortStanding(state, q.portId, hit * 2, `threw up "${q.title}"`);
        const power = q.faction ?? powerOfPort(q.portId);
        if (power) addFactionStanding(state, power, hit, "Broke a contract");
      }
      pushLog(state, "world", `You throw up the contract "${q.title}". Word travels.${kept}`);
      break;
    }

    case "deliverQuest": {
      if (!ship || ship.voyage) break;
      const q = state.quests.find((x) => x.id === action.questId);
      if (!q || !q.accepted) break;
      if (q.targetPortId !== ship.portId) break;
      if (q.kind === "cargo" && q.cid && q.qty) {
        if ((ship.cargo[q.cid] ?? 0) < q.qty) break;
        releaseLocked(ship, q.cid, q.qty, true);
        const market = state.markets[ship.portId]!;
        market.stock[q.cid] = (market.stock[q.cid] ?? 0) + q.qty;
      }
      if (q.kind === "procure" && q.cid && q.qty) {
        const free = (ship.cargo[q.cid] ?? 0) - (ship.locked?.[q.cid] ?? 0);
        if (free < q.qty) break;
        ship.cargo[q.cid] = (ship.cargo[q.cid] ?? 0) - q.qty;
        if ((ship.cargo[q.cid] ?? 0) < 0.5 && !ship.locked?.[q.cid]) delete ship.cargo[q.cid];
        const market = state.markets[ship.portId]!;
        market.stock[q.cid] = (market.stock[q.cid] ?? 0) + q.qty;
      }
      const late = state.day > q.dueDay;
      const paid = late ? Math.round((q.reward - q.advance) * 0.6) : q.reward - q.advance;
      const crewCut = shareGold(state, paid);
      if (crewCut > 0)
        pushLog(state, "money", `${crewCut} gold of it goes to the people, by the articles.`);
      state.quests = state.quests.filter((x) => x.id !== q.id);
      if (state.trackedQuestId === q.id) delete state.trackedQuestId;
      {
        const gain = late ? 1 : q.standing;
        adjustReputation(state, gain, `Discharged "${q.title}"`, PORT_MAP[ship.portId]!.power);
        // Both ends of the run remember it; the crown, much less so.
        addPortStanding(state, ship.portId, gain, `discharged "${q.title}"`);
        addPortStanding(state, q.portId, gain * 0.5);
        if (q.black) {
          addFactionStanding(state, "pirate", gain * 0.6, "Black work carried through");
          addInfamy(
            state,
            14 + q.reward / 90,
            `Ran contraband into ${PORT_MAP[ship.portId]!.name}`,
          );
        } else {
          addFactionStanding(state, PORT_MAP[ship.portId]!.power, gain * 0.25, "Honest carriage");
          addPrestige(state, 10 + q.reward / 120, `Discharged "${q.title}"`);
        }
      }
      shareXp(state, "all", late ? 60 : 140);
      pushLog(
        state,
        "money",
        `Contract discharged at ${PORT_MAP[ship.portId]!.name}${late ? ", late and docked for it" : ""}: ${paid} gold paid.`,
      );
      break;
    }

    // The harbour master's price for forgetting his grievance.
    case "payFine": {
      const owed = state.fines?.[action.portId];
      if (!owed || state.cash < owed) break;
      state.cash -= owed;
      const rest = { ...(state.fines ?? {}) };
      delete rest[action.portId];
      state.fines = rest;
      // A fine buys the harbour back, and a little of its patience.
      const book = (state.portStanding ??= {});
      if (portStanding(state, action.portId) <= -60) {
        book[action.portId] = clamp(
          (book[action.portId] ?? 0) + (-58 - portStanding(state, action.portId)),
          -100,
          100,
        );
      }
      pushLog(
        state,
        "money",
        `${owed} gold paid to the port of ${PORT_MAP[action.portId]!.name}. Your boats may land again.`,
      );
      break;
    }

    case "payDebt": {
      const amount = Math.min(action.amount, state.cash, state.debt);
      if (amount <= 0) break;
      state.cash -= amount;
      state.debt -= amount;
      state.reputation = clamp(state.reputation + amount / 4000, -100, 100);
      pushLog(
        state,
        "money",
        state.debt <= 0
          ? "The chandler's note is discharged in full. You own your hull outright."
          : `${amount} gold paid against the note. ${Math.round(state.debt)} still owing.`,
      );
      break;
    }

    case "installComponent": {
      const s4 = state.ships.find((x) => x.id === action.shipId);
      if (!s4 || s4.voyage) break;
      const port = PORT_MAP[s4.portId]!;
      const def = COMPONENT_MAP[action.defId];
      if (!def || port.shipyard < 1) break;
      const stats = shipStats(s4);
      if (stats.slotsUsed >= stats.slots) break;
      if (s4.components.some((c) => c.defId === def.id)) break;
      const cost = componentCost(def, 0);
      if (state.cash < cost) break;
      state.cash -= cost;
      s4.components.push({
        id: uid("cmp", state.day + s4.components.length),
        defId: def.id,
        level: 1,
      });
      pushLog(state, "money", `${def.name} fitted to ${s4.name} at ${port.name} for ${cost} gold.`);
      break;
    }

    case "upgradeComponent": {
      const s5 = state.ships.find((x) => x.id === action.shipId);
      if (!s5 || s5.voyage) break;
      const port = PORT_MAP[s5.portId]!;
      if (port.shipyard < 1) break;
      const fitted = s5.components.find((c) => c.id === action.componentId);
      const def = fitted && COMPONENT_MAP[fitted.defId];
      if (!fitted || !def || fitted.level >= 5) break;
      if (fitted.level >= yardMaxMark(port)) break;
      const cost = componentCost(def, fitted.level);
      if (state.cash < cost) break;
      state.cash -= cost;
      fitted.level += 1;
      pushLog(
        state,
        "money",
        `${def.name} on ${s5.name} raised to mark ${fitted.level} for ${cost} gold.`,
      );
      break;
    }

    case "removeComponent": {
      const s6 = state.ships.find((x) => x.id === action.shipId);
      if (!s6 || s6.voyage) break;
      const fitted = s6.components.find((c) => c.id === action.componentId);
      const def = fitted && COMPONENT_MAP[fitted.defId];
      if (!fitted || !def) break;
      const refund = Math.round(componentCost(def, fitted.level - 1) * 0.4);
      state.cash += refund;
      s6.components = s6.components.filter((c) => c.id !== fitted.id);
      pushLog(state, "money", `${def.name} stripped out of ${s6.name}; ${refund} gold recovered.`);
      break;
    }

    case "buyGun": {
      const sg = state.ships.find((x) => x.id === action.shipId);
      if (!sg || sg.voyage) break;
      const port = PORT_MAP[sg.portId]!;
      if (port.shipyard < 1) break;
      const cls = SHIP_CLASS_MAP[sg.classId]!;
      sg.guns ??= [];
      if (sg.guns.length >= cls.gunPorts) break;
      const cost = gunCost(0);
      if (state.cash < cost) break;
      state.cash -= cost;
      sg.guns.push(1);
      pushLog(state, "money", `A gun mounted aboard ${sg.name} at ${port.name} for ${cost} gold.`);
      break;
    }

    case "upgradeGun": {
      const sg2 = state.ships.find((x) => x.id === action.shipId);
      if (!sg2 || sg2.voyage) break;
      const port = PORT_MAP[sg2.portId]!;
      if (port.shipyard < 1) break;
      const mark = sg2.guns?.[action.index];
      if (!mark || mark >= 5 || mark >= yardMaxMark(port)) break;
      const cost = gunCost(mark);
      if (state.cash < cost) break;
      state.cash -= cost;
      sg2.guns![action.index] = mark + 1;
      pushLog(
        state,
        "money",
        `A gun aboard ${sg2.name} rebored to mark ${mark + 1} for ${cost} gold.`,
      );
      break;
    }

    case "sellGun": {
      const sg3 = state.ships.find((x) => x.id === action.shipId);
      if (!sg3 || sg3.voyage) break;
      const mark = sg3.guns?.[action.index];
      if (!mark) break;
      const refund = Math.round(gunCost(mark - 1) * 0.4);
      state.cash += refund;
      sg3.guns!.splice(action.index, 1);
      pushLog(state, "money", `A gun landed from ${sg3.name}; ${refund} gold recovered.`);
      break;
    }

    case "installHold": {
      const s2 = state.ships.find((x) => x.id === action.shipId);
      const def = HOLD_MAP[action.category];
      if (!s2 || !def || def.price <= 0 || s2.voyage) break;
      s2.holds ??= [];
      if (s2.holds.includes(action.category)) break;
      if (state.cash < def.price) break;
      state.cash -= def.price;
      s2.holds.push(action.category);
      pushLog(
        state,
        "money",
        `${def.name} fitted aboard ${s2.name} for ${Math.round(def.price)} gold.`,
      );
      break;
    }

    case "removeHold": {
      const s2 = state.ships.find((x) => x.id === action.shipId);
      const def = HOLD_MAP[action.category];
      if (!s2 || !def || def.price <= 0 || s2.voyage) break;
      s2.holds = (s2.holds ?? []).filter((h) => h !== action.category);
      state.cash += Math.round(def.price * 0.4);
      pushLog(state, "money", `${def.name} torn out of ${s2.name}.`);
      break;
    }

    case "installQuarter": {
      const s7 = state.ships.find((x) => x.id === action.shipId);
      if (!s7 || s7.voyage) break;
      const port = PORT_MAP[s7.portId]!;
      const q = QUARTER_MAP[action.position];
      if (!q || port.shipyard < 1) break;
      if (s7.quarters.includes(action.position)) break;
      if (quartersUsed(s7) >= shipStats(s7).crewCapacity) break;
      if (state.cash < q.price) break;
      state.cash -= q.price;
      s7.quarters.push(action.position);
      pushLog(
        state,
        "money",
        `${q.name} built into ${s7.name} at ${port.name} for ${q.price} gold.`,
      );
      break;
    }

    case "removeQuarter": {
      const s8 = state.ships.find((x) => x.id === action.shipId);
      if (!s8 || s8.voyage || action.position === "captain") break;
      if (!s8.quarters.includes(action.position)) break;
      s8.quarters = s8.quarters.filter((p) => p !== action.position);
      const held = s8.assignments[action.position];
      if (held) {
        const m = state.crew.find((c) => c.id === held);
        if (m) delete m.shipId;
        delete s8.assignments[action.position];
      }
      state.cash += Math.round((QUARTER_MAP[action.position]?.price ?? 0) * 0.4);
      break;
    }

    case "assignCrew": {
      const s9 = state.ships.find((x) => x.id === action.shipId);
      if (!s9) break;
      if (!action.memberId) {
        delete s9.assignments[action.position];
        break;
      }
      const m = state.crew.find((c) => c.id === action.memberId);
      if (!m || m.shipId !== s9.id) break;
      if (action.position !== "captain" && !s9.quarters.includes(action.position)) break;
      for (const other of state.ships) {
        for (const [pos, id] of Object.entries(other.assignments ?? {})) {
          if (id === m.id) delete other.assignments[pos as CrewPosition];
        }
      }
      s9.assignments[action.position] = m.id;
      m.shipId = s9.id;
      break;
    }

    case "buyPermit": {
      const def = PERMIT_KIND_MAP[action.kind];
      if (!def || action.power === "pirate") break;
      if (!permitEligible(state, action.power, action.kind)) break;
      const price = permitPrice(action.power, action.kind);
      if (state.cash < price) break;
      state.cash -= price;
      state.permits ??= [];
      const held = permitGrant(state, action.power, action.kind);
      if (held) held.expiresDay += PERMIT_TERM;
      else
        state.permits.push({
          power: action.power,
          kind: action.kind,
          expiresDay: state.day + PERMIT_TERM,
        });
      state.relations[action.power] = clamp((state.relations[action.power] ?? 0) + 2, -100, 100);
      pushLog(
        state,
        "world",
        `${held ? "Renewed" : "Sealed"} in your name: a ${def.name} of the ${action.power} crown, good for a year. ${price} gold to the clerks.`,
      );
      break;
    }

    case "setShipBanner": {
      const s2 = state.ships.find((x) => x.id === action.shipId);
      if (!s2) break;
      if (action.banner) s2.banner = action.banner;
      else delete s2.banner;
      break;
    }

    case "setAllegiance": {
      const s3 = state.ships.find((x) => x.id === action.shipId);
      if (!s3) break;
      if (
        action.power &&
        !state.letters.includes(action.power) &&
        (state.relations[action.power] ?? 0) < 25
      )
        break;
      if (action.power) s3.allegiance = action.power;
      else delete s3.allegiance;
      break;
    }

    case "encounter": {
      if (state.encounter)
        resolveSeaEncounter(state, action.choice, rng(state.seed + state.day * 7919));
      break;
    }

    case "dismissOutcome":
      delete state.outcome;
      break;

    case "story": {
      if (state.story) resolveStory(state, action.choice, rng(state.seed + state.day * 6221));
      break;
    }

    case "mockBattle": {
      const ship = activeShip(state);
      if (ship && !ship.voyage)
        openMockCombat(state, ship, action.classId, action.count ?? 1, action.fortLevel);
      break;
    }

    case "assaultPort": {
      const ship = activeShip(state);
      if (ship && !ship.voyage && !state.combat) openPortAssault(state, ship, action.portId);
      break;
    }

    case "combat": {
      if (!state.combat) break;
      if (action.move === "evade") tryEvade(state);
      else if (action.move === "engage") beginBattle(state);
      else if (action.move === "watched") state.combat.phase = "result";
      else delete state.combat;
      break;
    }

    case "devCheat": {
      if (!state.dev) break;
      switch (action.what) {
        case "gold":
          state.cash += 50000;
          pushLog(
            state,
            "world",
            "A chest of 50,000 gold appears on the desk, from nowhere at all.",
          );
          break;
        case "clear":
          state.debt = 0;
          state.loans = [];
          pushLog(state, "world", "Every note against your name is struck out.");
          break;
        case "prestige":
          addPrestige(state, 200);
          break;
        case "infamy":
          addInfamy(state, 200);
          break;
        case "reveal": {
          const hidden = PORTS.filter((p) => p.hidden).map((p) => p.id);
          state.knownPorts = Array.from(new Set([...(state.knownPorts ?? []), ...hidden]));
          setRevealedPorts(state.knownPorts);
          pushLog(state, "world", "Every black harbour in the Atlantic is marked on your charts.");
          break;
        }
        case "permits": {
          const grants = state.permits ?? [];
          for (const p of POWERS) {
            if (p.id === "pirate") continue;
            for (const k of PERMIT_KINDS) {
              const at = grants.findIndex((g) => g.power === p.id && g.kind === k.id);
              const grant = { power: p.id, kind: k.id, expiresDay: state.day + PERMIT_TERM };
              if (at >= 0) grants[at] = grant;
              else grants.push(grant);
            }
          }
          state.permits = grants;
          pushLog(state, "world", "Every custom house in the Indies has stamped your papers.");
          break;
        }
      }
      break;
    }
  }

  return state;
}

export function netWorth(state: GameState): number {
  let total = state.cash;
  for (const s of state.ships) {
    const cls = SHIP_CLASS_MAP[s.classId]!;
    total += cls.price * 0.6 * ((s.hull + s.sails) / 200);
    for (const c of s.components) total += (COMPONENT_MAP[c.defId]?.price ?? 0) * c.level * 0.5;
    for (const [cid, q] of Object.entries(s.cargo)) total += q * COMMODITY_MAP[cid]!.base * 0.8;
  }
  for (const b of state.businesses) total += BUSINESS_MAP[b.typeId]!.price * 0.7 * b.level;
  for (const l of state.loans) total -= l.principal;
  total -= state.debt;
  return Math.round(total);
}

/** Profit teaches the men who handle the cargo — the captain's own trade, not shared prize. */
function tradeLearning(state: GameState, shipId: string, amount: number) {
  for (const m of state.crew) {
    if (m.shipId !== shipId) continue;
    const isQm = state.ships.some((sh) => sh.assignments?.quartermaster === m.id);
    giveXp(m, "logistics", isQm ? amount : amount * 0.25);
  }
}
