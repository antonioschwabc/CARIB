import type { Outcome } from "./sim/outcome";
export type { Outcome, OutcomeLine } from "./sim/outcome";
export type PowerId =
  | "spain"
  | "england"
  | "france"
  | "dutch"
  | "portugal"
  | "pirate";

export interface Power {
  id: PowerId;
  name: string;
  adjective: string;
  color: string;
  currency: string;
  note: string;
}

export type CommodityCategory =
  | "agricultural"
  | "alcohol"
  | "food"
  | "raw"
  | "metals"
  | "manufactured"
  | "luxury"
  | "naval"
  | "contraband";

export interface Commodity {
  id: string;
  name: string;
  category: CommodityCategory;
  /** gold per unit at equilibrium */
  base: number;
  /** singular measure the good is traded in, e.g. "barrel" */
  unit: string;
  unitPlural: string;
  /** tons of hold space per unit */
  tons: number;
  /** 0-1 fraction lost per day at sea */
  perish: number;
  /** price elasticity multiplier */
  volatility: number;
  illegalFor?: PowerId[];
  note: string;
}

export interface Port {
  id: string;
  name: string;
  power: PowerId;
  region: string;
  lat: number;
  lon: number;
  population: number;
  /** 0-1 */
  prosperity: number;
  /** 0-1, higher = safer harbour */
  security: number;
  /** 0-1 chance weighting of piracy in surrounding waters */
  pirateRisk: number;
  /** fraction added to purchase price */
  tariff: number;
  /** gold charged on arrival */
  portFee: number;
  /** 0-3 */
  shipyard: number;
  /** 1-5: the port's standing in the Atlantic world. Set in ports.ts. */
  level?: number;
  /** black harbours: absent from every chart until the captain finds them */
  hidden?: boolean;
  produces: Record<string, number>;
  consumes: Record<string, number>;
  note: string;
}

export interface MarketState {
  stock: Record<string, number>;
  shock: Record<string, number>;
  history: Record<string, number[]>;
}

export type ShipStatKey =
  | "hull"
  | "firepower"
  | "maneuverability"
  | "scouting"
  | "cargo"
  | "speed";

export interface ShipClass {
  id: string;
  name: string;
  price: number;
  /** structural health points */
  hull: number;
  firepower: number;
  maneuverability: number;
  scouting: number;
  /** tons of goods */
  cargo: number;
  /** km/h */
  speed: number;
  /** crew quarters installable in the lower deck (captain's cabin excluded) */
  crewCapacity: number;
  /** component slots across all six regions */
  componentSlots: number;
  /** hands she is rated for: berths in the lodgings, twice her optional quarters */
  hands: number;
  /** guns she comes out of the yard with */
  guns: number;
  /** gun ports: the most pieces she can ever carry */
  gunPorts: number;
  /** firepower one gun of mark 1 contributes */
  gunPower: number;
  /** gold per day */
  upkeep: number;
  note: string;
}

/** Anywhere the rudder can point: a harbour, or bare water. */
export interface Destination {
  /** set when the mark is a harbour */
  portId?: string;
  lat: number;
  lon: number;
  label: string;
}

export interface Voyage {
  /** port of departure, empty when she weighed from open water */
  from: string;
  /** port of destination, empty when the mark is open water */
  to: string;
  fromLat: number;
  fromLon: number;
  toLat: number;
  toLon: number;
  label: string;
  totalDays: number;
  daysLeft: number;
  distanceNm: number;
  /** the water road she follows, worked round the land */
  path: { lat: number; lon: number }[];
  /** sea miles made good so far along that road */
  progressNm: number;
  /** the day's wind, as a fraction of her best speed */
  wind?: number;
}


export type ShipRegion = "bow" | "stern" | "deck" | "bridge" | "mast" | "hull" | "ordnance" | "warehouse";

export interface FittedComponent {
  id: string;
  defId: string;
  /** 1-5 */
  level: number;
}

export interface Ship {
  id: string;
  name: string;
  classId: string;
  portId: string;
  cargo: Record<string, number>;
  /** goods held under contract: they may not be sold, eaten or broken up */
  locked?: Record<string, number>;
  /** sealed goods that are also illegal: seizable at an inspection */
  contraband?: Record<string, number>;
  /** 0-100 structural condition */
  hull: number;
  sails: number;
  crew: number;
  morale: number;
  /** legacy abstract stores; supplies now live in the hold */
  provisions: number;
  /** consecutive days on short commons */
  hunger?: number;
  /** fitted components, limited by the archetype's slot count */
  components: FittedComponent[];
  /** her battery: one entry per mounted gun, holding its mark 1-5 */
  guns?: number[];
  /** cargo hold fittings: which kinds of goods she may stow */
  holds?: CommodityCategory[];
  /** crew quarters installed in the lower deck */
  quarters: CrewPosition[];
  /** position → crew member id */
  assignments: Partial<Record<CrewPosition, string>>;
  /** where the rudder is set for, if anywhere */
  course?: Destination;
  /** hove to on open water: her position when she is not in any port */
  station?: { lat: number; lon: number; label?: string };
  /** true when the rudder is spinning: she sails for her course on the next day */
  underway?: boolean;
  /** her own colours; falls back to the house banner when absent */
  banner?: Banner;
  /** the crown she sails under, if any */
  allegiance?: PowerId;
  voyage?: Voyage;
}

export interface PermitGrant {
  power: PowerId;
  kind: import("./data/permits").PermitKind;
  /** day the sheet lapses */
  expiresDay: number;
}

export interface Business {
  id: string;
  typeId: string;
  portId: string;
  level: number;
}

export interface Loan {
  id: string;
  principal: number;
  rate: number;
  dueDay: number;
}

export type LogKind = "trade" | "voyage" | "world" | "peril" | "money";

export interface LogEntry {
  id: string;
  day: number;
  kind: LogKind;
  text: string;
}

export type SeaEventKind =
  | "pirate"
  | "patrol"
  | "merchant"
  | "wreck"
  | "flotsam"
  | "rumour"
  | "squall"
  | "derelict"
  | "castaways"
  | "fishing"
  | "reef"
  | "becalmed"
  | "whales"
  /** friendly: a convoy of countrymen in company */
  | "convoy"
  /** friendly: free traders working the coast without papers */
  | "smuggler"
  /** hostile: a corsair out of the black harbours */
  | "corsair"
  /** hostile: a commissioned privateer with a grudge */
  | "privateer";

/** Sails that will fight if the captain lets them. */
export const HOSTILE_KINDS: SeaEventKind[] = ["corsair", "privateer", "pirate"];


/** Something afloat at a bearing on the chart, waiting to be run across. */
export interface SeaEvent {
  id: string;
  kind: SeaEventKind;
  lat: number;
  lon: number;
  power?: PowerId;
  /** rough force of the party, 0-2 */
  strength: number;
  title: string;
  text: string;
  /** day the mark fades from the chart */
  expiresDay: number;
  /** true once a lookout has raised it */
  seen?: boolean;
  /** true once the captain has dealt with it */
  done?: boolean;
}

/**
 * A harbour raised without the crown's leave. She lies off the bar while the
 * captain decides: stand out again, pay the harbour master, or try it on.
 */
export interface DockPrompt {
  portId: string;
  portName: string;
  power: PowerId;
  /** what the harbour master will take to look the other way, once */
  fee: number;
}

export interface Encounter {
  id: string;
  shipId: string;
  kind: SeaEventKind;
  power: PowerId;
  strength: number;
  text: string;
  title?: string;
  eventId?: string;
  lat?: number;
  lon?: number;
}

/** A moment aboard or ashore that wants the captain's word. */
export interface StoryPrompt {
  id: string;
  defId: string;
  title: string;
  text: string;
  /** where it happened: at sea, in harbour, or on the quay */
  scene: "sea" | "port" | "quay";
  /** the man it concerns, if it concerns one */
  crewId?: string;
  crewName?: string;
  portName?: string;
}

// ---- Combat -------------------------------------------------------------

export interface BattleShip {
  id: string;
  name: string;
  side: "friend" | "foe";
  className: string;
  hull: number;
  maxHull: number;
  firepower: number;
  speed: number;
  maneuver: number;
  /** a shore battery: it does not move, and its hull is called Defensiveness */
  fort?: boolean;
}


export interface BattleShot {
  from: string;
  to: string;
  hit: boolean;
}

export interface BattleFrame {
  ships: { id: string; x: number; y: number; h: number; hull: number }[];
  shots: BattleShot[];
  /** shot in flight: a cascade of round shot crossing the water */
  balls?: { x: number; y: number; f: 0 | 1 }[];
  /** powder smoke hanging over a gun that has just spoken */
  smoke?: { x: number; y: number; a: number }[];
}

export interface BattleArena {
  w: number;
  h: number;
  islands: { x: number; y: number; r: number }[];
  /** the light the action is fought in */
  light?: "dawn" | "day" | "dusk" | "night";
  /** which way the wind sets, in radians */
  wind?: number;
  /** shoal water: paler, but no bar to a hull */
  shoals?: { x: number; y: number; r: number }[];
  /** a shoreline along one edge, with its depth into the arena */
  shore?: { side: "n" | "s" | "e" | "w"; depth: number };
  /** the pregenerated stretch of water this action is fought on */
  groundId?: string;
  groundName?: string;
}




/** What the lookouts can honestly say of a stranger before the first gun. */
export interface FoeEstimate {
  id: string;
  name: string;
  className: string;
  hull: [number, number];
  firepower: [number, number];
  speed: [number, number];
  maneuver: [number, number];
}

export interface CombatResult {
  victory: boolean;
  hullLost: number;
  sailsLost: number;
  gold: number;
  prestige: number;
  reputation: number;
  goods: { cid: string; qty: number }[];
  part?: string;
  dead: string[];
  hurt: { name: string; health: number }[];
  note: string;
}

export interface CombatState {
  /** a yard exercise: fought in full, but nothing carries over */
  mock?: boolean;
  phase: "preview" | "battle" | "result";
  shipId: string;
  encounterKind: SeaEventKind;
  power: PowerId;
  title: string;
  text: string;
  eventId?: string;
  /** a shore action: the harbour under the guns */
  portId?: string;
  friends: BattleShip[];
  foes: BattleShip[];
  estimates: FoeEstimate[];
  evadeChance: number;
  winChance: number;
  arena: BattleArena;
  frames?: BattleFrame[];
  result?: CombatResult;
}

// ---- The world beyond the player ---------------------------------------

/** A hull the world sails: a crown's cruiser, or an independent trader. */
export interface NpcShip {
  id: string;
  name: string;
  classId: string;
  /** the crown she answers to; absent for a free merchant */
  power?: PowerId;
  fleetId?: string;
  banner: Banner;
  captain: { name: string; nationality: string; age: number; portraitSeed: string; skills: Record<string, number> };
  crewNames: string[];
  components: string[];
  hull: number;
  maxHull: number;
  firepower: number;
  speed: number;
  maneuver: number;
  /** how far her lookouts see, in nautical miles */
  sightNm: number;
  lat: number;
  lon: number;
  /** where she is steering */
  toLat: number;
  toLon: number;
  toPortId?: string;
  /** free merchants only */
  gold?: number;
  cargo?: Record<string, number>;
  /** the honest sort keep a good book; the other sort do not */
  wits?: "shrewd" | "poor";
  /** the player has had her under his own glass, and knows her figures */
  seen?: boolean;
  /** locked in an action until this day */
  battleId?: string;
}

export interface NpcFleet {
  id: string;
  name: string;
  power: PowerId;
}

/** An action between others, fought out over a week of chart days. */
export interface NpcBattle {
  id: string;
  lat: number;
  lon: number;
  endsDay: number;
  shipIds: string[];
  /** a shore action against this harbour */
  portId?: string;
  attacker: PowerId;
  defender: PowerId;
}






export type SkillId =
  | "navigation"
  | "charisma"
  | "scouting"
  | "craftsmanship"
  | "gunnery"
  | "logistics"
  | "cooking"
  | "medicine";

/** Every character, the player included, is described by these eight. */
export interface Skills {
  navigation: number;
  charisma: number;
  scouting: number;
  craftsmanship: number;
  gunnery: number;
  logistics: number;
  cooking: number;
  medicine: number;
}

export type CrewPosition =
  | "captain"
  | "firstMate"
  | "scout"
  | "carpenter"
  | "gunner"
  | "quartermaster"
  | "cook"
  | "surgeon";

export interface CrewMember {
  id: string;
  name: string;
  nationality: string;
  /** what he swears by; flavour, and sometimes friction */
  faith?: string;
  age: number;
  skills: Skills;
  /** 1-100 ceiling for his best skill, shown only as a letter grade */
  potential: number;
  wage: number;
  /** experience banked in each discipline; 100 buys a point */
  xp: Skills;
  /** 0-100. At zero he walks. Never higher than health. */
  morale: number;
  /** 0-100. At zero he dies. */
  health: number;
  /** units of stores eaten per day at sea, 2-20 */
  appetite: number;
  traits: string[];
  shipId?: string;
}

/**
 * letter  — sealed dispatches, no hold space at all
 * cargo   — the goods are handed over on the quay and locked in your hold
 * procure — you must buy the goods yourself and land them
 */
export type QuestKind = "letter" | "cargo" | "procure";

export interface Quest {
  id: string;
  kind: QuestKind;
  /** port that issues it */
  portId: string;
  targetPortId?: string;
  cid?: string;
  qty?: number;
  reward: number;
  advance: number;
  standing: number;
  dueDay: number;
  title: string;
  text: string;
  accepted?: boolean;
  /** the crown or brotherhood that posted it, when it is more than quay work */
  faction?: PowerId;
  /** a black posting: illegal, better paid, and sealed as contraband */
  black?: boolean;
}

/** One line in the book of standing: what happened, and what it cost. */
export interface RepEntry {
  id: string;
  day: number;
  delta: number;
  reason: string;
}

export interface PortEvent {
  defId: string;
  title: string;
  text: string;
  tone: "good" | "bad" | "neutral";
  startedDay: number;
  endsDay: number;
}

export interface Player {
  name: string;
  nationality: string;
  age: number;
  /** what he swears by */
  faith?: string;
  /** the two traits he carries, from the same catalogue as the crew */
  traits?: string[];
  /** seed for his painted bust */
  portraitSeed?: string;
  stats: Skills;
  xp: Skills;
  level: number;
}

/** The articles: how prize money and experience are divided. */
export interface ShipLaws {
  /** 0-100 percent of gold and XP from events, combat and contracts given to the crew */
  crewShare: number;
}

export type BannerIcon =
  | "none"
  | "anchor"
  | "skull"
  | "lion"
  | "eagle"
  | "star"
  | "cross"
  | "sun"
  | "ship"
  | "swords"
  | "crown"
  | "key"
  | "moon"
  | "compass"
  | "fleur"
  | "palm"
  | "serpent"
  | "hourglass"
  | "cannon"
  | "tower"
  | "castle"
  | "rose"
  | "trident"
  | "wheel"
  | "dagger"
  | "chalice"
  | "oak"
  | "boar"
  | "bell"
  | "escallop"
  | "hammer"
  | "arrows";


/** How the field itself is divided. */
export type BannerPattern =
  | "plain"
  | "band"
  | "fess"
  | "pale"
  | "tricolour"
  | "tribar"
  | "cross"
  | "saltire"
  | "quarters"
  | "bend"
  | "chevron"
  | "border"
  | "stripes"
  | "canton"
  | "lozenge";

/** Where the charge sits on the field. */
export type BannerLayout = "centre" | "large" | "chief" | "base" | "hoist" | "fly" | "canton" | "twin";

export interface Banner {
  name: string;
  /** primary field, secondary band, charge colour */
  colors: [string, string, string];
  icon: BannerIcon;
  /** how the field is divided */
  pattern?: BannerPattern;
  /** where the charge sits */
  layout?: BannerLayout;
  /** legacy single colour, kept for older UI paths */
  color?: string;
}


export interface GameState {
  schemaVersion: number;
  seed: number;
  day: number;
  cash: number;
  debt: number;
  /** weekly interest fraction on the outstanding debt */
  debtRate: number;
  merchantName: string;
  player: Player;
  banner: Banner;
  crew: CrewMember[];
  laws: ShipLaws;
  recruits: Record<string, CrewMember[]>;
  quests: Quest[];
  ships: Ship[];
  activeShipId: string;
  markets: Record<string, MarketState>;
  relations: Record<PowerId, number>;
  reputation: number;
  notoriety: number;
  /** what each harbour thinks of you on its own account, before the crown's half */
  portStanding?: Record<string, number>;
  /** banner prestige points; twenty ranks are cut from them */
  prestige?: number;
  /** the black ledger: twenty ranks of infamy */
  infamyPoints?: number;
  /** the harbour he was raised in, worth goodwill for a year */
  homePortId?: string;
  /** harbours closed to him, and the fine that would open them */
  fines?: Record<string, number>;
  /** every gain and loss of standing, newest first */
  repLedger?: RepEntry[];
  /** the contract the captain is following on the chart */
  trackedQuestId?: string;
  letters: PowerId[];
  /** harbours cut for this save alone: the Brethren's black havens */
  extraPorts?: Port[];
  /** hidden harbours the captain has actually found */
  knownPorts?: string[];
  /** what the crowns think of each other, keyed "a|b" */
  factionRelations?: Record<string, number>;
  /** a save opened with the dev ledger: cheats allowed */
  dev?: boolean;
  /** crown licences held, each with an expiry */
  permits: PermitGrant[];
  businesses: Business[];
  loans: Loan[];
  log: LogEntry[];
  /** active weekly event per port id */
  portEvents: Record<string, PortEvent>;
  /** units already lifted off a tavern's shelf this week, keyed port:commodity */
  tavernTaken?: Record<string, number>;
  /** marks afloat on the chart: wrecks, sails, rumours, patrols */
  seaEvents?: SeaEvent[];
  encounter?: Encounter;
  /** a moment among the people, waiting on the captain's word */
  story?: StoryPrompt;
  /** an action being fought, previewed or reckoned up */
  combat?: CombatState;
  /** the reckoning of the last decision, waiting to be read and dismissed */
  outcome?: Outcome;
  /** no hostile sail will close with her before this day */
  peaceUntil?: number;
  /** quiet water: no chart mark will heave her to before this day */
  calmUntil?: number;
  /** the day each moment among the people was last played, so none repeats soon */
  storySeen?: Record<string, number>;
  /** a harbour reached without the crown's leave, waiting on the captain's word */
  dockPrompt?: DockPrompt;
  /** the crowns' cruisers and the free traders, sailing their own business */
  npcShips?: NpcShip[];
  /** the squadrons the crowns keep in the Indies */
  npcFleets?: NpcFleet[];
  /** actions between others, marked on the chart while they last */
  npcBattles?: NpcBattle[];
  /** harbours taken from their crown, keyed port id */
  portControl?: Record<string, PowerId>;
  /** harbours sacked: the day the smoke clears */
  pillaged?: Record<string, number>;
}



