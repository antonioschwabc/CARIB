import { COMMODITIES } from "./data/commodities";
import {
  PORTS,
  PORT_MAP,
  clearGeneratedPorts,
  registerPorts,
  setRevealedPorts,
} from "./data/ports";
import { makePirateHavens } from "./data/pirateHavens";
import { initFactionRelations } from "./sim/factions";
import { registerCaptain, registerCrew } from "./sim/shipStats";
import { traitSkillMult } from "./data/traits";
import { SHIP_CLASS_MAP } from "./data/ships";

import { emptySkills, makeRecruit, rosterSize } from "./data/crew";
import type { Banner, CrewMember, GameState, MarketState, Ship, Skills } from "./types";
import { demandDepth } from "./sim/economy";
import { PERMIT_TERM } from "./data/permits";
import { refreshQuests } from "./sim/quests";
import { initWorld } from "./sim/world";
import { rng, uid } from "./sim/util";
import { portEdge, startingRelations } from "./sim/standing";

export const SCHEMA_VERSION = 16;

function blankMarket(): MarketState {
  return { stock: {}, shock: {}, history: {} };
}

export interface NewGameSetup {
  captain: string;
  shipName: string;
  classId: string;
  bannerName: string;
  banner: Banner;
  startPortId: string;
  nationality: string;
  age: number;
  faith: string;
  traits: string[];
  /** coin drawn against the note at the outset; added to the debt */
  startingCash?: number;
  /** point-buy result; falls back to the old fixed spread */
  stats?: Skills;
  /** open the ledger with the dev tools enabled */
  dev?: boolean;
  portraitSeed: string;
}

/** Points the player may spend at creation. Years lived, skills learned. */
export function skillPool(age: number) {
  return Math.round(70 + (age - 16) * 5.5);
}

export const SKILL_FLOOR = 12;
export const SKILL_CEIL = 88;

export function baseStats(): Skills {
  const s = emptySkills();
  for (const k of Object.keys(s) as (keyof Skills)[]) s[k] = SKILL_FLOOR;
  return s;
}

export const DEFAULT_SETUP: NewGameSetup = {
  captain: "Ambrose Hale",
  shipName: "Wayfarer",
  classId: "sloop",
  bannerName: "Hale & Company",
  banner: {
    name: "Hale & Company",
    colors: ["oklch(0.32 0.05 250)", "oklch(0.62 0.16 42)", "oklch(0.9 0.05 90)"],
    icon: "anchor",
  },
  startPortId: "havana",
  nationality: "English",
  age: 28,
  faith: "Anglican",
  traits: ["Steady", "Ambitious"],
  portraitSeed: "hale-1",
};

/** Debt taken on to get the hull: the whole price, on a chandler's paper. */
export function startingDebt(classId: string) {
  const cls = SHIP_CLASS_MAP[classId];
  return cls ? Math.round(cls.price * 1.05) : 0;
}

/** A fresh hull with her cabin built and nothing else fitted. */
export function makeShip(classId: string, name: string, portId: string): Ship {
  const cls = SHIP_CLASS_MAP[classId] ?? SHIP_CLASS_MAP["sloop"]!;
  return {
    id: uid("shp", Math.floor(Math.random() * 1e6)),
    name,
    classId: cls.id,
    portId,
    cargo: {},
    hull: 100,
    sails: 100,
    crew: Math.round(cls.hands * 0.8),
    guns: Array.from({ length: cls.guns }, () => 1),
    morale: 65,
    provisions: cls.hands * 12,
    components: [],
    holds: [],
    quarters: ["captain"],
    assignments: {},
  };
}

export function newGame(setup: Partial<NewGameSetup> = {}): GameState {
  const s: NewGameSetup = { ...DEFAULT_SETUP, ...setup };
  const cls = SHIP_CLASS_MAP[s.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const home = PORT_MAP[s.startPortId] ?? PORT_MAP["havana"]!;
  const seed = Math.floor(Math.random() * 1e9) || 12345;

  // Every save cuts its own black harbours, and they are on nobody's chart.
  clearGeneratedPorts();
  const havens = makePirateHavens(
    seed,
    PORTS.filter((p) => p.power !== "pirate"),
  );
  registerPorts(havens);
  setRevealedPorts([]);

  // The Dutch keep no custom house — and charge for the privilege at the desk.
  const dutchStart = home.power === "dutch";

  const starter: Ship = makeShip(cls.id, s.shipName || "Wayfarer", home.id);
  starter.hull = 74;
  starter.sails = 70;
  starter.crew = 1;
  starter.morale = 62;
  starter.provisions = 0;
  starter.cargo = {};

  // A stranger with one hull: nobody's friend, and the black flag's enemy.
  const relations = startingRelations(s.nationality || "English", s.faith || "Anglican");

  const state: GameState = {
    schemaVersion: SCHEMA_VERSION,
    seed,
    day: 0,
    cash: Math.max(0, Math.round(s.startingCash ?? 0)),
    debt: startingDebt(cls.id) + Math.max(0, Math.round(s.startingCash ?? 0)),
    debtRate: dutchStart ? 0.02 : 0.0125,
    merchantName: s.captain || "Ambrose Hale",
    player: {
      name: s.captain || "Ambrose Hale",
      nationality: s.nationality || "English",
      age: s.age || 28,
      faith: s.faith || "Anglican",
      traits: s.traits ?? [],
      portraitSeed: s.portraitSeed || "hale-1",
      stats: s.stats ?? {
        navigation: 34,
        charisma: 32,
        scouting: 28,
        craftsmanship: 24,
        gunnery: 24,
        logistics: 30,
        cooking: 21,
        medicine: 21,
      },
      xp: emptySkills(),
      level: 1,
    },
    banner: {
      ...(s.banner ?? DEFAULT_SETUP.banner),
      name: s.bannerName || "Hale & Company",
    },
    crew: [],
    laws: { crewShare: 35 },
    recruits: {},
    quests: [],
    ships: [starter],
    activeShipId: starter.id,
    markets: {},
    relations,
    reputation: 0,
    notoriety: 0,
    portStanding: { [home.id]: 0 },
    prestige: 0,
    infamyPoints: 0,
    homePortId: home.id,
    fines: {},
    repLedger: [],
    letters: [],
    permits: dutchStart
      ? []
      : [
          { power: home.power, kind: "dock", expiresDay: PERMIT_TERM },
          { power: home.power, kind: "trade", expiresDay: PERMIT_TERM },
          { power: home.power, kind: "agricultural", expiresDay: PERMIT_TERM },
        ],
    extraPorts: havens,
    knownPorts: [],
    factionRelations: initFactionRelations(),
    dev: !!s.dev,
    businesses: [],
    loans: [],
    portEvents: {},
    log: [
      {
        id: uid("ev", 0),
        day: 0,
        kind: "world",
        text: `${home.name}, 1 January 1670. The ${cls.name} ${starter.name} is yours — on paper. The chandler holds a note for every plank of her, and it grows heavier each week. No crew, four hundred gold, and a harbour full of men who want paying.`,
      },
    ],
  };

  for (const port of PORTS) {
    const m = blankMarket();
    for (const c of COMMODITIES) {
      const traded = port.produces[c.id] || port.consumes[c.id];
      const remoteness = port.population > 20000 ? 1 : 0.55;
      const depth = demandDepth(port, c.id);
      m.stock[c.id] = traded
        ? depth * (0.75 + Math.random() * 0.6)
        : depth * 0.35 * remoteness * (0.5 + Math.random());
      m.shock[c.id] = 0;
    }
    state.markets[port.id] = m;
  }

  const rand = rng(seed);
  refreshRecruits(state, rand);
  refreshQuests(state, rand);
  // The world is peopled before the player sets foot in it.
  initWorld(state, rand);

  return state;
}

/** Fold a save's own harbours back into the world tables after a load. */
export function hydrateWorld(state: GameState) {
  clearGeneratedPorts();
  registerPorts(state.extraPorts ?? []);
  setRevealedPorts(state.knownPorts ?? []);
  syncCrewContext(state);
  // A ledger cut before the world had ships of its own gets them now.
  if (!state.npcShips?.length) initWorld(state, rng(state.seed + 4211));
  return state;
}

/** Keep the muster and the captain's own hand current for every stat call. */
export function syncCrewContext(state: GameState) {
  registerCrew(state.crew ?? []);
  const own = state.player?.stats;
  if (own) {
    const traits = state.player.traits ?? [];
    const skills: Record<string, number> = {};
    for (const [k, v] of Object.entries(own)) skills[k] = Math.round(v * traitSkillMult(traits, k as never));
    registerCaptain(skills, state.activeShipId);
  }
}

export function refreshRecruits(state: GameState, rand: () => number) {
  for (const port of PORTS) {
    const roster: CrewMember[] = [];
    const hands = Math.max(1, rosterSize(port) + portEdge(state, port.id).recruits);
    for (let i = 0; i < hands; i++) roster.push(makeRecruit(port, rand, state.day + i));
    state.recruits[port.id] = roster;
  }
}
