import type { Port } from "../types";

/** Rough production/consumption weights; units per day at prosperity 1. */
const P = (o: Record<string, number>) => o;

export const PORTS: Port[] = [
  // ---- Greater Antilles (Spanish) ----
  { id: "havana", name: "Havana", power: "spain", region: "Greater Antilles", lat: 23.13, lon: -82.38, population: 22000, prosperity: 0.82, security: 0.9, pirateRisk: 0.12, tariff: 0.22, portFee: 240, shipyard: 3,
    produces: P({ tobacco: 5, hides: 3, sugar: 2, silver: 1.2 }), consumes: P({ flour: 5, wine: 4, cloth: 3, tools: 3, iron: 2, saltfish: 3 }),
    note: "The key to the New World. The treasure flota gathers here before the Atlantic crossing." },
  { id: "santiago", name: "Santiago de Cuba", power: "spain", region: "Greater Antilles", lat: 20.02, lon: -75.82, population: 6000, prosperity: 0.5, security: 0.6, pirateRisk: 0.3, tariff: 0.2, portFee: 110, shipyard: 1,
    produces: P({ hides: 3, tobacco: 2, copper: 1.5 }), consumes: P({ flour: 2, cloth: 2, tools: 2, wine: 2 }),
    note: "A shabby, well-walled town that has been sacked more than once." },
  { id: "santodomingo", name: "Santo Domingo", power: "spain", region: "Greater Antilles", lat: 18.47, lon: -69.9, population: 9000, prosperity: 0.55, security: 0.7, pirateRisk: 0.22, tariff: 0.2, portFee: 140, shipyard: 2,
    produces: P({ hides: 4, sugar: 2, ginger: 1.5 }), consumes: P({ flour: 3, linen: 2, tools: 2, wine: 2 }),
    note: "The oldest European city in the Indies, and long past its best years." },
  { id: "sanjuan", name: "San Juan", power: "spain", region: "Greater Antilles", lat: 18.47, lon: -66.11, population: 5000, prosperity: 0.48, security: 0.85, pirateRisk: 0.18, tariff: 0.2, portFee: 120, shipyard: 1,
    produces: P({ ginger: 2, hides: 2, sugar: 1.5 }), consumes: P({ flour: 2, cloth: 2, saltbeef: 2, tools: 1.5 }),
    note: "A fortress with a town attached: El Morro guards the eastern gate of the Indies." },
  { id: "portroyal", name: "Port Royal", power: "england", region: "Greater Antilles", lat: 17.94, lon: -76.84, population: 6500, prosperity: 0.78, security: 0.5, pirateRisk: 0.15, tariff: 0.1, portFee: 150, shipyard: 3,
    produces: P({ sugar: 4, rum: 4, ginger: 2, dyewood: 1.5 }), consumes: P({ flour: 4, saltfish: 4, cloth: 3, tools: 3, muskets: 2, powder: 2, wine: 2 }),
    note: "The wickedest city in the world: prize goods sold cheap, and no awkward questions." },
  { id: "petitgoave", name: "Petit-Goâve", power: "france", region: "Greater Antilles", lat: 18.43, lon: -72.87, population: 2500, prosperity: 0.55, security: 0.35, pirateRisk: 0.2, tariff: 0.08, portFee: 70, shipyard: 1,
    produces: P({ hides: 3, tobacco: 2, dyewood: 2 }), consumes: P({ brandy: 2, flour: 2, muskets: 2, powder: 2, linen: 2 }),
    note: "The flibustiers' haven, where a governor sells commissions by the sheet." },
  { id: "tortuga", name: "Tortuga", power: "france", region: "Greater Antilles", lat: 20.06, lon: -72.79, population: 1500, prosperity: 0.42, security: 0.25, pirateRisk: 0.1, tariff: 0.02, portFee: 30, shipyard: 1,
    produces: P({ hides: 2, salt: 3, rum: 1.5 }), consumes: P({ muskets: 2.5, powder: 2.5, brandy: 2, flour: 1.5, saltbeef: 2 }),
    note: "A rock full of hunters and cut-throats. Powder and shot fetch a fine price." },

  // ---- Lesser Antilles ----
  { id: "bridgetown", name: "Bridgetown", power: "england", region: "Lesser Antilles", lat: 13.1, lon: -59.62, population: 8000, prosperity: 0.8, security: 0.75, pirateRisk: 0.08, tariff: 0.1, portFee: 120, shipyard: 2,
    produces: P({ sugar: 6, molasses: 4, rum: 3, cotton: 1.5 }), consumes: P({ flour: 4, saltfish: 4, saltbeef: 3, cloth: 3, tools: 3, timber: 3 }),
    note: "Barbados: forty years of sugar have made it the richest few square miles in the English world." },
  { id: "stjohns", name: "St. John's", power: "england", region: "Lesser Antilles", lat: 17.12, lon: -61.85, population: 2600, prosperity: 0.55, security: 0.55, pirateRisk: 0.12, tariff: 0.1, portFee: 60, shipyard: 1,
    produces: P({ sugar: 3, molasses: 2, cotton: 1 }), consumes: P({ flour: 2, saltfish: 2, tools: 2, timber: 2 }),
    note: "Antigua's harbour, deep and defensible, and short of fresh water." },
  { id: "basseterre", name: "Basseterre", power: "france", region: "Lesser Antilles", lat: 17.3, lon: -62.72, population: 3200, prosperity: 0.58, security: 0.5, pirateRisk: 0.12, tariff: 0.12, portFee: 70, shipyard: 1,
    produces: P({ sugar: 3, tobacco: 2, indigo: 1 }), consumes: P({ brandy: 2, flour: 2, linen: 2, tools: 2 }),
    note: "St. Christopher, shared uneasily with the English and periodically burned." },
  { id: "fortroyal", name: "Fort-Royal", power: "france", region: "Lesser Antilles", lat: 14.6, lon: -61.07, population: 4200, prosperity: 0.63, security: 0.65, pirateRisk: 0.1, tariff: 0.12, portFee: 95, shipyard: 2,
    produces: P({ sugar: 4, molasses: 2, cacao: 1.5, rum: 2 }), consumes: P({ brandy: 3, flour: 3, linen: 3, tools: 2, saltbeef: 2 }),
    note: "Martinique's seat of government and the pivot of the French islands." },
  { id: "willemstad", name: "Willemstad", power: "dutch", region: "Lesser Antilles", lat: 12.11, lon: -68.93, population: 4500, prosperity: 0.72, security: 0.8, pirateRisk: 0.08, tariff: 0.04, portFee: 90, shipyard: 3,
    produces: P({ salt: 5, linen: 3, tools: 3, muskets: 2, powder: 2 }), consumes: P({ sugar: 3, hides: 3, cacao: 3, dyewood: 2, tobacco: 2 }),
    note: "Curaçao: the great free warehouse of the Caribbean, selling to every flag at once." },
  { id: "oranjestad", name: "Oranjestad", power: "dutch", region: "Lesser Antilles", lat: 17.48, lon: -62.98, population: 1400, prosperity: 0.6, security: 0.4, pirateRisk: 0.1, tariff: 0.02, portFee: 35, shipyard: 1,
    produces: P({ tools: 2, linen: 2, powder: 1.5 }), consumes: P({ sugar: 2, tobacco: 2, rum: 1.5 }),
    note: "St. Eustatius, a barren rock that lives entirely off other people's contraband." },
  { id: "charlotte", name: "Charlotte Amalie", power: "dutch", region: "Lesser Antilles", lat: 18.34, lon: -64.93, population: 1200, prosperity: 0.5, security: 0.45, pirateRisk: 0.14, tariff: 0.03, portFee: 40, shipyard: 1,
    produces: P({ rum: 2, salt: 2 }), consumes: P({ flour: 1.5, cloth: 1.5, tools: 1.5 }),
    note: "A Danish flag over a harbour that welcomes anyone with cargo." },
  { id: "roseau", name: "Roseau", power: "france", region: "Lesser Antilles", lat: 15.3, lon: -61.39, population: 900, prosperity: 0.35, security: 0.3, pirateRisk: 0.2, tariff: 0.06, portFee: 30, shipyard: 0,
    produces: P({ timber: 3, hides: 1.5, ginger: 1 }), consumes: P({ tools: 1.5, cloth: 1, saltbeef: 1 }),
    note: "Dominica: Carib country, timber, water, and very little law." },
  { id: "bridgetownsvincent", name: "Kingstown", power: "england", region: "Lesser Antilles", lat: 13.16, lon: -61.22, population: 700, prosperity: 0.32, security: 0.3, pirateRisk: 0.18, tariff: 0.08, portFee: 25, shipyard: 0,
    produces: P({ timber: 2, cotton: 1.5 }), consumes: P({ tools: 1, flour: 1, cloth: 1 }),
    note: "A watering place more than a colony, and Carib land in every practical sense." },
  { id: "portofspain", name: "Port of Spain", power: "spain", region: "Lesser Antilles", lat: 10.65, lon: -61.5, population: 1100, prosperity: 0.3, security: 0.25, pirateRisk: 0.22, tariff: 0.18, portFee: 40, shipyard: 0,
    produces: P({ cacao: 3, tobacco: 1.5 }), consumes: P({ cloth: 1.5, tools: 1.5, wine: 1, muskets: 1 }),
    note: "Trinidad's neglected outpost: cacao, and a governor who trades with smugglers to eat." },

  // ---- Spanish Main ----
  { id: "cartagena", name: "Cartagena de Indias", power: "spain", region: "Spanish Main", lat: 10.4, lon: -75.51, population: 15000, prosperity: 0.8, security: 0.92, pirateRisk: 0.1, tariff: 0.24, portFee: 220, shipyard: 3,
    produces: P({ silver: 1.5, gold: 0.6, hides: 3, pearls: 0.8 }), consumes: P({ cloth: 4, linen: 4, wine: 4, flour: 4, tools: 3, iron: 2 }),
    note: "Walls, bastions and the galeones. The richest prize in the Indies, and the hardest." },
  { id: "portobelo", name: "Portobelo", power: "spain", region: "Spanish Main", lat: 9.55, lon: -79.65, population: 2000, prosperity: 0.6, security: 0.7, pirateRisk: 0.2, tariff: 0.25, portFee: 170, shipyard: 1,
    produces: P({ silver: 2.5, gold: 0.8 }), consumes: P({ cloth: 3, linen: 3, wine: 3, flour: 3, tools: 2 }),
    note: "Pestilential and nearly empty, until the Peru silver arrives and the fair begins." },
  { id: "maracaibo", name: "Maracaibo", power: "spain", region: "Spanish Main", lat: 10.65, lon: -71.62, population: 4000, prosperity: 0.45, security: 0.4, pirateRisk: 0.26, tariff: 0.2, portFee: 90, shipyard: 1,
    produces: P({ cacao: 3, hides: 3, tobacco: 2 }), consumes: P({ flour: 2, cloth: 2, tools: 2, wine: 2 }),
    note: "Behind a shallow bar in a great lake — which has not kept the buccaneers out." },
  { id: "lacaracas", name: "La Guaira", power: "spain", region: "Spanish Main", lat: 10.6, lon: -66.93, population: 3000, prosperity: 0.52, security: 0.5, pirateRisk: 0.2, tariff: 0.2, portFee: 95, shipyard: 1,
    produces: P({ cacao: 5, tobacco: 2, hides: 2 }), consumes: P({ flour: 2, linen: 2, tools: 2, iron: 1.5 }),
    note: "Caracas cacao comes down the mountain here, and much of it leaves in Dutch bottoms." },
  { id: "campeche", name: "Campeche", power: "spain", region: "Spanish Main", lat: 19.85, lon: -90.53, population: 3500, prosperity: 0.48, security: 0.45, pirateRisk: 0.3, tariff: 0.2, portFee: 80, shipyard: 1,
    produces: P({ dyewood: 6, salt: 2, hides: 2 }), consumes: P({ flour: 2, cloth: 2, tools: 2, wine: 1.5 }),
    note: "Logwood country. The cutters in the lagoons are half smugglers, half pirates." },
  { id: "veracruz", name: "Veracruz", power: "spain", region: "Spanish Main", lat: 19.19, lon: -96.14, population: 8000, prosperity: 0.7, security: 0.75, pirateRisk: 0.16, tariff: 0.25, portFee: 200, shipyard: 2,
    produces: P({ silver: 2.5, silk: 0.5, cacao: 2 }), consumes: P({ cloth: 4, linen: 3, wine: 3, iron: 2, tools: 2 }),
    note: "New Spain's gate. Manila silk arrives overland and departs, unofficially, in every direction." },

  // ---- North America ----
  { id: "charlestown", name: "Charles Town", power: "england", region: "North America", lat: 32.78, lon: -79.93, population: 1800, prosperity: 0.45, security: 0.5, pirateRisk: 0.14, tariff: 0.08, portFee: 55, shipyard: 1,
    produces: P({ timber: 4, pitch: 3, hides: 2, saltbeef: 2 }), consumes: P({ cloth: 2, tools: 2, rum: 2, sugar: 1.5 }),
    note: "A young Carolina settlement trading deerskins, naval stores and discreet prize goods." },
  { id: "boston", name: "Boston", power: "england", region: "North America", lat: 42.36, lon: -71.06, population: 5000, prosperity: 0.62, security: 0.7, pirateRisk: 0.06, tariff: 0.08, portFee: 90, shipyard: 3,
    produces: P({ saltfish: 6, timber: 5, flour: 3, pitch: 2, cordage: 2 }), consumes: P({ sugar: 3, molasses: 4, rum: 2, wine: 2, cloth: 2 }),
    note: "New England salt cod and pine go south; molasses comes back and becomes rum." },
  { id: "newamsterdam", name: "New York", power: "england", region: "North America", lat: 40.7, lon: -74.01, population: 3500, prosperity: 0.6, security: 0.65, pirateRisk: 0.07, tariff: 0.08, portFee: 80, shipyard: 2,
    produces: P({ flour: 5, saltbeef: 3, timber: 3, hides: 2 }), consumes: P({ sugar: 3, rum: 2, cloth: 2, linen: 2 }),
    note: "Dutch-built, English-flagged, and eternally interested in a cargo of unclear origin." },

  // ---- Brazil & Africa ----
  { id: "recife", name: "Recife", power: "portugal", region: "Brazil", lat: -8.05, lon: -34.88, population: 9000, prosperity: 0.65, security: 0.6, pirateRisk: 0.1, tariff: 0.16, portFee: 130, shipyard: 2,
    produces: P({ sugar: 7, molasses: 3, dyewood: 3, cotton: 2 }), consumes: P({ flour: 3, wine: 3, cloth: 3, tools: 3, iron: 2 }),
    note: "Pernambuco sugar, retaken from the Dutch and still the greatest sugar coast on earth." },
  { id: "salvador", name: "Salvador da Bahia", power: "portugal", region: "Brazil", lat: -12.97, lon: -38.5, population: 14000, prosperity: 0.7, security: 0.7, pirateRisk: 0.08, tariff: 0.16, portFee: 150, shipyard: 2,
    produces: P({ sugar: 6, tobacco: 4, gold: 0.5 }), consumes: P({ wine: 4, flour: 3, cloth: 3, iron: 2, tools: 2 }),
    note: "Seat of the Brazilian viceroyalty, thick with sugar money and church silver." },
  { id: "elmina", name: "Elmina", power: "dutch", region: "West Africa", lat: 5.08, lon: -1.35, population: 2500, prosperity: 0.55, security: 0.6, pirateRisk: 0.12, tariff: 0.1, portFee: 70, shipyard: 1,
    produces: P({ gold: 2.2, ginger: 1 }), consumes: P({ muskets: 3, powder: 3, linen: 3, iron: 3, brandy: 2, tools: 2 }),
    note: "The great castle of the Gold Coast, buying iron and arms with gold dust." },
  { id: "luanda", name: "Luanda", power: "portugal", region: "West Africa", lat: -8.84, lon: 13.23, population: 4000, prosperity: 0.5, security: 0.55, pirateRisk: 0.1, tariff: 0.14, portFee: 80, shipyard: 1,
    produces: P({ copper: 2, hides: 2, gold: 0.5 }), consumes: P({ wine: 3, cloth: 3, muskets: 2, iron: 2 }),
    note: "Angola's port, and the darkest hinge of the Atlantic economy." },

  // ---- Europe ----
  { id: "seville", name: "Seville", power: "spain", region: "Europe", lat: 37.39, lon: -5.98, population: 90000, prosperity: 0.75, security: 0.95, pirateRisk: 0.02, tariff: 0.28, portFee: 320, shipyard: 3,
    produces: P({ wine: 6, iron: 4, cloth: 3, tools: 3 }), consumes: P({ silver: 4, cacao: 4, hides: 4, indigo: 3, sugar: 4, dyewood: 3, tobacco: 3, pearls: 1 }),
    note: "The Casa de Contratación holds the legal monopoly on all Indies trade — on paper." },
  { id: "lisbon", name: "Lisbon", power: "portugal", region: "Europe", lat: 38.72, lon: -9.14, population: 65000, prosperity: 0.72, security: 0.9, pirateRisk: 0.02, tariff: 0.2, portFee: 280, shipyard: 3,
    produces: P({ wine: 6, salt: 5, cloth: 2, iron: 2 }), consumes: P({ sugar: 5, tobacco: 4, gold: 2, dyewood: 3, cotton: 2 }),
    note: "Brazil's counting house, and the salt cellar of northern Europe." },
  { id: "amsterdam", name: "Amsterdam", power: "dutch", region: "Europe", lat: 52.37, lon: 4.9, population: 200000, prosperity: 0.95, security: 0.95, pirateRisk: 0.01, tariff: 0.05, portFee: 300, shipyard: 3,
    produces: P({ linen: 7, tools: 6, cordage: 5, canvas: 5, muskets: 4, powder: 4, spices: 3, iron: 4 }),
    consumes: P({ sugar: 6, tobacco: 5, indigo: 4, cacao: 3, dyewood: 4, cotton: 4, coffee: 3, hides: 3, pearls: 1, tortoiseshell: 1 }),
    note: "The market that sets every other market's prices. Nothing here is scarce for long." },
  { id: "london", name: "London", power: "england", region: "Europe", lat: 51.51, lon: -0.13, population: 400000, prosperity: 0.93, security: 0.95, pirateRisk: 0.01, tariff: 0.12, portFee: 300, shipyard: 3,
    produces: P({ cloth: 7, tools: 5, iron: 4, muskets: 3, powder: 3, canvas: 3 }),
    consumes: P({ sugar: 8, tobacco: 6, ginger: 3, indigo: 3, cotton: 4, dyewood: 3, coffee: 3, rum: 3, silver: 2 }),
    note: "Sugar and tobacco land here by law. The Navigation Acts see to that, mostly." },
  { id: "nantes", name: "Nantes", power: "france", region: "Europe", lat: 47.22, lon: -1.55, population: 40000, prosperity: 0.75, security: 0.9, pirateRisk: 0.02, tariff: 0.15, portFee: 250, shipyard: 3,
    produces: P({ brandy: 6, wine: 5, linen: 4, cloth: 3 }), consumes: P({ sugar: 5, cacao: 3, indigo: 3, cotton: 3, tobacco: 3 }),
    note: "Brandy and linen out, colonial produce in, and the slave trade growing behind it all." },
] as unknown as Port[];

/** 1-5: weight in the Atlantic world — market depth, quay talent, yard quality, contracts. */
export const PORT_LEVEL: Record<string, number> = {
  london: 5, amsterdam: 5, seville: 5, lisbon: 5,
  havana: 4, cartagena: 4, portroyal: 4, veracruz: 4, salvador: 4, boston: 4,
  santodomingo: 3, sanjuan: 3, portobelo: 3, recife: 3, newamsterdam: 3, nantes: 3,
  fortroyal: 3, willemstad: 3, luanda: 3,
  santiago: 2, tortuga: 2, bridgetown: 2, stjohns: 2, basseterre: 2, charlotte: 2,
  maracaibo: 2, lacaracas: 2, campeche: 2, charlestown: 2, portofspain: 2, elmina: 2,
  petitgoave: 2,
  oranjestad: 1, roseau: 1, bridgetownsvincent: 1,
};

for (const p of PORTS) p.level = PORT_LEVEL[p.id] ?? 2;

export const PORT_MAP: Record<string, Port> = Object.fromEntries(PORTS.map((p) => [p.id, p]));

/**
 * Harbours cut fresh for a single save — the Brethren's black havens — are
 * folded into the same two structures so that every part of the game that
 * knows about a port knows about them too.
 */
const BASE_IDS = new Set(PORTS.map((p) => p.id));

/** Drop the harbours cut for some other save before laying out a new one. */
export function clearGeneratedPorts() {
  for (let i = PORTS.length - 1; i >= 0; i--) {
    const p = PORTS[i]!;
    if (!BASE_IDS.has(p.id)) {
      PORTS.splice(i, 1);
      delete PORT_MAP[p.id];
    }
  }
}

export function registerPorts(extra: Port[] = []) {
  for (const p of extra) {
    if (PORT_MAP[p.id]) {
      Object.assign(PORT_MAP[p.id]!, p);
      continue;
    }
    PORTS.push(p);
    PORT_MAP[p.id] = p;
  }
}

const REVEALED = new Set<string>();

/** Which hidden harbours the running save has found. */
export function setRevealedPorts(ids: string[] = []) {
  REVEALED.clear();
  for (const id of ids) REVEALED.add(id);
}

export function portVisible(port: Port) {
  return !port.hidden || REVEALED.has(port.id);
}

const R_NM = 3440.065;

export function distanceNm(a: Port, b: Port): number {
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(b.lat - a.lat);
  const dLon = toRad(b.lon - a.lon);
  const s =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(a.lat)) * Math.cos(toRad(b.lat)) * Math.sin(dLon / 2) ** 2;
  // 1.15 factor: ships do not sail great circles through islands.
  return Math.round(2 * R_NM * Math.asin(Math.sqrt(s)) * 1.15);
}
