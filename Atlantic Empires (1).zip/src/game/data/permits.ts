import type { GameState, PowerId } from "../types";
import { factionStanding } from "../sim/standing";
import { COMMODITY_MAP } from "./commodities";
import { POWER_MAP } from "./powers";

/**
 * Absolutist paperwork. Every crown sells the right to enter its harbours, the
 * right to stand in its market at all, and a separate sheet for each class of
 * goods. Every sheet of it expires.
 *
 * Two flags ask for nothing: the Dutch, who care only that you pay, and the
 * Brethren, who keep no custom house.
 */
export type PermitKind = "dock" | "trade" | "yard" | "agricultural" | "raw" | "manufactured" | "military";

export interface PermitKindDef {
  id: PermitKind;
  name: string;
  note: string;
  price: number;
  minRelation: number;
  minReputation: number;
}

/** A licence runs for a year and a day, near enough. */
export const PERMIT_TERM = 365;

/** Crowns that keep no custom house — no paper wanted, of any kind. */
export const FREE_POWERS: PowerId[] = ["dutch", "pirate"];

export const PERMIT_KINDS: PermitKindDef[] = [
  {
    id: "dock",
    name: "Permit to Dock",
    note: "Leave to enter, moor and clear from the crown's harbours.",
    price: 6000,
    minRelation: -30,
    minReputation: 0,
  },
  {
    id: "trade",
    name: "Permit to Trade",
    note: "Leave to stand in the crown's market house at all, whatever the goods.",
    price: 7500,
    minRelation: -20,
    minReputation: 0,
  },
  {
    id: "yard",
    name: "Shipwright's Warrant",
    note: "Leave to careen, refit and buy timber in the crown's yards.",
    price: 5000,
    minRelation: -20,
    minReputation: 0,
  },
  {
    id: "agricultural",
    name: "Agricultural Goods Permit",
    note: "Sugar, tobacco, provisions, spirits and other produce of the soil.",
    price: 4500,
    minRelation: -20,
    minReputation: 0,
  },
  {
    id: "raw",
    name: "Raw Goods Permit",
    note: "Timber, hides, dyewood, naval stores, ore and unwrought metal.",
    price: 6500,
    minRelation: -10,
    minReputation: 0,
  },
  {
    id: "manufactured",
    name: "Manufactured Goods Permit",
    note: "Cloth, ironmongery, tools, specie and fine wares.",
    price: 12000,
    minRelation: 10,
    minReputation: 10,
  },
  {
    id: "military",
    name: "Military Goods Permit",
    note: "Muskets and powder. Refused to almost everyone, and for good reason.",
    price: 30000,
    minRelation: 45,
    minReputation: 30,
  },
];

export const PERMIT_KIND_MAP: Record<PermitKind, PermitKindDef> = Object.fromEntries(
  PERMIT_KINDS.map((k) => [k.id, k]),
) as Record<PermitKind, PermitKindDef>;

/** Which sheet of paper a given commodity falls under. */
export function kindForCommodity(cid: string): PermitKind {
  const c = COMMODITY_MAP[cid];
  if (!c) return "agricultural";
  if (c.category === "contraband") return "military";
  if (c.category === "agricultural" || c.category === "food" || c.category === "alcohol") return "agricultural";
  if (c.category === "raw" || c.category === "naval" || c.category === "metals") return "raw";
  return "manufactured";
}

/** The price a crown asks — great powers charge more for their harbours. */
export function permitPrice(power: PowerId, kind: PermitKind) {
  const base = PERMIT_KIND_MAP[kind].price;
  const weight = power === "spain" || power === "england" ? 1.15 : 1;
  return Math.round(base * weight);
}

export function permitGrant(state: GameState, power: PowerId, kind: PermitKind) {
  return (state.permits ?? []).find((p) => p.power === power && p.kind === kind && p.expiresDay > state.day);
}

export function freePower(power: PowerId) {
  return FREE_POWERS.includes(power);
}

export function hasPermit(state: GameState, power: PowerId, kind: PermitKind) {
  if (freePower(power)) return true;
  return !!permitGrant(state, power, kind);
}

export interface PermitBlock {
  power: PowerId;
  powerName: string;
  kind: PermitKind;
  name: string;
  note: string;
}

function block(power: PowerId, kind: PermitKind): PermitBlock {
  const def = PERMIT_KIND_MAP[kind];
  return { power, powerName: POWER_MAP[power]!.adjective, kind, name: def.name, note: def.note };
}

/** True when this port's crown will not let you touch the commodity. */
export function permitBlocked(state: GameState, power: PowerId, cid: string): PermitBlock | undefined {
  if (freePower(power)) return undefined;
  if (!hasPermit(state, power, "trade")) return block(power, "trade");
  const kind = kindForCommodity(cid);
  if (hasPermit(state, power, kind)) return undefined;
  return block(power, kind);
}

/** No dock permit, no anchorage. */
export function dockBlocked(state: GameState, power: PowerId): PermitBlock | undefined {
  if (hasPermit(state, power, "dock")) return undefined;
  return block(power, "dock");
}

/** No trade permit, no market house. */
export function marketBlocked(state: GameState, power: PowerId): PermitBlock | undefined {
  if (hasPermit(state, power, "dock")) {
    return hasPermit(state, power, "trade") ? undefined : block(power, "trade");
  }
  return block(power, "dock");
}

/** No yard warrant, no careening beach. */
export function yardBlocked(state: GameState, power: PowerId): PermitBlock | undefined {
  if (!hasPermit(state, power, "dock")) return block(power, "dock");
  return hasPermit(state, power, "yard") ? undefined : block(power, "yard");
}

/** Standing required before a crown will treat with you at all. */
export const DIPLOMACY_REPUTATION = 10;

export function diplomacyOpen(state: GameState) {
  return state.reputation >= DIPLOMACY_REPUTATION;
}

export function permitEligible(state: GameState, power: PowerId, kind: PermitKind) {
  const def = PERMIT_KIND_MAP[kind];
  return (
    !freePower(power) &&
    factionStanding(state, power) >= def.minRelation &&
    state.reputation >= def.minReputation
  );
}
