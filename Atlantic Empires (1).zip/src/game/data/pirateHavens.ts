import type { Port } from "../types";
import { rng } from "../sim/util";

/**
 * The Brethren keep no charts worth the name, and no two accounts of the coast
 * agree. Every save therefore cuts its own black harbours out of a list of
 * plausible anchorages — a careening beach, fresh water, and a bar the King's
 * ships draw too much to cross.
 */

interface Site {
  lat: number;
  lon: number;
  region: string;
  where: string;
}

const CARIBBEAN: Site[] = [
  { lat: 25.06, lon: -77.35, region: "Greater Antilles", where: "New Providence" },
  { lat: 16.32, lon: -86.53, region: "Spanish Main", where: "the Bay Islands" },
  { lat: 18.1, lon: -73.68, region: "Greater Antilles", where: "Île-à-Vache" },
  { lat: 19.29, lon: -81.38, region: "Greater Antilles", where: "the Caymanas" },
  { lat: 13.35, lon: -81.37, region: "Spanish Main", where: "Providencia" },
  { lat: 18.13, lon: -65.44, region: "Lesser Antilles", where: "Crab Island" },
  { lat: 21.23, lon: -86.73, region: "Spanish Main", where: "Isla Mujeres" },
  { lat: 11.85, lon: -64.58, region: "Lesser Antilles", where: "La Blanquilla" },
];

const COLONIES: Site[] = [
  { lat: 35.11, lon: -75.98, region: "Carolinas", where: "the Ocracoke banks" },
  { lat: 33.86, lon: -78.02, region: "Carolinas", where: "the Cape Fear river" },
  { lat: 37.93, lon: -75.36, region: "Chesapeake", where: "the Chincoteague shoals" },
  { lat: 39.75, lon: -74.1, region: "Chesapeake", where: "Barnegat inlet" },
  { lat: 32.38, lon: -80.68, region: "Carolinas", where: "the Port Royal sound" },
];

const AFRICA: Site[] = [
  { lat: 7.55, lon: -12.8, region: "Guinea Coast", where: "the Sherbro river" },
  { lat: 11.3, lon: -15.85, region: "Guinea Coast", where: "the Bissagos" },
  { lat: 0.62, lon: 8.72, region: "Guinea Coast", where: "Cape Lopez" },
  { lat: -1.43, lon: 5.63, region: "Guinea Coast", where: "Annobón" },
  { lat: 4.86, lon: -2.24, region: "Guinea Coast", where: "the Axim shore" },
];

const FIRST = [
  "Gallows", "Careen", "Black", "Rogue's", "Dead Man's", "Powder", "Salt", "Cutlass",
  "Hangman's", "Broken", "Sharks'", "Lantern", "Bones", "Rum", "Widow's", "Crossbone",
];
const SECOND = ["Bay", "Cove", "Harbour", "Point", "Reach", "Roads", "Key", "Landing", "Hole", "Sound"];

function nameFor(rand: () => number, used: Set<string>) {
  for (let i = 0; i < 60; i++) {
    const n = `${FIRST[Math.floor(rand() * FIRST.length)]} ${SECOND[Math.floor(rand() * SECOND.length)]}`;
    if (!used.has(n)) {
      used.add(n);
      return n;
    }
  }
  return `Black Harbour ${used.size + 1}`;
}

function farEnough(site: Site, ports: Port[], minDeg: number) {
  return ports.every((p) => Math.hypot(p.lat - site.lat, (p.lon - site.lon) * 0.85) > minDeg);
}

function makePort(site: Site, name: string, level: number, rand: () => number, capital: boolean): Port {
  const id = `black-${name.toLowerCase().replace(/[^a-z]+/g, "-")}`;
  const pop = capital ? 900 + Math.round(rand() * 700) : 200 + Math.round(rand() * 400);
  return {
    id,
    name,
    power: "pirate",
    region: site.region,
    lat: site.lat,
    lon: site.lon,
    population: pop,
    prosperity: capital ? 0.45 + rand() * 0.15 : 0.22 + rand() * 0.16,
    security: capital ? 0.35 : 0.18,
    pirateRisk: 0.05,
    tariff: 0,
    portFee: capital ? 40 : 15,
    shipyard: capital ? 1 : 0,
    level,
    hidden: true,
    produces: capital
      ? { rum: 2.5, salt: 2, hides: 1.5, dyewood: 1 }
      : { salt: 1.5, hides: 1.2, timber: 1.5 },
    consumes: capital
      ? { powder: 3, muskets: 2.5, flour: 2.5, saltbeef: 2, brandy: 2, tools: 1.5 }
      : { powder: 1.5, muskets: 1.2, flour: 1.5, saltbeef: 1.2, rum: 1 },
    note: capital
      ? `No crown, no custom house: the Brethren's own town at ${site.where}, and the nearest thing they have to a capital.`
      : `A careening beach and a few palm-thatched huts at ${site.where}. Nobody puts it on a chart.`,
  };
}

/** Three black harbours: one Caribbean capital, one on the colonies' coast, one in Guinea. */
export function makePirateHavens(seed: number, existing: Port[]): Port[] {
  const rand = rng((seed ^ 0x9e3779b9) >>> 0);
  const used = new Set<string>();
  const out: Port[] = [];
  const plan: [Site[], number, boolean][] = [
    [CARIBBEAN, 2, true],
    [COLONIES, 1, false],
    [AFRICA, 1, false],
  ];
  for (const [pool, level, capital] of plan) {
    const open = pool.filter((s) => farEnough(s, existing, 1.4)) ;
    const list = open.length ? open : pool;
    const site = list[Math.floor(rand() * list.length)]!;
    out.push(makePort(site, nameFor(rand, used), level, rand, capital));
  }
  return out;
}
