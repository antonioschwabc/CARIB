import type { CrewPosition, ShipRegion, ShipStatKey } from "../types";

export interface RegionInfo {
  id: ShipRegion;
  name: string;
  note: string;
}

/** The upper ship. Every hull has all six; only the slot count differs. */
export const SHIP_REGIONS: RegionInfo[] = [
  { id: "bow", name: "Bow", note: "The forward third: anchor gear, chase guns, the cutwater." },
  { id: "stern", name: "Stern", note: "Aft quarters, the rudder head and the retreating battery." },
  { id: "deck", name: "Deck", note: "The working platform: broadside, cargo tackle, signals." },
  {
    id: "bridge",
    name: "Bridge",
    note: "The command post: charts, glasses and the speaking trumpet.",
  },
  { id: "mast", name: "Mast", note: "Spars, canvas and cordage — everything that makes her move." },
  { id: "hull", name: "Hull", note: "Frames, planking and the hold beneath your feet." },
  {
    id: "ordnance",
    name: "Ordnance",
    note: "The guns: carriages, magazine, shot lockers and the powder trail.",
  },
  {
    id: "warehouse",
    name: "Warehouse",
    note: "Her stowage: what she can carry, and what kinds of goods she may carry at all.",
  },
];

export const REGION_MAP: Record<ShipRegion, RegionInfo> = Object.fromEntries(
  SHIP_REGIONS.map((r) => [r.id, r]),
) as Record<ShipRegion, RegionInfo>;

const HULL_STEPS = [0.02, 0.04, 0.06, 0.08, 0.1];
const STD_STEPS = [0.05, 0.075, 0.1, 0.125, 0.15];

export interface ComponentDef {
  id: string;
  name: string;
  region: ShipRegion;
  stat: ShipStatKey;
  /** fractional bonus at levels 1–5 */
  steps: number[];
  /** cost of level 1; each further level costs price × level */
  price: number;
  note: string;
}

export const COMPONENT_DEFS: ComponentDef[] = [
  // HULL
  {
    id: "bow-reinforcement",
    name: "Bow Reinforcement",
    region: "bow",
    stat: "hull",
    steps: HULL_STEPS,
    price: 6400,
    note: "Doubled breasthooks and an ice-proof stem.",
  },
  {
    id: "structural-reinforcement",
    name: "Structural Reinforcement",
    region: "hull",
    stat: "hull",
    steps: HULL_STEPS,
    price: 7200,
    note: "Extra riders and knees worked into the frames.",
  },
  {
    id: "deck-reinforcement",
    name: "Deck Reinforcement",
    region: "deck",
    stat: "hull",
    steps: HULL_STEPS,
    price: 6000,
    note: "Heavier beams so the deck takes a hit without staving.",
  },

  // FIREPOWER
  {
    id: "forward-gun-mount",
    name: "Forward Gun Mount",
    region: "bow",
    stat: "firepower",
    steps: STD_STEPS,
    price: 9000,
    note: "Chase guns for the pursuit.",
  },
  {
    id: "broadside-gun-mount",
    name: "Broadside Gun Mount",
    region: "deck",
    stat: "firepower",
    steps: STD_STEPS,
    price: 9800,
    note: "The main battery, run out along the waist.",
  },
  {
    id: "aft-gun-mount",
    name: "Aft Gun Mount",
    region: "stern",
    stat: "firepower",
    steps: STD_STEPS,
    price: 8600,
    note: "Stern chasers to discourage a follower.",
  },

  // MANEUVERABILITY
  {
    id: "rudder",
    name: "Rudder",
    region: "stern",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 7800,
    note: "A balanced blade and a wheel that answers.",
  },
  {
    id: "lightweight-rigging",
    name: "Lightweight Rigging",
    region: "mast",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 7000,
    note: "Less weight aloft, quicker in stays.",
  },
  {
    id: "maneuvering-sails",
    name: "Maneuvering Sails",
    region: "mast",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 7400,
    note: "Staysails and jibs for close work.",
  },

  // SCOUTING
  {
    id: "lookout-platform",
    name: "Lookout Platform",
    region: "mast",
    stat: "scouting",
    steps: STD_STEPS,
    price: 5200,
    note: "A proper top for the man on watch.",
  },
  {
    id: "spyglass-station",
    name: "Spyglass Station",
    region: "bridge",
    stat: "scouting",
    steps: STD_STEPS,
    price: 6600,
    note: "Good Dutch glasses, kept dry and to hand.",
  },
  {
    id: "signal-station",
    name: "Signal Station",
    region: "deck",
    stat: "scouting",
    steps: STD_STEPS,
    price: 5800,
    note: "Flags, lanterns and a gun for answering.",
  },

  // CARGO
  {
    id: "cargo-hold-expansion",
    name: "Cargo Hold Expansion",
    region: "hull",
    stat: "cargo",
    steps: STD_STEPS,
    price: 8200,
    note: "Bulkheads moved and the orlop cut deeper.",
  },
  {
    id: "cargo-handling-equipment",
    name: "Cargo Handling Equipment",
    region: "deck",
    stat: "cargo",
    steps: STD_STEPS,
    price: 6800,
    note: "Yard tackles and a capstan that stows faster.",
  },
  {
    id: "storage-extension",
    name: "Storage Extension",
    region: "stern",
    stat: "cargo",
    steps: STD_STEPS,
    price: 7600,
    note: "Lazarette space under the great cabin.",
  },

  // SPEED
  {
    id: "main-sails",
    name: "Main Sails",
    region: "mast",
    stat: "speed",
    steps: STD_STEPS,
    price: 9200,
    note: "A full suit of well-cut canvas.",
  },
  {
    id: "rigging",
    name: "Rigging",
    region: "mast",
    stat: "speed",
    steps: STD_STEPS,
    price: 8000,
    note: "Fresh cordage and blocks that run sweetly.",
  },
  {
    id: "streamlined-bow",
    name: "Streamlined Bow",
    region: "bow",
    stat: "speed",
    steps: STD_STEPS,
    price: 8800,
    note: "A finer entry that parts the sea instead of shoving it.",
  },

  // BRIDGE & HULL utility (still stat-bearing, filed under command and repair)
  {
    id: "navigation-equipment",
    name: "Navigation Equipment",
    region: "bridge",
    stat: "speed",
    steps: STD_STEPS,
    price: 7200,
    note: "Charts, a good compass and a running log — fewer miles wasted.",
  },
  {
    id: "communication-equipment",
    name: "Communication Equipment",
    region: "bridge",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 6400,
    note: "Orders reach the tops before the moment passes.",
  },
  {
    id: "command-equipment",
    name: "Command Equipment",
    region: "bridge",
    stat: "firepower",
    steps: STD_STEPS,
    price: 8400,
    note: "A quarterdeck fitted for fighting the ship properly.",
  },
  {
    id: "anchor-equipment",
    name: "Anchor Equipment",
    region: "bow",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 5600,
    note: "Bowers, kedge and cable — she can be warped out of trouble.",
  },
  {
    id: "hull-plating",
    name: "Hull Plating",
    region: "hull",
    stat: "hull",
    steps: HULL_STEPS,
    price: 8600,
    note: "Lead and copper over the planking below the waterline.",
  },
  {
    id: "repair-equipment",
    name: "Repair Equipment",
    region: "hull",
    stat: "hull",
    steps: HULL_STEPS,
    price: 5400,
    note: "Spare timber, plugs and a carpenter's stores worth the name.",
  },
  {
    id: "mast-reinforcement",
    name: "Mast Reinforcement",
    region: "mast",
    stat: "hull",
    steps: HULL_STEPS,
    price: 6200,
    note: "Fished spars and doubled shrouds that hold in a blow.",
  },
  // ORDNANCE
  {
    id: "gun-carriages",
    name: "Gun Carriages",
    region: "ordnance",
    stat: "firepower",
    steps: STD_STEPS,
    price: 9400,
    note: "Truck carriages and breeching that let the pieces run out fast.",
  },
  {
    id: "powder-magazine",
    name: "Powder Magazine",
    region: "ordnance",
    stat: "firepower",
    steps: STD_STEPS,
    price: 10600,
    note: "A lined magazine and a filling room: more powder, safely kept.",
  },
  {
    id: "shot-locker",
    name: "Shot Locker",
    region: "ordnance",
    stat: "firepower",
    steps: STD_STEPS,
    price: 7600,
    note: "Round, bar and grape stowed to hand instead of hunted for.",
  },
  {
    id: "swivel-guns",
    name: "Swivel Guns",
    region: "ordnance",
    stat: "firepower",
    steps: STD_STEPS,
    price: 6800,
    note: "Rail pieces loaded with langrage to sweep a boarder's deck.",
  },
  {
    id: "gunports",
    name: "Gunport Cutting",
    region: "ordnance",
    stat: "maneuverability",
    steps: STD_STEPS,
    price: 7000,
    note: "Ports recut and lidded so she fights without swamping.",
  },

  {
    id: "stern-reinforcement",
    name: "Stern Reinforcement",
    region: "stern",
    stat: "hull",
    steps: HULL_STEPS,
    price: 6600,
    note: "The transom braced against a raking shot.",
  },
];

export const COMPONENT_MAP: Record<string, ComponentDef> = Object.fromEntries(
  COMPONENT_DEFS.map((c) => [c.id, c]),
);

export function componentsForRegion(region: ShipRegion) {
  return COMPONENT_DEFS.filter((c) => c.region === region);
}

/**
 * The best mark of work a harbour can do. A careening beach fits plain gear;
 * only a great dockyard turns out mark five.
 */
export function yardMaxMark(port: { level?: number; shipyard: number }) {
  const byLevel = Math.max(1, Math.min(5, port.level ?? 3));
  const byYard = Math.max(1, Math.min(5, port.shipyard * 2));
  return Math.min(byLevel, byYard);
}

/** Cost to take a component from `level` to `level + 1` (level 0 = install). */
export function componentCost(def: ComponentDef, level: number) {
  return Math.round(def.price * (level + 1));
}

/** Cost to mount a fresh gun (level 0) or take one from `level` to `level + 1`. */
export function gunCost(level: number) {
  return Math.round(2600 * (level + 1));
}

export interface QuarterDef {
  id: CrewPosition;
  name: string;
  note: string;
  price: number;
}

/** Lower-deck quarters. A position cannot be filled without its quarter. */
export const QUARTERS: QuarterDef[] = [
  {
    id: "captain",
    name: "Captain's Cabin",
    note: "Always aboard. Your table, your charts, your authority.",
    price: 0,
  },
  {
    id: "firstMate",
    name: "Officer's Quarters",
    note: "Berth for a first mate to keep the ship running when you sleep.",
    price: 9000,
  },
  {
    id: "scout",
    name: "Lookout",
    note: "A watch berth and a masthead station for the eyes of the ship.",
    price: 6500,
  },
  {
    id: "carpenter",
    name: "Carpenter's Workshop",
    note: "Bench, tools and timber; repairs at sea become possible.",
    price: 11000,
  },
  {
    id: "gunner",
    name: "Gun Deck",
    note: "Powder, shot and a gunner to lay the pieces properly.",
    price: 13000,
  },
  {
    id: "quartermaster",
    name: "Cargo Office",
    note: "Manifests, scales and a man who knows what a cargo is worth.",
    price: 10000,
  },
  {
    id: "cook",
    name: "Kitchen",
    note: "A galley and a copper. Hot food keeps a crew loyal.",
    price: 7000,
  },
  {
    id: "surgeon",
    name: "Sickbay",
    note: "Cots, instruments and a chance of surviving your wounds.",
    price: 12000,
  },
];

export const QUARTER_MAP: Record<CrewPosition, QuarterDef> = Object.fromEntries(
  QUARTERS.map((q) => [q.id, q]),
) as Record<CrewPosition, QuarterDef>;

/** Quarters that consume lower-deck capacity (everything but the cabin). */
export const OPTIONAL_QUARTERS = QUARTERS.filter((q) => q.id !== "captain");
