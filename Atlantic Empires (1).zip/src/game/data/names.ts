/**
 * Names for the player's trading house (banner) and for vessels.
 * Everything is culture-flavoured: a Dutch skipper does not sail the
 * "Santa Ventura", and a Spaniard does not fly the colours of the
 * "Zeeland Free Company".
 */

const pick = <T,>(arr: readonly T[], rand: () => number) => arr[Math.floor(rand() * arr.length)]!;

type Pools = {
  /** stately adjectives used in company styling */
  adj: string[];
  /** nouns a house might take as its device */
  noun: string[];
  /** places the house might claim as its seat */
  seat: string[];
  /** full company templates, {S} surname, {A} adj, {N} noun, {P} seat */
  house: string[];
  /** vessel names */
  vessel: string[];
};

const P: Record<string, Pools> = {
  English: {
    adj: ["Royal", "Bold", "Free", "Honourable", "Windward", "Leeward", "Golden", "Iron", "Merchant", "Providence"],
    noun: ["Adventurers", "Anchor", "Compass", "Crown", "Hart", "Lion", "Rose", "Sovereigns", "Tide", "Wager", "Fortune", "Harbour", "Gauntlet"],
    seat: ["Bristol", "Plymouth", "Port Royal", "London", "Barbados", "Bermuda", "Dover", "Kingston"],
    house: [
      "{S} & Company",
      "{S} & Sons",
      "The {A} {N} Company",
      "House of {S}",
      "The {P} {N} Company",
      "The {A} Company of {P}",
      "{S}, {P} & Co.",
      "Company of {A} {N}",
      "The {N} Concern",
      "{S} Trading House",
      "The {A} {N} Venture",
      "Brethren of the {N}",
    ],
    vessel: [
      "Swiftsure", "Marigold", "Black Swan", "Redemption", "Sea Hart", "Providence", "Gallant", "Bristol Maid",
      "Windward Rose", "Endeavour", "Kestrel", "Nightingale", "Constant Mary", "Dover Pride", "Thornbury",
      "Grace of God", "Merry Widow", "Salamander", "Wolfhound", "Tempest", "Fortune's Wheel", "Ravenscar",
    ],
  },
  Irish: {
    adj: ["Wild", "Green", "Free", "Blessed", "Grey", "Western", "Faithful"],
    noun: ["Geese", "Harp", "Hound", "Salmon", "Shamrock", "Cliffs", "Kern", "Gale"],
    seat: ["Galway", "Kinsale", "Waterford", "Cork", "Dingle", "Sligo"],
    house: [
      "{S} & Company",
      "The {A} {N} Company",
      "Clan {S}",
      "House of {S}",
      "The {P} {N} Company",
      "{S} of {P}",
      "The {A} Geese of {P}",
      "Brotherhood of the {N}",
      "{S} & Kin",
    ],
    vessel: [
      "Wild Goose", "Banshee", "Saint Brendan", "Cliffs of Moher", "Grania", "Kinsale Lass", "Sea Hound",
      "Emerald", "Sláinte", "Rose of Cork", "Fiach Dubh", "Galway Hooker", "Aoife", "Wolf of Sligo",
    ],
  },
  Dutch: {
    adj: ["Vrije", "Grote", "Golden", "Northern", "United", "Steadfast"],
    noun: ["Compagnie", "Anchor", "Guilder", "Herring", "Windmill", "Lion", "Beurs", "Zeewind"],
    seat: ["Amsterdam", "Zeeland", "Rotterdam", "Hoorn", "Curaçao", "Middelburg", "Enkhuizen"],
    house: [
      "{S} & Compagnie",
      "{P} {N} Compagnie",
      "The {A} {P} Company",
      "Huis {S}",
      "{S} en Zonen",
      "Vereenigde {N} Compagnie",
      "The {A} {N} Compagnie",
      "{P} Handelshuis",
      "Kamer van {P}",
    ],
    vessel: [
      "Zeewolf", "Gouden Leeuw", "Batavia", "Nachtwacht", "De Hoop", "Windvaan", "Zwarte Zwaan", "Fortuyn",
      "Vliegende Draeck", "Amsterdam", "Duyfken", "Meermin", "Noordster", "Stormvogel", "De Zeven Provinciën",
    ],
  },
  French: {
    adj: ["Royale", "Grande", "Libre", "Noble", "Nouvelle", "Sainte"],
    noun: ["Compagnie", "Fleur", "Corsaires", "Couronne", "Ancre", "Étoile", "Marée"],
    seat: ["Saint-Malo", "La Rochelle", "Tortuga", "Nantes", "Martinique", "Le Havre", "Dieppe"],
    house: [
      "Maison {S}",
      "{S} et Fils",
      "Compagnie {A} de {P}",
      "La {A} {N}",
      "Compagnie des {N}",
      "{S} & Cie",
      "Les {N} de {P}",
      "Confrérie de la {N}",
    ],
    vessel: [
      "L'Espérance", "Le Sanglier", "Belle Aurore", "La Sirène", "Fleur de Mer", "Le Corsaire", "Étoile du Nord",
      "La Foudre", "Marie-Galante", "Le Dauphin", "Vent d'Ouest", "La Revanche", "Saint-Michel", "L'Intrépide",
    ],
  },
  Spanish: {
    adj: ["Real", "Santa", "Nueva", "Grande", "Fiel", "Dorada"],
    noun: ["Compañía", "Ancla", "Corona", "Cruz", "Estrella", "Armada", "Marea", "Plata"],
    seat: ["Sevilla", "Cádiz", "Havana", "Cartagena", "Veracruz", "Panamá", "Santo Domingo"],
    house: [
      "Casa {S}",
      "{S} y Hijos",
      "Compañía {A} de {P}",
      "La {A} {N}",
      "Casa de la {N}",
      "{S} y Compañía",
      "Hermandad de la {N}",
      "Los {N} de {P}",
    ],
    vessel: [
      "Nuestra Señora", "San Cristóbal", "La Concepción", "Espíritu Santo", "El Halcón", "Santa Clara",
      "La Tormenta", "Rosario", "El Alcatraz", "Buen Viaje", "La Cazadora", "San Telmo", "Doncella de Cádiz",
    ],
  },
  Portuguese: {
    adj: ["Real", "Santa", "Nova", "Livre", "Dourada"],
    noun: ["Companhia", "Âncora", "Cruz", "Estrela", "Maré", "Coroa", "Bandeira"],
    seat: ["Lisboa", "Porto", "Recife", "Bahia", "Madeira", "Cabo Verde", "Faro"],
    house: [
      "Casa {S}",
      "{S} e Filhos",
      "Companhia {A} de {P}",
      "A {A} {N}",
      "Companhia da {N}",
      "{S} & Companhia",
      "Irmandade da {N}",
      "Feitoria de {P}",
    ],
    vessel: [
      "Bom Jesus", "Flor do Mar", "Santa Cruz", "Nau Vitória", "Andorinha", "O Corvo", "Estrela do Sul",
      "Nossa Senhora da Guia", "Ventania", "Sagres", "Caravela Negra", "Pérola do Recife", "Mareante",
    ],
  },
  Creole: {
    adj: ["Free", "Wild", "Bright", "Old", "Salt"],
    noun: ["Cane", "Palm", "Drum", "Iguana", "Trade Winds", "Reef", "Cimarron"],
    seat: ["Tortuga", "Petit-Goâve", "Willemstad", "Basse-Terre", "Saint-Pierre"],
    house: [
      "{S} & Company",
      "Maison {S}",
      "The {A} {N} Company",
      "Compagnie du {N}",
      "The {N} of {P}",
      "{S} & Frères",
      "Free Men of {P}",
    ],
    vessel: [
      "Ti Rouge", "Bon Vent", "Manatee", "Cimarron", "Papillon", "Sugar Bird", "Bel Espoir", "Kalinago",
      "Nightjar", "Zombi", "Cassava", "Reef Runner", "Mama Wata", "Trade Wind",
    ],
  },
  African: {
    adj: ["Free", "Golden", "Elder", "Wide", "Sun"],
    noun: ["Ivory", "Lion", "Baobab", "Drum", "Gold Coast", "Kola", "Horizon"],
    seat: ["Elmina", "Ouidah", "Benin", "Loango", "Cape Coast"],
    house: [
      "{S} & Company",
      "House of {S}",
      "The {A} {N} Company",
      "The {N} of {P}",
      "{S} & Kin",
      "Company of {P}",
    ],
    vessel: [
      "Anansi", "Sunjata", "Baobab", "Elmina Star", "Oyo", "Nana Buluku", "Ivory Gull", "Kola Wind",
      "Shango", "Sea Drum", "Benin Rose", "Mansa",
    ],
  },
};

function pools(nationality: string) {
  return P[nationality] ?? P["English"]!;
}

/** A name for the player's trading house / faction. */
export function randomBannerName(nationality: string, surname: string, rand: () => number = Math.random) {
  const p = pools(nationality);
  return pick(p.house, rand)
    .replace("{S}", surname || pick(p.seat, rand))
    .replace("{A}", pick(p.adj, rand))
    .replace("{N}", pick(p.noun, rand))
    .replace("{P}", pick(p.seat, rand));
}

/** A vessel name in keeping with the captain's culture. */
export function randomVesselName(nationality: string, rand: () => number = Math.random) {
  return pick(pools(nationality).vessel, rand);
}
