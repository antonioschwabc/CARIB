/**
 * Battlegrounds: a dozen stretches of water, cut once and kept.
 *
 * Every action is fought on one of these, chosen by lot. They are drawn as
 * tiles — deep water, shoal, and land — in the same hand as the great chart,
 * and no hull may cross a land tile.
 */

export const TILE = 2.5;
export const COLS = 40;
export const ROWS = 25;

export const DEEP = 0;
export const SHOAL = 1;
export const LAND = 2;

export interface Battleground {
  id: string;
  name: string;
  cols: number;
  rows: number;
  tile: number;
  /** rows of tiles, each DEEP | SHOAL | LAND */
  tiles: number[][];
  /**
   * Which stretch of water each sea tile belongs to. Land is -1. Ponds cut off
   * from the open sea carry their own number, and no hull is ever laid in one.
   */
  region: number[][];
  /** the number of the open sea: the largest connected body of water */
  main: number;
}

/** Flood the water and number each separate body of it. */
function regions(tiles: number[][]) {
  const region: number[][] = tiles.map((r) => r.map((t) => (t === LAND ? -1 : -2)));
  const sizes: number[] = [];
  let next = 0;
  for (let y = 0; y < tiles.length; y++) {
    for (let x = 0; x < tiles[0]!.length; x++) {
      if (region[y]![x] !== -2) continue;
      const id = next++;
      let size = 0;
      const stack = [[x, y] as [number, number]];
      region[y]![x] = id;
      while (stack.length) {
        const [cx, cy] = stack.pop()!;
        size++;
        for (const [dx, dy] of [
          [1, 0],
          [-1, 0],
          [0, 1],
          [0, -1],
        ] as const) {
          const nx = cx + dx;
          const ny = cy + dy;
          if (region[ny]?.[nx] === -2) {
            region[ny]![nx] = id;
            stack.push([nx, ny]);
          }
        }
      }
      sizes.push(size);
    }
  }
  let main = 0;
  sizes.forEach((s, i) => {
    if (s > (sizes[main] ?? 0)) main = i;
  });
  return { region, main };
}

function rng(seed: number) {
  let s = seed >>> 0 || 1;
  return () => {
    s ^= s << 13;
    s ^= s >>> 17;
    s ^= s << 5;
    s >>>= 0;
    return s / 4294967296;
  };
}

/** A blob of land grown out of a few overlapping lobes, so nothing is a circle. */
function blob(
  grid: number[][],
  cx: number,
  cy: number,
  r: number,
  rand: () => number,
) {
  const lobes = [{ x: cx, y: cy, r }];
  const n = 2 + Math.floor(rand() * 3);
  for (let i = 0; i < n; i++) {
    const a = rand() * Math.PI * 2;
    const d = r * (0.4 + rand() * 0.7);
    lobes.push({ x: cx + Math.cos(a) * d, y: cy + Math.sin(a) * d * 0.7, r: r * (0.4 + rand() * 0.6) });
  }
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      for (const l of lobes) {
        if (Math.hypot(x - l.x, (y - l.y) * 1.25) <= l.r) {
          grid[y]![x] = LAND;
          break;
        }
      }
    }
  }
}

/** Sand shows through wherever the water shelves up against a shore. */
function shelve(grid: number[][]) {
  const out = grid.map((r) => r.slice());
  for (let y = 0; y < ROWS; y++) {
    for (let x = 0; x < COLS; x++) {
      if (grid[y]![x] !== DEEP) continue;
      let near = false;
      for (let dy = -2; dy <= 2 && !near; dy++)
        for (let dx = -2; dx <= 2; dx++) {
          const g = grid[y + dy]?.[x + dx];
          if (g === LAND && Math.abs(dx) + Math.abs(dy) <= 3) {
            near = true;
            break;
          }
        }
      if (near) out[y]![x] = SHOAL;
    }
  }
  return out;
}

const NAMES = [
  "The Windward Passage",
  "Bahía de Matanzas",
  "The Mona Shoals",
  "Cayos de la Reina",
  "The Grenada Roads",
  "Baie du Cul-de-Sac",
  "Anegada Bank",
  "The Bight of Providence",
  "Boca del Dragón",
  "Zeeland Flats",
  "The Serrana Bank",
  "Cabo Rojo Sound",
];

function build(seed: number, name: string, id: string): Battleground {
  const rand = rng(seed);
  const grid: number[][] = Array.from({ length: ROWS }, () => Array.from({ length: COLS }, () => DEEP));

  const kind = rand();
  if (kind < 0.3) {
    // a coast along one edge, with the sea open to the other side
    const side = Math.floor(rand() * 4);
    const depth = 3 + Math.floor(rand() * 3);
    for (let y = 0; y < ROWS; y++)
      for (let x = 0; x < COLS; x++) {
        const wobble = Math.round(Math.sin((side < 2 ? x : y) * 0.4 + seed) * 1.4);
        if (side === 0 && y < depth + wobble) grid[y]![x] = LAND;
        if (side === 1 && y >= ROWS - depth - wobble) grid[y]![x] = LAND;
        if (side === 2 && x < depth + wobble) grid[y]![x] = LAND;
        if (side === 3 && x >= COLS - depth - wobble) grid[y]![x] = LAND;
      }
    const isles = Math.floor(rand() * 2);
    for (let i = 0; i < isles; i++)
      blob(grid, 10 + rand() * (COLS - 20), 4 + rand() * (ROWS - 8), 1.5 + rand() * 2, rand);
  } else if (kind < 0.6) {
    // a strait: land top and bottom, open water between
    const d1 = 2 + Math.floor(rand() * 3);
    const d2 = 2 + Math.floor(rand() * 3);
    for (let y = 0; y < ROWS; y++)
      for (let x = 0; x < COLS; x++) {
        const w = Math.round(Math.sin(x * 0.28 + seed) * 1.6);
        if (y < d1 + w) grid[y]![x] = LAND;
        if (y >= ROWS - d2 - w) grid[y]![x] = LAND;
      }
  } else if (kind < 0.85) {
    // scattered cays
    const isles = 2 + Math.floor(rand() * 3);
    for (let i = 0; i < isles; i++)
      blob(grid, 8 + rand() * (COLS - 16), 4 + rand() * (ROWS - 8), 1.4 + rand() * 2.4, rand);
  } else {
    // blue water: nothing but swell, and perhaps one rock
    if (rand() < 0.5) blob(grid, 14 + rand() * (COLS - 28), 6 + rand() * (ROWS - 12), 1.2, rand);
  }

  // Keep the two ends of the arena clear so both parties have sea room.
  for (let y = 0; y < ROWS; y++)
    for (const x of [0, 1, 2, COLS - 3, COLS - 2, COLS - 1]) {
      if (y > 3 && y < ROWS - 4) grid[y]![x] = DEEP;
    }

  const tiles = shelve(grid);
  const { region, main } = regions(tiles);
  return { id, name, cols: COLS, rows: ROWS, tile: TILE, tiles, region, main };
}

export const BATTLEGROUNDS: Battleground[] = NAMES.map((n, i) =>
  build(90210 + i * 7717, n, `bg${i + 1}`),
);

export const BATTLEGROUND_MAP: Record<string, Battleground> = Object.fromEntries(
  BATTLEGROUNDS.map((b) => [b.id, b]),
);

/** The tile under a point in arena units. */
export function tileAt(bg: Battleground, x: number, y: number) {
  const cx = Math.floor(x / bg.tile);
  const cy = Math.floor(y / bg.tile);
  return bg.tiles[cy]?.[cx] ?? LAND;
}

export function isLand(bg: Battleground, x: number, y: number) {
  return tileAt(bg, x, y) === LAND;
}

/** Is this point on the open sea — water joined to the whole body of it? */
export function isOpenSea(bg: Battleground, x: number, y: number) {
  const cx = Math.floor(x / bg.tile);
  const cy = Math.floor(y / bg.tile);
  return (bg.region[cy]?.[cx] ?? -1) === bg.main;
}

/**
 * The nearest patch of open water — never a landlocked pond, so no hull is
 * ever laid where she cannot sail out again.
 */
export function nearestSea(bg: Battleground, x: number, y: number) {
  if (isOpenSea(bg, x, y)) return { x, y };
  const cx = Math.floor(x / bg.tile);
  const cy = Math.floor(y / bg.tile);
  let best: { x: number; y: number; d: number } | undefined;
  for (let ty = 0; ty < bg.rows; ty++) {
    for (let tx = 0; tx < bg.cols; tx++) {
      if (bg.region[ty]![tx] !== bg.main) continue;
      const px = (tx + 0.5) * bg.tile;
      const py = (ty + 0.5) * bg.tile;
      const d = Math.hypot(tx - cx, ty - cy);
      if (!best || d < best.d) best = { x: px, y: py, d };
    }
  }
  return best ? { x: best.x, y: best.y } : { x: (bg.cols * bg.tile) / 2, y: (bg.rows * bg.tile) / 2 };
}
