import type { EncEffects } from "../sim/encounters";
import type { SkillId } from "../types";

/**
 * Small human weather: quarrels, kindnesses, dockside temptations and the
 * gossip of a harbour. None of it is a fight; all of it wants a word from the
 * captain. `{crew}` is replaced with a man's name, `{port}` with a harbour.
 */

export interface LifeOption {
  id: string;
  label: string;
  skill?: SkillId;
  dc?: number;
  ok: string;
  bad?: string;
  gain?: EncEffects;
  loss?: EncEffects;
  /** what it does to the one man it concerns, on success / on failure */
  crewOk?: { health?: number; morale?: number };
  crewBad?: { health?: number; morale?: number };
}

export interface LifeEventDef {
  id: string;
  scene: "sea" | "port" | "quay";
  /** needs a named crew member to hang on */
  needsCrew?: boolean;
  title: string;
  lines: string[];
  weight: number;
  options: LifeOption[];
}

export const LIFE_EVENTS: LifeEventDef[] = [
  // ---- Among the people, at sea ----
  {
    id: "quarrel",
    scene: "sea",
    needsCrew: true,
    weight: 1.2,
    title: "A quarrel on the forecastle",
    lines: [
      "{crew} has a man by the collar over a lost knife, and the watch has formed a ring.",
      "{crew} and another hand are shouting themselves hoarse over a hand of cards.",
    ],
    options: [
      {
        id: "flog",
        label: "Order a dozen lashes and have done",
        ok: "The grating is rigged, the sentence read, and the ship is very quiet after.",
        loss: { morale: [2, 5] },
        crewBad: { health: -8, morale: -14 },
      },
      {
        id: "talk",
        label: "Hear both men out on the quarterdeck",
        skill: "charisma",
        dc: 45,
        ok: "You give each man his say, split the difference, and they shake on it before the watch.",
        bad: "Neither will give way, and now the whole ship knows you could not settle it.",
        gain: { morale: [1, 4], xp: { skill: "charisma", amount: 120 } },
        loss: { morale: [1, 4] },
        crewOk: { morale: 8 },
        crewBad: { morale: -8 },
      },
      {
        id: "work",
        label: "Set them both to holystoning until they are friends",
        ok: "Four hours on their knees together and they are laughing by the last bell.",
        gain: { morale: [0, 2] },
        crewOk: { morale: 4 },
      },
      {
        id: "ignore",
        label: "Let the mate deal with it",
        ok: "It burns itself out by supper, as these things do.",
      },
    ],
  },
  {
    id: "shanty",
    scene: "sea",
    needsCrew: true,
    weight: 1,
    title: "A fiddle in the last dog watch",
    lines: [
      "{crew} has a fiddle out and half the watch is stamping on the boards.",
      "{crew} strikes up a song the whole forecastle knows the words to.",
    ],
    options: [
      {
        id: "join",
        label: "Send up a cask and let them sing",
        ok: "The mess sings until the mate loses his temper, and everyone sleeps well.",
        gain: { morale: [3, 6] },
        loss: { supplies: [1, 2] },
        crewOk: { morale: 8 },
      },
      {
        id: "quiet",
        label: "Silence on deck — this is a working ship",
        ok: "The fiddle goes back in its bag. The ship is quiet, and sullen with it.",
        loss: { morale: [1, 4] },
        crewBad: { morale: -6 },
      },
    ],
  },
  {
    id: "sickberth",
    scene: "sea",
    needsCrew: true,
    weight: 1,
    title: "A man down in the berth",
    lines: [
      "{crew} cannot stand his watch: he is grey, sweating and no use to anyone.",
      "{crew} is carried below with his leg opened on a splintered spar.",
    ],
    options: [
      {
        id: "physic",
        label: "Break out the physic and work on him",
        skill: "medicine",
        dc: 45,
        ok: "The fever breaks by morning and he is on his feet inside the week.",
        bad: "Nothing answers. He worsens, and the mess watches you fail at it.",
        gain: { xp: { skill: "medicine", amount: 150 } },
        loss: { medicine: [1, 3], morale: [1, 3] },
        crewOk: { health: 18 },
        crewBad: { health: -14, morale: -6 },
      },
      {
        id: "rest",
        label: "Off the watch bill until he mends",
        ok: "He keeps his hammock. The ship is a hand short and nobody complains much.",
        crewOk: { health: 8, morale: 4 },
        loss: { days: [0, 1] },
      },
      {
        id: "drive",
        label: "Every man stands his watch",
        ok: "He stands it. He is worse for it, and the forecastle has an opinion.",
        loss: { morale: [2, 5] },
        crewBad: { health: -12, morale: -10 },
      },
    ],
  },
  {
    id: "pilfer",
    scene: "sea",
    needsCrew: true,
    weight: 0.9,
    title: "Stores gone missing",
    lines: [
      "The steward swears a cask has been broached, and {crew} was last in the bread room.",
      "Two days' beef is unaccounted for and {crew} will not meet your eye.",
    ],
    options: [
      {
        id: "search",
        label: "Turn out every chest in the ship",
        skill: "logistics",
        dc: 50,
        ok: "The stores turn up under a false bottom, and the ship's honest men are relieved.",
        bad: "Every chest opened, nothing found, and the whole company insulted.",
        gain: { supplies: [1, 4], xp: { skill: "logistics", amount: 120 } },
        loss: { morale: [3, 6] },
        crewBad: { morale: -8 },
      },
      {
        id: "pardon",
        label: "Say nothing and put the mess on full rations",
        ok: "Whoever took it does not take again. It is remembered as a decency.",
        gain: { morale: [2, 4] },
        loss: { supplies: [1, 3] },
      },
      {
        id: "stop",
        label: "Stop the man's pay and let it be known why",
        ok: "The purser makes his note. Discipline is served, warmth is not.",
        loss: { morale: [1, 3] },
        crewBad: { morale: -12 },
        gain: { gold: [30, 120] },
      },
    ],
  },
  {
    id: "omen",
    scene: "sea",
    weight: 0.8,
    title: "An ill omen",
    lines: [
      "A shark has followed the ship since dawn and the older hands have gone quiet.",
      "St Elmo's fire burns blue on the yardarms and half the watch is praying.",
    ],
    options: [
      {
        id: "scoff",
        label: "Laugh at it in front of them",
        skill: "charisma",
        dc: 40,
        ok: "You make a joke of it that goes round the ship, and the fear goes with it.",
        bad: "Nobody laughs. They think you a fool who does not know the sea.",
        gain: { morale: [2, 5], xp: { skill: "charisma", amount: 100 } },
        loss: { morale: [2, 5] },
      },
      {
        id: "ritual",
        label: "Let them have their rites, and a tot besides",
        ok: "A prayer, a splash of rum over the side, and the ship settles.",
        gain: { morale: [1, 4] },
        loss: { supplies: [0, 2] },
      },
    ],
  },

  // ---- Ashore, in harbour ----
  {
    id: "brawl",
    scene: "port",
    needsCrew: true,
    weight: 1.1,
    title: "Trouble in {port}",
    lines: [
      "The watch of {port} has {crew} in irons for breaking up a tap-room.",
      "{crew} is brought back aboard bloodied, with a magistrate's man behind him.",
    ],
    options: [
      {
        id: "fine",
        label: "Pay the fine and get him aboard",
        ok: "Coin changes hands, the magistrate loses interest, and the man is yours again.",
        loss: { gold: [-400, -90] },
        crewOk: { morale: 10 },
        gain: { morale: [0, 2] },
      },
      {
        id: "argue",
        label: "Argue him out of it",
        skill: "charisma",
        dc: 55,
        ok: "You talk the magistrate round entirely, and it costs you nothing but an hour.",
        bad: "He doubles the fine for your trouble and keeps the man overnight.",
        gain: { xp: { skill: "charisma", amount: 160 }, morale: [1, 3] },
        loss: { gold: [-700, -250], days: [1, 1] },
        crewBad: { morale: -8, health: -6 },
      },
      {
        id: "leave",
        label: "Leave him to the magistrate",
        ok: "The ship sails a hand short. The forecastle notes it, and says nothing.",
        loss: { morale: [3, 7] },
      },
    ],
  },
  {
    id: "wedding",
    scene: "port",
    needsCrew: true,
    weight: 0.7,
    title: "A man wants leave",
    lines: [
      "{crew} asks for three days ashore: there is a girl in {port} and a priest willing.",
      "{crew} stands at the cabin door with his hat in his hands, asking for leave.",
    ],
    options: [
      {
        id: "grant",
        label: "Grant it, and stand him a cask",
        ok: "He comes back on the third morning, sober, married, and yours for life.",
        gain: { morale: [2, 5] },
        loss: { gold: [-200, -40], days: [1, 2] },
        crewOk: { morale: 20 },
      },
      {
        id: "refuse",
        label: "Refuse — the ship sails on the tide",
        ok: "He says nothing at all, which is worse than if he had.",
        loss: { morale: [1, 4] },
        crewBad: { morale: -16 },
      },
    ],
  },
  {
    id: "quaywork",
    scene: "quay",
    weight: 1,
    title: "The quay at {port}",
    lines: [
      "A factor offers your idle hands a day's work shifting somebody else's sugar.",
      "The harbour master wants men for the careening beach and will pay for them.",
    ],
    options: [
      {
        id: "hire",
        label: "Hire the company out for the day",
        ok: "A hard day for other men's cargo, and honest coin at the end of it.",
        gain: { gold: [120, 500], xp: { skill: "logistics", amount: 80 } },
        loss: { morale: [1, 3], days: [1, 1] },
      },
      {
        id: "rest",
        label: "Let them have the day to themselves",
        ok: "They spend it badly and come back the better for it.",
        gain: { morale: [2, 5] },
      },
      {
        id: "drill",
        label: "Exercise the great guns instead",
        ok: "Powder burnt for nothing but practice, and the gun crews the sharper for it.",
        gain: { xp: { skill: "gunnery", amount: 160 } },
        loss: { morale: [1, 3] },
      },
    ],
  },
  {
    id: "peddler",
    scene: "quay",
    weight: 0.9,
    title: "A man on the quay with a story",
    lines: [
      "A ragged fellow offers a chart of a reef nobody has troubled to sound.",
      "A ship's boy sells you word of what the customs house is looking for this month.",
    ],
    options: [
      {
        id: "buy",
        label: "Pay him what he asks",
        skill: "scouting",
        dc: 45,
        ok: "The paper is good. There is a channel there that will save you days.",
        bad: "It is a copy of a copy, and worth nothing at all.",
        gain: { xp: { skill: "scouting", amount: 150 } },
        loss: { gold: [-260, -60] },
      },
      {
        id: "haggle",
        label: "Beat him down first",
        skill: "charisma",
        dc: 40,
        ok: "He takes a third of what he asked and is glad of it.",
        bad: "He spits, pockets his paper, and sells it to the next master along.",
        gain: { xp: { skill: "charisma", amount: 110 } },
        loss: { gold: [-80, -20] },
      },
      { id: "wave", label: "Wave him off", ok: "He shrugs and works his way down the quay." },
    ],
  },
  {
    id: "priest",
    scene: "port",
    weight: 0.7,
    title: "The church at {port}",
    lines: [
      "A priest asks a subscription for the hospital, and makes a point of your ship's name.",
      "The parish is raising money for the sick of the waterfront, and you have been noticed.",
    ],
    options: [
      {
        id: "give",
        label: "Subscribe handsomely",
        ok: "Your name is read out at Mass, which is worth more here than a cargo.",
        gain: { reputation: 3, morale: [1, 3] },
        loss: { gold: [-600, -150] },
      },
      {
        id: "token",
        label: "Give a token and be gone",
        ok: "A small coin, a smaller thank you, and no more said about it.",
        loss: { gold: [-60, -15] },
      },
      {
        id: "refuse",
        label: "Refuse the priest",
        ok: "He blesses you anyway, in a tone that carries down the street.",
        loss: { reputation: -2 },
      },
    ],
  },
];

export const LIFE_EVENT_MAP: Record<string, LifeEventDef> = Object.fromEntries(
  LIFE_EVENTS.map((e) => [e.id, e]),
);
