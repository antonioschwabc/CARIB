import { PORTS, portVisible } from "./ports";
import type { Port } from "../types";

export interface MapRegion {
  id: string;
  name: string;
  blurb: string;
  /** [lonMin, latMin, lonMax, latMax] — must match the coastline generator. */
  bbox: [number, number, number, number];
  /** which way to stretch open ocean so the sheet fills the frame */
  fill?: "e" | "w";
  /** engraved water names */
  seas?: { name: string; lon: number; lat: number; size?: number }[];
  /** what lies beyond each edge of this sheet */
  links?: { side: "n" | "s" | "e" | "w"; regionId: string; label: string }[];
}

export const MAP_REGIONS: MapRegion[] = [
  {
    id: "caribbean",
    name: "Caribbean",
    blurb: "The Antilles, the Spanish Main and the Gulf — the theatre of the war of trade.",
    bbox: [-98, 8.5, -57, 31],
    seas: [
      { name: "GULF OF MEXICO", lon: -91, lat: 25, size: 20 },
      { name: "CARIBBEAN SEA", lon: -75, lat: 14, size: 22 },
      { name: "Yucatán Channel", lon: -85.5, lat: 21.6, size: 11 },
      { name: "Windward Passage", lon: -73.8, lat: 19.9, size: 10 },
      { name: "Gulf of Honduras", lon: -87.4, lat: 16.4, size: 10 },
      { name: "Mona Passage", lon: -68.2, lat: 18.6, size: 10 },
      { name: "Gulf of Venezuela", lon: -71.2, lat: 11.6, size: 10 },
      { name: "ATLANTIC OCEAN", lon: -63, lat: 26, size: 16 },
    ],
    links: [{ side: "n", regionId: "colonies", label: "the Colonies" }, { side: "e", regionId: "europe", label: "Atlantic Europe" }, { side: "s", regionId: "brazil", label: "the Brazils" }],
  },
  {
    id: "colonies",
    fill: "e",
    name: "The Colonies",
    blurb: "Carolina to New England: fish, timber, flour and molasses.",
    bbox: [-84, 28, -64, 46],
    seas: [
      { name: "ATLANTIC OCEAN", lon: -68, lat: 33, size: 20 },
      { name: "Gulf of Maine", lon: -68.5, lat: 43.2, size: 11 },
      { name: "Chesapeake Bay", lon: -75.4, lat: 37.6, size: 10 },
      { name: "Long Island Sound", lon: -72.5, lat: 41.2, size: 9 },
      { name: "Cape Hatteras", lon: -74.6, lat: 35.2, size: 9 },
    ],
    links: [{ side: "s", regionId: "caribbean", label: "the Caribbean" }, { side: "e", regionId: "europe", label: "Atlantic Europe" }],
  },
  {
    id: "europe",
    fill: "w",
    name: "Atlantic Europe",
    blurb: "London, Amsterdam, Nantes, Lisbon, Seville — where colonial cargo turns into fortunes.",
    bbox: [-16, 34, 15, 60],
    seas: [
      { name: "NORTH SEA", lon: 3.5, lat: 55.5, size: 18 },
      { name: "BAY OF BISCAY", lon: -5, lat: 45.2, size: 16 },
      { name: "ENGLISH CHANNEL", lon: -2.5, lat: 49.9, size: 12 },
      { name: "ATLANTIC OCEAN", lon: -11, lat: 41, size: 18 },
      { name: "Irish Sea", lon: -5.2, lat: 53.6, size: 10 },
      { name: "Gulf of Cádiz", lon: -7.6, lat: 36.4, size: 10 },
    ],
    links: [{ side: "w", regionId: "caribbean", label: "the Caribbean" }, { side: "s", regionId: "africa", label: "the African Coast" }, { side: "n", regionId: "colonies", label: "the Colonies" }],
  },
  {
    id: "africa",
    fill: "w",
    name: "African Coast",
    blurb: "The Gold Coast and Angola: gold dust, iron, powder and darker trades.",
    bbox: [-20, -14, 20, 22],
    seas: [
      { name: "GULF OF GUINEA", lon: 2, lat: 1.5, size: 18 },
      { name: "ATLANTIC OCEAN", lon: -14, lat: 8, size: 20 },
      { name: "Bight of Benin", lon: 3.5, lat: 5.2, size: 10 },
      { name: "Bight of Biafra", lon: 7.6, lat: 3.4, size: 10 },
    ],
    links: [{ side: "n", regionId: "europe", label: "Atlantic Europe" }, { side: "w", regionId: "brazil", label: "the Brazils" }],
  },
  {
    id: "brazil",
    fill: "e",
    name: "South America",
    blurb: "The Brazilian sugar coast under the Portuguese crown.",
    bbox: [-62, -26, -30, 8],
    seas: [
      { name: "ATLANTIC OCEAN", lon: -36, lat: -12, size: 22 },
      { name: "Mouths of the Amazon", lon: -47.5, lat: 0.5, size: 11 },
      { name: "Bay of All Saints", lon: -37.4, lat: -13.2, size: 10 },
    ],
    links: [{ side: "n", regionId: "caribbean", label: "the Caribbean" }, { side: "e", regionId: "africa", label: "the African Coast" }],
  },
];

export const REGION_MAP: Record<string, MapRegion> = Object.fromEntries(
  MAP_REGIONS.map((r) => [r.id, r]),
);

export function inRegion(port: Port, r: MapRegion) {
  return port.lon >= r.bbox[0] && port.lon <= r.bbox[2] && port.lat >= r.bbox[1] && port.lat <= r.bbox[3];
}

export function portsOfRegion(regionId: string): Port[] {
  const r = REGION_MAP[regionId];
  if (!r) return [];
  return PORTS.filter((p) => inRegion(p, r) && portVisible(p));
}

export function regionOfPort(portId: string): string {
  const p = PORTS.find((x) => x.id === portId);
  if (!p) return "caribbean";
  return MAP_REGIONS.find((r) => inRegion(p, r))?.id ?? "caribbean";
}
