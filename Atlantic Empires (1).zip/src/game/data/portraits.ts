/**
 * The gallery: forty-eight painted busts in one hand — Dutch Golden Age oils,
 * three-quarter turn, dark ground, one warm light. Each canvas is described
 * by who it depicts, and every soul in the game is matched to the nearest fit.
 */

import englishYoung1 from "@/assets/portraits/english-young-m.jpg";
import englishYoung2 from "@/assets/portraits/english-young-m2.jpg";
import englishPrime1 from "@/assets/portraits/english-prime-m.jpg";
import englishPrime2 from "@/assets/portraits/english-prime-m2.jpg";
import englishElder1 from "@/assets/portraits/english-elder-m.jpg";
import englishElder2 from "@/assets/portraits/english-elder-m2.jpg";
import irishYoung1 from "@/assets/portraits/irish-young-m.jpg";
import irishYoung2 from "@/assets/portraits/irish-young-m2.jpg";
import irishPrime1 from "@/assets/portraits/irish-prime-m.jpg";
import irishPrime2 from "@/assets/portraits/irish-prime-m2.jpg";
import irishElder1 from "@/assets/portraits/irish-elder-m.jpg";
import irishElder2 from "@/assets/portraits/irish-elder-m2.jpg";
import frenchYoung1 from "@/assets/portraits/french-young-m.jpg";
import frenchYoung2 from "@/assets/portraits/french-young-m2.jpg";
import frenchPrime1 from "@/assets/portraits/french-prime-m.jpg";
import frenchPrime2 from "@/assets/portraits/french-prime-m2.jpg";
import frenchElder1 from "@/assets/portraits/french-elder-m.jpg";
import frenchElder2 from "@/assets/portraits/french-elder-m2.jpg";
import spanishYoung1 from "@/assets/portraits/spanish-young-m.jpg";
import spanishYoung2 from "@/assets/portraits/spanish-young-m2.jpg";
import spanishPrime1 from "@/assets/portraits/spanish-prime-m.jpg";
import spanishPrime2 from "@/assets/portraits/spanish-prime-m2.jpg";
import spanishElder1 from "@/assets/portraits/spanish-elder-m.jpg";
import spanishElder2 from "@/assets/portraits/spanish-elder-m2.jpg";
import portugueseYoung1 from "@/assets/portraits/portuguese-young-m.jpg";
import portugueseYoung2 from "@/assets/portraits/portuguese-young-m2.jpg";
import portuguesePrime1 from "@/assets/portraits/portuguese-prime-m.jpg";
import portuguesePrime2 from "@/assets/portraits/portuguese-prime-m2.jpg";
import portugueseElder1 from "@/assets/portraits/portuguese-elder-m.jpg";
import portugueseElder2 from "@/assets/portraits/portuguese-elder-m2.jpg";
import dutchYoung1 from "@/assets/portraits/dutch-young-m.jpg";
import dutchYoung2 from "@/assets/portraits/dutch-young-m2.jpg";
import dutchPrime1 from "@/assets/portraits/dutch-prime-m.jpg";
import dutchPrime2 from "@/assets/portraits/dutch-prime-m2.jpg";
import dutchElder1 from "@/assets/portraits/dutch-elder-m.jpg";
import dutchElder2 from "@/assets/portraits/dutch-elder-m2.jpg";
import creoleYoung1 from "@/assets/portraits/creole-young-m.jpg";
import creoleYoung2 from "@/assets/portraits/creole-young-m2.jpg";
import creolePrime1 from "@/assets/portraits/creole-prime-m.jpg";
import creolePrime2 from "@/assets/portraits/creole-prime-m2.jpg";
import creoleElder1 from "@/assets/portraits/creole-elder-m.jpg";
import creoleElder2 from "@/assets/portraits/creole-elder-m2.jpg";
import africanYoung1 from "@/assets/portraits/african-young-m.jpg";
import africanYoung2 from "@/assets/portraits/african-young-m2.jpg";
import africanPrime1 from "@/assets/portraits/african-prime-m.jpg";
import africanPrime2 from "@/assets/portraits/african-prime-m2.jpg";
import africanElder1 from "@/assets/portraits/african-elder-m.jpg";
import africanElder2 from "@/assets/portraits/african-elder-m2.jpg";

export type AgeBand = "young" | "prime" | "elder";

export interface PaintedPortrait {
  id: string;
  src: string;
  nationality: string;
  band: AgeBand;
  /** what the canvas shows, in a line */
  note: string;
}

export function ageBand(age: number): AgeBand {
  if (age <= 28) return "young";
  if (age <= 44) return "prime";
  return "elder";
}

export const PORTRAITS: PaintedPortrait[] = [
  { id: "english-young-1", src: englishYoung1, nationality: "English", band: "young", note: "A young English hand, weather-tanned, dark curls, rough jerkin." },
  { id: "english-young-2", src: englishYoung2, nationality: "English", band: "young", note: "A sandy-haired English lad in a brown leather jerkin." },
  { id: "english-prime-1", src: englishPrime1, nationality: "English", band: "prime", note: "An English officer in his prime, trimmed beard, navy coat, brass buttons." },
  { id: "english-prime-2", src: englishPrime2, nationality: "English", band: "prime", note: "An English quartermaster, short beard, black doublet and white collar." },
  { id: "english-elder-1", src: englishElder1, nationality: "English", band: "elder", note: "An old English captain, grey mane, worn gold braid." },
  { id: "english-elder-2", src: englishElder2, nationality: "English", band: "elder", note: "An old English surgeon, balding, white hair, plain black coat." },

  { id: "irish-young-1", src: irishYoung1, nationality: "Irish", band: "young", note: "A young Irish sailor, freckled, red hair, red neck-cloth." },
  { id: "irish-young-2", src: irishYoung2, nationality: "Irish", band: "young", note: "A freckled Irish lad with a fresh scar and a green neck cloth." },
  { id: "irish-prime-1", src: irishPrime1, nationality: "Irish", band: "prime", note: "An Irish carpenter, red beard, brown wool coat." },
  { id: "irish-prime-2", src: irishPrime2, nationality: "Irish", band: "prime", note: "An Irish gunner, heavy moustache, powder-stained buff coat." },
  { id: "irish-elder-1", src: irishElder1, nationality: "Irish", band: "elder", note: "An old Irish salt, grizzled beard, blue head-cloth, patched jerkin." },
  { id: "irish-elder-2", src: irishElder2, nationality: "Irish", band: "elder", note: "An old Irish cook, one eye patched, stained apron." },

  { id: "french-young-1", src: frenchYoung1, nationality: "French", band: "young", note: "A young Frenchman, thin moustache, blue sash over linen." },
  { id: "french-young-2", src: frenchYoung2, nationality: "French", band: "young", note: "A young French hand, long hair, blue coat with wooden buttons." },
  { id: "french-prime-1", src: frenchPrime1, nationality: "French", band: "prime", note: "A French surgeon, long dark hair, black coat, falling band collar." },
  { id: "french-prime-2", src: frenchPrime2, nationality: "French", band: "prime", note: "A French buccaneer captain, plumed hat, crimson sash." },
  { id: "french-elder-1", src: frenchElder1, nationality: "French", band: "elder", note: "An old French master, grey hair, moustache, silver buttons." },
  { id: "french-elder-2", src: frenchElder2, nationality: "French", band: "elder", note: "An old French carpenter, grey beard, plain brown smock." },

  { id: "spanish-young-1", src: spanishYoung1, nationality: "Spanish", band: "young", note: "A young Spaniard, olive skin, leather jerkin, red cloak." },
  { id: "spanish-young-2", src: spanishYoung2, nationality: "Spanish", band: "young", note: "A young Spanish soldier in a steel gorget and dark doublet." },
  { id: "spanish-prime-1", src: spanishPrime1, nationality: "Spanish", band: "prime", note: "A Spanish gunner, pointed beard, buff coat, red sash." },
  { id: "spanish-prime-2", src: spanishPrime2, nationality: "Spanish", band: "prime", note: "A Spanish merchant in black velvet with a gold chain." },
  { id: "spanish-elder-1", src: spanishElder1, nationality: "Spanish", band: "elder", note: "An old Spanish captain, grey beard, black doublet and ruff." },
  { id: "spanish-elder-2", src: spanishElder2, nationality: "Spanish", band: "elder", note: "An old Spanish friar-physician in a coarse brown habit." },

  { id: "portuguese-young-1", src: portugueseYoung1, nationality: "Portuguese", band: "young", note: "A young Portuguese sailor, black curls, gold hoop." },
  { id: "portuguese-young-2", src: portugueseYoung2, nationality: "Portuguese", band: "young", note: "A young Portuguese hand, dark stubble, white shirt and brown vest." },
  { id: "portuguese-prime-1", src: portuguesePrime1, nationality: "Portuguese", band: "prime", note: "A Portuguese pilot, dark beard, sunburnt, plain collar." },
  { id: "portuguese-prime-2", src: portuguesePrime2, nationality: "Portuguese", band: "prime", note: "A Portuguese sugar factor in a dark green coat, papers in hand." },
  { id: "portuguese-elder-1", src: portugueseElder1, nationality: "Portuguese", band: "elder", note: "An old Portuguese mariner, white beard, blue coat, black cap." },
  { id: "portuguese-elder-2", src: portugueseElder2, nationality: "Portuguese", band: "elder", note: "An old Portuguese boatswain, red knitted cap, faded blue jacket." },

  { id: "dutch-young-1", src: dutchYoung1, nationality: "Dutch", band: "young", note: "A young Dutch hand, blond, open face, leather waistcoat." },
  { id: "dutch-young-2", src: dutchYoung2, nationality: "Dutch", band: "young", note: "A young Dutch apprentice, black doublet, wide white collar." },
  { id: "dutch-prime-1", src: dutchPrime1, nationality: "Dutch", band: "prime", note: "A Dutch shipmaster, blond beard, flat white collar." },
  { id: "dutch-prime-2", src: dutchPrime2, nationality: "Dutch", band: "prime", note: "A Dutch gunner, red beard, leather jerkin and powder strap." },
  { id: "dutch-elder-1", src: dutchElder1, nationality: "Dutch", band: "elder", note: "An old Dutch merchant, white hair, fur-trimmed coat." },
  { id: "dutch-elder-2", src: dutchElder2, nationality: "Dutch", band: "elder", note: "An old Dutch pilot in spectacles and a black cap." },

  { id: "creole-young-1", src: creoleYoung1, nationality: "Creole", band: "young", note: "A young creole sailor, red head-cloth, loose linen shirt." },
  { id: "creole-young-2", src: creoleYoung2, nationality: "Creole", band: "young", note: "A young creole hand in a blue kerchief and open shirt." },
  { id: "creole-prime-1", src: creolePrime1, nationality: "Creole", band: "prime", note: "A creole seaman of forty, blue coat, brass buttons, steady eye." },
  { id: "creole-prime-2", src: creolePrime2, nationality: "Creole", band: "prime", note: "A creole quartermaster, gold earring, patched dark red coat." },
  { id: "creole-elder-1", src: creoleElder1, nationality: "Creole", band: "elder", note: "An old creole hand, grey beard, patched coat, faded kerchief." },
  { id: "creole-elder-2", src: creoleElder2, nationality: "Creole", band: "elder", note: "An old creole fisherman in a straw hat and faded green shirt." },

  { id: "african-young-1", src: africanYoung1, nationality: "African", band: "young", note: "A young West African sailor, blue neck-cloth, pale linen shirt." },
  { id: "african-young-2", src: africanYoung2, nationality: "African", band: "young", note: "A young West African hand, grey linen shirt tied with red cord." },
  { id: "african-prime-1", src: africanPrime1, nationality: "African", band: "prime", note: "A West African seaman in his prime, short beard, dark blue coat." },
  { id: "african-prime-2", src: africanPrime2, nationality: "African", band: "prime", note: "A West African carpenter in a leather apron, brass earring." },
  { id: "african-elder-1", src: africanElder1, nationality: "African", band: "elder", note: "An old West African man, white beard, patched brown coat." },
  { id: "african-elder-2", src: africanElder2, nationality: "African", band: "elder", note: "An old West African mariner, indigo head cloth, grey beard." },
];

/** Cultures with no canvas of their own borrow the nearest hand. */
const KIN: Record<string, string> = {
  Scottish: "English",
  Welsh: "English",
  Danish: "Dutch",
  Flemish: "Dutch",
  Italian: "Spanish",
  Brazilian: "Portuguese",
  Taino: "Creole",
  Maroon: "African",
};

function hash(s: string) {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) {
    h ^= s.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return h >>> 0;
}

export interface PortraitSubjectLike {
  nationality: string;
  age: number;
  /** anything stable about the person: their id, or a fixed portrait seed */
  seed: string;
}

/**
 * Score every canvas against the sitter and hang the best one.
 * Culture weighs heaviest, then the years. Ties are broken on the sitter's
 * own seed, so a face never changes on its own.
 */
export function pickPortrait(s: PortraitSubjectLike): PaintedPortrait {
  const nat = KIN[s.nationality] ?? s.nationality;
  const band = ageBand(s.age);
  const bandRank: Record<AgeBand, number> = { young: 0, prime: 1, elder: 2 };

  let best = PORTRAITS[0]!;
  let bestScore = -Infinity;
  PORTRAITS.forEach((p, i) => {
    let score = 0;
    if (p.nationality === nat) score += 100;
    score -= Math.abs(bandRank[p.band] - bandRank[band]) * 30;
    // a whisper of noise so equal fits do not always fall the same way
    score += (hash(s.seed + p.id) % 11) / 10;
    if (score > bestScore) {
      bestScore = score;
      best = PORTRAITS[i]!;
    }
  });
  return best;
}
