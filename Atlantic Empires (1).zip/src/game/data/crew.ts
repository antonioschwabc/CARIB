import type { CrewMember, CrewPosition, Port, SkillId, Skills } from "../types";
import { clamp, uid } from "../sim/util";
import { TRAITS, traitMult, traitSkillMult } from "./traits";

export { TRAIT_NOTE, TRAIT_MAP, traitSummary } from "./traits";

export const POSITIONS: CrewPosition[] = [
  "captain",
  "firstMate",
  "scout",
  "carpenter",
  "gunner",
  "quartermaster",
  "cook",
  "surgeon",
];

export const POSITION_LABEL: Record<CrewPosition, string> = {
  captain: "Captain",
  firstMate: "First Mate",
  scout: "Scout",
  carpenter: "Carpenter",
  gunner: "Gunner",
  quartermaster: "Quartermaster",
  cook: "Cook",
  surgeon: "Surgeon",
};

export const POSITION_NOTE: Record<CrewPosition, string> = {
  captain: "Commands the ship. Navigation shortens every passage.",
  firstMate: "Runs the watches and steadies morale when you cannot.",
  scout: "Eyes aloft. Sees other sail before they see you.",
  carpenter: "Keeps the hull sound and refits cheap.",
  gunner: "Lays the guns. The difference between a fight and a slaughter.",
  quartermaster: "Manifests, stowage and a shrewder bargain ashore.",
  cook: "Hot food, stretched provisions, a crew that does not mutiny.",
  surgeon: "Fewer men lost to wounds and fever.",
};

export const SKILL_LABEL: Record<SkillId, string> = {
  navigation: "Navigation",
  charisma: "Charisma",
  scouting: "Scouting",
  craftsmanship: "Craftsmanship",
  gunnery: "Gunnery",
  logistics: "Logistics",
  cooking: "Cooking",
  medicine: "Medicine",
};

export const SKILL_IDS = Object.keys(SKILL_LABEL) as SkillId[];

/** The skill each post is judged on. */
export const POSITION_SKILL: Record<CrewPosition, SkillId> = {
  captain: "navigation",
  firstMate: "charisma",
  scout: "scouting",
  carpenter: "craftsmanship",
  gunner: "gunnery",
  quartermaster: "logistics",
  cook: "cooking",
  surgeon: "medicine",
};

export function emptySkills(): Skills {
  return {
    navigation: 0,
    charisma: 0,
    scouting: 0,
    craftsmanship: 0,
    gunnery: 0,
    logistics: 0,
    cooking: 0,
    medicine: 0,
  };
}

const NAMES: Record<string, { first: string[]; last: string[] }> = {
  English: {
    first: ["Thomas", "William", "Ned", "Jonas", "Silas", "Roger", "Matthew", "Abel", "Hugh", "Bartholomew", "Edward", "Francis", "Ralph", "Gideon", "Josiah", "Nathaniel", "Ambrose", "Simon", "Walter", "Peregrine", "Isaac", "Humphrey", "Clement", "Rowland", "Benedict", "Cuthbert", "Anthony", "Giles", "Reuben", "Martin"],
    last: ["Fletcher", "Cobb", "Wray", "Halliwell", "Stubbs", "Marlow", "Pike", "Ashcroft", "Dunn", "Verney", "Hawkridge", "Selby", "Trelawny", "Bagshaw", "Norrington", "Quill", "Rookwood", "Standish", "Waverley", "Prideaux", "Hollis", "Blackwood", "Cutler", "Ferrers", "Loveridge", "Thackery", "Winslow", "Cade", "Ravenhill", "Sackville"],
  },
  French: {
    first: ["Étienne", "Guillaume", "Renaud", "Pascal", "Théo", "Julien", "Marc", "Olivier", "Gaspard", "Anselme", "Jacques", "Michel", "Auguste", "Bertrand", "Clément", "Édouard", "Fabien", "Hilaire", "Laurent", "Mathurin", "Nicolas", "Raymond", "Sébastien", "Yves", "Amaury", "Baptiste", "Côme", "Dominique", "Florent", "Gervais"],
    last: ["Baudin", "Lechat", "Moreau", "Duquesne", "Belhomme", "Tessier", "Rouvier", "Charest", "Lussier", "Vaillant", "Grandmaison", "Beauchêne", "Dufresne", "Lacroix", "Marchand", "Poirier", "Sansregret", "Thibault", "Villeneuve", "Bonnefoy", "Desmarais", "Fontaine", "Gauthier", "Hébert", "Larivière", "Montclair", "Perrault", "Rochefort", "Sauvage", "Turgeon"],
  },
  Spanish: {
    first: ["Diego", "Rodrigo", "Álvaro", "Bartolomé", "Nicolás", "Cristóbal", "Andrés", "Gaspar", "Íñigo", "Sebastián", "Francisco", "Alonso", "Jerónimo", "Lorenzo", "Matías", "Pedro", "Ramiro", "Tomás", "Vicente", "Julián", "Baltasar", "Melchor", "Esteban", "Hernán", "Joaquín", "Lope", "Marcos", "Rafael", "Santiago", "Ximeno"],
    last: ["Ordóñez", "Salazar", "Peralta", "Quiroga", "Vela", "Montoya", "Arriaga", "Herrera", "Cabral", "Ibarra", "Aguilar", "Bustamante", "Carvajal", "Delgado", "Escobedo", "Fuentes", "Guzmán", "Hurtado", "Lozano", "Mendoza", "Narváez", "Olivares", "Pizarro", "Ramírez", "Sandoval", "Torrealba", "Ulloa", "Valdés", "Zúñiga", "Espinosa"],
  },
  Dutch: {
    first: ["Klaas", "Joost", "Willem", "Pieter", "Barend", "Dirk", "Maarten", "Cornelis", "Hendrick", "Roelof", "Adriaan", "Bastiaan", "Evert", "Floris", "Gerrit", "Huybert", "Jacob", "Lodewijk", "Michiel", "Nicolaes", "Reynier", "Sybrandt", "Teunis", "Wouter", "Abram", "Egbert", "Jelle", "Rutger", "Steven", "Volkert"],
    last: ["van Roon", "Blaeu", "de Wit", "Coenraads", "Verhoef", "Bakhuis", "van Dijk", "Snel", "Kuiper", "ter Meer", "van Leeuwen", "Doorn", "Heemskerck", "de Graaf", "Vermeulen", "van Beek", "Oostveen", "Rietveld", "Sluijter", "van Haaren", "Brouwer", "de Ruyter", "Nagel", "Wildeboer", "van Hoorn", "Zwart", "Prins", "Stuyver", "Meulenbelt", "van der Zee"],
  },
  Portuguese: {
    first: ["Duarte", "Manoel", "Vasco", "Álvaro", "Simão", "Gil", "Fernão", "Bento", "Estêvão", "Rui", "Afonso", "Baltasar", "Cristóvão", "Diogo", "Gaspar", "Henrique", "Inácio", "Jorge", "Lourenço", "Miguel", "Nuno", "Paulo", "Salvador", "Tomé", "Vicente", "Álvares", "Damião", "Eusébio", "Joaquim", "Sebastião"],
    last: ["Coutinho", "Mascarenhas", "Nogueira", "Teixeira", "Faria", "Ribeiro", "Almada", "Pinto", "Sá", "Vilar", "Albuquerque", "Barreto", "Carvalho", "Dantas", "Esteves", "Furtado", "Guedes", "Henriques", "Lobato", "Macedo", "Negreiros", "Osório", "Pacheco", "Quaresma", "Rezende", "Serrão", "Tavares", "Valadares", "Xavier", "Azevedo"],
  },
  Irish: {
    first: ["Cormac", "Donal", "Fergus", "Owen", "Rory", "Padraig", "Brendan", "Cathal", "Niall", "Tadhg", "Aidan", "Colm", "Diarmuid", "Eamon", "Finnian", "Garrett", "Lorcan", "Muiris", "Oisín", "Ruairí", "Seamus", "Turlough", "Ultan", "Conor", "Daithí", "Fiachra", "Malachy", "Piaras", "Ronan", "Sean"],
    last: ["O'Sullivan", "Kinsella", "MacQuaid", "Doherty", "Barry", "Lenihan", "Rafferty", "Cavanagh", "Bourke", "Nolan", "O'Driscoll", "MacCarthy", "Fitzgibbon", "Hennessy", "Gallagher", "O'Meara", "Devlin", "Sheridan", "Mulcahy", "O'Rourke", "Fahy", "Considine", "Tierney", "MacMahon", "Quillan", "Cassidy", "O'Brien", "Hanlon", "Blake", "Lynch"],
  },
  Creole: {
    first: ["Zacharie", "Faustin", "Emile", "Toussaint", "Baptiste", "Célestin", "Marcus", "Josué", "Elie", "Amadou", "Anatole", "Benoît", "Cyprien", "Désiré", "Fabrice", "Gaston", "Hippolyte", "Ismaël", "Léon", "Médard", "Narcisse", "Olivier", "Placide", "Rémy", "Salomon", "Théodule", "Valcourt", "Wilfrid", "Xavier", "Yvon"],
    last: ["Belrose", "Sainte-Croix", "Duval", "Lafleur", "Antoine", "Boisvert", "Cadet", "Moreno", "Delacroix", "Prosper", "Beaumont", "Cassave", "Dorléans", "Étienne", "Fortuné", "Gaspard", "Hilaire", "Joseph-Marie", "Laguerre", "Mondésir", "Népomucène", "Ozias", "Philogène", "Rocher", "Sylvain", "Toussaint", "Valmy", "Zéphirin", "Baptiste", "Charlemagne"],
  },
  African: {
    first: ["Kwame", "Kofi", "Yaw", "Abeni", "Chibueze", "Ekon", "Femi", "Gyasi", "Ibrahima", "Jelani", "Kwabena", "Lamine", "Mansa", "Nuru", "Obi", "Oumar", "Sekou", "Tafari", "Uzoma", "Yusuf", "Adisa", "Bakari", "Chike", "Dembe", "Emeka", "Faraji", "Kojo", "Musa", "Ousmane", "Sadiq"],
    last: ["Adeyemi", "Bakayoko", "Cissé", "Danso", "Ekwueme", "Fofana", "Gueye", "Hassane", "Iwu", "Jallow", "Keita", "Lumumba", "Mensah", "Nwosu", "Owusu", "Pereira-Kanu", "Quartey", "Rahim", "Sankara", "Traoré", "Ubaka", "Wanjiru", "Yeboah", "Zongo", "Asante", "Diallo", "Konaté", "Mbeki", "Nkrumah", "Sesay"],
  },
};


export const NAME_POOLS = NAMES;

/** A historically plausible given name for a man of that culture. */
export function randomFirstName(nationality: string, rand: () => number = Math.random) {
  const n = NAMES[nationality] ?? NAMES["English"]!;
  return n.first[Math.floor(rand() * n.first.length)]!;
}

/** A historically plausible surname for a man of that culture. */
export function randomSurname(nationality: string, rand: () => number = Math.random) {
  const n = NAMES[nationality] ?? NAMES["English"]!;
  return n.last[Math.floor(rand() * n.last.length)]!;
}

export const NATIONALITIES = ["English", "French", "Spanish", "Dutch", "Portuguese", "Irish", "Creole", "African"] as const;

/** What a man of each culture is most likely to swear by. */
export const FAITHS_BY_CULTURE: Record<string, string[]> = {
  English: ["Anglican", "Puritan", "Quaker", "Catholic"],
  French: ["Catholic", "Huguenot", "Jansenist"],
  Spanish: ["Catholic", "Converso", "Catholic"],
  Dutch: ["Calvinist", "Mennonite", "Catholic", "Sephardic Jewish"],
  Portuguese: ["Catholic", "Sephardic Jewish", "Catholic"],
  Irish: ["Catholic", "Catholic", "Anglican"],
  Creole: ["Catholic", "Vodou", "Obeah", "Syncretist"],
  African: ["Orisha", "Muslim", "Ancestral", "Catholic"],
};

export const FAITH_NOTE: Record<string, string> = {
  Anglican: "The king's church, kept lightly at sea.",
  Puritan: "Plain worship, plainer opinions about your rum.",
  Quaker: "Will work the ship but not the guns, gladly.",
  Catholic: "Rome, a rosary and a saint for every hazard.",
  Huguenot: "Reformed and exiled; no love for Spain.",
  Jansenist: "Grim grace. Expects little of this world.",
  Converso: "Christian on paper, careful in every port.",
  Calvinist: "Predestined to be here, and says so often.",
  Mennonite: "Quiet, sober, and no oath-taking.",
  Orisha: "Keeps the old gods of the coast, and their days.",
  Muslim: "Prays at the rail, dawn and dusk, whatever the weather.",
  Ancestral: "Pours the first cup for the dead of his line.",
  "Sephardic Jewish": "Keeps his own days and his own counsel.",
  Vodou: "Serves the lwa; keeps a charm in his shirt.",
  Obeah: "Knows the working of things nobody will name.",
  Syncretist: "Saints and spirits, and no contradiction seen.",
};

export const FAITHS = Object.keys(FAITH_NOTE);

/** A man's working skill, after his traits are reckoned in. */
export function effSkill(m: CrewMember, key: SkillId) {
  return Math.round(m.skills[key] * traitSkillMult(m.traits, key));
}


/** Hidden potential shown as a letter. */
export function grade(potential: number): string {
  if (potential >= 92) return "A+";
  if (potential >= 84) return "A";
  if (potential >= 76) return "A−";
  if (potential >= 68) return "B+";
  if (potential >= 60) return "B";
  if (potential >= 52) return "B−";
  if (potential >= 44) return "C+";
  if (potential >= 37) return "C";
  return "C−";
}

/** The discipline a man is best at, traits reckoned in. */
export function bestSkill(m: CrewMember): SkillId {
  let top: SkillId = "navigation";
  for (const s of SKILL_IDS) if (effSkill(m, s) > effSkill(m, top)) top = s;
  return top;
}

/** His strongest number, for a card. */
export function keySkill(m: CrewMember) {
  return effSkill(m, bestSkill(m));
}

/** Wages are settled weekly, on the seventh day. */
export function wageFor(skill: number, traits: string[] = []) {
  // A plain hand is cheap; a master of his craft is dear, and steeply so.
  return Math.max(8, Math.round(20 * Math.pow(Math.max(10, skill) / 30, 2.4) * traitMult(traits, "wage")));
}


/** Weekly pay for the anonymous hands who are not officers. */
export const HAND_WEEKLY_WAGE = 11;


const NATIONALITY_BY_POWER: Record<string, string> = {
  england: "English",
  france: "French",
  spain: "Spanish",
  dutch: "Dutch",
  portugal: "Portuguese",
  pirate: "Creole",
};



export function makeRecruit(port: Port, rand: () => number, seedDay: number): CrewMember {
  const pool = Object.keys(NAMES);
  const nationality =
    rand() < 0.55 ? (NATIONALITY_BY_POWER[port.power] ?? "English") : pool[Math.floor(rand() * pool.length)]!;
  const n = NAMES[nationality]!;
  const age = 16 + Math.floor(rand() * 45);
  // Big, prosperous ports draw better men.
  const level = port.level ?? 3;
  const quality = 0.4 + port.prosperity * 0.3 + level * 0.06;
  // Talent is rare: the roll is bent hard towards the ordinary.
  const roll = Math.pow(rand(), 2.6 - level * 0.22);
  const potential = clamp(Math.round(30 + roll * 62 * quality + quality * 14), 30, 99);
  // Older men have already spent their growth; the young are raw but rise fast.
  const spent = clamp((age - 16) / 44, 0, 1);
  const main = clamp(Math.round(20 + (potential - 20) * (0.2 + spent * 0.75) * (0.75 + rand() * 0.4)), 20, potential);

  const skills = emptySkills();
  for (const s2 of SKILL_IDS) skills[s2] = clamp(Math.round(20 + rand() * 34), 20, 99);
  // Every man has one discipline he is plainly better at.
  skills[SKILL_IDS[Math.floor(rand() * SKILL_IDS.length)]!] = main;

  // Every man carries something. One or two traits, never more.
  const traits: string[] = [];
  traits.push(TRAITS[Math.floor(rand() * TRAITS.length)]!.name);
  if (rand() < 0.45) {
    const t = TRAITS[Math.floor(rand() * TRAITS.length)]!.name;
    if (!traits.includes(t)) traits.push(t);
  }

  const faithPool = FAITHS_BY_CULTURE[nationality] ?? ["Catholic"];
  const faith = faithPool[Math.floor(rand() * faithPool.length)]!;

  return {
    id: uid("crw", seedDay),
    name: `${randomFirstName(nationality, rand)} ${n.last[Math.floor(rand() * n.last.length)]}`,
    nationality,
    faith,
    age,
    skills,
    potential,
    wage: wageFor(main, traits),
    xp: emptySkills(),
    morale: 60 + Math.round(rand() * 25),
    health: 78 + Math.round(rand() * 22),
    appetite: appetiteFor(age, traits, rand),
    traits,
  };
}

/** How much a man eats and drinks in a day at sea, 2-20 units. */
export function appetiteFor(age: number, traits: string[], rand: () => number) {
  let a = 4 + rand() * 9;
  if (age < 22) a += 2.5;
  if (age > 50) a -= 1.5;
  return clamp(Math.round(a * traitMult(traits, "appetite")), 2, 20);
}

/** Signing fee to bring a man aboard: two weeks' pay and something for promise. */
export function signingFee(m: CrewMember) {
  const best = keySkill(m);
  return Math.round((m.wage * 4 + Math.pow(best, 2.2) / 7 + Math.pow(m.potential, 1.9) / 12) * traitMult(m.traits, "fee"));
}

/** The quay only ever holds a handful of men worth signing. */
export function rosterSize(port: Port) {
  return clamp(3 + Math.round((port.level ?? 3) / 2), 4, 6);
}
