import type { SkillId } from "../types";

/**
 * Every modifier is a marginal fraction: 0.05 or 0.15, positive or negative.
 * A trait carries one or two of them, never more.
 */
export interface TraitEffects {
  /** experience banked per day and from prizes */
  xp?: number;
  /** natural healing rate */
  healthRegen?: number;
  /** daily temper drift */
  morale?: number;
  /** how fast his spirits recover in harbour and from prize money */
  moraleGain?: number;
  /** stores eaten per day */
  appetite?: number;
  /** what he asks to be paid */
  wage?: number;
  /** signing fee demanded */
  fee?: number;
  /** percentage change to named skills */
  skills?: Partial<Record<SkillId, number>>;
}

export interface Trait {
  name: string;
  note: string;
  tone: "good" | "bad" | "mixed";
  effects: TraitEffects;
}

export const TRAITS: Trait[] = [
  // ── temperament ──────────────────────────────────────────────
  { name: "Steady", note: "Never panics. His temper holds when others break.", tone: "good", effects: { morale: 0.15 } },
  { name: "Hot-headed", note: "Fierce at the guns, trouble in port.", tone: "mixed", effects: { skills: { gunnery: 0.15 }, morale: -0.05 } },
  { name: "Sullen", note: "Does the work and hates every hour of it.", tone: "bad", effects: { morale: -0.15 } },
  { name: "Cheerful", note: "Sings on the capstan and the others sing with him.", tone: "good", effects: { moraleGain: 0.15, morale: 0.05 } },
  { name: "Homesick", note: "Counts the leagues back to a place he will not name.", tone: "bad", effects: { morale: -0.05, moraleGain: -0.15 } },
  { name: "Fatalist", note: "Whatever the sea wants, it will have. Nothing shakes him.", tone: "mixed", effects: { morale: 0.05, xp: -0.05 } },
  { name: "Ambitious", note: "Means to have a ship of his own one day.", tone: "mixed", effects: { xp: 0.15, wage: 0.15 } },
  { name: "Loyal", note: "Signed with you, stays with you.", tone: "good", effects: { moraleGain: 0.15 } },
  { name: "Mutinous", note: "Talks in corners. Cheap, and a risk.", tone: "bad", effects: { morale: -0.15, wage: -0.15 } },

  // ── body ─────────────────────────────────────────────────────
  { name: "Iron stomach", note: "Eats anything, sails through anything.", tone: "mixed", effects: { healthRegen: 0.15, appetite: 0.15 } },
  { name: "Wiry", note: "Half a man's weight and twice his endurance.", tone: "good", effects: { appetite: -0.15, healthRegen: 0.05 } },
  { name: "Strong back", note: "Shifts cargo two men could not.", tone: "good", effects: { skills: { logistics: 0.15 }, appetite: 0.05 } },
  { name: "Consumptive", note: "A cough that never clears.", tone: "bad", effects: { healthRegen: -0.15, morale: -0.05 } },
  { name: "Fast healer", note: "Wounds close on him like a dog's.", tone: "good", effects: { healthRegen: 0.15 } },
  { name: "Sickly", note: "First to catch whatever comes aboard.", tone: "bad", effects: { healthRegen: -0.15 } },
  { name: "Scarred", note: "Frightens boarders, unsettles governors.", tone: "mixed", effects: { skills: { gunnery: 0.05, charisma: -0.15 } } },
  { name: "One-eyed", note: "Sees less, flinches at nothing.", tone: "mixed", effects: { skills: { scouting: -0.15 }, morale: 0.05 } },
  { name: "Hard hands", note: "Rope and tar have made him useful.", tone: "good", effects: { skills: { craftsmanship: 0.05 }, healthRegen: 0.05 } },
  { name: "Glutton", note: "Eats his share and looks at yours.", tone: "bad", effects: { appetite: 0.15, morale: 0.05 } },

  // ── vice and virtue ──────────────────────────────────────────
  { name: "Drunkard", note: "Cheap to hire, dear to keep.", tone: "mixed", effects: { wage: -0.15, appetite: 0.15 } },
  { name: "Temperate", note: "Takes water where others take rum.", tone: "good", effects: { appetite: -0.05, healthRegen: 0.05 } },
  { name: "Gambler", note: "Wins the crew's pay and loses their goodwill.", tone: "bad", effects: { morale: -0.05, fee: -0.15 } },
  { name: "Thief", note: "Something always goes missing. Signs for little.", tone: "bad", effects: { fee: -0.15, morale: -0.05 } },
  { name: "Devout", note: "Keeps the watch honest and the Sabbath badly.", tone: "good", effects: { morale: 0.05, appetite: -0.05 } },
  { name: "Superstitious", note: "Will not sail on a Friday without grumbling.", tone: "bad", effects: { morale: -0.05, skills: { navigation: -0.05 } } },
  { name: "Pious scholar", note: "Reads scripture and everything else he can find.", tone: "good", effects: { xp: 0.15, skills: { medicine: 0.05 } } },

  // ── trade and craft ──────────────────────────────────────────
  { name: "Literate", note: "Keeps accounts nobody can quietly cook.", tone: "good", effects: { skills: { logistics: 0.15 }, xp: 0.05 } },
  { name: "Ex-buccaneer", note: "Knows the black trade and its harbours.", tone: "mixed", effects: { skills: { gunnery: 0.15 }, wage: 0.05 } },
  { name: "Navy-trained", note: "Learned his trade under a king's pennant.", tone: "good", effects: { skills: { gunnery: 0.05, navigation: 0.05 } } },
  { name: "Shipwright's son", note: "Grew up in a yard with an adze in his hand.", tone: "good", effects: { skills: { craftsmanship: 0.15 } } },
  { name: "Chandler's clerk", note: "Knows what everything costs and what it is worth.", tone: "good", effects: { skills: { logistics: 0.05, charisma: 0.05 } } },
  { name: "Sharp eyes", note: "Sees the topsail before it is a topsail.", tone: "good", effects: { skills: { scouting: 0.15 } } },
  { name: "Night owl", note: "Keeps the middle watch without complaint.", tone: "good", effects: { skills: { scouting: 0.05, navigation: 0.05 } } },
  { name: "Silver tongue", note: "Talks a governor out of a fine.", tone: "good", effects: { skills: { charisma: 0.15 } } },
  { name: "Mumbler", note: "Gives orders nobody can make out.", tone: "bad", effects: { skills: { charisma: -0.15 } } },
  { name: "Field surgeon", note: "Has taken off more limbs than he can count.", tone: "good", effects: { skills: { medicine: 0.15 } } },
  { name: "Herbalist", note: "Knows what grows ashore and what it cures.", tone: "good", effects: { skills: { medicine: 0.05, cooking: 0.05 } } },
  { name: "Galley-bred", note: "Can make salt beef taste of something.", tone: "good", effects: { skills: { cooking: 0.15 } } },
  { name: "Burns the pot", note: "Every meal is a small punishment.", tone: "bad", effects: { skills: { cooking: -0.15 } } },
  { name: "Pilot's memory", note: "Carries the soundings of a coast in his head.", tone: "good", effects: { skills: { navigation: 0.15 } } },
  { name: "Landsman", note: "Signed on last month and it shows.", tone: "bad", effects: { skills: { navigation: -0.15 }, wage: -0.05 } },
  { name: "Slow learner", note: "Gets there. Eventually.", tone: "bad", effects: { xp: -0.15 } },
  { name: "Quick study", note: "Watches once and can do it.", tone: "good", effects: { xp: 0.15 } },
  { name: "Old salt", note: "Forty years at sea and no surprises left.", tone: "mixed", effects: { xp: -0.05, skills: { navigation: 0.15 } } },
  { name: "Lucky", note: "Somehow always on the surviving boat.", tone: "good", effects: { moraleGain: 0.15 } },
  { name: "Cursed", note: "The others watch him when the glass falls.", tone: "bad", effects: { healthRegen: -0.15, morale: -0.05 } },
  { name: "Deserter", note: "Ran from a king's ship. Signs for anything.", tone: "mixed", effects: { fee: -0.15, morale: -0.05 } },
  { name: "Well-connected", note: "Has cousins in three ports and debts in four.", tone: "mixed", effects: { skills: { charisma: 0.05 }, wage: 0.15 } },
  { name: "Frugal", note: "Asks little and spends less.", tone: "good", effects: { wage: -0.15 } },
  { name: "Proud", note: "Will not sign for a common man's money.", tone: "bad", effects: { wage: 0.15, morale: 0.05 } },
];

export const TRAIT_MAP: Record<string, Trait> = Object.fromEntries(TRAITS.map((t) => [t.name, t]));

export const TRAIT_NOTE: Record<string, string> = Object.fromEntries(TRAITS.map((t) => [t.name, t.note]));

/** Sum one modifier across a man's traits. Returns a multiplier around 1. */
export function traitMult(traits: string[] | undefined, key: Exclude<keyof TraitEffects, "skills">) {
  let m = 1;
  for (const t of traits ?? []) m += TRAIT_MAP[t]?.effects[key] ?? 0;
  return Math.max(0.2, m);
}

/** Percentage change to a single skill from traits. */
export function traitSkillMult(traits: string[] | undefined, skill: SkillId) {
  let m = 1;
  for (const t of traits ?? []) m += TRAIT_MAP[t]?.effects.skills?.[skill] ?? 0;
  return Math.max(0.2, m);
}

/** Short readable summary of what a trait does, for tooltips. */
export function traitSummary(name: string): string[] {
  const t = TRAIT_MAP[name];
  if (!t) return [];
  const out: string[] = [];
  const pct = (v: number) => `${v > 0 ? "+" : "−"}${Math.round(Math.abs(v) * 100)}%`;
  const e = t.effects;
  const label: Record<string, string> = {
    xp: "XP a day",
    healthRegen: "healing",
    morale: "daily morale",
    moraleGain: "morale recovery",
    appetite: "stores eaten",
    wage: "wages",
    fee: "signing fee",
  };
  for (const [k, v] of Object.entries(e)) {
    if (k === "skills") continue;
    out.push(`${pct(v as number)} ${label[k] ?? k}`);
  }
  const skillLabel: Record<string, string> = {
    navigation: "Navigation", charisma: "Charisma", scouting: "Scouting", craftsmanship: "Craftsmanship",
    gunnery: "Gunnery", logistics: "Logistics", cooking: "Cooking", medicine: "Medicine",
  };
  for (const [k, v] of Object.entries(e.skills ?? {})) out.push(`${pct(v)} ${skillLabel[k] ?? k}`);
  return out;
}
