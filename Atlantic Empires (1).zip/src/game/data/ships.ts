import type { ShipClass } from "../types";

/**
 * Five archetypes. Every ship is described by seven stats; components and crew
 * modify them from these bases.
 */
export const SHIP_CLASSES: ShipClass[] = [
  {
    id: "sloop",
    name: "Sloop",
    price: 72000,
    hull: 200,
    firepower: 20,
    maneuverability: 95,
    scouting: 85,
    cargo: 20,
    speed: 9,
    crewCapacity: 2,
    componentSlots: 4,
    hands: 4,
    guns: 4,
    gunPorts: 6,
    gunPower: 5,
    upkeep: 26,
    note: "One mast, shallow draft and a turn of speed. Cheap to keep, hopeless in a broadside.",
  },
  {
    id: "brigantine",
    name: "Brigantine",
    price: 168000,
    hull: 350,
    firepower: 40,
    maneuverability: 82,
    scouting: 75,
    cargo: 60,
    speed: 10.5,
    crewCapacity: 4,
    componentSlots: 6,
    hands: 8,
    guns: 8,
    gunPorts: 12,
    gunPower: 5,
    upkeep: 58,
    note: "The buccaneer's favourite: guns enough to argue and hold enough to profit.",
  },
  {
    id: "brig",
    name: "Brig",
    price: 260000,
    hull: 450,
    firepower: 60,
    maneuverability: 70,
    scouting: 65,
    cargo: 100,
    speed: 12,
    crewCapacity: 5,
    componentSlots: 8,
    hands: 10,
    guns: 12,
    gunPorts: 15,
    gunPower: 5,
    upkeep: 86,
    note: "Square-rigged on both masts. A stubborn, useful trader that can defend herself.",
  },
  {
    id: "galleon",
    name: "Galleon",
    price: 740000,
    hull: 700,
    firepower: 100,
    maneuverability: 38,
    scouting: 45,
    cargo: 200,
    speed: 14,
    crewCapacity: 7,
    componentSlots: 12,
    hands: 14,
    guns: 20,
    gunPorts: 25,
    gunPower: 5,
    upkeep: 240,
    note: "Towering, treasure-carrying, and a poor sailer on a foul wind.",
  },
  {
    id: "frigate",
    name: "Frigate",
    price: 560000,
    hull: 650,
    firepower: 120,
    maneuverability: 76,
    scouting: 92,
    cargo: 120,
    speed: 13.5,
    crewCapacity: 7,
    componentSlots: 10,
    hands: 14,
    guns: 15,
    gunPorts: 20,
    gunPower: 6,
    upkeep: 190,
    note: "A ship that takes other ships. Fast, far-seeing, and heavy in the battery.",
  },
];

export const SHIP_CLASS_MAP: Record<string, ShipClass> = Object.fromEntries(
  SHIP_CLASSES.map((s) => [s.id, s]),
);

export interface BusinessType {
  id: string;
  name: string;
  price: number;
  /** gold per day per level, before prosperity */
  yield: number;
  upkeep: number;
  note: string;
}

export const BUSINESS_TYPES: BusinessType[] = [
  {
    id: "warehouse",
    name: "Warehouse",
    price: 14000,
    yield: 42,
    upkeep: 8,
    note: "Storage let out to other merchants; dull, steady coin.",
  },
  {
    id: "tavern",
    name: "Tavern",
    price: 9000,
    yield: 34,
    upkeep: 7,
    note: "Where crews are found and rumours are cheapest.",
  },
  {
    id: "distillery",
    name: "Rum Distillery",
    price: 32000,
    yield: 96,
    upkeep: 22,
    note: "Turns molasses into kill-devil and kill-devil into money.",
  },
  {
    id: "plantation",
    name: "Sugar Plantation",
    price: 68000,
    yield: 205,
    upkeep: 54,
    note: "The great fortune-maker of the age, and its great cruelty.",
  },
  {
    id: "shipyard",
    name: "Careening Yard",
    price: 48000,
    yield: 130,
    upkeep: 34,
    note: "Repairs for your fleet and everyone else's.",
  },
  {
    id: "counting",
    name: "Counting House",
    price: 55000,
    yield: 148,
    upkeep: 30,
    note: "Bills of exchange, insurance, and other people's debts.",
  },
];

export const BUSINESS_MAP: Record<string, BusinessType> = Object.fromEntries(
  BUSINESS_TYPES.map((b) => [b.id, b]),
);
