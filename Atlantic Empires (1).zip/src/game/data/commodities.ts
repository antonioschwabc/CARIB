import type { Commodity, CommodityCategory } from "../types";

export const CATEGORY_LABEL: Record<CommodityCategory, string> = {
  agricultural: "Agricultural",
  alcohol: "Spirits & Wine",
  food: "Provisions",
  raw: "Raw Materials",
  metals: "Metals & Specie",
  manufactured: "Manufactures",
  luxury: "Luxuries",
  naval: "Naval Stores",
  contraband: "Contraband",
};

export const COMMODITIES: Commodity[] = [
  { id: "sugar", name: "Muscovado Sugar", category: "agricultural", base: 17, unit: "hogshead", unitPlural: "hogsheads", tons: 0.5, perish: 0.001, volatility: 1.1, note: "The engine of the islands. Heavy, bulky, endlessly wanted in Europe." },
  { id: "molasses", name: "Molasses", category: "agricultural", base: 9, unit: "hogshead", unitPlural: "hogsheads", tons: 0.5, perish: 0.002, volatility: 1.0, note: "Sugar's by-product; the distiller's raw stock." },
  { id: "tobacco", name: "Tobacco", category: "agricultural", base: 24, unit: "hogshead", unitPlural: "hogsheads", tons: 0.45, perish: 0.001, volatility: 1.2, note: "Virginian and Cuban leaf, cured and pressed into hogsheads." },
  { id: "cotton", name: "Raw Cotton", category: "agricultural", base: 6, unit: "bale", unitPlural: "bales", tons: 0.15, perish: 0.001, volatility: 1.0, note: "Light but bulky; bound for Lancashire and Haarlem." },
  { id: "indigo", name: "Indigo", category: "agricultural", base: 24, unit: "chest", unitPlural: "chests", tons: 0.08, perish: 0, volatility: 1.4, note: "Blue dyestuff worth many times its weight in grain." },
  { id: "cacao", name: "Cacao", category: "agricultural", base: 12, unit: "sack", unitPlural: "sacks", tons: 0.1, perish: 0.002, volatility: 1.3, note: "Caracas beans; the Spanish court cannot get enough." },
  { id: "coffee", name: "Coffee", category: "agricultural", base: 17, unit: "sack", unitPlural: "sacks", tons: 0.1, perish: 0.001, volatility: 1.3, note: "A new fashion in the coffee-houses of London and Amsterdam." },
  { id: "ginger", name: "Ginger", category: "agricultural", base: 8, unit: "sack", unitPlural: "sacks", tons: 0.1, perish: 0.002, volatility: 1.1, note: "Jamaican root, dried and sacked." },
  { id: "dyewood", name: "Logwood", category: "raw", base: 31, unit: "load", unitPlural: "loads", tons: 0.8, perish: 0, volatility: 1.5, note: "Campeche dyewood, cut by log-cutters the Spanish call thieves." },
  { id: "hides", name: "Hides", category: "raw", base: 5, unit: "bundle", unitPlural: "bundles", tons: 0.25, perish: 0.002, volatility: 0.9, note: "Cattle hides off the Main and Hispaniola's wild herds." },
  { id: "tortoiseshell", name: "Tortoiseshell", category: "luxury", base: 48, unit: "chest", unitPlural: "chests", tons: 0.05, perish: 0, volatility: 1.6, note: "Worked into combs and cabinets for European vanity." },
  { id: "pearls", name: "Pearls", category: "luxury", base: 84, unit: "casket", unitPlural: "caskets", tons: 0.01, perish: 0, volatility: 1.8, note: "Margarita's beds, thinned but not exhausted." },
  { id: "silver", name: "Silver Specie", category: "metals", base: 168, unit: "chest", unitPlural: "chests", tons: 0.03, perish: 0, volatility: 0.7, illegalFor: ["england", "france", "dutch"], note: "Pieces of eight from Potosí. Exporting it is nobody's legal business." },
  { id: "gold", name: "Gold Dust", category: "metals", base: 196, unit: "casket", unitPlural: "caskets", tons: 0.01, perish: 0, volatility: 0.9, note: "Traded on the Gold Coast by the ounce." },
  { id: "copper", name: "Copper", category: "metals", base: 8, unit: "ingot", unitPlural: "ingots", tons: 0.1, perish: 0, volatility: 0.8, note: "Sheathing, kettles, and stills." },
  { id: "iron", name: "Iron Bar", category: "metals", base: 4, unit: "bar", unitPlural: "bars", tons: 0.1, perish: 0, volatility: 0.7, note: "Swedish and Biscay bar iron for every smith in the Indies." },
  { id: "rum", name: "Rum", category: "alcohol", base: 30, unit: "pipe", unitPlural: "pipes", tons: 0.45, perish: 0, volatility: 1.2, note: "Kill-devil. Wages, medicine, and currency all at once." },
  { id: "wine", name: "Wine", category: "alcohol", base: 32, unit: "pipe", unitPlural: "pipes", tons: 0.45, perish: 0.001, volatility: 1.0, note: "Canary, Madeira and Bordeaux, casked for the tropics." },
  { id: "brandy", name: "Brandy", category: "alcohol", base: 55, unit: "pipe", unitPlural: "pipes", tons: 0.45, perish: 0, volatility: 1.1, note: "French spirit, dear and always short in the islands." },
  { id: "water", name: "Fresh Water", category: "food", base: 2, unit: "cask", unitPlural: "casks", tons: 0.2, perish: 0.004, volatility: 0.6, note: "Casked at the watering place. Nothing at sea matters more." },
  { id: "salt", name: "Salt", category: "food", base: 2, unit: "barrel", unitPlural: "barrels", tons: 0.15, perish: 0, volatility: 0.8, note: "Raked at Tortuga and Bonaire; without it, no salt beef." },
  { id: "saltfish", name: "Salt Cod", category: "food", base: 3, unit: "barrel", unitPlural: "barrels", tons: 0.12, perish: 0.003, volatility: 0.9, note: "New England's staple, fed to plantation gangs." },
  { id: "flour", name: "Flour", category: "food", base: 3, unit: "barrel", unitPlural: "barrels", tons: 0.12, perish: 0.004, volatility: 1.0, note: "The islands grow sugar, not bread." },
  { id: "saltbeef", name: "Salt Beef", category: "food", base: 4, unit: "barrel", unitPlural: "barrels", tons: 0.14, perish: 0.003, volatility: 0.9, note: "Barrelled provision, the sailor's daily portion." },
  { id: "cloth", name: "Woollen Cloth", category: "manufactured", base: 17, unit: "bale", unitPlural: "bales", tons: 0.15, perish: 0, volatility: 0.9, note: "English broadcloth; a poor fit for the tropics, sold anyway." },
  { id: "linen", name: "Linen", category: "manufactured", base: 16, unit: "bale", unitPlural: "bales", tons: 0.12, perish: 0, volatility: 0.9, note: "Dutch and Breton linen, the colonies' true clothing." },
  { id: "tools", name: "Tools & Ironmongery", category: "manufactured", base: 9, unit: "crate", unitPlural: "crates", tons: 0.12, perish: 0, volatility: 0.8, note: "Bills, hoes, nails: a plantation eats them." },
  { id: "muskets", name: "Muskets", category: "contraband", base: 35, unit: "chest", unitPlural: "chests", tons: 0.1, perish: 0, volatility: 1.4, illegalFor: ["spain"], note: "Trade arms. Governors ashore ask no questions until they do." },
  { id: "powder", name: "Gunpowder", category: "contraband", base: 13, unit: "half-barrel", unitPlural: "half-barrels", tons: 0.05, perish: 0.001, volatility: 1.5, illegalFor: ["spain"], note: "Corned powder in half-barrels. Keep it dry and far from the galley." },
  { id: "canvas", name: "Sailcloth", category: "naval", base: 10, unit: "bolt", unitPlural: "bolts", tons: 0.1, perish: 0, volatility: 0.8, note: "Bolts of duck; a refit devours them." },
  { id: "cordage", name: "Cordage", category: "naval", base: 8, unit: "coil", unitPlural: "coils", tons: 0.12, perish: 0, volatility: 0.8, note: "Riga hemp, laid into cable." },
  { id: "timber", name: "Ship Timber", category: "naval", base: 10, unit: "load", unitPlural: "loads", tons: 0.6, perish: 0, volatility: 0.7, note: "Plank and knee-timber for the careening yards." },
  { id: "pitch", name: "Pitch & Tar", category: "naval", base: 5, unit: "barrel", unitPlural: "barrels", tons: 0.15, perish: 0, volatility: 0.8, note: "Against worm and weather." },
  { id: "spices", name: "Spices", category: "luxury", base: 80, unit: "chest", unitPlural: "chests", tons: 0.05, perish: 0, volatility: 1.5, note: "Pepper, clove and nutmeg by way of the Dutch East trade." },
  { id: "silk", name: "Silk", category: "luxury", base: 95, unit: "bale", unitPlural: "bales", tons: 0.05, perish: 0, volatility: 1.4, note: "Chinese silk landed at Acapulco, smuggled east." },
];

/** "12 barrels" / "1 cask" — a good counted in its own measure. */
export function unitLabel(cid: string, qty: number) {
  const c = COMMODITY_MAP[cid];
  if (!c) return `${qty}`;
  return `${qty} ${Math.abs(qty) === 1 ? c.unit : c.unitPlural}`;
}


export const COMMODITY_MAP: Record<string, Commodity> = Object.fromEntries(
  COMMODITIES.map((c) => [c.id, c]),
);
