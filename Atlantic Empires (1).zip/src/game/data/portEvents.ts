import type { GameState, PortEvent } from "../types";
import { PORTS, PORT_MAP } from "./ports";
import { clamp } from "../sim/util";

export interface PortEventDef {
  id: string;
  title: string;
  text: string;
  tone: "good" | "bad" | "neutral";
  days: [number, number];
  /** applied once when the event begins */
  onStart?: (state: GameState, portId: string) => void;
  /** modifiers while active */
  prosperity?: number;
  security?: number;
  pirateRisk?: number;
  /** goods made dear (+) or cheap (−) while the event runs */
  shocks?: Record<string, number>;
}

export const PORT_EVENT_DEFS: PortEventDef[] = [
  {
    id: "fair",
    title: "Annual fair",
    text: "Country traders crowd the quay. Manufactures move quickly and coin is loose.",
    tone: "good",
    days: [5, 10],
    prosperity: 0.04,
    shocks: { cloth: 0.18, linen: 0.16, tools: 0.14 },
  },
  {
    id: "flota",
    title: "Treasure flota expected",
    text: "The plate fleet is looked for within the month. Provisions and naval stores are bought up.",
    tone: "neutral",
    days: [8, 16],
    shocks: { saltbeef: 0.24, flour: 0.2, canvas: 0.18, cordage: 0.16, powder: 0.12 },
  },
  {
    id: "blockade",
    title: "Blockade offshore",
    text: "Hostile cruisers stand off the harbour mouth. Little comes in, and less goes out.",
    tone: "bad",
    days: [6, 14],
    prosperity: -0.05,
    pirateRisk: 0.08,
    shocks: { flour: 0.3, wine: 0.25, cloth: 0.22, sugar: -0.15 },
  },
  {
    id: "fever",
    title: "Fever in the town",
    text: "A sickness walks the waterfront. Hands are hard to find and warehouses stand idle.",
    tone: "bad",
    days: [7, 18],
    prosperity: -0.06,
    shocks: { rum: 0.2, brandy: 0.22, saltfish: 0.12 },
  },
  {
    id: "harvest",
    title: "Harvest landed",
    text: "The crop is in and the warehouses are full. Whatever this coast grows is going cheap.",
    tone: "good",
    days: [6, 12],
    onStart: (state, portId) => {
      const m = state.markets[portId];
      const port = PORT_MAP[portId];
      if (!m || !port) return;
      for (const cid of Object.keys(port.produces)) {
        m.stock[cid] = (m.stock[cid] ?? 0) * 1.5;
        m.shock[cid] = (m.shock[cid] ?? 0) - 0.2;
      }
    },
  },
  {
    id: "shortage",
    title: "Provision shortage",
    text: "Bread and beef are short in the town and the governor has fixed no price.",
    tone: "bad",
    days: [5, 12],
    shocks: { flour: 0.35, saltbeef: 0.3, saltfish: 0.25, salt: 0.15 },
  },
  {
    id: "pirates",
    title: "Pirates in these waters",
    text: "Two prizes were taken within sight of the headland this week.",
    tone: "bad",
    days: [7, 16],
    pirateRisk: 0.12,
    security: -0.05,
    shocks: { muskets: 0.2, powder: 0.22 },
  },
  {
    id: "governor",
    title: "New governor sworn",
    text: "A new man holds the seal. Customs are keen, but the town has hopes of him.",
    tone: "neutral",
    days: [8, 20],
    prosperity: 0.02,
    security: 0.06,
  },
  {
    id: "refit",
    title: "Squadron refitting",
    text: "A crown squadron careens here. Timber, canvas and cordage vanish from the yards.",
    tone: "neutral",
    days: [6, 14],
    shocks: { timber: 0.28, canvas: 0.26, cordage: 0.24, pitch: 0.2 },
  },
  {
    id: "freeport",
    title: "Duties suspended",
    text: "The governor has waived his duties for a season to draw shipping.",
    tone: "good",
    days: [7, 15],
    prosperity: 0.05,
    shocks: { sugar: -0.12, tobacco: -0.12, rum: -0.1 },
  },
];

export const PORT_EVENT_MAP: Record<string, PortEventDef> = Object.fromEntries(
  PORT_EVENT_DEFS.map((e) => [e.id, e]),
);

/** Weekly: expire finished events and roll fresh ones for a slice of the world. */
export function rollPortEvents(state: GameState, rand: () => number) {
  state.portEvents ??= {};

  for (const [portId, ev] of Object.entries(state.portEvents)) {
    if (state.day >= ev.endsDay) delete state.portEvents[portId];
  }

  for (const port of PORTS) {
    if (state.portEvents[port.id]) continue;
    if (rand() > 0.22) continue;
    const def = PORT_EVENT_DEFS[Math.floor(rand() * PORT_EVENT_DEFS.length)]!;
    const span = def.days[0] + Math.floor(rand() * (def.days[1] - def.days[0] + 1));
    const ev: PortEvent = {
      defId: def.id,
      title: def.title,
      text: def.text,
      tone: def.tone,
      startedDay: state.day,
      endsDay: state.day + span,
    };
    state.portEvents[port.id] = ev;
    def.onStart?.(state, port.id);
  }
}

/** Applied each day: active events push prices, prosperity and risk around. */
export function applyPortEvents(state: GameState) {
  if (!state.portEvents) return;
  for (const [portId, ev] of Object.entries(state.portEvents)) {
    const def = PORT_EVENT_MAP[ev.defId];
    const port = PORT_MAP[portId];
    const m = state.markets[portId];
    if (!def || !port || !m) continue;
    if (def.prosperity) port.prosperity = clamp(port.prosperity + def.prosperity * 0.08, 0.12, 1);
    if (def.security) port.security = clamp(port.security + def.security * 0.08, 0.05, 1);
    if (def.pirateRisk) port.pirateRisk = clamp(port.pirateRisk + def.pirateRisk * 0.05, 0.02, 0.7);
    for (const [cid, v] of Object.entries(def.shocks ?? {})) {
      m.shock[cid] = (m.shock[cid] ?? 0) + v * 0.1;
    }
  }
}
