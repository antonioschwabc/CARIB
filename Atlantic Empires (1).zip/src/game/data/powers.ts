import type { Power, PowerId } from "../types";

export const POWERS: Power[] = [
  { id: "spain", name: "Crown of Spain", adjective: "Spanish", color: "#e0b420", currency: "pieces of eight", note: "Master of the Main, jealous of its trade and slow to change." },
  { id: "england", name: "Kingdom of England", adjective: "English", color: "#c0332c", currency: "pounds sterling", note: "Sugar, buccaneers, and the Navigation Acts." },
  { id: "france", name: "Kingdom of France", adjective: "French", color: "#4a6fa5", currency: "livres", note: "Colbert's companies, Saint-Domingue's boucaniers." },
  { id: "dutch", name: "Dutch Republic", adjective: "Dutch", color: "#d98b2b", currency: "guilders", note: "Carriers to everyone, welcome in no one's law books." },
  { id: "portugal", name: "Kingdom of Portugal", adjective: "Portuguese", color: "#3f7a55", currency: "réis", note: "Brazil sugar and the Guinea trade." },
  { id: "pirate", name: "Brethren of the Coast", adjective: "Pirate", color: "#2c2c2c", currency: "plunder", note: "No sovereign, no port dues, no mercy owed." },
];

export const POWER_MAP: Record<PowerId, Power> = Object.fromEntries(
  POWERS.map((p) => [p.id, p]),
) as Record<PowerId, Power>;
