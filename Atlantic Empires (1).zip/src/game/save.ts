import type { GameState } from "./types";
import { SCHEMA_VERSION } from "./state";
import { emptySkills } from "./data/crew";
import { SHIP_CLASS_MAP } from "./data/ships";

const INDEX_KEY = "carib.saves";
export const AUTOSAVE = "autosave";
export const DAILY_SAVE = "daily";
export const MANUAL_SLOTS = ["log-1", "log-2", "log-3"];

export interface SaveMeta {
  slot: string;
  label: string;
  day: number;
  cash: number;
  savedAt: number;
}

const isBrowser = () => typeof window !== "undefined" && !!window.localStorage;

export function listSaves(): SaveMeta[] {
  if (!isBrowser()) return [];
  try {
    return JSON.parse(localStorage.getItem(INDEX_KEY) ?? "[]") as SaveMeta[];
  } catch {
    return [];
  }
}

export function saveGame(slot: string, label: string, state: GameState) {
  if (!isBrowser()) return;
  localStorage.setItem(`carib.slot.${slot}`, JSON.stringify(state));
  const index = listSaves().filter((s) => s.slot !== slot);
  index.unshift({ slot, label, day: state.day, cash: state.cash, savedAt: Date.now() });
  localStorage.setItem(INDEX_KEY, JSON.stringify(index.slice(0, 12)));
}

export function loadGame(slot: string): GameState | undefined {
  if (!isBrowser()) return undefined;
  const raw = localStorage.getItem(`carib.slot.${slot}`);
  if (!raw) return undefined;
  try {
    const parsed = JSON.parse(raw) as GameState;
    if (parsed.schemaVersion !== SCHEMA_VERSION) return undefined;
    return heal(parsed);
  } catch {
    return undefined;
  }
}

/** Fill in anything a half-migrated save is missing so the UI never reads undefined. */
export function heal(state: GameState): GameState {
  if (!state.laws || typeof state.laws.crewShare !== "number") state.laws = { crewShare: 35 };
  state.crew ??= [];
  state.seaEvents ??= [];
  state.portStanding ??= {};
  state.prestige ??= 0;
  state.infamyPoints ??= 0;
  state.fines ??= {};
  state.repLedger ??= [];
  state.ships ??= [];
  // Voyages from before the sea-road chart have no track: put her back in port.
  for (const sh of state.ships) {
    if (sh.voyage && !sh.voyage.path?.length) delete sh.voyage;
    if (sh.voyage) sh.voyage.progressNm ??= 0;
    sh.holds ??= [];
    // Before the battery was its own thing a hull could show zero firepower: give her her rated guns.
    if (!sh.guns?.length) {
      const cls = SHIP_CLASS_MAP[sh.classId];
      sh.guns = Array.from({ length: cls?.guns ?? 0 }, () => 1);
    }
  }
  for (const m of state.crew) {
    m.health ??= 100;
    m.morale ??= 70;
    m.appetite ??= 6;
    m.xp ??= emptySkills();
    m.traits ??= [];
    m.faith ??= "Catholic";
  }
  return state;
}

export function deleteSave(slot: string) {
  if (!isBrowser()) return;
  localStorage.removeItem(`carib.slot.${slot}`);
  localStorage.setItem(INDEX_KEY, JSON.stringify(listSaves().filter((s) => s.slot !== slot)));
}
