import { useState } from "react";
import { Link } from "@tanstack/react-router";

import { COMMODITY_MAP } from "@/game/data/commodities";
import { PORT_MAP } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { VoyagePlanner } from "@/components/game/VoyagePlanner";
import { dockBlocked, freePower, marketBlocked, permitGrant, yardBlocked } from "@/game/data/permits";
import { distanceBetween, inPort, portDestination, shipPos } from "@/game/sim/position";
import { fortStats, isPillaged, portOwner } from "@/game/sim/world";
import { fortificationOf, portIntel } from "@/game/sim/portIntel";
import { money } from "@/game/sim/util";
import { PORT_TIERS, portEdge, portStandingParts, tierName } from "@/game/sim/standing";
import { useGame } from "@/game/store";
import { activeShip } from "@/game/actions";
import { PortPainting } from "@/components/game/PortPainting";
import { TavernScreen } from "@/components/game/TavernScreen";

export function PortDossier({ portId }: { portId: string }) {
  const { state, dispatch } = useGame();
  const port = PORT_MAP[portId]!;
  const ship = activeShip(state);
  const here = !!ship && ship.portId === portId && inPort(ship);
  const dest = portDestination(portId)!;
  const denied = dockBlocked(state, port.power);
  const fort = fortificationOf(port);
  const intel = portIntel(state, portId);
  const event = state.portEvents?.[portId];
  const free = freePower(port.power);
  const marketDenied = marketBlocked(state, port.power);
  const yardDenied = yardBlocked(state, port.power);
  const contractsPermit = free || !!permitGrant(state, port.power, "manufactured");
  const [tavernOpen, setTavernOpen] = useState(false);
  const parts = portStandingParts(state, portId);
  const edge = portEdge(state, portId);
  const fine = state.fines?.[portId];
  const owner = portOwner(state, portId);
  const guns = fortStats(port);
  const offing = ship && !ship.voyage ? distanceBetween(shipPos(ship), port) : Infinity;
  const canAssault = !!ship && !ship.voyage && !state.combat && offing <= 140;

  return (
    <div className="space-y-4 text-sm">
      {tavernOpen && <TavernScreen onExit={() => setTavernOpen(false)} />}
      <PortPainting port={port} />

      <header>
        <div className="flex items-baseline justify-between gap-2">
          <h2 className="text-xl font-semibold">{port.name}</h2>
          <span className="numeric text-xs text-muted-foreground">
            {port.lat.toFixed(1)}°, {port.lon.toFixed(1)}°
          </span>
        </div>
        <p className="text-xs uppercase tracking-wide text-muted-foreground">
          {POWER_MAP[port.power]!.adjective} · {port.region}
        </p>
        <p className="mt-2 leading-relaxed text-muted-foreground">{port.note}</p>

        <div className="mt-2 rounded-sm border border-border/70 bg-secondary/30 p-2">
          <div className="flex flex-wrap items-baseline gap-2 text-xs">
            <span className="uppercase tracking-wide text-muted-foreground">Standing here</span>
            <span className="font-semibold">{tierName(parts.total, PORT_TIERS)}</span>
            {state.homePortId === portId && (
              <span className="rounded-sm bg-secondary px-1 text-[10px] uppercase">homestead</span>
            )}
            <span className={`numeric ml-auto ${parts.total < 0 ? "text-loss" : "text-profit"}`}>
              {parts.total > 0 ? "+" : ""}
              {parts.total.toFixed(0)}
            </span>
          </div>
          <div className="relative mt-1 h-1.5 w-full rounded-full bg-muted">
            <div className="absolute left-1/2 top-[-2px] h-[10px] w-px bg-border" />
            <div
              className="absolute top-0 h-1.5 rounded-full"
              style={{
                left: `${Math.min(50, ((parts.total + 100) / 200) * 100)}%`,
                width: `${Math.abs(((parts.total + 100) / 200) * 100 - 50)}%`,
                background: parts.total < 0 ? "var(--color-destructive)" : "var(--color-accent)",
              }}
            />
          </div>
          <p className="numeric mt-1 text-[10px] text-muted-foreground">
            Quay {parts.own > 0 ? "+" : ""}
            {parts.own.toFixed(1)} · {POWER_MAP[port.power]!.adjective} crown {parts.crown > 0 ? "+" : ""}
            {parts.crown.toFixed(0)}
            {parts.home ? ` · homestead +${parts.home}` : ""} · quotations {edge.price > 0 ? "−" : "+"}
            {Math.abs(Math.round(edge.price * 100))}% to you
          </p>
          {fine ? (
            <div className="mt-2 flex flex-wrap items-center gap-2 rounded-sm border border-destructive/50 bg-destructive/10 p-2">
              <span className="text-[11px] text-loss">
                This harbour is closed to you. The port master wants {money(fine)} before your boats may land.
              </span>
              <button
                type="button"
                disabled={state.cash < fine}
                onClick={() => dispatch({ type: "payFine", portId })}
                className="ml-auto rounded-sm border border-input px-2 py-0.5 text-[11px] disabled:opacity-40"
              >
                Pay the fine
              </button>
            </div>
          ) : null}
        </div>
      </header>

      {event && (
        <div
          className={`rounded-sm border p-3 ${
            event.tone === "bad"
              ? "border-loss/50 bg-loss/10"
              : event.tone === "good"
                ? "border-accent/50 bg-accent/10"
                : "border-border bg-secondary/40"
          }`}
        >
          <h3 className="text-xs font-semibold uppercase tracking-wide">{event.title}</h3>
          <p className="mt-1 text-xs text-muted-foreground">{event.text}</p>
          <p className="numeric mt-1 text-[11px] text-muted-foreground">
            Expected to last {Math.max(1, event.endsDay - state.day)} more days.
          </p>
        </div>
      )}

      {here ? (
        <section className="space-y-2 rounded-sm border-2 border-[oklch(0.34_0.045_50)] bg-[oklch(0.22_0.03_45)]/60 p-3">
          <h3 className="text-xs font-semibold uppercase tracking-[0.16em] text-[oklch(0.78_0.07_80)]">
            Ashore at {port.name}
          </h3>
          <div className="grid gap-2 sm:grid-cols-2">
            <Ashore
              to="/play/market"
              label="Merchants' quay"
              note="Buy and sell in bulk"
              locked={!!marketDenied}
              lockNote={marketDenied ? `A ${marketDenied.powerName} ${marketDenied.name} is wanted at the custom house.` : undefined}
            />
            <Ashore
              label="The tavern"
              note="Rumours, postings, hirings, barter"
              onOpen={() => setTavernOpen(true)}
            />
            <Ashore
              to="/play/yard"
              label="Shipwright's yard"
              note="Parts, repairs, hulls"
              locked={!!yardDenied}
              lockNote={yardDenied ? `A ${yardDenied.powerName} ${yardDenied.name} is wanted before the yard will take your lines.` : undefined}
            />
            <Ashore
              to="/play/quests"
              label="Contract board"
              note="Charters and crown commissions"
              locked={!contractsPermit}
              lockNote={`The board is closed to masters without a ${POWER_MAP[port.power]!.adjective} trade permit.`}
            />
          </div>
        </section>
      ) : (
        <section className="panel space-y-2 p-3">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
            Report of the harbour <span className="normal-case">(second-hand, and possibly stale)</span>
          </h3>
          <IntelRow label="Wanting" lines={intel.lacking} tone="up" />
          <IntelRow label="In surplus" lines={intel.surplus} tone="down" />
          <p className="text-xs text-muted-foreground">
            <strong className="text-foreground">Defences:</strong> {fort.label} — perhaps {fort.guns} guns bearing on
            the anchorage.
          </p>
        </section>
      )}

      <section className="rounded-sm border border-loss/40 bg-loss/5 p-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">The batteries</h3>
        <p className="numeric mt-1 text-xs">
          Defensiveness <strong className="text-foreground">{guns.defensiveness}</strong> · firepower{" "}
          <strong className="text-foreground">{guns.firepower}</strong> · {guns.guns} guns ·{" "}
          {POWER_MAP[owner]!.adjective} colours
        </p>
        {isPillaged(state, portId) && (
          <p className="mt-1 text-xs text-loss">
            Sacked. The warehouses are bare and no man will sign here until the smoke clears.
          </p>
        )}
        <button
          type="button"
          disabled={!canAssault}
          onClick={() => dispatch({ type: "assaultPort", portId })}
          className="mt-2 rounded-sm bg-destructive px-3 py-1 text-xs text-destructive-foreground disabled:opacity-40"
        >
          Stand in and engage the batteries
        </button>
        <p className="mt-1 text-[11px] text-muted-foreground">
          {canAssault
            ? "A shore action. Beat her walls down and the town is yours to sack."
            : "You must be in the offing — within a hundred and forty miles — to stand in."}
        </p>
      </section>

      <dl className="grid grid-cols-2 gap-x-4 gap-y-1">
        <Stat label="Population" value={port.population.toLocaleString("en-GB")} />
        <Stat label="Prosperity" value={`${Math.round(port.prosperity * 100)}%`} />
        <Stat label="Harbour security" value={`${Math.round(port.security * 100)}%`} />
        <Stat label="Piracy in these waters" value={`${Math.round(port.pirateRisk * 100)}%`} />
        <Stat label="Import duty" value={`${Math.round(port.tariff * 100)}%`} />
        <Stat label="Port dues" value={money(port.portFee)} />
        <Stat label="Shipyard" value={["None", "Careening beach", "Yard", "Naval dockyard"][port.shipyard]!} />
        <Stat label="Fortification" value={`${Math.round(fort.score * 100)}%`} />
      </dl>

      <div>
        <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Produces</h3>
        <p className="leading-relaxed">
          {Object.keys(port.produces).map((c) => COMMODITY_MAP[c]?.name).filter(Boolean).join(", ") || "Little of note"}
        </p>
      </div>
      <div>
        <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Wants</h3>
        <p className="leading-relaxed">
          {Object.keys(port.consumes).map((c) => COMMODITY_MAP[c]?.name).filter(Boolean).join(", ") ||
            "Nothing in particular"}
        </p>
      </div>

      {!here && <VoyagePlanner dest={dest} />}

      {denied && (
        <p className="rounded-sm border border-loss/50 bg-loss/10 p-3 text-xs">
          Her papers are not in order for this flag: a {POWER_MAP[port.power]!.adjective} Permit to Dock is wanted
          before the harbour master will admit her. Buy one at the Diplomacy table.
        </p>
      )}
    </div>
  );
}

function Ashore({
  to,
  label,
  note,
  locked,
  lockNote,
  onOpen,
}: {
  to?: string;
  label: string;
  note: string;
  locked?: boolean;
  lockNote?: string | undefined;
  onOpen?: () => void;
}) {
  const face = (
    <>
      <span className="block text-sm font-semibold text-[oklch(0.90_0.04_80)]">{label} ▸</span>
      <span className="block text-[11px] text-muted-foreground">{note}</span>
    </>
  );
  const shell =
    "group rounded-sm border border-[oklch(0.48_0.06_65)]/70 bg-[oklch(0.26_0.035_48)]/70 px-3 py-2 text-left transition-colors hover:border-accent hover:bg-[oklch(0.30_0.04_50)]";
  if (locked) {
    return (
      <div
        title={lockNote}
        className="cursor-not-allowed rounded-sm border border-dashed border-border/70 bg-secondary/20 px-3 py-2 text-left opacity-70"
      >
        <span className="block text-sm font-medium">{label} <span className="text-[10px] uppercase tracking-wide text-loss">closed</span></span>
        <span className="block text-[11px] text-muted-foreground">{lockNote ?? note}</span>
      </div>
    );
  }
  if (onOpen || !to) {
    return (
      <button type="button" onClick={onOpen} className={shell}>
        {face}
      </button>
    );
  }
  return (
    <Link to={to} className={shell}>
      {face}
    </Link>
  );
}

function IntelRow({
  label,
  lines,
  tone,
}: {
  label: string;
  lines: { cid: string; name: string; price: number }[];
  tone: "up" | "down";
}) {
  return (
    <div className="flex items-baseline justify-between gap-2 text-xs">
      <span className="text-muted-foreground">{label}</span>
      <span className={tone === "up" ? "text-loss" : "text-accent"}>
        {lines.length
          ? lines.map((l) => `${l.name} ~${Math.round(l.price)} gold`).join(" · ")
          : "nothing reported"}
      </span>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-border/60 py-0.5">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="numeric">{value}</dd>
    </div>
  );
}
