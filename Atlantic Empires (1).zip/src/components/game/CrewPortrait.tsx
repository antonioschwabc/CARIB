import type { CrewMember, Skills } from "@/game/types";
import { pickPortrait } from "@/game/data/portraits";

/** Everything the gallery needs to hang the right canvas. */
export type PortraitSubject = Pick<CrewMember, "id" | "name" | "nationality" | "age"> & {
  traits?: string[];
  /** fixed seed for the painting; when given, the likeness never changes with the name */
  seed?: string;
  /** the sitter's learning — decides what the canvas is framed in */
  skills?: Skills;
};

export type FrameTier = "wood" | "copper" | "silver" | "gold";

const FRAMES: Record<FrameTier, { label: string; outer: string; inner: string; lip: string }> = {
  wood: {
    label: "Plain walnut frame — a common hand",
    outer: "linear-gradient(145deg, oklch(0.38 0.05 55), oklch(0.24 0.03 50) 45%, oklch(0.42 0.05 58))",
    inner: "oklch(0.20 0.03 50)",
    lip: "oklch(0.52 0.06 58 / 0.55)",
  },
  copper: {
    label: "Copper frame — a capable hand",
    outer: "linear-gradient(145deg, oklch(0.62 0.12 45), oklch(0.38 0.08 40) 45%, oklch(0.68 0.13 50))",
    inner: "oklch(0.28 0.05 42)",
    lip: "oklch(0.74 0.12 50 / 0.6)",
  },
  silver: {
    label: "Silver frame — a rare talent",
    outer: "linear-gradient(145deg, oklch(0.86 0.01 250), oklch(0.55 0.01 250) 45%, oklch(0.90 0.01 250))",
    inner: "oklch(0.40 0.01 250)",
    lip: "oklch(0.92 0.01 250 / 0.6)",
  },
  gold: {
    label: "Gilt frame — a master of the age",
    outer: "linear-gradient(145deg, oklch(0.88 0.14 88), oklch(0.58 0.12 75) 45%, oklch(0.92 0.15 92))",
    inner: "oklch(0.42 0.08 70)",
    lip: "oklch(0.94 0.14 90 / 0.65)",
  },
};

/**
 * The frame's metal weighs the sitter's single best discipline, his mean
 * learning across the eight, and the whole sum of them together.
 */
export function frameTier(skills?: Skills): FrameTier {
  if (!skills) return "wood";
  const v = Object.values(skills) as number[];
  if (!v.length) return "wood";
  const total = v.reduce((a, b) => a + b, 0);
  const avg = total / v.length;
  const best = Math.max(...v);
  // best 40%, mean 40%, whole body of learning 20% (scored against 8x99)
  const score = best * 0.4 + avg * 0.4 + (total / (v.length * 99)) * 99 * 0.2;
  if (score >= 82) return "gold";
  if (score >= 66) return "silver";
  if (score >= 50) return "copper";
  return "wood";
}

/**
 * A painted bust after the Dutch masters, chosen from the gallery to suit the
 * sitter's culture and years, hung in wood, copper, silver or gilt according
 * to his learning. Deterministic: the same soul, the same canvas.
 */
export function CrewPortrait({
  m,
  className = "h-12 w-12",
  frame,
}: {
  m: PortraitSubject;
  className?: string;
  /** override the metal; by default it follows the sitter's skills */
  frame?: FrameTier;
}) {
  const p = pickPortrait({
    nationality: m.nationality,
    age: m.age,
    seed: m.seed ?? m.id ?? m.name,
  });
  const tier = frame ?? frameTier(m.skills);
  const f = FRAMES[tier];

  return (
    <span
      className={`relative block overflow-hidden p-[6%] ${className}`}
      title={`${p.note} · ${f.label}`}
      style={{ background: f.outer, boxShadow: `inset 0 0 0 1px ${f.lip}, 0 1px 4px oklch(0.10 0.01 55 / 0.6)` }}
    >
      <span className="absolute inset-[6%] block overflow-hidden" style={{ boxShadow: `0 0 0 2px ${f.inner}` }}>
        <img
          src={p.src}
          alt={`Oil portrait of ${m.name}`}
          loading="lazy"
          width={816}
          height={816}
          className="h-full w-full object-cover"
        />
        {/* varnish and vignette, so every canvas sits in the same light */}
        <span
          aria-hidden
          className="pointer-events-none absolute inset-0"
          style={{
            background:
              "radial-gradient(120% 100% at 30% 25%, transparent 45%, oklch(0.10 0.02 50 / 0.55) 100%)",
          }}
        />
      </span>
    </span>
  );
}
