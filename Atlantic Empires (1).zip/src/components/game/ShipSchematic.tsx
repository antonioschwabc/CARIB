import { useState } from "react";
import { ChevronRight } from "lucide-react";

import { COMPONENT_MAP, SHIP_REGIONS } from "@/game/data/shipParts";
import { regionCondition } from "@/game/sim/shipStats";
import { SHIP_CLASS_MAP } from "@/game/data/ships";
import type { Ship, ShipRegion } from "@/game/types";

/** Cloths the shipwright pins behind his elevation. */
const TAPESTRIES = [
  { name: "Draughtsman's parchment", fill: "linear-gradient(150deg, oklch(0.88 0.04 86), oklch(0.82 0.05 80))", grid: "oklch(0.35 0.04 60)", ink: "oklch(0.28 0.03 55)" },
  { name: "Admiralty blue", fill: "linear-gradient(150deg, oklch(0.31 0.07 250), oklch(0.22 0.06 255))", grid: "oklch(0.86 0.05 240)", ink: "oklch(0.92 0.03 240)" },
  { name: "Sailcloth", fill: "linear-gradient(150deg, oklch(0.83 0.02 95), oklch(0.75 0.03 92))", grid: "oklch(0.40 0.02 80)", ink: "oklch(0.26 0.02 70)" },
  { name: "Tarred oak", fill: "repeating-linear-gradient(92deg, oklch(0.20 0.025 44) 0 26px, oklch(0.24 0.03 46) 26px 52px)", grid: "oklch(0.80 0.05 70)", ink: "oklch(0.90 0.04 80)" },
  { name: "Green baize", fill: "linear-gradient(150deg, oklch(0.34 0.06 150), oklch(0.25 0.05 152))", grid: "oklch(0.88 0.05 140)", ink: "oklch(0.92 0.04 140)" },
];

interface Zone {
  id: ShipRegion;
  /** hit box in viewBox units */
  x: number;
  y: number;
  w: number;
  h: number;
  label: string;
  lx: number;
  ly: number;
}

const ZONES: Zone[] = [
  { id: "mast", x: 176, y: 6, w: 240, h: 118, label: "Mast", lx: 296, ly: 20 },
  { id: "bow", x: 444, y: 124, w: 146, h: 66, label: "Bow", lx: 517, ly: 138 },
  { id: "stern", x: 22, y: 112, w: 132, h: 80, label: "Stern", lx: 88, ly: 126 },
  { id: "bridge", x: 154, y: 118, w: 96, h: 40, label: "Bridge", lx: 202, ly: 132 },
  { id: "deck", x: 254, y: 126, w: 186, h: 32, label: "Deck", lx: 347, ly: 140 },
  { id: "ordnance", x: 254, y: 158, w: 186, h: 34, label: "Ordnance", lx: 347, ly: 178 },
  { id: "warehouse", x: 154, y: 194, w: 300, h: 40, label: "Warehouse", lx: 300, ly: 218 },
  { id: "hull", x: 56, y: 158, w: 96, h: 76, label: "Hull", lx: 100, ly: 228 },
];

/** A shipwright's elevation: her regions, drawn, with what is fitted where. */
export function ShipSchematic({
  ship,
  region,
  onRegion,
}: {
  ship: Ship;
  region: ShipRegion;
  onRegion: (r: ShipRegion) => void;
}) {
  const cls = SHIP_CLASS_MAP[ship.classId] ?? SHIP_CLASS_MAP["sloop"]!;
  const masts = cls.id === "sloop" ? 1 : cls.id === "brigantine" || cls.id === "brig" ? 2 : 3;
  const wear = ship.hull / 100;
  const [cloth, setCloth] = useState(0);
  const tap = TAPESTRIES[cloth % TAPESTRIES.length]!;
  const guns = ship.guns ?? [];

  const fittedIn = (r: ShipRegion) => ship.components.filter((c) => COMPONENT_MAP[c.defId]?.region === r);

  return (
    <div className="relative">
      <button
        type="button"
        onClick={() => setCloth((c) => (c + 1) % TAPESTRIES.length)}
        title={`Backing cloth: ${tap.name} — click for the next`}
        aria-label="Change the backing cloth"
        className="absolute right-2 top-2 z-10 flex items-center gap-1 rounded-sm border px-2 py-1 text-[10px] uppercase tracking-[0.14em] shadow"
        style={{ borderColor: "oklch(0.30 0.045 45)", background: "oklch(0.88 0.04 84)", color: "oklch(0.26 0.03 55)" }}
      >
        {tap.name}
        <ChevronRight className="size-3.5" />
      </button>
      <svg
        viewBox="0 0 600 300"
        className="max-h-[380px] w-full rounded-sm border"
        style={{ borderColor: "oklch(0.30 0.045 45)", background: tap.fill, color: tap.ink }}
      >
        <defs>
          <linearGradient id="sch-hull" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.42 0.04 60)" />
            <stop offset="100%" stopColor="oklch(0.26 0.03 55)" />
          </linearGradient>
          <pattern id="sch-grid" width="20" height="20" patternUnits="userSpaceOnUse">
            <path d="M20 0 L0 0 0 20" fill="none" stroke="currentColor" strokeWidth="0.4" opacity="0.18" />
          </pattern>
        </defs>

        <rect width="600" height="300" fill="url(#sch-grid)" style={{ color: tap.grid }} />
        <line x1="0" y1="232" x2="600" y2="232" stroke={tap.grid} strokeWidth="1" opacity="0.5" />

        {/* masts, yards and canvas */}
        {Array.from({ length: masts }).map((_, i) => {
          const x = 220 + i * (170 / Math.max(1, masts - 1 || 1));
          return (
            <g key={i} className="text-foreground">
              <line x1={x} y1={20} x2={x} y2={160} stroke="currentColor" strokeWidth="4" opacity="0.85" />
              <line x1={x - 55} y1={54} x2={x + 55} y2={54} stroke="currentColor" strokeWidth="2.5" opacity="0.7" />
              <path
                d={`M${x - 52} 56 Q ${x} ${72 + (1 - ship.sails / 100) * 14} ${x + 52} 56 L ${x + 44} 108 Q ${x} 122 ${x - 44} 108 Z`}
                fill="oklch(0.88 0.03 85)"
                opacity={0.35 + (ship.sails / 100) * 0.5}
                stroke="currentColor"
                strokeWidth="1"
              />
            </g>
          );
        })}

        {/* hull */}
        <path
          d="M40 158 L578 158 L534 212 Q 300 246 94 212 Z"
          fill="url(#sch-hull)"
          stroke="currentColor"
          strokeWidth="1.5"
          className="text-border"
          opacity={0.55 + wear * 0.45}
        />
        {/* deck line, stern castle, bowsprit */}
        <rect x="150" y="140" width="100" height="18" fill="oklch(0.38 0.04 60)" stroke="currentColor" className="text-border" />
        <rect x="42" y="128" width="110" height="30" fill="oklch(0.34 0.04 55)" stroke="currentColor" className="text-border" />
        <line x1="572" y1="158" x2="598" y2="130" stroke="currentColor" strokeWidth="4" className="text-foreground" opacity="0.8" />

        {/* gun ports along the waist */}
        {Array.from({ length: 8 }).map((_, i) => {
          const open = i < Math.min(8, Math.round((guns.length / Math.max(1, cls.gunPorts)) * 8));
          return (
            <g key={i}>
              <rect x={120 + i * 50} y={170} width="14" height="12" fill="oklch(0.18 0.02 50)" opacity="0.75" />
              {open && <rect x={122 + i * 50} y={172} width="10" height="8" fill="oklch(0.62 0.16 42)" opacity="0.9" />}
            </g>
          );
        })}

        {/* interactive regions */}
        {ZONES.map((z) => {
          const active = z.id === region;
          const fitted = fittedIn(z.id);
          const info = SHIP_REGIONS.find((r) => r.id === z.id)!;
          return (
            <g key={z.id} onClick={() => onRegion(z.id)} className="cursor-pointer">
              <title>{`${info.name} — condition ${Math.round(regionCondition(ship, z.id))}% · ${fitted.length} fitted`}</title>
              <rect
                x={z.x}
                y={z.y}
                width={z.w}
                height={z.h}
                rx="4"
                fill={active ? "oklch(0.62 0.16 42 / 0.22)" : "transparent"}
                stroke="currentColor"
                strokeDasharray={active ? undefined : "4 4"}
                strokeWidth={active ? 2 : 1}
                style={{ color: active ? "oklch(0.62 0.16 42)" : tap.ink }}
                opacity={active ? 1 : 0.55}
              />
              <text
                x={z.lx}
                y={z.ly}
                textAnchor="middle"
                fill={active ? "oklch(0.62 0.16 42)" : tap.ink}
                style={{ fontSize: 11, letterSpacing: "0.12em", textTransform: "uppercase" }}
              >
                {z.label}
              </text>
              {fitted.map((c, i) => (
                <circle
                  key={c.id}
                  cx={z.lx - (fitted.length - 1) * 6 + i * 12}
                  cy={z.ly + 12}
                  r="4"
                  className="fill-accent"
                  opacity={0.35 + c.level * 0.13}
                />
              ))}
            </g>
          );
        })}
      </svg>
    </div>
  );
}
