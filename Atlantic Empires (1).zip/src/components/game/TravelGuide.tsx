import { useMemo } from "react";

import { activeShip } from "@/game/actions";
import { COASTLINES } from "@/game/data/coastlines";
import { PORT_MAP } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { coordLabel, shipPos } from "@/game/sim/position";
import { seaRoute } from "@/game/sim/seagrid";
import { sightRangeNm } from "@/game/sim/seaEvents";
import { planVoyage } from "@/game/sim/voyage";
import { suppliesAboard } from "@/game/sim/stores";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";
import type { Destination } from "@/game/types";

/** The passage brief: where she is, the water road, the stores, the ETA, the risks. */
export function TravelGuide({ dest, onClose }: { dest: Destination; onClose: () => void }) {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const here = ship ? shipPos(ship) : { lat: 0, lon: 0 };
  const route = useMemo(() => seaRoute(here, dest), [here.lat, here.lon, dest.lat, dest.lon]);
  if (!ship) return null;

  const plan = planVoyage(state, ship, dest);
  const port = dest.portId ? PORT_MAP[dest.portId] : undefined;
  const aboard = suppliesAboard(ship);
  const short = Math.max(0, plan.provisionsNeeded - aboard);
  const underway = !!ship.voyage;

  const dangers: string[] = [];
  if (plan.pirateRisk > 0.25) dangers.push("These are known pirate waters — a heavy risk of a strange sail.");
  else if (plan.pirateRisk > 0.1) dangers.push("Some risk of pirates on this run.");
  if (plan.stormRisk > 0.3) dangers.push("The season is against you: expect heavy weather.");
  if (short > 0) dangers.push(`Short of stores by ${Math.ceil(short)} units — men go hungry before landfall.`);
  if (ship.hull < 55) dangers.push("Her hull is in poor repair for a passage of this length.");
  if (port) dangers.push(`${port.name} has ${Math.round(port.security * 100)}% harbour security under the ${POWER_MAP[port.power]!.adjective} flag.`);
  for (const n of plan.notes) dangers.push(n);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Passage brief"
        onClick={(e) => e.stopPropagation()}
        className="panel max-h-[92vh] w-full max-w-3xl overflow-auto p-5 text-card-foreground"
      >
        <header className="flex items-baseline justify-between gap-3 border-b border-border pb-2">
          <h2 className="font-serif text-2xl font-bold">Passage to {dest.label}</h2>
          <button type="button" onClick={onClose} className="text-xs text-muted-foreground hover:text-foreground">
            Close ✕
          </button>
        </header>

        <div className="mt-3 grid gap-4 md:grid-cols-[1.1fr_1fr]">
          <div className="space-y-3">
            <RouteSketch points={route.points} />
            <p className="text-xs text-muted-foreground">
              {route.ok
                ? `A clear water road of ${route.points.length - 1} legs, worked round the land.`
                : "No clear water road could be found to this bearing."}
            </p>
          </div>

          <div className="space-y-3 text-sm">
            <section className="panel p-3">
              <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Where she lies</h3>
              <p className="numeric mt-1">{coordLabel(here.lat, here.lon)}</p>
              <p className="text-xs text-muted-foreground">
                {ship.name} · lookouts see {sightRangeNm(ship)} nm about her
              </p>
            </section>

            <dl className="grid grid-cols-2 gap-x-4 gap-y-1">
              <Row label="Distance" value={`${plan.distanceNm.toLocaleString("en-GB")} nm`} />
              <Row label="ETA" value={`${plan.days} days`} />
              <Row label="Stores needed" value={`${plan.provisionsNeeded} (${Math.floor(aboard)} aboard)`} />
              <Row label="Wages on passage" value={money(plan.wages)} />
              <Row label="Storm risk" value={`${Math.round(plan.stormRisk * 100)}%`} />
              <Row label="Piracy risk" value={`${Math.round(plan.pirateRisk * 100)}%`} />
              {port && <Row label="Port dues" value={money(port.portFee)} />}
            </dl>

            <section>
              <h3 className="mb-1 text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                What may be met with
              </h3>
              <ul className="list-inside list-disc space-y-0.5 text-xs text-muted-foreground">
                {dangers.length ? dangers.map((d) => <li key={d}>{d}</li>) : <li>Nothing much is expected.</li>}
              </ul>
            </section>
          </div>
        </div>

        <footer className="mt-4 grid gap-2 sm:grid-cols-3">
          <button type="button" onClick={onClose} className="rounded-sm border border-input px-3 py-2 text-sm">
            Think on it
          </button>
          <button
            type="button"
            onClick={() => {
              dispatch({ type: "setCourse", dest });
              onClose();
            }}
            className="rounded-sm border border-input px-3 py-2 text-sm disabled:opacity-40"
          >
            Lay the course only
          </button>
          <button
            type="button"
            disabled={!!plan.blocked}
            onClick={() => {
              dispatch({ type: "setCourse", dest });
              dispatch({ type: "setRudder", underway: true });
              onClose();
            }}
            className="rounded-sm bg-primary px-3 py-2 text-sm font-medium text-primary-foreground disabled:opacity-40"
          >
            {plan.blocked ?? (underway ? "Change course — sail on" : "Release the rudder — sail")}
          </button>
        </footer>
      </div>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-border/60 py-0.5">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="numeric text-sm">{value}</dd>
    </div>
  );
}

/** A small chart of the proposed water road, from departure to landfall. */
function RouteSketch({ points }: { points: { lat: number; lon: number }[] }) {
  const w = 420;
  const h = 260;
  if (points.length < 2) return null;
  const lons = points.map((p) => p.lon);
  const lats = points.map((p) => p.lat);
  const pad = 1;
  const lon0 = Math.min(...lons) - pad;
  const lon1 = Math.max(...lons) + pad;
  const lat0 = Math.min(...lats) - pad;
  const lat1 = Math.max(...lats) + pad;
  const sx = w / Math.max(0.001, lon1 - lon0);
  const sy = h / Math.max(0.001, lat1 - lat0);
  const s = Math.min(sx, sy);
  const ox = (w - (lon1 - lon0) * s) / 2;
  const oy = (h - (lat1 - lat0) * s) / 2;
  const pt = (p: { lat: number; lon: number }) => ({
    x: ox + (p.lon - lon0) * s,
    y: oy + (lat1 - p.lat) * s,
  });
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${pt(p).x.toFixed(1)} ${pt(p).y.toFixed(1)}`).join("");
  const a = pt(points[0]!);
  const b = pt(points[points.length - 1]!);

  // The land shown behind the track, so the water road reads plainly.
  const land: string[] = [];
  for (const rings of Object.values(COASTLINES)) {
    for (const ring of rings) {
      let inside = false;
      for (const [lon, lat] of ring) {
        if (lon >= lon0 - 4 && lon <= lon1 + 4 && lat >= lat0 - 4 && lat <= lat1 + 4) {
          inside = true;
          break;
        }
      }
      if (!inside) continue;
      let path = "";
      for (let i = 0; i < ring.length; i++) {
        const q = pt({ lon: ring[i]![0], lat: ring[i]![1] });
        path += `${i === 0 ? "M" : "L"}${q.x.toFixed(1)} ${q.y.toFixed(1)}`;
      }
      land.push(`${path}Z`);
    }
  }

  return (
    <svg viewBox={`0 0 ${w} ${h}`} className="w-full rounded-sm border border-border bg-[oklch(0.34_0.07_243)]">
      {land.map((p, i) => (
        <path key={`land${i}`} d={p} fill="oklch(0.58 0.08 118)" stroke="oklch(0.42 0.06 95)" strokeWidth={0.5} />
      ))}
      <path d={d} fill="none" stroke="oklch(0.92 0.13 85)" strokeWidth={2} strokeDasharray="7 5" />
      {points.map((p, i) => {
        const q = pt(p);
        return <circle key={i} cx={q.x} cy={q.y} r={2} fill="oklch(0.9 0.05 85)" opacity={0.7} />;
      })}
      <circle cx={a.x} cy={a.y} r={5} fill="oklch(0.95 0.12 85)" />
      <circle cx={b.x} cy={b.y} r={5} fill="none" stroke="oklch(0.95 0.12 85)" strokeWidth={2} />
    </svg>
  );
}
