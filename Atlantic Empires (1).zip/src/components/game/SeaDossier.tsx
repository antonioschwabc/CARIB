import { VoyagePlanner } from "@/components/game/VoyagePlanner";
import { activeShip } from "@/game/actions";
import { PORTS, portVisible } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { distanceBetween, seaDestination, shipPos } from "@/game/sim/position";
import { useGame } from "@/game/store";

/** A mark on bare water: what lies near it, and how far off she is. */
export function SeaDossier({ lat, lon }: { lat: number; lon: number }) {
  const { state } = useGame();
  const ship = activeShip(state);
  const dest = seaDestination(lat, lon);
  const here = ship ? shipPos(ship) : { lat, lon };

  const near = PORTS.filter(portVisible).map((p) => ({ p, d: distanceBetween({ lat, lon }, p) }))
    .sort((a, b) => a.d - b.d)
    .slice(0, 4);

  return (
    <div className="space-y-4 text-sm">
      <header className="panel p-3">
        <h2 className="font-serif text-xl font-semibold">Open water</h2>
        <p className="numeric text-xs text-muted-foreground">{dest.label}</p>
        <p className="mt-2 text-xs text-muted-foreground">
          No harbour here — only sea room. She can be sailed to this bearing and hove to, to lie in wait, to keep off a
          hostile coast, or to work her way across in stages.
        </p>
        <p className="numeric mt-2 text-xs">
          {distanceBetween(here, dest).toLocaleString("en-GB")} nm from {ship?.name ?? "your ship"}
        </p>
      </header>

      <section className="panel space-y-1 p-3">
        <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Nearest harbours</h3>
        {near.map(({ p, d }) => (
          <div key={p.id} className="flex items-baseline justify-between gap-2 text-xs">
            <span>
              {p.name} <span className="text-muted-foreground">· {POWER_MAP[p.power]!.adjective}</span>
            </span>
            <span className="numeric text-muted-foreground">{d.toLocaleString("en-GB")} nm</span>
          </div>
        ))}
      </section>

      <VoyagePlanner dest={dest} />
    </div>
  );
}
