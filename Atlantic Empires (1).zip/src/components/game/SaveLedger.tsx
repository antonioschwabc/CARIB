import { useState } from "react";
import { HudArt } from "@/components/game/HudArt";

import { AUTOSAVE, DAILY_SAVE, MANUAL_SLOTS, deleteSave, listSaves } from "@/game/save";
import { formatDate, money } from "@/game/sim/util";
import { useGame } from "@/game/store";

const PARCH = "oklch(0.88 0.045 85)";
const INK = "oklch(0.26 0.04 55)";
const FAINT = "oklch(0.42 0.03 60)";

/** The captain's log book: keep the game, take it up again. */
export function SaveLedger() {
  const { state, saveTo, loadFrom } = useGame();
  const [open, setOpen] = useState(false);
  const [tick, setTick] = useState(0);
  const [note, setNote] = useState("");
  const saves = open ? listSaves() : [];
  const bump = () => setTick((t) => t + 1);
  void tick;

  const row = (slot: string, fallback: string) => {
    const meta = saves.find((s) => s.slot === slot);
    return (
      <div
        key={slot}
        className="flex items-center gap-3 rounded-sm border px-3 py-2"
        style={{ borderColor: "oklch(0.55 0.05 60)", background: "oklch(0.93 0.035 85)" }}
      >
        <div className="min-w-0 flex-1">
          <p className="truncate text-sm font-semibold" style={{ color: INK }}>
            {meta?.label ?? fallback}
          </p>
          <p className="numeric text-[11px]" style={{ color: FAINT }}>
            {meta ? `${formatDate(meta.day)} · ${money(meta.cash)}` : "empty"}
          </p>
        </div>
        {slot !== AUTOSAVE && slot !== DAILY_SAVE && (
          <button
            type="button"
            className="rounded-sm border px-2 py-1 text-xs"
            style={{ borderColor: "oklch(0.5 0.05 60)", color: INK }}
            onClick={() => {
              saveTo(slot, note.trim() || `${state.merchantName} · ${formatDate(state.day)}`);
              setNote("");
              bump();
            }}
          >
            Write
          </button>
        )}
        <button
          type="button"
          disabled={!meta}
          className="rounded-sm border px-2 py-1 text-xs disabled:opacity-40"
          style={{ borderColor: "oklch(0.5 0.05 60)", color: INK }}
          onClick={() => {
            if (loadFrom(slot)) setOpen(false);
          }}
        >
          Resume
        </button>
        {slot !== AUTOSAVE && slot !== DAILY_SAVE && (
          <button
            type="button"
            disabled={!meta}
            className="rounded-sm border px-2 py-1 text-xs disabled:opacity-40"
            style={{ borderColor: "oklch(0.5 0.05 60)", color: "oklch(0.42 0.15 28)" }}
            onClick={() => {
              deleteSave(slot);
              bump();
            }}
          >
            Tear out
          </button>
        )}
      </div>
    );
  };

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex size-9 items-center justify-center rounded-sm border border-[oklch(0.52_0.10_75)]/50 bg-[oklch(0.18_0.03_45)]/70 text-[oklch(0.88_0.08_82)] hover:bg-[oklch(0.24_0.04_45)]"
        title="Log book — save or resume the voyage"
        aria-label="Log book"
      >
        <HudArt name="logbook" className="size-7" />
      </button>
      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-lg rounded-sm border-4 p-4 shadow-2xl"
            style={{ borderColor: "oklch(0.32 0.05 50)", background: PARCH }}
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-baseline justify-between">
              <h2 className="font-serif text-xl font-bold" style={{ color: INK }}>
                Log book
              </h2>
              <button type="button" className="text-sm" style={{ color: FAINT }} onClick={() => setOpen(false)}>
                Close ✕
              </button>
            </div>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Name this entry (optional)"
              className="mb-3 w-full rounded-sm border px-2 py-1 text-sm"
              style={{ borderColor: "oklch(0.55 0.05 60)", background: "oklch(0.95 0.03 85)", color: INK }}
            />
            <div className="flex flex-col gap-2">
              {MANUAL_SLOTS.map((s, i) => row(s, `Entry ${i + 1}`))}
              {row(DAILY_SAVE, "Dawn keepsake")}
              {row(AUTOSAVE, "Autosave")}
            </div>
            <p className="mt-3 text-[11px]" style={{ color: FAINT }}>
              The voyage saves itself constantly, and a fresh keepsake is written every dawn.
            </p>
          </div>
        </div>
      )}
    </>
  );
}
