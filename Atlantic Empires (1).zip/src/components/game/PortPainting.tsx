import { FactionFlag } from "@/components/game/FactionFlag";
import { PortView } from "@/components/game/PortView";
import type { Port } from "@/game/types";

/** Painted prospects of the harbours, bundled with the game. */
const FILES = import.meta.glob("../../assets/ports/*.jpg", { eager: true, import: "default" }) as Record<
  string,
  string
>;

const PAINTINGS: Record<string, string> = Object.fromEntries(
  Object.entries(FILES).map(([path, url]) => [path.split("/").pop()!.replace(/\.jpg$/, ""), url]),
);

export function hasPainting(portId: string) {
  return !!PAINTINGS[portId];
}

/** An oil prospect of the harbour where one has been painted; otherwise the drawn chartsman's view. */
export function PortPainting({ port }: { port: Port }) {
  const src = PAINTINGS[port.id];
  const flag = (
    <div className="pointer-events-none absolute right-3 top-0 z-10 w-[13%] min-w-14 max-w-24 drop-shadow-[0_4px_8px_rgba(0,0,0,0.45)]">
      <FactionFlag power={port.power} draped title={`${port.name} flies the colours of its owner`} />
    </div>
  );
  if (!src) {
    return (
      <div className="relative">
        <PortView port={port} />
        {flag}
      </div>
    );
  }
  return (
    <figure className="relative overflow-hidden rounded-sm border-4 border-[oklch(0.32_0.045_55)] shadow-lg">
      <img
        src={src}
        alt={`A 17th-century oil prospect of ${port.name}`}
        loading="lazy"
        className="block aspect-[16/9] w-full object-cover"
      />
      {flag}
    </figure>
  );
}
