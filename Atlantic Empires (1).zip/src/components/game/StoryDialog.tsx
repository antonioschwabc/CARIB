import type { LifeOption } from "@/game/data/lifeEvents";
import { storyOdds, storyOptions } from "@/game/sim/story";
import { useGame } from "@/game/store";

const SCENE_LABEL: Record<string, string> = {
  sea: "At sea",
  port: "In harbour",
  quay: "On the quay",
};

const SKILL_LABEL: Record<string, string> = {
  navigation: "Navigation",
  charisma: "Charisma",
  scouting: "Scouting",
  craftsmanship: "Craftsmanship",
  gunnery: "Gunnery",
  logistics: "Logistics",
  cooking: "Cooking",
  medicine: "Medicine",
};

/** A moment among the people, waiting on the captain's word. */
export function StoryDialog() {
  const { state, dispatch } = useGame();
  const st = state.story;
  if (!st || state.combat) return null;
  const options = storyOptions(st.defId);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div role="dialog" aria-modal="true" className="panel w-full max-w-lg space-y-4 p-5 text-card-foreground">
        <header className="border-b border-border pb-3">
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground">
            {SCENE_LABEL[st.scene]}
            {st.portName ? ` · ${st.portName}` : ""}
          </p>
          <h2 className="font-serif text-xl font-bold text-accent">{st.title}</h2>
        </header>

        <p className="text-sm leading-relaxed">{st.text}</p>

        <div className="grid gap-2">
          {options.map((o) => (
            <Row key={o.id} opt={o} onPick={() => dispatch({ type: "story", choice: o.id })} />
          ))}
        </div>
      </div>
    </div>
  );
}

function Row({ opt, onPick }: { opt: LifeOption; onPick: () => void }) {
  const { state } = useGame();
  const odds = storyOdds(state, opt);
  return (
    <button
      type="button"
      onClick={onPick}
      className="rounded-sm border border-input px-3 py-2 text-left transition-colors hover:bg-secondary"
    >
      <div className="flex flex-wrap items-baseline gap-2">
        <span className="text-sm font-medium">{opt.label}</span>
        {odds && (
          <span className="numeric ml-auto text-[11px] text-muted-foreground">
            {SKILL_LABEL[odds.skill]} {odds.score} vs {odds.dc} · {odds.label} ·{" "}
            <span className="text-accent">{Math.round(odds.chance * 100)}%</span> to succeed
          </span>
        )}
      </div>
    </button>
  );
}
