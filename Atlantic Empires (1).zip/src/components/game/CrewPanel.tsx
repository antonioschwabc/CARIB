import { Link } from "@tanstack/react-router";

import { BannerFlag } from "@/components/game/BannerFlag";
import { CrewCard } from "@/components/game/CrewCard";
import { CrewPortrait } from "@/components/game/CrewPortrait";
import { activeShip } from "@/game/actions";
import { POSITIONS, POSITION_LABEL, SKILL_IDS, SKILL_LABEL } from "@/game/data/crew";
import { HAND_WEEKLY_WAGE } from "@/game/data/crew";
import { PORT_MAP } from "@/game/data/ports";
import { SHIP_CLASS_MAP } from "@/game/data/ships";
import { bannerStats, weeklyWages } from "@/game/sim/crewStats";
import { lodgings, postOf } from "@/game/sim/shipStats";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";
import type { CrewPosition, SkillId } from "@/game/types";

export function CrewPanel() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  if (!ship) return <p className="p-6">You have no ships.</p>;

  const cls = SHIP_CLASS_MAP[ship.classId]!;
  const port = PORT_MAP[ship.portId]!;
  const atSea = !!ship.voyage;
  const roster = state.crew.filter((m) => m.shipId === ship.id);
  const banner = bannerStats(state);
  const hands = Math.max(0, ship.crew - roster.length);
  const payroll = weeklyWages(state) + hands * HAND_WEEKLY_WAGE;

  return (
    <div className="grid gap-4 p-4 xl:grid-cols-[22rem_1fr]">
      <section className="panel space-y-4 p-4">
        <header className="flex items-baseline justify-between">
          <div>
            <h2 className="text-lg font-semibold">{state.banner.name}</h2>
            <p className="text-xs text-muted-foreground">Your own skill plus the best of your people.</p>
          </div>
          <BannerFlag banner={state.banner} className="h-10 w-14" />
        </header>

        <div className="flex items-center gap-3 border-y border-border/60 py-3">
          <CrewPortrait
            m={{
              id: state.player.portraitSeed ?? state.player.name,
              seed: state.player.portraitSeed ?? state.player.name,

              name: state.player.name,
              nationality: state.player.nationality,
              age: state.player.age,
              traits: state.player.traits ?? [],
            }}
            className="h-20 w-20 rounded-sm"
          />
          <div className="text-xs">
            <p className="text-sm font-semibold">{state.player.name}</p>
            <p className="text-muted-foreground">
              {state.player.age} years · {state.player.nationality}
              {state.player.faith ? ` · ${state.player.faith}` : ""}
            </p>
            {!!state.player.traits?.length && (
              <p className="mt-1 italic text-muted-foreground">{state.player.traits.join(" · ")}</p>
            )}
          </div>
        </div>

        <dl className="grid gap-2">
          {SKILL_IDS.map((k: SkillId) => (
            <div key={k}>
              <div className="flex justify-between text-xs">
                <dt className="text-muted-foreground">{SKILL_LABEL[k]}</dt>
                <dd className="numeric">
                  {banner[k]} <span className="text-muted-foreground">({state.player.stats[k]} you)</span>
                </dd>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-sm bg-secondary">
                <div className="h-full bg-accent" style={{ width: `${Math.min(100, banner[k])}%` }} />
              </div>
            </div>
          ))}
        </dl>

        <div className="grid grid-cols-3 gap-2 text-center text-xs">
          <Stat label="Level" value={String(state.player.level)} />
          <Stat label="Hands" value={`${ship.crew} / ${cls.hands}`} />
          <Stat label="Berths" value={`${roster.length} / ${lodgings(ship)}`} />
          <Stat label="Payroll / week" value={money(Math.round(payroll))} />
        </div>

        <div className="rounded-sm border border-border bg-secondary/30 p-3">
          <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Ship's articles</h3>
          <p className="mt-1 text-[11px] text-muted-foreground">
            The share of prize gold and experience — from fights, contracts and events, never from honest trade — that
            goes to the people.
          </p>
          <div className="mt-2 flex items-center gap-3">
            <span className="numeric w-24 text-sm">Captain {100 - state.laws.crewShare}%</span>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={state.laws.crewShare}
              onChange={(e) => dispatch({ type: "setLaws", crewShare: Number(e.target.value) })}
              className="flex-1 accent-[var(--accent)]"
              aria-label="Crew share of prize gold and experience"
            />
            <span className="numeric w-20 text-right text-sm">Crew {state.laws.crewShare}%</span>
          </div>
        </div>

        <div className="rounded-sm border border-border p-3 text-xs">
          <h3 className="mb-1 font-semibold uppercase tracking-wide text-muted-foreground">Common hands</h3>
          <p className="text-[11px] text-muted-foreground">
            {hands} unnamed hands at {HAND_WEEKLY_WAGE} gold a week each.
          </p>
          <div className="mt-2 grid grid-cols-2 gap-2">
            <button
              type="button"
              disabled={atSea || state.cash < 200}
              onClick={() => dispatch({ type: "hire", count: 5 })}
              className="rounded-sm border border-input px-2 py-1.5 disabled:opacity-40"
            >
              Ship five · {money(200)}
            </button>
            <button
              type="button"
              disabled={atSea}
              onClick={() => dispatch({ type: "dismiss", count: 5 })}
              className="rounded-sm border border-input px-2 py-1.5 disabled:opacity-40"
            >
              Pay off five
            </button>
          </div>
        </div>
      </section>

      <section className="panel space-y-3 p-4">
        <header className="flex flex-wrap items-baseline justify-between gap-2">
          <div>
            <h2 className="text-lg font-semibold">
              Signed articles ({roster.length} / {lodgings(ship)} berths)
            </h2>
            <p className="text-xs text-muted-foreground">
              Everyone signed aboard {ship.name}. A man takes a berth in the lodgings first; give him a post only if
              the quarter is built. Men off the watch bill still eat and draw wages, but rest the better for it.
            </p>
          </div>
          <Link to="/play/tavern" className="rounded-sm border border-input px-2.5 py-1 text-xs">
            Look for men in the tavern →
          </Link>
        </header>

        {roster.length === 0 ? (
          <p className="text-sm text-muted-foreground">
            Not a soul but yourself. Candidates drink in the tavern at {port.name} — sign one before you sail.
          </p>
        ) : (
          <ul className="grid gap-2 2xl:grid-cols-2">
            {roster.map((m) => {
              const post = postOf(ship, m.id) as CrewPosition | undefined;
              return (
              <CrewCard
                key={m.id}
                m={m}
                post={post}
                footer={
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="numeric text-muted-foreground">{m.wage} gold/week</span>
                    <select
                      value={post ?? ""}
                      onChange={(e) =>
                        dispatch({
                          type: "assignCrew",
                          shipId: ship.id,
                          position: (e.target.value || post || "captain") as CrewPosition,
                          memberId: e.target.value ? m.id : undefined,
                        })
                      }
                      className="rounded-sm border border-input bg-card px-1.5 py-0.5 text-xs"
                    >
                      <option value="">In the lodgings</option>
                      {POSITIONS.filter((p) => ship.quarters?.includes(p)).map((p) => {
                        const held = ship.assignments?.[p];
                        return (
                          <option key={p} value={p} disabled={!!held && held !== m.id}>
                            {POSITION_LABEL[p]}
                            {held && held !== m.id ? " (filled)" : ""}
                          </option>
                        );
                      })}
                    </select>
                    <button
                      type="button"
                      disabled={atSea}
                      onClick={() => dispatch({ type: "dismissMember", memberId: m.id })}
                      className="rounded-sm border border-input px-2 py-0.5 disabled:opacity-40"
                    >
                      Pay off
                    </button>
                  </div>
                }
              />
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-sm border border-border p-2">
      <div className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</div>
      <div className="numeric font-semibold">{value}</div>
    </div>
  );
}
