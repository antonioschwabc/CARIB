import { activeShip } from "@/game/actions";
import { PORT_MAP } from "@/game/data/ports";
import { sameDestination, shipPos } from "@/game/sim/position";
import { planVoyage } from "@/game/sim/voyage";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";
import type { Destination } from "@/game/types";

/** The passage-plan card: what it costs, what it risks, and the two rudder orders. */
export function VoyagePlanner({ dest }: { dest: Destination }) {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  if (!ship) return null;

  const here = shipPos(ship);
  const atThisMark = Math.abs(here.lat - dest.lat) < 0.05 && Math.abs(here.lon - dest.lon) < 0.05;
  if (atThisMark)
    return (
      <p className="panel p-3 text-center text-xs text-muted-foreground">
        {ship.name} lies here already. Pick another mark on the chart to lay a course.
      </p>
    );

  const plan = planVoyage(state, ship, dest);
  const laid = sameDestination(ship.course, dest);

  return (
    <div className="panel space-y-2 p-3">
      <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Proposed voyage</h3>
      <dl className="grid grid-cols-2 gap-x-4 gap-y-1">
        <Row label="Distance" value={`${plan.distanceNm.toLocaleString("en-GB")} nm`} />
        <Row label="Passage" value={`${plan.days} days`} />
        <Row label="Supplies needed" value={`${plan.provisionsNeeded}`} />
        <Row label="Wages" value={money(plan.wages)} />
        <Row label="Storm risk" value={`${Math.round(plan.stormRisk * 100)}%`} />
        <Row label="Piracy risk" value={`${Math.round(plan.pirateRisk * 100)}%`} />
        {dest.portId && <Row label="Port dues" value={money(PORT_MAP[dest.portId]!.portFee)} />}
      </dl>
      {plan.notes.length > 0 && (
        <ul className="list-inside list-disc space-y-0.5 text-xs text-muted-foreground">
          {plan.notes.map((n) => (
            <li key={n}>{n}</li>
          ))}
        </ul>
      )}
      <div className="grid gap-2 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => dispatch({ type: "setCourse", dest })}
          className="rounded-sm border border-input px-3 py-2 text-sm"
        >
          {laid ? "Course laid" : `Lay course for ${dest.label}`}
        </button>
        <button
          type="button"
          disabled={!!plan.blocked}
          onClick={() => {
            dispatch({ type: "setCourse", dest });
            dispatch({ type: "setRudder", underway: true });
          }}
          className="rounded-sm bg-primary px-3 py-2 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90 disabled:opacity-40"
        >
          {plan.blocked ?? "Release the rudder — sail"}
        </button>
      </div>
      <p className="text-[11px] italic text-muted-foreground">
        With the rudder spinning she weighs anchor on the next day and closes on her course each day you continue.
      </p>
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="numeric text-sm">{value}</dd>
    </div>
  );
}
