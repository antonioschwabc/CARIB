import { useState } from "react";

import { activeShip, volumeOf } from "@/game/actions";
import { unitLabel } from "@/game/data/commodities";
import { questBlocker, questTons } from "@/game/sim/quests";
import { cargoUsed, shipCapacity } from "@/game/sim/voyage";
import { KIND_LABEL } from "@/components/game/QuestsPanel";
import { CrewCard } from "@/components/game/CrewCard";
import { signingFee } from "@/game/data/crew";
import { COMMODITY_MAP } from "@/game/data/commodities";
import { PORT_MAP } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { PortPainting } from "@/components/game/PortPainting";
import { RUMOUR_RANGE_NM, rumourPrice, tavernBid, tavernOffers } from "@/game/sim/tavern";
import { lodgings } from "@/game/sim/shipStats";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";

type Room = "rumours" | "postings" | "hirings" | "barter";

const ROOMS: { id: Room; label: string; note: string }[] = [
  { id: "rumours", label: "Rumours", note: "Buy a drink, buy a word" },
  { id: "postings", label: "General Postings", note: "The board by the door" },
  { id: "hirings", label: "Hirings", note: "Men wanting a berth" },
  { id: "barter", label: "Barter", note: "Goods over the table" },
];

/**
 * The tap-room, as a room: rusted wood and lamp-black, entered from the port
 * and left by the door. Nothing here asks to see your papers.
 */
export function TavernScreen({ onExit }: { onExit: () => void }) {
  const { state, dispatch } = useGame();
  const [room, setRoom] = useState<Room>("rumours");
  const ship = activeShip(state);

  if (!ship || ship.voyage) {
    return (
      <Frame title="At sea" onExit={onExit}>
        <p className="p-6 text-sm text-[oklch(0.78_0.03_75)]">
          There are no taverns at sea. Only the water butt.
        </p>
      </Frame>
    );
  }

  const port = PORT_MAP[ship.portId]!;

  return (
    <Frame title={`The tavern at ${port.name}`} onExit={onExit}>
      <div className="grid gap-4 p-4 lg:grid-cols-[18rem_1fr]">
        <aside className="space-y-3">
          <PortPainting port={port} />
          <p className="text-[11px] leading-relaxed text-[oklch(0.72_0.03_75)]">
            Smoke, small beer and other men's business, under {POWER_MAP[port.power]!.adjective} law and barely that.
            No permits are asked for at this table.
          </p>
          <nav className="grid gap-2">
            {ROOMS.map((r) => (
              <button
                key={r.id}
                type="button"
                onClick={() => setRoom(r.id)}
                className={`rounded-sm border-2 px-3 py-2 text-left transition-colors ${
                  room === r.id
                    ? "border-[oklch(0.62_0.10_60)] bg-[oklch(0.30_0.05_45)]"
                    : "border-[oklch(0.34_0.04_45)] bg-[oklch(0.22_0.03_40)] hover:border-[oklch(0.50_0.07_55)]"
                }`}
              >
                <span className="block font-serif text-base font-semibold text-[oklch(0.90_0.05_80)]">{r.label}</span>
                <span className="block text-[11px] text-[oklch(0.70_0.03_75)]">{r.note}</span>
              </button>
            ))}
          </nav>
        </aside>

        <section className="min-h-[24rem] rounded-sm border-2 border-[oklch(0.34_0.04_45)] bg-[oklch(0.18_0.025_40)]/80 p-4">
          {room === "rumours" && <Rumours />}
          {room === "postings" && <Postings />}
          {room === "hirings" && <Hirings />}
          {room === "barter" && <Barter />}
        </section>
      </div>
    </Frame>
  );
}

/** Rusted-wood ledger: the tavern's own chrome. */
function Frame({ title, children, onExit }: { title: string; children: React.ReactNode; onExit: () => void }) {
  return (
    <div className="fixed inset-0 z-50 flex items-start justify-center overflow-auto bg-[oklch(0.08_0.01_45)]/85 p-3 sm:p-6">
      <div
        className="w-full max-w-6xl rounded-sm border-4 shadow-2xl"
        style={{
          borderColor: "oklch(0.30 0.045 45)",
          background:
            "repeating-linear-gradient(92deg, oklch(0.17 0.022 42) 0 22px, oklch(0.19 0.026 44) 22px 46px)",
          boxShadow: "0 24px 60px oklch(0.05 0.01 40 / 0.7)",
        }}
      >
        <header
          className="flex items-center justify-between gap-3 border-b-4 px-4 py-3"
          style={{
            borderColor: "oklch(0.26 0.04 42)",
            background:
              "linear-gradient(180deg, oklch(0.34 0.06 48), oklch(0.24 0.04 44) 60%, oklch(0.20 0.03 42))",
            boxShadow: "inset 0 -3px 0 oklch(0.42 0.08 55 / 0.35)",
          }}
        >
          <div>
            <h2 className="font-serif text-xl font-semibold tracking-wide text-[oklch(0.92_0.06_82)]">{title}</h2>
            <p className="text-[11px] uppercase tracking-[0.18em] text-[oklch(0.70_0.05_70)]">
              Rumours · Postings · Hirings · Barter
            </p>
          </div>
          <button
            type="button"
            onClick={onExit}
            className="rounded-sm border-2 border-[oklch(0.48_0.08_55)] bg-[oklch(0.26_0.04_44)] px-4 py-2 text-sm font-semibold text-[oklch(0.90_0.05_80)] hover:bg-[oklch(0.32_0.05_48)]"
          >
            Leave the tavern
          </button>
        </header>
        {children}
      </div>
    </div>
  );
}

function Heading({ children, note }: { children: React.ReactNode; note?: string }) {
  return (
    <header className="mb-3">
      <h3 className="font-serif text-lg font-semibold text-[oklch(0.90_0.05_80)]">{children}</h3>
      {note && <p className="text-[11px] text-[oklch(0.70_0.03_75)]">{note}</p>}
    </header>
  );
}

function Rumours() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state)!;
  const port = PORT_MAP[ship.portId]!;
  const price = rumourPrice(port);
  const gossip = state.log.filter((l) => l.kind === "world").slice(0, 6);
  const nearbyEvents = Object.entries(state.portEvents ?? {})
    .filter(([pid]) => pid !== port.id)
    .slice(0, 5);

  return (
    <div className="space-y-4 text-sm text-[oklch(0.84_0.03_78)]">
      <Heading note={`What is afloat within ${RUMOUR_RANGE_NM} sea miles of this coast, for the price of a round.`}>
        Pay for rumours
      </Heading>
      <button
        type="button"
        disabled={state.cash < price}
        onClick={() => dispatch({ type: "buyRumours" })}
        className="rounded-sm border-2 border-[oklch(0.55_0.10_60)] bg-[oklch(0.30_0.06_48)] px-4 py-2 font-semibold text-[oklch(0.93_0.06_82)] disabled:opacity-40"
      >
        Buy a round — {money(price)}
      </button>

      <div>
        <h4 className="mb-1 text-[11px] uppercase tracking-wide text-[oklch(0.68_0.03_75)]">Talk of other ports</h4>
        {nearbyEvents.length === 0 ? (
          <p className="text-xs text-[oklch(0.70_0.03_75)]">Nothing but weather and old grievances tonight.</p>
        ) : (
          <ul className="space-y-1 text-xs">
            {nearbyEvents.map(([pid, ev]) => (
              <li key={pid} className="rounded-sm border border-[oklch(0.32_0.04_45)] bg-[oklch(0.22_0.03_42)] p-2">
                <span className="font-semibold">{PORT_MAP[pid]!.name}:</span> {ev.title.toLowerCase()} — {ev.text}
              </li>
            ))}
          </ul>
        )}
      </div>

      <div>
        <h4 className="mb-1 text-[11px] uppercase tracking-wide text-[oklch(0.68_0.03_75)]">Gossip</h4>
        <ul className="space-y-1 text-xs text-[oklch(0.72_0.03_75)]">
          {gossip.map((g) => (
            <li key={g.id}>{g.text}</li>
          ))}
          {gossip.length === 0 && <li>The room has nothing to say to a stranger.</li>}
        </ul>
      </div>
    </div>
  );
}

function Postings() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state)!;
  const port = PORT_MAP[ship.portId]!;
  const open = state.quests.filter((q) => q.portId === port.id && !q.accepted);
  // The same contract waits on the board at the far end, as a delivery.
  const due = state.quests.filter((q) => q.accepted && q.targetPortId === port.id);
  const elsewhere = state.quests.filter((q) => q.accepted && q.targetPortId !== port.id);
  const freeTons = shipCapacity(ship) - cargoUsed(ship, volumeOf);

  return (
    <div className="space-y-4 text-sm text-[oklch(0.84_0.03_78)]">
      <Heading note="Notes pinned to the board: letters wanting a ship, cargo wanting carriage, factors wanting goods found.">
        General postings
      </Heading>

      {due.length > 0 && (
        <section className="space-y-2">
          <h4 className="font-serif text-sm uppercase tracking-wide text-[oklch(0.86_0.09_80)]">
            For discharge here
          </h4>
          <ul className="grid gap-2">
            {due.map((q) => {
              const short =
                q.kind === "letter"
                  ? 0
                  : Math.max(0, (q.qty ?? 0) - (q.cid ? (ship.cargo[q.cid] ?? 0) : 0));
              const late = state.day > q.dueDay;
              return (
                <li
                  key={q.id}
                  className="rounded-sm border-2 border-[oklch(0.50_0.09_78)] bg-[oklch(0.24_0.04_46)] p-3"
                >
                  <div className="flex flex-wrap items-baseline justify-between gap-2">
                    <span className="font-serif text-base font-semibold text-[oklch(0.93_0.07_82)]">
                      Delivery · {q.title}
                    </span>
                    <span className="numeric text-xs text-[oklch(0.82_0.09_80)]">
                      {money(q.reward - q.advance)} on the table
                    </span>
                  </div>
                  <p className="mt-1 text-xs text-[oklch(0.72_0.03_75)]">
                    {late
                      ? "You are past the day named. He will pay, but he will pay short."
                      : "The factor is expecting you."}
                  </p>
                  <button
                    type="button"
                    disabled={short > 0}
                    onClick={() => dispatch({ type: "deliverQuest", questId: q.id })}
                    className="mt-2 rounded-sm border-2 border-[oklch(0.58_0.11_62)] bg-[oklch(0.33_0.07_50)] px-3 py-1 text-[11px] font-semibold text-[oklch(0.95_0.07_84)] disabled:opacity-40"
                  >
                    {short > 0
                      ? `Short ${unitLabel(q.cid!, short)} of ${COMMODITY_MAP[q.cid!]!.name}`
                      : "Hand it over and take the money"}
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      )}

      {open.length === 0 ? (
        <p className="text-xs text-[oklch(0.70_0.03_75)]">The board is bare tonight. Come back in a week.</p>
      ) : (
        <ul className="grid gap-2">
          {open.map((q) => {
            const blocked = questBlocker(q, ship, freeTons);
            const tons = questTons(q);
            return (
              <li key={q.id} className="rounded-sm border border-[oklch(0.32_0.04_45)] bg-[oklch(0.22_0.03_42)] p-3">
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <span className="flex items-baseline gap-2">
                    <span
                      className="rounded-full px-2 py-0.5 text-[10px] uppercase tracking-wide"
                      style={
                        q.black
                          ? { background: "oklch(0.18 0.02 30)", color: "oklch(0.86 0.10 40)", border: "1px solid oklch(0.45 0.10 35)" }
                          : { background: "oklch(0.36 0.07 60)", color: "oklch(0.93 0.06 84)" }
                      }
                    >
                      {q.black ? "Black work" : KIND_LABEL[q.kind]}
                    </span>
                    <span className="font-serif text-base font-semibold text-[oklch(0.90_0.05_80)]">{q.title}</span>
                  </span>
                  <span className="numeric text-xs text-[oklch(0.78_0.08_80)]">{money(q.reward)} in all</span>
                </div>
                <p className="mt-1 text-xs text-[oklch(0.72_0.03_75)]">{q.text}</p>
                <div className="mt-2 flex flex-wrap items-center justify-between gap-2 text-[11px] text-[oklch(0.70_0.03_75)]">
                  <span className="numeric">
                    {q.advance ? `${money(q.advance)} advance` : "No advance"} · {q.dueDay - state.day} days ·{" "}
                    {q.kind === "letter" ? "no hold space" : `${tons.toFixed(1)} t of hold`}
                  </span>
                  <button
                    type="button"
                    disabled={!!blocked}
                    title={blocked}
                    onClick={() => dispatch({ type: "acceptQuest", questId: q.id })}
                    className="rounded-sm border-2 border-[oklch(0.55_0.10_60)] bg-[oklch(0.30_0.06_48)] px-3 py-1 font-semibold text-[oklch(0.93_0.06_82)] disabled:opacity-40"
                  >
                    {blocked ?? "Take the work"}
                  </button>
                </div>
              </li>
            );
          })}
        </ul>
      )}

      {elsewhere.length > 0 && (
        <p className="text-[11px] text-[oklch(0.70_0.03_75)]">
          In hand elsewhere: {elsewhere.map((q) => q.title).join(" · ")}
        </p>
      )}
    </div>
  );
}

function Hirings() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state)!;
  const port = PORT_MAP[ship.portId]!;
  const pool = state.recruits[port.id] ?? [];
  const aboard = state.crew.filter((c) => c.shipId === ship.id).length;
  const full = aboard >= lodgings(ship);
  const nextMuster = 21 - (state.day % 21);

  return (
    <div className="space-y-3 text-sm text-[oklch(0.84_0.03_78)]">
      <Heading
        note={`Berths taken ${aboard} of ${lodgings(ship)}. A fresh muster gathers here in ${nextMuster} days.`}
      >
        Hirings
      </Heading>
      {pool.length === 0 ? (
        <p className="text-xs text-[oklch(0.70_0.03_75)]">Nobody worth signing tonight.</p>
      ) : (
        <ul className="grid gap-2 xl:grid-cols-2">
          {pool.map((m) => {
            const fee = signingFee(m);
            return (
              <CrewCard
                key={m.id}
                m={m}
                variant="tavern"
                footer={
                  <div className="flex flex-wrap items-center justify-between gap-2 text-xs">
                    <span className="numeric text-muted-foreground">
                      {m.wage} gold/week · signing {money(fee)}
                    </span>
                    <button
                      type="button"
                      disabled={state.cash < fee || full}
                      onClick={() => dispatch({ type: "recruit", memberId: m.id })}
                      className="rounded-sm bg-primary px-3 py-1 text-primary-foreground disabled:opacity-40"
                    >
                      {full ? "No berth free" : "Sign articles"}
                    </button>
                  </div>
                }
              />
            );
          })}
        </ul>
      )}
    </div>
  );
}

function Barter() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state)!;
  const port = PORT_MAP[ship.portId]!;
  const offers = tavernOffers(state, port).filter((o) => o.qty > 0);
  const hold = Object.entries(ship.cargo)
    .filter(([, n]) => n >= 1)
    .map(([cid, n]) => ({ cid, name: COMMODITY_MAP[cid]?.name ?? cid, held: Math.floor(n), bid: tavernBid(state, port, cid) }));

  return (
    <div className="grid gap-4 text-sm text-[oklch(0.84_0.03_78)] xl:grid-cols-2">
      <div>
        <Heading note="What the house has out the back this week. Dearer than the market, and no paper wanted.">
          On offer
        </Heading>
        {offers.length === 0 ? (
          <p className="text-xs text-[oklch(0.70_0.03_75)]">The cellar is bare but for the beer.</p>
        ) : (
          <ul className="space-y-2">
            {offers.map((o) => (
              <TradeRow
                key={o.cid}
                label={o.name}
                tag={o.rare ? "rare" : undefined}
                unitLabel={`${o.unit.toFixed(2)} gold a ${COMMODITY_MAP[o.cid]?.unit ?? "unit"} · ${o.qty} to be had`}
                max={Math.min(o.qty, Math.floor(state.cash / Math.max(1, o.unit)))}
                unit={o.unit}
                action="Buy"
                onConfirm={(qty) => dispatch({ type: "tavernBarterBuy", cid: o.cid, qty })}
              />
            ))}
          </ul>
        )}
      </div>

      <div>
        <Heading note="What is in your hold. He buys cheap — but he buys anything.">Your goods</Heading>
        {hold.length === 0 ? (
          <p className="text-xs text-[oklch(0.70_0.03_75)]">Your hold is empty. Nothing to lay on the table.</p>
        ) : (
          <ul className="space-y-2">
            {hold.map((h) => (
              <TradeRow
                key={h.cid}
                label={h.name}
                unitLabel={`${h.bid.toFixed(2)} gold a ${COMMODITY_MAP[h.cid]?.unit ?? "unit"} offered · ${h.held} aboard`}
                max={h.held}
                unit={h.bid}
                action="Sell"
                onConfirm={(qty) => dispatch({ type: "tavernBarterSell", cid: h.cid, qty })}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function TradeRow({
  label,
  tag,
  unitLabel,
  max,
  unit,
  action,
  onConfirm,
}: {
  label: string;
  tag?: string | undefined;
  unitLabel: string;
  max: number;
  unit: number;
  action: string;
  onConfirm: (qty: number) => void;
}) {
  const cap = Math.max(0, Math.floor(max));
  const [qty, setQty] = useState(Math.min(1, cap));

  return (
    <li className="rounded-sm border border-[oklch(0.32_0.04_45)] bg-[oklch(0.22_0.03_42)] p-2">
      <div className="flex items-baseline justify-between gap-2">
        <span className="font-semibold text-[oklch(0.90_0.05_80)]">
          {label}
          {tag && (
            <span className="ml-1 rounded-sm border border-[oklch(0.62_0.12_80)] px-1 text-[9px] uppercase tracking-wide text-[oklch(0.82_0.10_80)]">
              {tag}
            </span>
          )}
        </span>
        <span className="numeric text-[11px] text-[oklch(0.72_0.03_75)]">{unitLabel}</span>
      </div>
      <div className="mt-2 flex items-center gap-2">
        <input
          type="range"
          min={0}
          max={cap}
          value={Math.min(qty, cap)}
          onChange={(e) => setQty(Number(e.target.value))}
          className="h-1 flex-1 accent-[oklch(0.70_0.12_70)]"
          aria-label={`${action} ${label}`}
        />
        <span className="numeric w-24 text-right text-[11px] text-[oklch(0.78_0.05_78)]">
          {Math.min(qty, cap)} · {money(Math.round(Math.min(qty, cap) * unit))}
        </span>
        <button
          type="button"
          disabled={cap < 1 || qty < 1}
          onClick={() => onConfirm(Math.min(qty, cap))}
          className="rounded-sm border-2 border-[oklch(0.55_0.10_60)] bg-[oklch(0.30_0.06_48)] px-3 py-1 text-xs font-semibold text-[oklch(0.93_0.06_82)] disabled:opacity-40"
        >
          {action}
        </button>
      </div>
    </li>
  );
}
