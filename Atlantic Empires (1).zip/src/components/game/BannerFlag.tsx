import type { Banner, BannerIcon, BannerLayout, BannerPattern } from "@/game/types";

export const BANNER_ICONS: { id: BannerIcon; label: string }[] = [
  { id: "none", label: "No charge" },
  { id: "anchor", label: "Anchor" },
  { id: "skull", label: "Death's head" },
  { id: "lion", label: "Lion's head" },
  { id: "eagle", label: "Displayed eagle" },
  { id: "star", label: "Mullet" },
  { id: "cross", label: "Cross" },
  { id: "sun", label: "Sun in splendour" },
  { id: "ship", label: "Lymphad" },
  { id: "swords", label: "Swords in saltire" },
  { id: "crown", label: "Crown" },
  { id: "key", label: "Keys crossed" },
  { id: "moon", label: "Crescent" },
  { id: "compass", label: "Compass rose" },
  { id: "fleur", label: "Fleur-de-lis" },
  { id: "palm", label: "Palm" },
  { id: "serpent", label: "Serpent" },
  { id: "hourglass", label: "Hourglass" },
  { id: "cannon", label: "Cannon" },
  { id: "tower", label: "Tower" },
  { id: "castle", label: "Castle" },
  { id: "rose", label: "Heraldic rose" },
  { id: "trident", label: "Trident" },
  { id: "wheel", label: "Ship's wheel" },
  { id: "dagger", label: "Dagger" },
  { id: "chalice", label: "Chalice" },
  { id: "oak", label: "Oak leaf" },
  { id: "boar", label: "Boar's head" },
  { id: "bell", label: "Bell" },
  { id: "escallop", label: "Escallop shell" },
  { id: "hammer", label: "Hammer" },
  { id: "arrows", label: "Sheaf of arrows" },
];

export const BANNER_PATTERNS: { id: BannerPattern; label: string }[] = [
  { id: "plain", label: "Plain field" },
  { id: "band", label: "Band at the foot" },
  { id: "fess", label: "Horizontal halves" },
  { id: "pale", label: "Vertical halves" },
  { id: "tricolour", label: "Tricolour (vertical)" },
  { id: "tribar", label: "Tribar (horizontal)" },
  { id: "cross", label: "Cross" },
  { id: "saltire", label: "Saltire" },
  { id: "quarters", label: "Quartered" },
  { id: "bend", label: "Bend" },
  { id: "chevron", label: "Chevron" },
  { id: "border", label: "Bordered" },
  { id: "stripes", label: "Stripes" },
  { id: "canton", label: "Canton" },
  { id: "lozenge", label: "Lozenge" },
];

export const BANNER_LAYOUTS: { id: BannerLayout; label: string }[] = [
  { id: "centre", label: "Centred" },
  { id: "large", label: "Large, centred" },
  { id: "chief", label: "In chief (top)" },
  { id: "base", label: "In base (foot)" },
  { id: "hoist", label: "At the hoist" },
  { id: "fly", label: "At the fly" },
  { id: "canton", label: "In the canton" },
  { id: "twin", label: "Twin, flanking" },
];

function Charge({ icon, color, field }: { icon: BannerIcon; color: string; field: string }) {
  switch (icon) {
    case "anchor":
      return (
        <g fill={color}>
          <path d="M30 8.5a3.6 3.6 0 00-2 6.6V18h-5.6v3.6H28v14.7c-4.2-1-7.2-4.4-7.8-8.6l-4.2 2C17.3 36.6 23 42 30 43c7-1 12.7-6.4 14-13.3l-4.2-2c-.6 4.2-3.6 7.6-7.8 8.6V21.6h5.6V18H32v-2.9a3.6 3.6 0 00-2-6.6z" />
          <circle cx="30" cy="12" r="1.3" fill={field} />
        </g>
      );
    case "skull":
      return (
        <g fill={color}>
          <path d="M30 9c-7 0-12 5-12 12 0 4 1.6 6.4 3 8.2.9 1.2 1.4 2.3 1.4 3.8v2h15.2v-2c0-1.5.5-2.6 1.4-3.8 1.4-1.8 3-4.2 3-8.2 0-7-5-12-12-12z" />
          <path d="M22.5 36h15v2.4h-15zM23.5 39.6h13v2.2h-13z" />
          <circle cx="25.6" cy="21.5" r="3.4" fill={field} />
          <circle cx="34.4" cy="21.5" r="3.4" fill={field} />
          <path d="M30 25.5l2.4 5h-4.8z" fill={field} />
        </g>
      );
    case "lion":
      return (
        <g fill={color}>
          <path d="M30 8c-2.4 0-4.4.8-6 2.2l-3.4-2 .6 4.2c-2 2-3.2 4.8-3.2 8 0 1.6-.9 2.6-2.6 3.4 1.7.9 2.6 2 2.6 3.6 0 6.6 5.4 12.6 12 14.6 6.6-2 12-8 12-14.6 0-1.6.9-2.7 2.6-3.6-1.7-.8-2.6-1.8-2.6-3.4 0-3.2-1.2-6-3.2-8l.6-4.2-3.4 2C34.4 8.8 32.4 8 30 8z" />
          <circle cx="26" cy="22" r="1.7" fill={field} />
          <circle cx="34" cy="22" r="1.7" fill={field} />
          <path d="M27 29h6l-3 3.4z" fill={field} />
        </g>
      );
    case "eagle":
      return (
        <path
          fill={color}
          d="M30 9c-2 0-3.4 1.4-3.4 3.2 0 1 .4 1.8 1 2.4L26 18 12 14l8 9-6 1 9 5-4 2 10 2-3 4h5v6h-2v2h10v-2h-2v-6h5l-3-4 10-2-4-2 9-5-6-1 8-9-14 4-1.6-3.4c.6-.6 1-1.4 1-2.4C33.4 10.4 32 9 30 9z"
        />
      );
    case "star":
      return <path fill={color} d="M30 8l5.6 12.2L48.6 21.8l-9.5 9 2.5 13.2L30 37.4 18.4 44l2.5-13.2-9.5-9 13-1.6z" />;
    case "cross":
      return <path fill={color} d="M26.4 8h7.2v14.4H48v7.2H33.6V44h-7.2V29.6H12v-7.2h14.4z" />;
    case "sun":
      return (
        <g fill={color}>
          <circle cx="30" cy="26" r="8.6" />
          {Array.from({ length: 16 }).map((_, i) => (
            <path key={i} d="M30 5.5l2 6.5h-4z" transform={`rotate(${i * 22.5} 30 26)`} />
          ))}
        </g>
      );
    case "ship":
      return (
        <g fill={color}>
          <path d="M12 33h36l-5 9H17z" />
          <path d="M28.6 8h2.8v24h-2.8z" />
          <path d="M31.4 10l11 6-11 5z" />
          <path d="M28.6 18l-9.6 4.6 9.6 4.4z" />
        </g>
      );
    case "swords":
      return (
        <g fill={color}>
          <g>
            <path d="M15 9l4-2 22 27-3 3z" />
            <path d="M45 9l-4-2-22 27 3 3z" />
          </g>
          <rect x="13" y="36" width="10" height="3" rx="1" transform="rotate(-45 18 37.5)" />
          <rect x="37" y="36" width="10" height="3" rx="1" transform="rotate(45 42 37.5)" />
        </g>
      );
    case "crown":
      return (
        <g fill={color}>
          <path d="M13 36l-2.4-19 9.6 8L30 11l9.8 14 9.6-8L47 36z" />
          <rect x="12" y="38" width="36" height="5" rx="1" />
          <circle cx="10.6" cy="15.4" r="2.4" />
          <circle cx="49.4" cy="15.4" r="2.4" />
          <circle cx="30" cy="8.6" r="2.6" />
        </g>
      );
    case "key":
      return (
        <g fill={color}>
          {[-28, 28].map((a) => (
            <g key={a} transform={`rotate(${a} 30 26)`}>
              <path d="M28.4 18h3.2v22h-3.2z" />
              <path d="M31.6 32h5v3h-5zM31.6 37h4v3h-4z" />
              <circle cx="30" cy="14" r="5.6" />
              <circle cx="30" cy="14" r="2.2" fill={field} />
            </g>
          ))}
        </g>
      );
    case "moon":
      return <path fill={color} d="M38 8a17 17 0 100 36 14 14 0 010-36z" />;
    case "compass":
      return (
        <g fill={color}>
          <path d="M30 7l4.4 14.6L49 26l-14.6 4.4L30 45l-4.4-14.6L11 26l14.6-4.4z" />
          <path d="M40.6 15.4l-3.4 8-8 3.4 3.4-8zM19.4 36.6l3.4-8 8-3.4-3.4 8z" opacity="0.85" />
          <circle cx="30" cy="26" r="2.4" fill={field} />
        </g>
      );
    case "fleur":
      return (
        <path
          fill={color}
          d="M30 7c-3.4 4.6-4.6 9-2.6 13.6-4-3.4-9-3-11 .8-2 3.8.4 8.4 5 9.4-2.6.4-4.4 1.6-5.4 3.2h28c-1-1.6-2.8-2.8-5.4-3.2 4.6-1 7-5.6 5-9.4-2-3.8-7-4.2-11-.8C34.6 16 33.4 11.6 30 7zM20 36.6h20v3.2H20zM26.6 41h6.8v4h-6.8z"
        />
      );
    case "palm":
      return (
        <g fill={color}>
          <path d="M28.6 22h3.2l1.4 22h-6z" />
          <path d="M30 20c-5-7-13-7-17-1 5-2.4 10-1.6 15 2.6zM30 20c5-7 13-7 17-1-5-2.4-10-1.6-15 2.6zM30 19c-1-8 3-12.6 8-14-3.6 4-4.6 8.6-4 14z" />
        </g>
      );
    case "serpent":
      return (
        <g fill={color}>
          <path d="M13 41c9 0 8-11 15-11s7-11 15-11v4c-5 0-4 11-15 11s-6 11-15 11z" />
          <circle cx="45" cy="17" r="4" />
          <circle cx="46" cy="16" r="1.2" fill={field} />
        </g>
      );
    case "hourglass":
      return (
        <g fill={color}>
          <rect x="16" y="8" width="28" height="3.6" />
          <rect x="16" y="40.4" width="28" height="3.6" />
          <path d="M19 11.6h22L30 26l11 14.4H19L30 26z" />
        </g>
      );
    case "cannon":
      return (
        <g fill={color}>
          <path d="M14 24h27v8H14z" />
          <path d="M41 25h8v6h-8z" />
          <path d="M12 32h30l-3 5H15z" />
          <circle cx="19" cy="39" r="5" />
          <circle cx="19" cy="39" r="1.6" fill={field} />
          <circle cx="35" cy="39" r="5" />
          <circle cx="35" cy="39" r="1.6" fill={field} />
        </g>
      );
    case "tower":
      return (
        <g fill={color}>
          <path d="M18 12h4v4h4v-4h4v4h4v-4h4v6H18z" />
          <path d="M20 18h20v26H20z" />
          <path d="M27 30h6v14h-6z" fill={field} />
        </g>
      );
    case "castle":
      return (
        <g fill={color}>
          <path d="M8 18h4v-4h4v4h4v-4h4v4h4v-4h4v4h4v-4h4v4h4v-4h4v4h4v26H8z" />
          <path d="M26 30h8v14h-8z" fill={field} />
          <rect x="14" y="24" width="5" height="6" fill={field} />
          <rect x="41" y="24" width="5" height="6" fill={field} />
        </g>
      );
    case "rose":
      return (
        <g fill={color}>
          {Array.from({ length: 5 }).map((_, i) => (
            <ellipse key={i} cx="30" cy="14" rx="6.4" ry="7.4" transform={`rotate(${i * 72} 30 26)`} />
          ))}
          <circle cx="30" cy="26" r="5.6" fill={field} />
          <circle cx="30" cy="26" r="3.2" fill={color} />
        </g>
      );
    case "trident":
      return (
        <g fill={color}>
          <path d="M28.6 14h2.8v30h-2.8z" />
          <path d="M14 12h3.6v10c0 5 3.4 8.6 8.4 9.4v3.6C18.8 34 14 29 14 22z" />
          <path d="M46 12h-3.6v10c0 5-3.4 8.6-8.4 9.4v3.6C41.2 34 46 29 46 22z" />
          <path d="M26.4 8h7.2v8h-7.2z" />
        </g>
      );
    case "wheel":
      return (
        <g fill={color}>
          <path d="M30 9a17 17 0 100 34 17 17 0 000-34zm0 5a12 12 0 110 24 12 12 0 010-24z" />
          {Array.from({ length: 8 }).map((_, i) => (
            <rect key={i} x="28.6" y="8" width="2.8" height="36" transform={`rotate(${i * 22.5} 30 26)`} />
          ))}
          <circle cx="30" cy="26" r="4.4" />
        </g>
      );
    case "dagger":
      return (
        <g fill={color}>
          <path d="M30 6l4 8v18h-8V14z" />
          <rect x="20" y="32" width="20" height="3.4" rx="1" />
          <rect x="28.4" y="35.4" width="3.2" height="7" />
          <circle cx="30" cy="44" r="2.6" />
        </g>
      );
    case "chalice":
      return (
        <g fill={color}>
          <path d="M18 12h24c0 9-4.4 15-9 16.6V36h7v4H20v-4h7v-7.4C22.4 27 18 21 18 12z" />
          <rect x="18" y="42" width="24" height="3" />
        </g>
      );
    case "oak":
      return (
        <path
          fill={color}
          d="M30 7c-4 3-6 6-6 9-3-1-6 0-7 2 2 1 3 2 3 4-3 0-5 2-5 4 2 1 3 2 3 4-2 1-3 3-2 5 3 1 6 0 8-2 1 3 3 5 5 6v6h2v-6c2-1 4-3 5-6 2 2 5 3 8 2 1-2 0-4-2-5 0-2 1-3 3-4 0-2-2-4-5-4 0-2 1-3 3-4-1-2-4-3-7-2 0-3-2-6-6-9z"
        />
      );
    case "boar":
      return (
        <g fill={color}>
          <path d="M12 30c0-9 7-16 16-16 7 0 12 3 15 8l5 2-3 4 3 3-6 2c-2 6-8 10-14 10-9 0-16-5-16-13z" />
          <circle cx="26" cy="25" r="1.8" fill={field} />
          <path d="M40 32l6 6-7-2zM36 34l4 8-6-4z" />
        </g>
      );
    case "bell":
      return (
        <g fill={color}>
          <path d="M30 8a3 3 0 00-2 5.2C22 15 19 20 19 27c0 5-1 8-3 10h28c-2-2-3-5-3-10 0-7-3-12-9-13.8A3 3 0 0030 8z" />
          <rect x="14" y="39" width="32" height="3.4" rx="1" />
          <circle cx="30" cy="45" r="2.8" />
        </g>
      );
    case "escallop":
      return (
        <g fill={color}>
          <path d="M30 44c-10 0-18-8-18-18l6-4 4 4 4-5 4 5 4-5 4 5 4-4 6 4c0 10-8 18-18 18z" />
          <path d="M30 42v-16M24 41l3-15M36 41l-3-15" stroke={field} strokeWidth="1.4" fill="none" />
        </g>
      );
    case "hammer":
      return (
        <g fill={color}>
          <path d="M14 12h32v10H14z" />
          <path d="M26.6 22h6.8v22h-6.8z" />
        </g>
      );
    case "arrows":
      return (
        <g fill={color}>
          {[-22, 0, 22].map((a) => (
            <g key={a} transform={`rotate(${a} 30 30)`}>
              <rect x="28.8" y="12" width="2.4" height="30" />
              <path d="M30 6l4 8h-8z" />
              <path d="M26 42h8l-4 4z" />
            </g>
          ))}
          <rect x="17" y="30" width="26" height="3.4" rx="1.4" />
        </g>
      );
    default:
      return null;
  }
}

const LAYOUTS: Record<BannerLayout, { x: number; y: number; s: number }[]> = {
  centre: [{ x: 0, y: 0, s: 0.95 }],
  large: [{ x: 0, y: 0, s: 1.25 }],
  chief: [{ x: 0, y: -10, s: 0.62 }],
  base: [{ x: 0, y: 11, s: 0.62 }],
  hoist: [{ x: -15, y: 0, s: 0.66 }],
  fly: [{ x: 15, y: 0, s: 0.66 }],
  canton: [{ x: -16, y: -13, s: 0.46 }],
  twin: [
    { x: -13, y: 0, s: 0.56 },
    { x: 13, y: 0, s: 0.56 },
  ],
};

function Field({ pattern, band }: { pattern: BannerPattern; band: string }) {
  switch (pattern) {
    case "band":
      return (
        <>
          <rect y="38" width="60" height="14" fill={band} />
          <rect y="0" width="60" height="4" fill={band} opacity="0.7" />
        </>
      );
    case "fess":
      return <rect y="26" width="60" height="26" fill={band} />;
    case "pale":
      return <rect x="30" width="30" height="52" fill={band} />;
    case "tricolour":
      return <rect x="20" width="20" height="52" fill={band} />;
    case "tribar":
      return <rect y="17.3" width="60" height="17.4" fill={band} />;
    case "cross":
      return (
        <>
          <rect x="21" width="10" height="52" fill={band} />
          <rect y="21" width="60" height="10" fill={band} />
        </>
      );
    case "saltire":
      return (
        <g stroke={band} strokeWidth="9">
          <path d="M0 0L60 52M60 0L0 52" />
        </g>
      );
    case "quarters":
      return (
        <>
          <rect width="30" height="26" fill={band} />
          <rect x="30" y="26" width="30" height="26" fill={band} />
        </>
      );
    case "bend":
      return <path d="M0 0L14 0L60 44L60 52L46 52L0 8z" fill={band} />;
    case "chevron":
      return <path d="M0 52L30 20L60 52L60 42L30 10L0 42z" fill={band} />;
    case "border":
      return <rect x="3" y="3" width="54" height="46" fill="none" stroke={band} strokeWidth="6" />;
    case "stripes":
      return (
        <>
          {[0, 1, 2, 3].map((i) => (
            <rect key={i} y={6 + i * 12} width="60" height="6" fill={band} />
          ))}
        </>
      );
    case "canton":
      return <rect width="26" height="22" fill={band} />;
    case "lozenge":
      return <path d="M30 4L54 26L30 48L6 26z" fill={band} />;
    default:
      return null;
  }
}

export function BannerFlag({
  banner,
  className = "",
  title,
  hoisted = false,
}: {
  banner: Banner;
  className?: string;
  title?: string;
  hoisted?: boolean;
}) {
  const [field, band, charge] = banner.colors ?? [banner.color ?? "#333", "#000", "#fff"];
  const pattern: BannerPattern = banner.pattern ?? "band";
  const layout: BannerLayout = banner.layout ?? "centre";
  const spots = LAYOUTS[layout] ?? LAYOUTS.centre;

  const design = (
    <g>
      <rect x="0" y="0" width="60" height="52" fill={field} />
      <Field pattern={pattern} band={band} />
      {spots.map((sp, i) => (
        <g key={i} transform={`translate(${30 + sp.x} ${26 + sp.y}) scale(${sp.s}) translate(-30 -26)`}>
          <Charge icon={banner.icon ?? "none"} color={charge} field={field} />
        </g>
      ))}
    </g>
  );

  return (
    <svg
      viewBox={hoisted ? "-10 -10 74 64" : "0 0 60 52"}
      role="img"
      aria-label={title ?? `${banner.name} colours`}
      className={hoisted ? className : `rounded-[2px] border border-border/70 ${className}`}
      preserveAspectRatio="xMidYMid meet"
    >
      {hoisted && (
        <g>
          {/* staff */}
          <rect x="-7" y="-8" width="3.2" height="68" rx="1.4" fill="#5c4a3a" />
          <rect x="-6.4" y="-8" width="1.1" height="68" fill="#8a7358" opacity="0.5" />
          <circle cx="-5.4" cy="-8.4" r="2.4" fill="#bfa36f" />
          {/* lashings */}
          {[4, 16, 29, 43].map((y, i) => (
            <rect key={y} x="-6.2" y={y} width={6.4 - i * 0.4} height="1.7" rx="0.85" fill="#3d3226" />
          ))}
        </g>
      )}

      <g transform={hoisted ? "translate(0, 0)" : undefined}>{design}</g>
    </svg>
  );
}
