import {
  DIPLOMACY_REPUTATION,
  PERMIT_KINDS,
  diplomacyOpen,
  permitEligible,
  permitGrant,
  permitPrice,
} from "@/game/data/permits";
import { FactionWeb } from "@/components/game/FactionWeb";
import { FactionFlag } from "@/components/game/FactionFlag";
import { POWERS } from "@/game/data/powers";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";

function standing(v: number) {
  if (v > 60) return "Favoured";
  if (v > 25) return "Friendly";
  if (v > -10) return "Neutral";
  if (v > -45) return "Suspicious";
  return "Hostile";
}

export function DiplomacyPanel() {
  const { state, dispatch } = useGame();
  const open = diplomacyOpen(state);

  return (
    <div className="space-y-4 p-4">
      <section className="panel p-4">
        <h1 className="font-semibold">The courts and the crowns</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Presents are always welcome. Licences, commissions and a nation&apos;s own shipwrights are not opened to a
          merchant nobody has heard of — you need a standing of {DIPLOMACY_REPUTATION} reputation before consuls will
          treat with you at all.
        </p>
        <p className="mt-2 text-xs">
          Your reputation:{" "}
          <span className={`numeric ${open ? "text-profit" : "text-loss"}`}>{Math.round(state.reputation)}</span>
          {!open && " — discharge contracts and pay your debts to be received."}
        </p>
      </section>

      <section className="panel p-4">
        <h2 className="font-semibold">The courts among themselves</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          What the crowns think of each other decides where their squadrons fire and where they escort. War is declared
          at −50; at +50 they fight side by side.
        </p>
        <div className="mt-3">
          <FactionWeb />
        </div>
      </section>


      <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
        {POWERS.map((p) => {
          const rel = state.relations[p.id] ?? 0;
          return (
            <section key={p.id} className="panel space-y-3 p-4">
              <div className="flex items-center gap-2">
                <span className="w-7 shrink-0">
                  <FactionFlag power={p.id} title={p.name} />
                </span>
                <h2 className="font-semibold">{p.name}</h2>
              </div>
              <p className="text-xs text-muted-foreground">{p.note}</p>
              <div>
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>{standing(rel)}</span>
                  <span className="numeric">{Math.round(rel)}</span>
                </div>
                <div className="mt-1 h-2 rounded-sm bg-secondary">
                  <div
                    className="h-full rounded-sm"
                    style={{
                      width: `${(Math.max(-100, Math.min(100, rel)) + 100) / 2}%`,
                      background: rel < -20 ? "var(--color-loss)" : rel > 20 ? "var(--color-profit)" : "var(--color-brass)",
                    }}
                  />
                </div>
              </div>

              <div className="flex flex-wrap gap-2">
                <button
                  type="button"
                  disabled={state.cash < 4000}
                  onClick={() => dispatch({ type: "gift", power: p.id, amount: 4000 })}
                  className="rounded-sm border border-input px-2 py-1 text-xs disabled:opacity-40"
                >
                  Present of {money(4000)}
                </button>
                {p.id !== "pirate" && (
                  <button
                    type="button"
                    disabled={!open || state.letters.includes(p.id) || rel < 0 || state.cash < 12000}
                    onClick={() => dispatch({ type: "letterOfMarque", power: p.id })}
                    className="rounded-sm border border-input px-2 py-1 text-xs disabled:opacity-40"
                  >
                    {state.letters.includes(p.id) ? "Commission held" : `Letter of marque · ${money(12000)}`}
                  </button>
                )}
              </div>

              {p.id !== "pirate" && (
                <div className="space-y-1.5">
                  <h3 className="text-[11px] font-semibold uppercase tracking-wide text-muted-foreground">
                    Licences of the custom house <span className="normal-case">(one year and a day)</span>
                  </h3>
                  {PERMIT_KINDS.map((kind) => {
                    const grant = permitGrant(state, p.id, kind.id);
                    const price = permitPrice(p.id, kind.id);
                    const eligible = permitEligible(state, p.id, kind.id) && state.cash >= price;
                    const daysLeft = grant ? grant.expiresDay - state.day : 0;
                    return (
                      <div key={kind.id} className="flex items-center justify-between gap-2 text-xs">
                        <div>
                          <div>{kind.name}</div>
                          <div className="text-[11px] text-muted-foreground">
                            {grant
                              ? `Held — ${daysLeft} days to run`
                              : `${kind.note} Needs ${kind.minRelation} standing · ${kind.minReputation} reputation.`}
                          </div>
                        </div>
                        <button
                          type="button"
                          disabled={!eligible || (!!grant && daysLeft > 60)}
                          onClick={() => dispatch({ type: "buyPermit", power: p.id, kind: kind.id })}
                          className="shrink-0 rounded-sm border border-input px-2 py-1 disabled:opacity-40"
                        >
                          {grant ? `Renew · ${money(price)}` : money(price)}
                        </button>
                      </div>
                    );
                  })}
                </div>
              )}

            </section>
          );
        })}
      </div>
    </div>
  );
}
