import bond from "@/assets/hud/bond.png";
import hat from "@/assets/hud/hat.png";
import journal from "@/assets/hud/journal.png";
import logbook from "@/assets/hud/logbook.png";
import medicine from "@/assets/hud/medicine.png";
import provisions from "@/assets/hud/provisions.png";
import purse from "@/assets/hud/purse.png";
import salvage from "@/assets/hud/salvage.png";
import shipArt from "@/assets/hud/ship.png";

/** Painted 17th-century objects used in the ledger head, in place of line icons. */
const ART = {
  ship: { src: shipArt, alt: "Painting of a full-rigged ship" },
  hat: { src: hat, alt: "Painting of a captain's tricorne" },
  purse: { src: purse, alt: "Painting of a coin purse" },
  bond: { src: bond, alt: "Painting of a sealed parchment bond" },
  provisions: { src: provisions, alt: "Painting of a bread loaf and salt meat" },
  medicine: { src: medicine, alt: "Painting of an apothecary bottle" },
  salvage: { src: salvage, alt: "Painting of an anchor and timber" },
  logbook: { src: logbook, alt: "Painting of a clasped log book" },
  journal: { src: journal, alt: "Painting of an open journal" },
} as const;

export type HudArtName = keyof typeof ART;

export function HudArt({ name, className = "size-8" }: { name: HudArtName; className?: string }) {
  const a = ART[name];
  return (
    <img
      src={a.src}
      alt={a.alt}
      loading="lazy"
      width={512}
      height={512}
      className={`${className} shrink-0 object-contain drop-shadow-[0_1px_2px_rgba(0,0,0,0.6)]`}
    />
  );
}
