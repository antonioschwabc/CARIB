import { activeShip } from "@/game/actions";
import { COMMODITY_MAP, unitLabel } from "@/game/data/commodities";
import { PORT_MAP } from "@/game/data/ports";
import { CONTRACT_GRACE } from "@/game/sim/tick";
import { StandingPanel } from "./StandingPanel";
import { questTons } from "@/game/sim/quests";
import { formatDate, money } from "@/game/sim/util";
import { useGame } from "@/game/store";
import type { LogKind, Quest } from "@/game/types";

const KIND_LABEL: Record<LogKind, string> = {
  trade: "Trade",
  voyage: "Voyage",
  world: "World",
  peril: "Peril",
  money: "Money",
};

const QUEST_LABEL: Record<Quest["kind"], string> = {
  letter: "Letters",
  cargo: "Courier",
  procure: "Procurement",
};

/**
 * The captain's own book: the contracts he owes, the state of his name, and
 * the day-by-day account of everything that has happened to him.
 */
export function JournalPanel() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const taken = state.quests.filter((q) => q.accepted);

  return (
    <div className="grid gap-4 p-4 xl:grid-cols-[1.05fr_1fr]">
      <div className="space-y-4">
        <section className="panel space-y-3 p-4">
          <header>
            <h2 className="text-lg font-semibold">Contracts owed ({taken.length})</h2>
            <p className="text-xs text-muted-foreground">
              Work taken at a tavern board is discharged at the tavern of the port named. Mark one and it is drawn on
              your chart.
            </p>
          </header>

          {taken.length === 0 ? (
            <p className="text-sm text-muted-foreground">No man is waiting on you but the chandler.</p>
          ) : (
            <ul className="space-y-2">
              {taken.map((q) => {
                const to = q.targetPortId ? PORT_MAP[q.targetPortId] : undefined;
                const left = q.dueDay - state.day;
                const forfeitIn = q.dueDay + CONTRACT_GRACE - state.day;
                const tracking = state.trackedQuestId === q.id;
                const here = !!ship && q.targetPortId === ship.portId && !ship.voyage;
                const sealed = q.kind === "cargo" && q.cid ? (ship?.locked?.[q.cid] ?? 0) : 0;
                return (
                  <li key={q.id} className="rounded-sm border border-border p-3">
                    <div className="flex flex-wrap items-baseline gap-2">
                      <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[10px] uppercase tracking-wide text-accent">
                        {q.black ? "Black work" : QUEST_LABEL[q.kind]}
                      </span>
                      <span className="font-semibold">{q.title}</span>
                      <span
                        className={`numeric ml-auto text-[11px] ${left < 0 ? "text-loss" : "text-muted-foreground"}`}
                      >
                        {left >= 0 ? `${left} days left` : `${forfeitIn} days before it is written off`}
                      </span>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">{q.text}</p>

                    <dl className="mt-2 grid grid-cols-2 gap-x-3 gap-y-1 text-[11px] sm:grid-cols-4">
                      <Fact label="Land it at" value={to?.name ?? "—"} />
                      <Fact label="Day named" value={formatDate(q.dueDay)} />
                      <Fact label="Still to pay" value={money(Math.max(0, q.reward - q.advance))} />
                      <Fact
                        label="In the hold"
                        value={
                          q.kind === "letter"
                            ? "papers only"
                            : q.cid
                              ? `${unitLabel(q.cid, q.qty ?? 0)} of ${COMMODITY_MAP[q.cid]?.name ?? "goods"} · ${questTons(q).toFixed(1)} t`
                              : "—"
                        }
                      />
                    </dl>

                    {q.kind === "cargo" && (
                      <p className="mt-1 text-[11px] text-muted-foreground">
                        {sealed > 0
                          ? q.black
                            ? "Sealed as contraband: it cannot be sold, eaten, physicked or broken up — and a customs boat that finds it will take the lot."
                            : "Sealed under contract: it cannot be sold, eaten, physicked or broken up for salvage."
                          : "The sealed parcel is no longer aboard this ship."}
                      </p>
                    )}

                    <div className="mt-2 flex flex-wrap items-center gap-2">
                      <button
                        type="button"
                        onClick={() => dispatch({ type: "trackQuest", questId: q.id })}
                        className={`rounded-sm px-2 py-1 text-xs ${
                          tracking ? "bg-primary text-primary-foreground" : "border border-input"
                        }`}
                      >
                        {tracking ? "Tracked on chart" : "Track on chart"}
                      </button>
                      <button
                        type="button"
                        disabled={!here}
                        title={here ? undefined : "Deliver at the tavern of the port named"}
                        onClick={() => dispatch({ type: "deliverQuest", questId: q.id })}
                        className="rounded-sm bg-accent px-2 py-1 text-xs text-accent-foreground disabled:opacity-40"
                      >
                        {here ? "Deliver here" : "Deliver at destination"}
                      </button>
                      <button
                        type="button"
                        onClick={() => dispatch({ type: "abandonQuest", questId: q.id })}
                        className="ml-auto rounded-sm border border-destructive/60 px-2 py-1 text-xs text-loss"
                        title="Keep the goods, lose your standing"
                      >
                        Abandon
                      </button>
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </section>

        <StandingPanel />
      </div>

      <section className="panel max-h-[74vh] overflow-auto p-4">
        <h2 className="mb-3 font-semibold">Journal</h2>
        <ol className="space-y-2">
          {state.log.map((e) => (
            <li key={e.id} className="border-b border-border/50 pb-2 text-sm">
              <div className="flex items-baseline gap-2 text-xs text-muted-foreground">
                <span className="numeric">{formatDate(e.day)}</span>
                <span
                  className="rounded-sm px-1 uppercase tracking-wide"
                  style={{
                    background: e.kind === "peril" ? "var(--color-destructive)" : "var(--color-secondary)",
                    color:
                      e.kind === "peril" ? "var(--color-destructive-foreground)" : "var(--color-secondary-foreground)",
                  }}
                >
                  {KIND_LABEL[e.kind]}
                </span>
              </div>
              <p className="mt-0.5 leading-relaxed">{e.text}</p>
            </li>
          ))}
        </ol>
      </section>
    </div>
  );
}

function Fact({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="uppercase tracking-wide text-muted-foreground">{label}</dt>
      <dd className="numeric">{value}</dd>
    </div>
  );
}
