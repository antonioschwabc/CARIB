import { useMemo, useState } from "react";

import { TravelGuide } from "@/components/game/TravelGuide";
import { activeShip } from "@/game/actions";
import { PORTS, portVisible } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { distanceBetween, portDestination, shipPos } from "@/game/sim/position";
import { useGame } from "@/game/store";
import type { Destination } from "@/game/types";

/** The wheel itself: spin it for a list of every harbour on the chart. */
export function RudderMenu() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [dest, setDest] = useState<Destination | undefined>();
  const here = ship ? shipPos(ship) : { lat: 0, lon: 0 };

  const list = useMemo(() => {
    const q = query.trim().toLowerCase();
    return PORTS.filter(portVisible).filter((p) => !q || p.name.toLowerCase().includes(q) || p.region.toLowerCase().includes(q))
      .map((p) => ({ p, d: distanceBetween(here, p) }))
      .sort((a, b) => a.d - b.d);
  }, [query, here.lat, here.lon, (state.knownPorts ?? []).join(",")]);

  if (!ship) return null;

  return (
    <div className="relative shrink-0">
      <div className="flex items-center gap-2">
        <button
          type="button"
          aria-label={ship.underway ? "Rudder released — click to lock and stay put" : "Rudder locked — click to release and sail"}
          title={
            ship.voyage
              ? "Under way"
              : ship.underway
                ? "Rudder released — click to lock her in place"
                : "Rudder locked — click to release and sail"
          }
          disabled={!ship.voyage && !ship.course}
          onClick={() => dispatch({ type: "setRudder", underway: !ship.underway })}
          className="block disabled:opacity-50"
        >
          <Rudder spinning={!!ship.voyage} swaying={!ship.voyage && !!ship.underway} />
        </button>
        <div className="text-[11px] leading-tight">
          <button
            type="button"
            aria-expanded={open}
            onClick={() => setOpen((o) => !o)}
            className="flex items-center gap-1 rounded-sm border border-[oklch(0.52_0.10_75)]/60 bg-[oklch(0.18_0.03_45)] px-2 py-0.5 text-[11px] font-semibold uppercase tracking-wide text-[oklch(0.90_0.10_85)]"
          >
            Set course for
            <span aria-hidden className={`transition-transform ${open ? "rotate-180" : ""}`}>
              ▾
            </span>
          </button>
          <div className="mt-0.5 text-[10px] text-[oklch(0.80_0.05_80)]">
            Course:{" "}
            <span className="numeric font-semibold">
              {ship.voyage ? ship.voyage.label : ship.course ? ship.course.label : "none laid"}
            </span>{" "}
            · ETA:{" "}
            <span className="numeric font-semibold">
              {ship.voyage ? `${ship.voyage.daysLeft}d` : ship.underway ? "sails at dawn" : "—"}
            </span>
          </div>
        </div>
      </div>

      {open && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setOpen(false)} />
          <div className="absolute left-0 top-full z-50 mt-2 max-h-[60vh] w-72 overflow-auto rounded-sm border border-[oklch(0.52_0.10_75)]/60 bg-[oklch(0.16_0.03_45)] p-2 shadow-xl">
            <input
              autoFocus
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search harbours…"
              className="mb-2 w-full rounded-sm border border-input bg-background px-2 py-1 text-xs"
            />
            {list.map(({ p, d }) => (
              <button
                key={p.id}
                type="button"
                onClick={() => {
                  setDest(portDestination(p.id));
                  setOpen(false);
                }}
                className="flex w-full items-baseline justify-between gap-2 rounded-sm px-2 py-1 text-left text-xs hover:bg-secondary"
              >
                <span>
                  {p.name}{" "}
                  <span className="text-muted-foreground">· {POWER_MAP[p.power]!.adjective}</span>
                </span>
                <span className="numeric text-muted-foreground">{d.toLocaleString("en-GB")} nm</span>
              </button>
            ))}
            {!list.length && <p className="px-2 py-1 text-xs text-muted-foreground">No such harbour.</p>}
          </div>
        </>
      )}

      {dest && <TravelGuide dest={dest} onClose={() => setDest(undefined)} />}
    </div>
  );
}

/** The wheel. Spinning at sea, swaying when released, still when locked. */
export function Rudder({ spinning, swaying }: { spinning: boolean; swaying?: boolean }) {
  return (
    <svg
      viewBox="0 0 100 100"
      className={`h-14 w-14 drop-shadow transition-transform hover:scale-105 ${
        spinning ? "animate-spin" : swaying ? "rudder-sway" : ""
      }`}
      style={spinning ? { animationDuration: "6s" } : undefined}
      aria-hidden
    >
      <g stroke="oklch(0.72 0.09 70)" strokeWidth="6" fill="none">
        {[0, 45, 90, 135].map((a) => (
          <line
            key={a}
            x1={50 - 44 * Math.cos((a * Math.PI) / 180)}
            y1={50 - 44 * Math.sin((a * Math.PI) / 180)}
            x2={50 + 44 * Math.cos((a * Math.PI) / 180)}
            y2={50 + 44 * Math.sin((a * Math.PI) / 180)}
            strokeLinecap="round"
          />
        ))}
        <circle cx="50" cy="50" r="30" strokeWidth="9" stroke="oklch(0.55 0.09 55)" />
      </g>
      <circle cx="50" cy="50" r="11" fill="oklch(0.82 0.12 80)" />
    </svg>
  );
}
