import {
  Anchor,
  Beef,
  Bolt,
  Candy,
  Coffee,
  Coins,
  Croissant,
  Cylinder,
  Feather,
  Fish,
  Flame,
  Gem,
  Grape,
  Hammer,
  Leaf,
  Package,
  Palette,
  Ribbon,
  Scissors,
  Shell,
  Shirt,
  Sparkles,
  Swords,
  TreePine,
  Wheat,
  Wine,
  type LucideIcon,
} from "lucide-react";

import type { CommodityCategory } from "@/game/types";

const BY_ID: Record<string, LucideIcon> = {
  sugar: Candy,
  molasses: Cylinder,
  tobacco: Leaf,
  cotton: Feather,
  indigo: Palette,
  cacao: Coffee,
  coffee: Coffee,
  ginger: Wheat,
  dyewood: TreePine,
  hides: Package,
  tortoiseshell: Shell,
  pearls: Sparkles,
  silver: Coins,
  gold: Coins,
  copper: Bolt,
  iron: Hammer,
  rum: Wine,
  wine: Grape,
  brandy: Wine,
  salt: Cylinder,
  saltfish: Fish,
  flour: Croissant,
  saltbeef: Beef,
  cloth: Shirt,
  linen: Scissors,
  tools: Hammer,
  muskets: Swords,
  powder: Flame,
  canvas: Ribbon,
  cordage: Anchor,
  timber: TreePine,
  pitch: Cylinder,
  spices: Sparkles,
  silk: Gem,
};

const BY_CATEGORY: Record<CommodityCategory, LucideIcon> = {
  agricultural: Wheat,
  alcohol: Wine,
  food: Beef,
  raw: TreePine,
  metals: Coins,
  manufactured: Hammer,
  luxury: Gem,
  naval: Anchor,
  contraband: Swords,
};

/** Tailwind-safe tinted tile per category, using chart tokens. */
const TINT: Record<CommodityCategory, string> = {
  agricultural: "bg-chart-3/15 text-chart-3",
  alcohol: "bg-chart-5/15 text-chart-5",
  food: "bg-chart-4/20 text-chart-4",
  raw: "bg-chart-1/15 text-chart-1",
  metals: "bg-brass/20 text-brass",
  manufactured: "bg-chart-2/15 text-chart-2",
  luxury: "bg-chart-5/20 text-chart-5",
  naval: "bg-chart-2/20 text-chart-2",
  contraband: "bg-destructive/15 text-destructive",
};

export function CommodityIcon({
  id,
  category,
  size = "md",
}: {
  id: string;
  category: CommodityCategory;
  size?: "sm" | "md" | "lg";
}) {
  const Icon = BY_ID[id] ?? BY_CATEGORY[category];
  const box = size === "lg" ? "size-10" : size === "sm" ? "size-6" : "size-8";
  const glyph = size === "lg" ? "size-5" : size === "sm" ? "size-3.5" : "size-4";
  return (
    <span
      aria-hidden
      className={`inline-flex ${box} shrink-0 items-center justify-center rounded-sm border border-border/60 ${TINT[category]}`}
    >
      <Icon className={glyph} strokeWidth={1.8} />
    </span>
  );
}
