/**
 * Hand-inked 17th-century style icons — woodcut / engraving look.
 * All inherit currentColor; stroke-heavy with little hatch marks.
 */
const stroke = {
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.5,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
};

function Svg({ children, className }: { children: React.ReactNode; className?: string | undefined }) {
  return (
    <svg viewBox="0 0 24 24" className={className} aria-hidden {...stroke}>
      {children}
    </svg>
  );
}

/** Full-rigged ship under sail — ship condition. */
export function ShipFullIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      {/* hull */}
      <path d="M2.5 16.5c2.2 2 5 3 9.5 3s7.5-1 9.5-3l-1.2-2.6H3.7z" />
      <path d="M4.5 17.2h15M5.6 18.3h12.8" strokeWidth={0.8} />
      {/* masts + sails */}
      <path d="M9 14V4.5M15 14V6" />
      <path d="M9 5.5c-2.6.6-3.4 2.6-3.2 4.6 1.6-.4 2.6-1.6 3.2-4.6z" />
      <path d="M9 5.5c2.4.6 3.1 2.6 3 4.4-1.4-.4-2.4-1.6-3-4.4z" />
      <path d="M15 6.8c-2 .5-2.7 2-2.6 3.7 1.3-.4 2.1-1.4 2.6-3.7z" />
      <path d="M15 6.8c1.9.5 2.5 2 2.4 3.6-1.2-.4-2-1.4-2.4-3.6z" />
      {/* pennant + waves */}
      <path d="M9 4.5c1.4-.5 2.6.2 3.8-.2" />
      <path d="M2 21c1.6-1 3-1 4.6 0M15.4 21c1.6-1 3-1 4.6 0" strokeWidth={0.9} />
    </Svg>
  );
}

/** Hourglass — skip time. */
export function HourglassIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M6 3.5h12M6 20.5h12" />
      <path d="M7.5 3.5c0 5 4 5.5 4.5 8.5-.5-3 4.5-3.5 4.5-8.5" />
      <path d="M7.5 20.5c0-4.5 3.5-4 4.5-7 1 3 4.5 2.5 4.5 7" />
      {/* sand */}
      <path d="M12 15.5v2" strokeWidth={0.9} />
      <path d="M9.5 19h5" strokeWidth={0.9} />
    </Svg>
  );
}

/** Open ledger book with quill — journal. */
export function QuillBookIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M12 6.5c-2-1.6-4.5-2-8-1.5v13c3.5-.5 6-.1 8 1.5 2-1.6 4.5-2 8-1.5V5c-3.5-.5-6-.1-8 1.5z" />
      <path d="M12 6.5v13" />
      <path d="M6.5 8.5c1.4-.2 2.4-.1 3.5.3M6.5 11c1.4-.2 2.4-.1 3.5.3M14 8.8c1.1-.4 2.1-.5 3.5-.3M14 11.3c1.1-.4 2.1-.5 3.5-.3" strokeWidth={0.8} />
      {/* quill */}
      <path d="M17.5 2.5c1.8.6 2.6 2 2.6 4-1.4-.4-2.4-1.6-2.6-4z" strokeWidth={1.1} />
    </Svg>
  );
}

/** Clasped log book — save ledger. */
export function LogBookIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M6.5 4h11a1.5 1.5 0 0 1 1.5 1.5v13a1.5 1.5 0 0 1-1.5 1.5h-11A1.5 1.5 0 0 1 5 18.5v-13A1.5 1.5 0 0 1 6.5 4z" />
      <path d="M8 4v16" strokeWidth={0.9} />
      {/* clasp */}
      <path d="M14 10.5h3.5v3H14" />
      <circle cx="15.7" cy="12" r="0.6" fill="currentColor" />
      <path d="M10.5 7.5h5M10.5 9.5h3.5" strokeWidth={0.8} />
    </Svg>
  );
}

/** Sun-and-wind compass rose — continue / advance a day. */
export function DayCompassIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <circle cx="12" cy="12" r="7.5" />
      <circle cx="12" cy="12" r="5" strokeWidth={0.7} />
      {/* rays */}
      <path d="M12 1.5v2M12 20.5v2M1.5 12h2M20.5 12h2M4.6 4.6l1.4 1.4M18 18l1.4 1.4M19.4 4.6L18 6M6 18l-1.4 1.4" strokeWidth={1} />
      {/* pointer east — onward */}
      <path d="M12 12l4.6-1.8-1.7 1.8 1.7 1.8z" fill="currentColor" stroke="none" />
      <circle cx="12" cy="12" r="1" fill="currentColor" stroke="none" />
    </Svg>
  );
}

/** Sailor's head with knotted kerchief — crew morale. */
export function CrewHeadIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      {/* kerchief */}
      <path d="M5.5 9.5C6 6 8.6 4 12 4s6 2 6.5 5.5c-2-1.4-4.2-2-6.5-2s-4.5.6-6.5 2z" />
      <path d="M18.5 9c1.2.3 2 .9 2.6 1.8-1 .2-1.9 0-2.7-.6" strokeWidth={1} />
      {/* face */}
      <path d="M6.5 10c0 4.6 2.4 8 5.5 8s5.5-3.4 5.5-8" />
      {/* brows + eyes */}
      <path d="M8.6 11.6h2M13.4 11.6h2" strokeWidth={1.1} />
      <circle cx="9.6" cy="13" r="0.55" fill="currentColor" stroke="none" />
      <circle cx="14.4" cy="13" r="0.55" fill="currentColor" stroke="none" />
      {/* nose + beard */}
      <path d="M12 13.2v2.2" strokeWidth={0.9} />
      <path d="M9.2 16.2c1.6 1.1 4 1.1 5.6 0" strokeWidth={0.9} />
    </Svg>
  );
}

/** Round loaf with scored crust — provisions. */
export function VictualsIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M3 13.5C3 9.4 7 6.5 12 6.5s9 2.9 9 7c0 2.6-2.4 4-5 4.2-2 .1-6 .1-8 0-2.6-.2-5-1.6-5-4.2z" />
      <path d="M7 8.8c-.6 1.6-.6 3.4 0 5M12 7.6c-.7 1.9-.7 4.2 0 6.3M17 8.8c.6 1.6.6 3.4 0 5" strokeWidth={0.9} />
    </Svg>
  );
}

/** Apothecary bottle with cork — medicine. */
export function PhysicIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M10 3.5h4M10.5 3.5V8c-2.6 1-4 3-4 6a5.5 5.5 0 0 0 11 0c0-3-1.4-5-4-6V3.5" />
      {/* liquid */}
      <path d="M7.2 14.5h9.6" strokeWidth={0.9} />
      <path d="M8.6 16.2c.8.5 1.7.5 2.5 0M12.9 17.4c.8.5 1.7.5 2.5 0" strokeWidth={0.8} />
      {/* cork */}
      <path d="M10.3 2h3.4v1.5h-3.4z" />
    </Svg>
  );
}

/** Fouled anchor — salvage and stores. */
export function AnchorStoresIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <circle cx="12" cy="4.6" r="1.9" />
      <path d="M12 6.5v13M7 9.5h10" />
      <path d="M4.5 13.5c0 4.5 3.4 7 7.5 7s7.5-2.5 7.5-7" />
      <path d="M4.5 13.5l-1.4 2.2M4.5 13.5l2.6.6M19.5 13.5l1.4 2.2M19.5 13.5l-2.6.6" strokeWidth={1.1} />
      {/* rope */}
      <path d="M12 8.6c1 .5 1 1.4 0 1.9-1 .5-1 1.4 0 1.9" strokeWidth={0.8} />
    </Svg>
  );
}

/** Stack of struck coins — gold in hand. */
export function DoubloonIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <ellipse cx="12" cy="17.5" rx="7.5" ry="2.6" />
      <path d="M4.5 14.5v3c0 1.4 3.4 2.6 7.5 2.6s7.5-1.2 7.5-2.6v-3" />
      <path d="M4.5 11.5v3c0 1.4 3.4 2.6 7.5 2.6s7.5-1.2 7.5-2.6v-3" />
      <ellipse cx="12" cy="11.5" rx="7.5" ry="2.6" />
      {/* cross struck on the top coin */}
      <path d="M12 9.9v3.2M9.4 11.5h5.2" strokeWidth={0.9} />
    </Svg>
  );
}

/** Sealed bond / scroll — debt owed. */
export function BondIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      <path d="M6 4.5h12v13c-2 1.2-4 1.9-6 1.9s-4-.7-6-1.9z" />
      <path d="M8.5 8h7M8.5 10.5h7M8.5 13h4.5" strokeWidth={0.9} />
      {/* wax seal */}
      <circle cx="15" cy="14.8" r="2" />
      <path d="M14.2 14.8h1.6M15 14v1.6" strokeWidth={0.7} />
      <path d="M13.6 16.4l-.9 2.4M16.4 16.4l.9 2.4" strokeWidth={0.9} />
    </Svg>
  );
}

/** Captain's tricorne hat — crew morale. */
export function CaptainHatIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      {/* tricorne brim */}
      <path d="M2.5 13.5c2.5-1.8 5-3.6 6.5-6.5.8-1.6 2.2-1.6 3 0 1.5 2.9 4 4.7 6.5 6.5 1.2.9.6 2.5-.8 2.5H3.3c-1.4 0-2-1.6-.8-2.5z" />
      {/* crown */}
      <path d="M8.8 11.5c.8 1 2 1.5 3.2 1.5s2.4-.5 3.2-1.5" strokeWidth={0.9} />
      {/* cockade */}
      <circle cx="12" cy="5.4" r="1.2" />
      <path d="M12 4.6v1.6M11.2 5.4h1.6" strokeWidth={0.6} />
      {/* braid */}
      <path d="M4.8 14.2c4.6 1.2 9.8 1.2 14.4 0" strokeWidth={0.8} />
    </Svg>
  );
}

/** Drawstring coin purse — the strongbox. */
export function CoinPurseIcon({ className }: { className?: string | undefined }) {
  return (
    <Svg className={className}>
      {/* pouch body */}
      <path d="M8 8.5C6 10 4.5 12.5 4.5 15a7.5 7.5 0 0 0 15 0c0-2.5-1.5-5-3.5-6.5" />
      {/* gathered neck + strings */}
      <path d="M8 8.5c1.3.8 2.6 1.1 4 1.1s2.7-.3 4-1.1" />
      <path d="M9.5 5.5C10 6.8 11 7.6 12 7.6s2-.8 2.5-2.1" />
      <path d="M12 7.6V5M10 5.8c.4-1 1-1.6 2-1.8M14 5.8c-.4-1-1-1.6-2-1.8" strokeWidth={0.9} />
      {/* coin glint */}
      <path d="M9 14.5c.8-1.4 2-2.2 3.4-2.3" strokeWidth={0.8} />
      <circle cx="12" cy="15.5" r="2.4" strokeWidth={0.9} />
      <path d="M12 14v3M10.8 15.5h2.4" strokeWidth={0.7} />
    </Svg>
  );
}
