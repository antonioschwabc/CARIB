import { useEffect, useRef, useState } from "react";

import { useGame } from "@/game/store";
import type { BattleFrame, CombatState } from "@/game/types";
import { COMMODITY_MAP } from "@/game/data/commodities";
import { money } from "@/game/sim/util";
import { BATTLEGROUNDS, BATTLEGROUND_MAP, LAND, SHOAL } from "@/game/data/battlegrounds";

/**
 * An action. The captain may try to run; if he cannot, the guns settle it and
 * he watches the record of it afterwards.
 */
export function CombatPanel() {
  const { state } = useGame();
  const c = state.combat;
  if (!c) return null;
  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/85 p-4">
      <div className="panel w-full max-w-3xl space-y-4 p-5 text-card-foreground">
        {c.phase === "preview" && <Preview c={c} />}
        {c.phase === "battle" && <Battle c={c} />}
        {c.phase === "result" && <Result c={c} />}
      </div>
    </div>
  );
}

function band([a, b]: [number, number]) {
  return a === b ? `${a}` : `${a}–${b}`;
}

function Preview({ c }: { c: CombatState }) {
  const { dispatch } = useGame();
  const mine = c.friends[0]!;
  return (
    <>
      <header className="border-b border-border pb-3">
        <p className="text-[11px] uppercase tracking-widest text-destructive">
          {c.mock ? "A yard exercise — no consequence" : "Beat to quarters"}
        </p>
        <h2 className="font-serif text-2xl font-bold text-accent">{c.title}</h2>
        <p className="mt-1 text-sm leading-relaxed">{c.text}</p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="rounded-sm border border-border p-3">
          <h3 className="font-serif text-sm font-bold">{mine.name}</h3>
          <p className="text-[11px] text-muted-foreground">{mine.className}</p>
          <dl className="numeric mt-2 grid grid-cols-2 gap-x-3 text-xs">
            <dt className="text-muted-foreground">Hull</dt>
            <dd>{Math.round(mine.hull)}</dd>
            <dt className="text-muted-foreground">Firepower</dt>
            <dd>{Math.round(mine.firepower)}</dd>
            <dt className="text-muted-foreground">Speed</dt>
            <dd>{mine.speed.toFixed(1)} kn</dd>
            <dt className="text-muted-foreground">Helm</dt>
            <dd>{Math.round(mine.maneuver)}</dd>
          </dl>
        </div>

        <div className="space-y-2">
          {c.estimates.map((e) => (
            <div key={e.id} className="rounded-sm border border-destructive/50 p-3">
              <h3 className="font-serif text-sm font-bold text-destructive">{e.name}</h3>
              <p className="text-[11px] text-muted-foreground">{e.className}</p>
              <dl className="numeric mt-2 grid grid-cols-2 gap-x-3 text-xs">
                <dt className="text-muted-foreground">Hull</dt>
                <dd>{band(e.hull)}</dd>
                <dt className="text-muted-foreground">Firepower</dt>
                <dd>{band(e.firepower)}</dd>
                <dt className="text-muted-foreground">Speed</dt>
                <dd>{band(e.speed)} kn</dd>
                <dt className="text-muted-foreground">Helm</dt>
                <dd>{band(e.maneuver)}</dd>
              </dl>
            </div>
          ))}
          <p className="text-[11px] italic text-muted-foreground">
            The lookouts can only guess. A keener Scout narrows the guess.
          </p>
        </div>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <button
          type="button"
          onClick={() => dispatch({ type: "combat", move: "evade" })}
          className="rounded-sm border border-input px-3 py-2 text-left transition-colors hover:bg-secondary"
        >
          <span className="text-sm font-medium">Crowd sail and run</span>
          <span className="numeric block text-[11px] text-muted-foreground">
            <span className="text-accent">{Math.round(c.evadeChance * 100)}%</span> to shake her off ·
            failure means action anyway
          </span>
        </button>
        <button
          type="button"
          onClick={() => dispatch({ type: "combat", move: "engage" })}
          className="rounded-sm border border-destructive px-3 py-2 text-left transition-colors hover:bg-destructive/20"
        >
          <span className="text-sm font-medium">Engage</span>
          <span className="numeric block text-[11px] text-muted-foreground">
            <span className="text-accent">{Math.round(c.winChance * 100)}%</span> reckoned in your favour
          </span>
        </button>
      </div>
    </>
  );
}

/** The light the day is fought in, and the water under it. */
const LIGHTS = {
  day: { deep: "oklch(0.36 0.07 235)", shoal: "oklch(0.52 0.08 200)", sky: "oklch(0.86 0.06 240)", sun: 1 },
  dawn: { deep: "oklch(0.32 0.06 260)", shoal: "oklch(0.46 0.07 215)", sky: "oklch(0.78 0.09 60)", sun: 0.7 },
  dusk: { deep: "oklch(0.28 0.06 285)", shoal: "oklch(0.40 0.08 30)", sky: "oklch(0.62 0.13 40)", sun: 0.6 },
  night: { deep: "oklch(0.17 0.05 265)", shoal: "oklch(0.26 0.05 240)", sky: "oklch(0.42 0.06 265)", sun: 0.25 },
} as const;

/** A hull seen from the masthead: deck, rail, bowsprit and canvas. */
function Hull({ friend, dead, scale }: { friend: boolean; dead: boolean; scale: number }) {
  const deck = dead ? "oklch(0.32 0.02 60)" : friend ? "oklch(0.66 0.05 80)" : "oklch(0.52 0.06 40)";
  const rail = dead ? "oklch(0.24 0.02 60)" : friend ? "oklch(0.86 0.09 88)" : "oklch(0.60 0.19 25)";
  return (
    <g transform={`scale(${scale})`} opacity={dead ? 0.55 : 1}>
      <path d="M-3.2 0 L-2.6 -1.25 L1.4 -1.15 L3.6 0 L1.4 1.15 L-2.6 1.25 Z" fill={deck} stroke={rail} strokeWidth={0.22} />
      <path d="M-2.4 0 L-2 -0.75 L1.2 -0.7 L2.6 0 L1.2 0.7 L-2 0.75 Z" fill="oklch(0.42 0.03 65)" opacity={0.65} />
      <line x1={3.6} y1={0} x2={5} y2={0} stroke={rail} strokeWidth={0.16} />
      {!dead && (
        <>
          <ellipse cx={0.4} cy={0} rx={1.5} ry={0.95} fill="oklch(0.95 0.02 90)" opacity={0.5} />
          <ellipse cx={-1.6} cy={0} rx={1} ry={0.7} fill="oklch(0.95 0.02 90)" opacity={0.42} />
        </>
      )}
      <circle cx={0.4} cy={0} r={0.22} fill="oklch(0.24 0.02 60)" />
      <circle cx={-1.6} cy={0} r={0.18} fill="oklch(0.24 0.02 60)" />
    </g>
  );
}

/** A star fort on the headland: bastions, curtain wall, and an embrasured face. */
function Fort({ x, y, fallen }: { x: number; y: number; fallen: boolean }) {
  const stone = fallen ? "oklch(0.34 0.02 70)" : "oklch(0.62 0.03 85)";
  const edge = fallen ? "oklch(0.22 0.02 60)" : "oklch(0.38 0.03 70)";
  return (
    <g transform={`translate(${x} ${y})`} opacity={fallen ? 0.6 : 1}>
      <path
        d="M-5 -3 L-2.6 -4.6 L0 -3.2 L2.6 -4.6 L5 -3 L6.2 0 L5 3 L2.6 4.6 L0 3.2 L-2.6 4.6 L-5 3 L-6.2 0 Z"
        fill={stone}
        stroke={edge}
        strokeWidth={0.35}
      />
      <path d="M-3 -1.8 L3 -1.8 L3 1.8 L-3 1.8 Z" fill="oklch(0.50 0.03 80)" stroke={edge} strokeWidth={0.2} />
      {[-2.2, -0.7, 0.7, 2.2].map((oy) => (
        <rect key={oy} x={5.4} y={oy - 0.25} width={1.1} height={0.5} fill={edge} />
      ))}
      <circle cx={0} cy={0} r={0.8} fill={edge} />
    </g>
  );
}


function Battle({ c }: { c: CombatState }) {
  const { dispatch } = useGame();
  const frames = c.frames ?? [];
  const [i, setI] = useState(0);
  const [speed, setSpeed] = useState(1);
  const timer = useRef<ReturnType<typeof setInterval> | undefined>(undefined);

  const step = Math.round(110 / speed);
  useEffect(() => {
    timer.current = setInterval(() => {
      setI((n) => {
        if (n >= frames.length - 1) {
          if (timer.current) clearInterval(timer.current);
          return n;
        }
        return n + 1;
      });
    }, step);
    return () => {
      if (timer.current) clearInterval(timer.current);
    };
  }, [frames.length, step]);

  const done = i >= frames.length - 1;
  const frame: BattleFrame | undefined = frames[i];
  const names = new Map([...c.friends, ...c.foes].map((s) => [s.id, s]));
  const light = LIGHTS[c.arena.light ?? "day"];
  const wind = c.arena.wind ?? 0;
  const ground =
    (c.arena.groundId ? BATTLEGROUND_MAP[c.arena.groundId] : undefined) ?? BATTLEGROUNDS[0]!;


  return (
    <>
      <header className="flex items-baseline gap-3 border-b border-border pb-2">
        <h2 className="font-serif text-lg font-bold text-accent">The action</h2>
        <span className="text-[11px] uppercase tracking-widest text-muted-foreground">
          {ground.name} · {c.arena.light ?? "day"} · wind {["N", "NE", "E", "SE", "S", "SW", "W", "NW"][Math.round((wind / (Math.PI * 2)) * 8) % 8]}
        </span>
        <div className="flex items-center gap-1">
          {[1, 2, 3].map((sp) => (
            <button
              key={sp}
              type="button"
              onClick={() => setSpeed(sp)}
              className={`numeric rounded-sm border px-1.5 py-0.5 text-[11px] ${
                speed === sp ? "border-accent text-accent" : "border-input text-muted-foreground"
              }`}
            >
              {sp}x
            </button>
          ))}
        </div>
        <button
          type="button"
          onClick={() => dispatch({ type: "combat", move: "watched" })}
          className="ml-auto rounded-sm border border-input px-2 py-1 text-xs hover:bg-secondary"
        >
          {done ? "The reckoning" : "Skip to the reckoning"}
        </button>
      </header>

      <svg
        viewBox={`0 0 ${c.arena.w} ${c.arena.h}`}
        className="w-full rounded-sm border border-border"
        style={{ background: light.deep }}
      >
        <defs>
          <radialGradient id="cb-sun" cx="18%" cy="12%" r="85%">
            <stop offset="0%" stopColor={light.sky} stopOpacity={0.42 * light.sun} />
            <stop offset="100%" stopColor={light.sky} stopOpacity={0} />
          </radialGradient>
          <pattern id="cb-swell" width="8" height="4" patternUnits="userSpaceOnUse" patternTransform={`rotate(${(wind * 180) / Math.PI})`}>
            <path d="M0 3 Q2 1.6 4 3 T8 3" fill="none" stroke="oklch(0.92 0.02 220)" strokeOpacity={0.09} strokeWidth={0.3} />
          </pattern>
        </defs>

        <rect width={c.arena.w} height={c.arena.h} fill="url(#cb-swell)" />

        {/* the ground itself: shoal water over sand, and land no hull may cross */}
        <g>
          {ground.tiles.map((row, y) =>
            row.map((t, x) =>
              t === SHOAL ? (
                <rect
                  key={`s${x}-${y}`}
                  x={x * ground.tile - 0.4}
                  y={y * ground.tile - 0.4}
                  width={ground.tile + 0.8}
                  height={ground.tile + 0.8}
                  rx={ground.tile * 0.5}
                  fill={light.shoal}
                  opacity={0.3}
                />
              ) : null,
            ),
          )}
          {ground.tiles.map((row, y) =>
            row.map((t, x) =>
              t === LAND ? (
                <rect
                  key={`l${x}-${y}`}
                  x={x * ground.tile - 0.5}
                  y={y * ground.tile - 0.5}
                  width={ground.tile + 1}
                  height={ground.tile + 1}
                  rx={ground.tile * 0.55}
                  fill="oklch(0.46 0.05 95)"
                />
              ) : null,
            ),
          )}
          {ground.tiles.map((row, y) =>
            row.map((t, x) =>
              t === LAND ? (
                <rect
                  key={`g${x}-${y}`}
                  x={x * ground.tile + 0.1}
                  y={y * ground.tile + 0.1}
                  width={ground.tile - 0.2}
                  height={ground.tile - 0.2}
                  rx={ground.tile * 0.45}
                  fill="oklch(0.42 0.07 128)"
                  opacity={0.45}
                />
              ) : null,
            ),
          )}
        </g>
        <rect width={c.arena.w} height={c.arena.h} fill="url(#cb-sun)" />


        {/* powder smoke */}
        {frame?.smoke?.map((s, n) => (
          <circle key={`sm${n}`} cx={s.x} cy={s.y} r={0.9 + (1 - s.a) * 2.4} fill="oklch(0.92 0.01 90)" opacity={s.a * 0.35} />
        ))}

        {/* round shot in flight */}
        {frame?.balls?.map((b, n) => (
          <circle
            key={`b${n}`}
            cx={b.x}
            cy={b.y}
            r={0.42}
            fill={b.f ? "oklch(0.9 0.02 90)" : "oklch(0.72 0.03 40)"}
            stroke="oklch(0.15 0.02 60)"
            strokeWidth={0.1}
          />
        ))}

        {frame?.ships.map((s) => {
          const meta = names.get(s.id);
          const friend = meta?.side === "friend";
          const dead = s.hull <= 0;
          if (meta?.fort) return <Fort key={s.id} x={s.x} y={s.y} fallen={dead} />;
          const big = (meta?.maxHull ?? 200) > 320 ? 1.3 : (meta?.maxHull ?? 200) > 240 ? 1.1 : 0.9;
          return (
            <g
              key={s.id}
              transform={`translate(${s.x} ${s.y}) rotate(${(s.h * 180) / Math.PI})`}
              style={{ transition: `transform ${step}ms linear` }}
            >
              {!dead && <ellipse cx={-3.4 * big} cy={0} rx={2.6 * big} ry={0.7 * big} fill="oklch(0.95 0.02 220)" opacity={0.16} />}
              <Hull friend={friend} dead={dead} scale={big} />
            </g>
          );
        })}

      </svg>

      <ul className="numeric grid gap-1 text-xs sm:grid-cols-2">
        {frame?.ships.map((s) => {
          const meta = names.get(s.id);
          if (!meta) return null;
          return (
            <li key={s.id} className="flex items-center gap-2">
              <span className={meta.side === "friend" ? "text-accent" : "text-destructive"}>{meta.name}</span>
              <span className="ml-auto text-muted-foreground">
                {Math.round(s.hull)} / {meta.maxHull}
              </span>
            </li>
          );
        })}
      </ul>
    </>
  );
}


function Result({ c }: { c: CombatState }) {
  const { dispatch } = useGame();
  const r = c.result;
  if (!r) return null;
  return (
    <>
      <header className="border-b border-border pb-3">
        <h2 className={`font-serif text-2xl font-bold ${r.victory ? "text-accent" : "text-destructive"}`}>
          {r.victory ? "The day is carried" : "Struck and sunk"}
        </h2>
        <p className="mt-1 text-sm leading-relaxed">{r.note}</p>
      </header>

      <dl className="numeric grid grid-cols-2 gap-x-6 gap-y-1 text-sm sm:grid-cols-3">
        <Line k="Hull lost" v={`${r.hullLost}%`} />
        <Line k="Canvas lost" v={`${r.sailsLost}%`} />
        <Line k="Coin taken" v={money(r.gold)} />
        <Line k="Prestige" v={`${r.prestige > 0 ? "+" : ""}${r.prestige}`} />
        <Line k="Standing" v={`${r.reputation > 0 ? "+" : ""}${r.reputation}`} />
        <Line k="Dead" v={`${r.dead.length}`} />
      </dl>

      {r.goods.length > 0 && (
        <p className="text-xs text-muted-foreground">
          Taken out of her:{" "}
          {r.goods.map((g) => `${g.qty} ${COMMODITY_MAP[g.cid]?.name ?? g.cid}`).join(", ")}
          {r.part ? ` · ${r.part}, salvaged whole` : ""}
        </p>
      )}
      {r.dead.length > 0 && <p className="text-xs text-destructive">Lost: {r.dead.join(", ")}</p>}
      {r.hurt.length > 0 && (
        <p className="text-xs text-muted-foreground">
          In the berth: {r.hurt.map((h) => `${h.name} (${h.health})`).join(", ")}
        </p>
      )}

      {!c.mock && (
        <p className="text-[11px] italic text-muted-foreground">
          No hostile sail will close with her for seven days.
        </p>
      )}
      {c.mock && (
        <p className="text-[11px] italic text-muted-foreground">
          A mock action only — no damage, no coin, no graves.
        </p>
      )}

      <button
        type="button"
        onClick={() => dispatch({ type: "combat", move: "close" })}
        className="w-full rounded-sm border border-input px-3 py-2 text-sm font-medium hover:bg-secondary"
      >
        Resume the passage
      </button>
    </>
  );
}

function Line({ k, v }: { k: string; v: string }) {
  return (
    <div className="flex justify-between gap-2">
      <dt className="text-muted-foreground">{k}</dt>
      <dd>{v}</dd>
    </div>
  );
}
