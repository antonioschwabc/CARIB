import { useEffect, useState } from "react";

import { activeShip } from "@/game/actions";
import { PORT_MAP } from "@/game/data/ports";
import { BUSINESS_MAP, BUSINESS_TYPES } from "@/game/data/ships";
import { cashProjection, fleetFinance } from "@/game/sim/finance";
import { formatDate, money } from "@/game/sim/util";
import { useGame } from "@/game/store";

export function FinancePanel() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const port = ship && !ship.voyage ? PORT_MAP[ship.portId]! : undefined;
  const fin = fleetFinance(state);
  const projection = cashProjection(state, fin, 12);

  return (
    <div className="grid gap-4 p-4 lg:grid-cols-2">
      {/* ---- The week's account ---- */}
      <section className="panel space-y-3 p-4 lg:col-span-2">
        <div className="flex flex-wrap items-baseline justify-between gap-2">
          <h2 className="font-semibold">The counting house — this week's account</h2>
          <span className={`numeric text-sm ${fin.weeklyNet >= 0 ? "text-profit" : "text-loss"}`}>
            {fin.weeklyNet >= 0 ? "+" : ""}
            {money(fin.weeklyNet)} a week
          </span>
        </div>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          <Stat label="Coin in hand" value={money(state.cash)} />
          <Stat label="Weekly wages" value={money(fin.weeklyWages)} tone="loss" />
          <Stat label="Weekly upkeep" value={money(fin.dailyUpkeep * 7)} tone="loss" />
          <Stat
            label="Ventures ashore"
            value={`${fin.venturesDailyNet >= 0 ? "+" : ""}${money(fin.venturesDailyNet * 7)}`}
            tone={fin.venturesDailyNet >= 0 ? "profit" : "loss"}
          />
        </div>
        <Bars
          rows={[
            { label: "Ventures", value: Math.max(0, fin.venturesDailyNet * 7), tone: "profit" },
            { label: "Wages", value: fin.weeklyWages, tone: "loss" },
            { label: "Ship upkeep", value: fin.dailyUpkeep * 7, tone: "loss" },
            {
              label: "Interest",
              value: fin.weeklyDebtInterest + fin.weeklyLoanInterest,
              tone: "loss",
            },
          ]}
        />
        <p className="text-xs text-muted-foreground">
          {fin.weeklyNet < 0
            ? `At this rate your coin lasts about ${fin.runwayDays ?? 0} days without a cargo sold.`
            : "Standing bills are covered before a single cask is traded."}
        </p>
      </section>

      {/* ---- Projection ---- */}
      <section className="panel space-y-3 p-4">
        <h2 className="font-semibold">Projection — twelve weeks of standing bills</h2>
        <Sparkline values={projection} />
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>
            Now · <span className="numeric">{money(state.cash)}</span>
          </span>
          <span>
            Week 12 ·{" "}
            <span className="numeric">{money(projection[projection.length - 1] ?? 0)}</span>
          </span>
        </div>
        <p className="text-xs text-muted-foreground">
          Trade is not counted here — only wages, keep, ventures and interest.
        </p>
      </section>

      {/* ---- Fleet payroll ---- */}
      <section className="panel space-y-3 p-4">
        <h2 className="font-semibold">Fleet payroll</h2>
        <ul className="space-y-2">
          {fin.ships.map((s) => (
            <li key={s.id} className="rounded-sm border border-border p-2 text-sm">
              <div className="flex justify-between">
                <span className="font-semibold">{s.name}</span>
                <span className="numeric text-loss">{money(s.weeklyWages)}/week</span>
              </div>
              <p className="text-xs text-muted-foreground">
                {s.className} · {s.officers} officers, {s.hands} hands · keep{" "}
                <span className="numeric">{money(s.dailyUpkeep)}</span>/day
              </p>
            </li>
          ))}
          {fin.ships.length === 0 && (
            <li className="text-sm text-muted-foreground">No vessels on the books.</li>
          )}
        </ul>
      </section>

      {/* ---- Debt ---- */}
      <section className="panel space-y-3 p-4">
        <h2 className="font-semibold">The chandler's note</h2>
        {state.debt > 0 ? (
          <>
            <p className="text-sm text-muted-foreground">
              <span className="numeric text-loss">{money(state.debt)}</span> owed on your hull,
              swelling {(state.debtRate * 400).toFixed(0)}% a month —{" "}
              <span className="numeric">{money(fin.weeklyDebtInterest)}</span> of interest each
              week. Pay down as much as you please.
            </p>
            <DebtSlider
              max={Math.min(Math.floor(state.cash), Math.ceil(state.debt))}
              onPay={(amount) => dispatch({ type: "payDebt", amount })}
            />
          </>
        ) : (
          <p className="text-sm text-muted-foreground">Your hull is your own, free of any note.</p>
        )}

        <dl className="text-sm">
          <Row label="Total owing" value={money(fin.totalDebt)} />
          <Row
            label="Interest a week"
            value={money(fin.weeklyDebtInterest + fin.weeklyLoanInterest)}
          />
          <Row label="Standing on the exchange" value={`${Math.round(state.reputation)}`} />
          <Row label="Notoriety" value={`${Math.round(state.notoriety)}`} />
        </dl>

        {state.loans.length > 0 && (
          <ul className="space-y-2">
            {state.loans.map((l) => (
              <li
                key={l.id}
                className="flex items-center justify-between rounded-sm border border-border p-2 text-sm"
              >
                <span className="numeric">
                  {money(l.principal)} at {Math.round(l.rate * 100)}% · due {formatDate(l.dueDay)}
                </span>
                <button
                  type="button"
                  disabled={state.cash < l.principal}
                  onClick={() => dispatch({ type: "repayLoan", loanId: l.id })}
                  className="rounded-sm bg-primary px-2 py-1 text-xs text-primary-foreground disabled:opacity-40"
                >
                  Repay
                </button>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* ---- Ventures ---- */}
      <section className="panel space-y-3 p-4">
        <h2 className="font-semibold">Ventures ashore</h2>
        {fin.ventures.length > 0 && (
          <ul className="space-y-2">
            {state.businesses.map((b) => {
              const t = BUSINESS_MAP[b.typeId]!;
              const v = fin.ventures.find((x) => x.id === b.id);
              return (
                <li key={b.id} className="rounded-sm border border-border p-2 text-sm">
                  <div className="flex justify-between">
                    <span>
                      {t.name} · {PORT_MAP[b.portId]!.name}
                    </span>
                    <span className="numeric text-xs text-profit">
                      {money((v ? v.dailyIncome - v.dailyUpkeep : 0) * 7)}/week
                    </span>
                  </div>
                  <div className="mt-1 flex items-center gap-2">
                    <span className="numeric text-xs text-muted-foreground">level {b.level}</span>
                    <button
                      type="button"
                      onClick={() => dispatch({ type: "upgradeBusiness", id: b.id })}
                      className="rounded-sm border border-input px-2 py-1 text-xs"
                    >
                      Enlarge · {money(Math.round(t.price * 0.7 * b.level))}
                    </button>
                    <button
                      type="button"
                      onClick={() => dispatch({ type: "sellBusiness", id: b.id })}
                      className="rounded-sm border border-input px-2 py-1 text-xs"
                    >
                      Sell
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}

        <p className="text-xs text-muted-foreground">
          Ventures ashore are arranged in the harbour itself, not at this desk. What you already
          hold is set out above.
        </p>
      </section>
    </div>
  );
}

function Stat({ label, value, tone }: { label: string; value: string; tone?: "profit" | "loss" }) {
  return (
    <div className="rounded-sm border border-border p-2">
      <div className="text-xs text-muted-foreground">{label}</div>
      <div
        className={`numeric text-base ${tone === "profit" ? "text-profit" : tone === "loss" ? "text-loss" : ""}`}
      >
        {value}
      </div>
    </div>
  );
}

function Bars({ rows }: { rows: { label: string; value: number; tone: "profit" | "loss" }[] }) {
  const max = Math.max(1, ...rows.map((r) => r.value));
  return (
    <ul className="space-y-1">
      {rows.map((r) => (
        <li key={r.label} className="flex items-center gap-2 text-xs">
          <span className="w-24 shrink-0 text-muted-foreground">{r.label}</span>
          <span className="h-2 flex-1 overflow-hidden rounded-sm bg-muted">
            <span
              className={`block h-full ${r.tone === "profit" ? "bg-profit" : "bg-loss"}`}
              style={{ width: `${(r.value / max) * 100}%` }}
            />
          </span>
          <span className="numeric w-20 shrink-0 text-right">{money(r.value)}</span>
        </li>
      ))}
    </ul>
  );
}

function Sparkline({ values }: { values: number[] }) {
  if (values.length < 2) return null;
  const min = Math.min(0, ...values);
  const max = Math.max(1, ...values);
  const w = 300;
  const h = 90;
  const pts = values
    .map((v, i) => {
      const x = (i / (values.length - 1)) * w;
      const y = h - ((v - min) / (max - min || 1)) * h;
      return `${x.toFixed(1)},${y.toFixed(1)}`;
    })
    .join(" ");
  const zeroY = h - ((0 - min) / (max - min || 1)) * h;
  return (
    <svg
      viewBox={`0 0 ${w} ${h}`}
      className="h-24 w-full"
      role="img"
      aria-label="Projected coin over twelve weeks"
    >
      <line
        x1="0"
        y1={zeroY}
        x2={w}
        y2={zeroY}
        stroke="currentColor"
        strokeOpacity="0.25"
        strokeDasharray="4 4"
      />
      <polyline
        points={pts}
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        className="text-primary"
      />
    </svg>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-baseline justify-between gap-2 border-b border-border/50 py-0.5">
      <dt className="text-xs text-muted-foreground">{label}</dt>
      <dd className="numeric">{value}</dd>
    </div>
  );
}

/** Pay the note down by whatever the purse allows. */
function DebtSlider({ max, onPay }: { max: number; onPay: (amount: number) => void }) {
  const [amount, setAmount] = useState(max);
  useEffect(() => setAmount((a) => Math.min(a, max)), [max]);
  if (max <= 0)
    return <p className="text-xs text-muted-foreground">No coin in hand to put against it.</p>;
  return (
    <div className="space-y-2">
      <input
        type="range"
        min={0}
        max={max}
        step={Math.max(1, Math.round(max / 200))}
        value={amount}
        onChange={(e) => setAmount(Number(e.target.value))}
        className="w-full accent-[oklch(0.62_0.16_42)]"
        aria-label="Amount to repay"
      />
      <div className="flex items-center justify-between gap-2">
        <span className="numeric text-sm">{money(amount)}</span>
        <button
          type="button"
          disabled={amount <= 0}
          onClick={() => onPay(amount)}
          className="rounded-sm bg-primary px-3 py-1.5 text-sm text-primary-foreground disabled:opacity-40"
        >
          Pay it down
        </button>
      </div>
    </div>
  );
}
