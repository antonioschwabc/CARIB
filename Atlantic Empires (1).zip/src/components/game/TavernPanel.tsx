import { useNavigate } from "@tanstack/react-router";

import { TavernScreen } from "@/components/game/TavernScreen";

/** The tavern always comes up as its own room, over whatever you were doing. */
export function TavernPanel() {
  const navigate = useNavigate();
  return <TavernScreen onExit={() => void navigate({ to: "/play/port" })} />;
}
