import { useState } from "react";

import { FactionFlag } from "@/components/game/FactionFlag";
import { POWERS, POWER_MAP } from "@/game/data/powers";
import { factionRel, pairKey, relationTone } from "@/game/sim/factions";
import { useGame } from "@/game/store";
import type { PowerId } from "@/game/types";

/**
 * The crowns in a ring, every pair joined by a thread whose colour is what
 * they think of one another. Hover a thread to read the figure.
 */
export function FactionWeb() {
  const { state } = useGame();
  const [hover, setHover] = useState<string | undefined>();

  const ring = POWERS.map((p, i) => {
    const a = (i / POWERS.length) * Math.PI * 2 - Math.PI / 2;
    return { power: p.id as PowerId, x: 200 + Math.cos(a) * 140, y: 165 + Math.sin(a) * 125 };
  });

  const lines: { key: string; a: (typeof ring)[number]; b: (typeof ring)[number]; v: number }[] = [];
  for (let i = 0; i < ring.length; i++) {
    for (let j = i + 1; j < ring.length; j++) {
      const a = ring[i]!;
      const b = ring[j]!;
      lines.push({ key: pairKey(a.power, b.power), a, b, v: factionRel(state, a.power, b.power) });
    }
  }

  const shown = lines.find((l) => l.key === hover);

  return (
    <div className="space-y-2">
      <svg viewBox="0 0 400 330" className="w-full max-w-xl" role="img" aria-label="Relations between the crowns">
        {lines.map((l) => {
          const tone = relationTone(l.v);
          const on = hover === l.key;
          return (
            <line
              key={l.key}
              x1={l.a.x}
              y1={l.a.y}
              x2={l.b.x}
              y2={l.b.y}
              stroke={tone.color}
              strokeWidth={on ? 4 : 1.6 + Math.abs(l.v) / 45}
              strokeDasharray={l.v <= -50 ? "6 4" : undefined}
              opacity={hover && !on ? 0.25 : 0.9}
              onMouseEnter={() => setHover(l.key)}
              onMouseLeave={() => setHover(undefined)}
              className="cursor-help"
            >
              <title>{`${POWER_MAP[l.a.power]!.adjective} – ${POWER_MAP[l.b.power]!.adjective}: ${Math.round(l.v)} (${tone.label})`}</title>
            </line>
          );
        })}
        {ring.map((n) => (
          <foreignObject key={n.power} x={n.x - 24} y={n.y - 22} width="48" height="60">
            <div className="flex flex-col items-center gap-0.5">
              <div className="w-10">
                <FactionFlag power={n.power} title={POWER_MAP[n.power]!.name} />
              </div>
              <span className="text-[9px] leading-none text-muted-foreground">{POWER_MAP[n.power]!.adjective}</span>
            </div>
          </foreignObject>
        ))}
      </svg>
      <p className="text-xs text-muted-foreground">
        {shown
          ? `${POWER_MAP[shown.a.power]!.name} and ${POWER_MAP[shown.b.power]!.name}: ${Math.round(shown.v)} — ${relationTone(shown.v).label.toLowerCase()}.`
          : "Hover a thread to read what one court thinks of another. Dashed threads are open war."}
      </p>
    </div>
  );
}
