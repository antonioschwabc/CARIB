import { PORTS } from "@/game/data/ports";
import { useGame } from "@/game/store";

/** The shipwright's own tools. Only a ledger opened as a dev save shows this. */
export function DevPanel() {
  const { state, dispatch } = useGame();

  if (!state.dev) {
    return (
      <div className="p-4">
        <section className="panel p-4 text-sm text-muted-foreground">
          This ledger was not opened with the shipwright&apos;s tools. Begin a new save and tick the dev box to use them.
        </section>
      </div>
    );
  }

  const buttons: { what: "gold" | "prestige" | "infamy" | "reveal" | "permits" | "clear"; label: string }[] = [
    { what: "gold", label: "Add 50,000 gold" },
    { what: "clear", label: "Strike out the debt" },
    { what: "prestige", label: "Add 500 prestige" },
    { what: "infamy", label: "Add 500 infamy" },
    { what: "reveal", label: "Reveal every black harbour and sail" },
    { what: "permits", label: "Stamp every permit" },
  ];

  const havens = PORTS.filter((p) => p.hidden);

  return (
    <div className="space-y-4 p-4">
      <section className="panel p-4">
        <h1 className="font-semibold">Dev ledger</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Amendments made by a hand outside the world. Every one of them is written into the journal.
        </p>
        <div className="mt-3 flex flex-wrap gap-2">
          {buttons.map((b) => (
            <button
              key={b.what}
              type="button"
              onClick={() => dispatch({ type: "devCheat", what: b.what })}
              className="rounded-sm border border-input px-3 py-1.5 text-xs"
            >
              {b.label}
            </button>
          ))}
        </div>
      </section>

      <section className="panel p-4">
        <h2 className="font-semibold">This save&apos;s black harbours</h2>
        <ul className="mt-2 space-y-1 text-sm">
          {havens.map((p) => (
            <li key={p.id} className="flex justify-between gap-3">
              <span>
                {p.name} <span className="text-xs text-muted-foreground">({p.region}, level {p.level})</span>
              </span>
              <span className="numeric text-xs text-muted-foreground">
                {p.lat.toFixed(2)}, {p.lon.toFixed(2)} —{" "}
                {(state.knownPorts ?? []).includes(p.id) ? "found" : "hidden"}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
}
