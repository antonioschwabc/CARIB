import type { PowerId } from "@/game/types";

/**
 * The colours of the crowns, cut to the same rectangle as a captain's own
 * banner so that every flag in the game reads the same way.
 */

function Fleur({ x, y, s }: { x: number; y: number; s: number }) {
  return (
    <g transform={`translate(${x} ${y}) scale(${s})`} fill="#e8c351">
      <path d="M0 -7 C2.6 -3.6 2.4 -0.6 1.1 1.4 C3.2 -0.4 6.4 -0.9 7.2 1.6 C7.9 3.9 5.4 5.6 2.4 4.6 L2.4 6.2 L-2.4 6.2 L-2.4 4.6 C-5.4 5.6 -7.9 3.9 -7.2 1.6 C-6.4 -0.9 -3.2 -0.4 -1.1 1.4 C-2.4 -0.6 -2.6 -3.6 0 -7 Z" />
      <rect x="-3.4" y="5.6" width="6.8" height="1.7" rx="0.6" />
    </g>
  );
}

function Skull() {
  return (
    <g fill="#f0ece0">
      <g transform="translate(30 22)">
        <path d="M0 -9 C6.6 -9 10 -4.8 10 -0.4 C10 3.2 7.6 5.2 5.4 6 L5.4 8.6 C5.4 9.6 4.4 10.2 3.2 10.2 L-3.2 10.2 C-4.4 10.2 -5.4 9.6 -5.4 8.6 L-5.4 6 C-7.6 5.2 -10 3.2 -10 -0.4 C-10 -4.8 -6.6 -9 0 -9 Z" />
        <ellipse cx="-3.9" cy="-1" rx="2.7" ry="3.1" fill="#0e0e0e" />
        <ellipse cx="3.9" cy="-1" rx="2.7" ry="3.1" fill="#0e0e0e" />
        <path d="M0 2.4 L-1.9 6 L1.9 6 Z" fill="#0e0e0e" />
      </g>
      <g stroke="#f0ece0" strokeWidth="3.1" strokeLinecap="round">
        <path d="M20 36 L40 44" />
        <path d="M40 36 L20 44" />
      </g>
      <g fill="#f0ece0">
        {[
          [19, 34.5],
          [19, 45.5],
          [41, 34.5],
          [41, 45.5],
        ].map(([cx, cy], i) => (
          <circle key={i} cx={cx} cy={cy} r="2.4" />
        ))}
      </g>
    </g>
  );
}

/** The design of each crown, drawn inside a 60 × 52 field. */
function Design({ power }: { power: PowerId }) {
  switch (power) {
    case "spain":
      return (
        <>
          <rect width="60" height="52" fill="#f3ecdd" />
          <g stroke="#b0231f" strokeWidth="7.5" strokeLinecap="square">
            <path d="M4 3 L56 49" />
            <path d="M56 3 L4 49" />
          </g>
          {/* the ragged staves of Burgundy */}
          <g stroke="#8e1a17" strokeWidth="1.1" opacity="0.85">
            <path d="M4 3 L56 49" />
            <path d="M56 3 L4 49" />
          </g>
        </>
      );
    case "england":
      return (
        <>
          <rect width="60" height="52" fill="#f3ecdd" />
          <rect x="24" width="12" height="52" fill="#c0332c" />
          <rect y="20" width="60" height="12" fill="#c0332c" />
        </>
      );
    case "france":
      return (
        <>
          <rect width="60" height="52" fill="#2c4a8f" />
          <Fleur x={20} y={16} s={1} />
          <Fleur x={40} y={16} s={1} />
          <Fleur x={30} y={36} s={1} />
        </>
      );
    case "dutch":
      return (
        <>
          <rect width="60" height="17.4" fill="#d97a26" />
          <rect y="17.4" width="60" height="17.2" fill="#f3ecdd" />
          <rect y="34.6" width="60" height="17.4" fill="#20386e" />
        </>
      );
    case "portugal":
      return (
        <>
          <rect width="60" height="52" fill="#f3ecdd" />
          <rect width="60" height="52" fill="none" stroke="#2f6b45" strokeWidth="5" />
          <g transform="translate(30 26)">
            <path d="M0 -14 C8 -14 10 -9 10 -3 C10 6 4 11 0 14 C-4 11 -10 6 -10 -3 C-10 -9 -8 -14 0 -14 Z" fill="#1d3f7a" />
            <path d="M0 -14 C8 -14 10 -9 10 -3 C10 6 4 11 0 14 C-4 11 -10 6 -10 -3 C-10 -9 -8 -14 0 -14 Z" fill="none" stroke="#e0b420" strokeWidth="1.6" />
            <g fill="#f3ecdd">
              <rect x="-1.6" y="-9" width="3.2" height="12" rx="1" />
              <rect x="-8" y="-9" width="3.2" height="9" rx="1" />
              <rect x="4.8" y="-9" width="3.2" height="9" rx="1" />
              <rect x="-4.8" y="4" width="3.2" height="6" rx="1" />
              <rect x="1.6" y="4" width="3.2" height="6" rx="1" />
            </g>
          </g>
        </>
      );
    case "pirate":
    default:
      return (
        <>
          <rect width="60" height="52" fill="#131313" />
          <Skull />
        </>
      );
  }
}

/**
 * A faction's colours. `draped` hangs the cloth from a short yard, as it is
 * flown over a harbour's works.
 */
export function FactionFlag({
  power,
  className = "",
  title,
  draped = false,
}: {
  power: PowerId;
  className?: string;
  title?: string;
  draped?: boolean;
}) {
  const id = `ff-${power}-${draped ? "d" : "f"}`;
  if (!draped) {
    return (
      <svg
        viewBox="0 0 60 52"
        role="img"
        aria-label={title ?? "Colours"}
        className={`rounded-[2px] border border-border/70 ${className}`}
        preserveAspectRatio="xMidYMid meet"
      >
        <Design power={power} />
      </svg>
    );
  }

  return (
    <svg
      viewBox="0 0 76 132"
      role="img"
      aria-label={title ?? "Colours"}
      className={className}
      preserveAspectRatio="xMidYMid meet"
    >
      <defs>
        <clipPath id={`${id}-clip`}>
          <path d="M8 10 H68 V104 q-8 8 -15 0 q-8 8 -15 0 q-8 8 -15 0 q-8 8 -15 0 Z" />
        </clipPath>
        <linearGradient id={`${id}-fold`} x1="0" y1="0" x2="1" y2="0">
          <stop offset="0%" stopColor="#000" stopOpacity="0.4" />
          <stop offset="14%" stopColor="#fff" stopOpacity="0.12" />
          <stop offset="34%" stopColor="#000" stopOpacity="0.26" />
          <stop offset="56%" stopColor="#fff" stopOpacity="0.14" />
          <stop offset="78%" stopColor="#000" stopOpacity="0.3" />
          <stop offset="100%" stopColor="#000" stopOpacity="0.45" />
        </linearGradient>
      </defs>

      {/* the yard it hangs from */}
      <rect x="2" y="4" width="72" height="5" rx="2.5" fill="#4a3a2b" />
      <rect x="2" y="4" width="72" height="1.6" fill="#7d6549" opacity="0.6" />

      <g clipPath={`url(#${id}-clip)`}>
        <g transform="translate(8 10) scale(1 1.9)">
          <Design power={power} />
        </g>
        <rect x="8" y="10" width="60" height="100" fill={`url(#${id}-fold)`} />
      </g>
      <path
        d="M8 10 H68 V104 q-8 8 -15 0 q-8 8 -15 0 q-8 8 -15 0 q-8 8 -15 0 Z"
        fill="none"
        stroke="#000"
        strokeOpacity="0.35"
        strokeWidth="1"
      />
      {/* lashings */}
      {[12, 30, 48, 64].map((x) => (
        <circle key={x} cx={x} cy="10" r="1.5" fill="#2b2118" opacity="0.7" />
      ))}
    </svg>
  );
}
