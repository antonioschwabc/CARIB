import { useGame } from "@/game/store";
import type { OutcomeLine } from "@/game/types";

const SKILL_LABEL: Record<string, string> = {
  navigation: "Navigation",
  charisma: "Charisma",
  scouting: "Scouting",
  craftsmanship: "Craftsmanship",
  gunnery: "Gunnery",
  logistics: "Logistics",
  cooking: "Cooking",
  medicine: "Medicine",
};

const VERDICT: Record<string, { word: string; tone: string }> = {
  won: { word: "It came off", tone: "text-emerald-300" },
  lost: { word: "It did not come off", tone: "text-red-300" },
  done: { word: "Settled", tone: "text-accent" },
};

/**
 * The reckoning: what the captain chose, how it went, and what the books show
 * for it. Nothing is settled behind his back.
 */
export function OutcomeDialog() {
  const { state, dispatch } = useGame();
  const o = state.outcome;
  if (!o || state.encounter || state.story || state.combat) return null;
  const v = VERDICT[o.verdict] ?? VERDICT["done"]!;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/75 p-4">
      <div role="dialog" aria-modal="true" className="panel w-full max-w-lg space-y-4 p-5 text-card-foreground">
        <header className="border-b border-border pb-3">
          <p className="text-[11px] uppercase tracking-widest text-muted-foreground">The reckoning</p>
          <h2 className="font-serif text-xl font-bold text-accent">{o.title}</h2>
          <p className="mt-0.5 text-xs text-muted-foreground">You chose: {o.choice}</p>
        </header>

        <p className={`font-serif text-lg font-semibold ${v.tone}`}>{v.word}</p>
        <p className="text-sm leading-relaxed">{o.text}</p>

        {o.roll && (
          <p className="numeric rounded-sm border border-border bg-secondary/40 px-2.5 py-1.5 text-xs text-muted-foreground">
            {SKILL_LABEL[o.roll.skill] ?? o.roll.skill} {o.roll.score} against a class of {o.roll.dc} —{" "}
            {Math.round(o.roll.chance * 100)}% at the outset
          </p>
        )}

        <div>
          <h3 className="text-[11px] uppercase tracking-widest text-muted-foreground">What the books show</h3>
          {o.lines.length ? (
            <ul className="mt-1.5 grid gap-1 sm:grid-cols-2">
              {o.lines.map((l: OutcomeLine) => (
                <li
                  key={l.label}
                  className="flex items-baseline justify-between gap-2 rounded-sm border border-border px-2 py-1 text-xs"
                >
                  <span className="text-muted-foreground">{l.label}</span>
                  <span
                    className={`numeric font-semibold ${
                      l.tone === "good" ? "text-emerald-300" : l.tone === "bad" ? "text-red-300" : ""
                    }`}
                  >
                    {l.text}
                  </span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="mt-1.5 text-xs italic text-muted-foreground">
              Neither coin nor timber changed hands. Only the hour is spent.
            </p>
          )}
        </div>

        <button
          type="button"
          autoFocus
          onClick={() => dispatch({ type: "dismissOutcome" })}
          className="w-full rounded-sm border border-accent/60 bg-accent/15 px-3 py-2 font-serif text-sm font-semibold text-accent hover:bg-accent/25"
        >
          Enter it in the log
        </button>
      </div>
    </div>
  );
}
