import { Link } from "@tanstack/react-router";

import { activeShip } from "@/game/actions";
import {
  COMPONENT_DEFS,
  COMPONENT_MAP,
  OPTIONAL_QUARTERS,
  QUARTER_MAP,
  componentCost,
  yardMaxMark,
} from "@/game/data/shipParts";
import { quartersUsed, shipStats } from "@/game/sim/shipStats";
import { PORT_MAP } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { SHIP_CLASSES, SHIP_CLASS_MAP } from "@/game/data/ships";
import { money } from "@/game/sim/util";
import { suppliesAboard } from "@/game/sim/stores";
import { useGame } from "@/game/store";

const YARD_LABEL = ["No yard here", "Careening beach", "Shipwright's yard", "Naval dockyard"];

export function YardPanel() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  if (!ship) return <p className="p-6">You have no ships.</p>;
  const port = PORT_MAP[ship.portId]!;
  const atSea = !!ship.voyage;

  if (atSea) {
    return (
      <p className="p-6 text-sm text-muted-foreground">The yard is ashore, and you are not.</p>
    );
  }

  const repairCost = Math.round((200 - ship.hull - ship.sails) * 46 * (1.3 - port.shipyard * 0.1));
  const stats = shipStats(ship);
  const canWork = port.shipyard > 0;
  const maxMark = yardMaxMark(port);

  return (
    <div className="grid gap-4 p-4 xl:grid-cols-2">
      <section className="panel space-y-4 p-4">
        <header>
          <h2 className="text-lg font-semibold">Shipwright's yard, {port.name}</h2>
          <p className="text-xs text-muted-foreground">
            {YARD_LABEL[port.shipyard]} · {POWER_MAP[port.power]!.adjective} crown work rates.
          </p>
        </header>

        <div className="space-y-2 rounded-sm border border-border p-3">
          <Bar label="Hull" value={ship.hull} />
          <Bar label="Sails & rigging" value={ship.sails} />
          <p className="text-xs text-muted-foreground">
            Idle hands repair her slowly in harbour using timber, pitch, canvas and cordage from the
            hold. The yard does it in a day, for coin.
          </p>
          <button
            type="button"
            disabled={!canWork || repairCost <= 0 || state.cash < repairCost}
            onClick={() => dispatch({ type: "repair" })}
            className="rounded-sm bg-primary px-3 py-1.5 text-sm text-primary-foreground disabled:opacity-40"
          >
            {repairCost <= 0 ? "She is sound" : `Careen and refit — ${money(repairCost)}`}
          </button>
        </div>

        <div className="space-y-2 rounded-sm border border-border p-3">
          <div className="flex items-baseline justify-between">
            <h3 className="text-sm font-semibold">Provisions</h3>
            <span className="numeric text-xs text-muted-foreground">
              {Math.round(suppliesAboard(ship))} units of stores aboard
            </span>
          </div>
          <div className="flex gap-2">
            {[20, 60, 150].map((u) => (
              <button
                key={u}
                type="button"
                disabled={state.cash < Math.round(u * 2.2)}
                onClick={() => dispatch({ type: "provision", units: u })}
                className="rounded-sm border border-input px-2 py-1 text-xs disabled:opacity-40"
              >
                +{u} — {money(Math.round(u * 2.2))}
              </button>
            ))}
          </div>
        </div>

        <div className="rounded-sm border border-border p-3">
          <div className="flex items-baseline justify-between">
            <h3 className="text-sm font-semibold">Fitting out</h3>
            <span className="text-[11px] text-muted-foreground">
              This yard works to mark {maxMark} · {stats.slotsUsed}/{stats.slots} slots
            </span>
          </div>
          <p className="mt-1 text-xs text-muted-foreground">
            A great harbour turns out finer work than a careening beach. Anything already aboard can
            be raised here up to the yard's own limit.
          </p>
          {!canWork ? (
            <p className="mt-2 text-xs text-muted-foreground">
              No shipwright keeps a bench on this beach.
            </p>
          ) : (
            <ul className="mt-2 max-h-72 space-y-1 overflow-auto pr-1 text-xs">
              {COMPONENT_DEFS.map((def) => {
                const fitted = ship.components.find((c) => c.defId === def.id);
                const level = fitted?.level ?? 0;
                const capped = level >= maxMark;
                const noSlot = !fitted && stats.slotsUsed >= stats.slots;
                const cost = componentCost(def, level);
                return (
                  <li
                    key={def.id}
                    className="flex items-baseline justify-between gap-2 rounded-sm border border-border px-2 py-1"
                  >
                    <div>
                      <div className="font-semibold">
                        {def.name}
                        {fitted ? (
                          <span className="ml-1 text-muted-foreground">· mark {level}</span>
                        ) : null}
                      </div>
                      <div className="text-[11px] text-muted-foreground">{def.note}</div>
                    </div>
                    <button
                      type="button"
                      disabled={capped || noSlot || state.cash < cost}
                      onClick={() =>
                        fitted
                          ? dispatch({
                              type: "upgradeComponent",
                              shipId: ship.id,
                              componentId: fitted.id,
                            })
                          : dispatch({ type: "installComponent", shipId: ship.id, defId: def.id })
                      }
                      className="shrink-0 rounded-sm border border-input px-2 py-1 disabled:opacity-40"
                    >
                      {capped
                        ? "Beyond this yard"
                        : noSlot
                          ? "No slot"
                          : `${fitted ? "Raise" : "Fit"} · ${money(cost)}`}
                    </button>
                  </li>
                );
              })}
            </ul>
          )}
          <Link
            to="/play/ship"
            className="mt-2 inline-block rounded-sm border border-input px-2 py-1 text-xs"
          >
            Open the ship's plan
          </Link>
        </div>
      </section>

      <section className="panel space-y-4 p-4">
        <div>
          <h2 className="mb-2 text-lg font-semibold">Fitted aboard {ship.name}</h2>
          <p className="mb-2 text-xs text-muted-foreground">
            {stats.slotsUsed} of {stats.slots} component slots taken · {quartersUsed(ship)} of{" "}
            {stats.crewCapacity} quarters built. Buy, upgrade and strip components in the ship's
            plan.
          </p>
          <ul className="space-y-1 text-xs">
            {ship.components.length === 0 && (
              <li className="text-muted-foreground">Nothing fitted but her bare timbers.</li>
            )}
            {ship.components.map((c) => (
              <li
                key={c.id}
                className="flex items-baseline justify-between rounded-sm border border-border px-2 py-1"
              >
                <span>{COMPONENT_MAP[c.defId]?.name ?? c.defId}</span>
                <span className="numeric text-muted-foreground">mark {c.level}</span>
              </li>
            ))}
          </ul>
          <div className="mt-2 flex flex-wrap gap-1 text-[11px]">
            {OPTIONAL_QUARTERS.map((q) => (
              <span
                key={q.id}
                className={`rounded-full px-2 py-0.5 ${
                  ship.quarters.includes(q.id)
                    ? "bg-accent/20 text-accent"
                    : "bg-secondary text-muted-foreground"
                }`}
              >
                {QUARTER_MAP[q.id].name}
              </span>
            ))}
          </div>
        </div>

        <div>
          <h2 className="mb-2 text-lg font-semibold">Hulls for sale</h2>
          {!canWork ? (
            <p className="text-xs text-muted-foreground">No hulls are built on this beach.</p>
          ) : (
            <ul className="space-y-2">
              {SHIP_CLASSES.map((c) => (
                <li
                  key={c.id}
                  className="flex items-baseline justify-between gap-2 rounded-sm border border-border p-2 text-xs"
                >
                  <div>
                    <div className="font-semibold">{c.name}</div>
                    <div className="numeric text-muted-foreground">
                      {c.cargo} t · {c.speed} km/h · {c.firepower} firepower · {c.hands} hands ·{" "}
                      {money(c.upkeep)}/day upkeep
                    </div>
                  </div>
                  <button
                    type="button"
                    disabled={state.cash < c.price}
                    onClick={() => dispatch({ type: "buyShip", classId: c.id })}
                    className="shrink-0 rounded-sm bg-primary px-2 py-1 text-primary-foreground disabled:opacity-40"
                  >
                    {money(c.price)}
                  </button>
                </li>
              ))}
            </ul>
          )}
          <p className="mt-2 text-[11px] text-muted-foreground">
            Currently commanding the {SHIP_CLASS_MAP[ship.classId]!.name} {ship.name}.
          </p>
        </div>
      </section>
    </div>
  );
}

function Bar({ label, value }: { label: string; value: number }) {
  return (
    <div>
      <div className="flex justify-between text-xs">
        <span className="text-muted-foreground">{label}</span>
        <span className="numeric">{Math.round(value)}%</span>
      </div>
      <div className="mt-1 h-1.5 overflow-hidden rounded-sm bg-secondary">
        <div
          className={`h-full ${value < 40 ? "bg-loss" : "bg-accent"}`}
          style={{ width: `${value}%` }}
        />
      </div>
    </div>
  );
}
