import type { SeaEventKind } from "@/game/types";

/**
 * Little chart devices, drawn in the manner of a working sea-chart: each kind
 * of mark has its own figure so the captain can read the water at a glance.
 */

export const MARK_TONE: Record<SeaEventKind, string> = {
  wreck: "oklch(0.78 0.09 60)",
  derelict: "oklch(0.72 0.06 70)",
  flotsam: "oklch(0.86 0.11 90)",
  castaways: "oklch(0.88 0.13 100)",
  merchant: "oklch(0.80 0.12 145)",
  fishing: "oklch(0.82 0.10 170)",
  patrol: "oklch(0.74 0.13 265)",
  pirate: "oklch(0.66 0.19 25)",
  reef: "oklch(0.80 0.10 200)",
  squall: "oklch(0.74 0.05 250)",
  becalmed: "oklch(0.85 0.03 250)",
  whales: "oklch(0.72 0.08 230)",
  rumour: "oklch(0.88 0.11 85)",
  convoy: "oklch(0.84 0.10 130)",
  smuggler: "oklch(0.70 0.07 300)",
  corsair: "oklch(0.62 0.22 20)",
  privateer: "oklch(0.58 0.20 10)",
};

export const MARK_NAME: Record<SeaEventKind, string> = {
  wreck: "Wreck",
  derelict: "Derelict",
  flotsam: "Flotsam",
  castaways: "Castaways",
  merchant: "Merchantman",
  fishing: "Fishing boats",
  patrol: "Patrol",
  pirate: "Strange sail",
  reef: "Broken water",
  squall: "Squall",
  becalmed: "Calm belt",
  whales: "Whales",
  rumour: "News on the water",
  convoy: "Convoy in company",
  smuggler: "Free traders",
  corsair: "Corsair",
  privateer: "Privateer",
};

/** Unit-square paths, drawn about the origin at roughly r = 1. */
function glyphPaths(kind: SeaEventKind): string[] {
  switch (kind) {
    case "wreck":
      return ["M-1 0.5 L1 0.5", "M-0.5 0.5 L0.3 -1", "M0.1 -0.5 L0.9 -0.2"];
    case "derelict":
      return ["M-1 0.4 L1 0.4 L0.6 0.9 L-0.6 0.9 Z", "M0 0.4 L0 -0.9"];
    case "flotsam":
      return ["M-0.9 0 A0.45 0.45 0 1 0 0 0 A0.45 0.45 0 1 0 0.9 0", "M-0.6 0.6 L0.6 0.6"];
    case "castaways":
      return ["M-0.9 0.6 L0.9 0.6 L0.5 0 L-0.5 0 Z", "M0 0 L0 -0.9", "M0 -0.9 L0.6 -0.6"];
    case "merchant":
      return ["M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z", "M0 0.5 L0 -1", "M0 -1 L0.8 0.1 L0 0.1 Z"];
    case "fishing":
      return ["M-0.8 0.5 L0.8 0.5 L0.4 0.9 L-0.4 0.9 Z", "M0 0.5 L0 -0.7", "M0 -0.7 L0.5 0.2"];
    case "patrol":
      return ["M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z", "M0 0.5 L0 -1", "M-0.8 -1 L0 -0.4 L0.8 -1"];
    case "pirate":
      return ["M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z", "M0 0.5 L0 -1", "M0 -1 L-0.8 -0.2 L0 -0.2 Z"];
    case "reef":
      return ["M-1 0.6 L-0.4 -0.4 L0 0.3 L0.5 -0.7 L1 0.6 Z"];
    case "squall":
      return ["M-1 -0.4 A0.6 0.6 0 0 1 0.8 -0.4", "M-0.5 0.1 L-0.8 0.9", "M0.1 0.1 L-0.2 0.9", "M0.7 0.1 L0.4 0.9"];
    case "becalmed":
      return ["M-0.9 -0.3 L0.9 -0.3", "M-0.9 0.2 L0.9 0.2", "M-0.5 0.7 L0.5 0.7"];
    case "whales":
      return ["M-1 0.4 A1 0.7 0 0 1 0.7 0.2", "M0.7 0.2 L1 -0.2", "M-0.2 -0.2 L-0.4 -0.9"];
    case "convoy":
      return [
        "M-1 0.7 L0 0.7 L-0.2 1 L-0.8 1 Z",
        "M-0.5 0.7 L-0.5 -0.2",
        "M0.2 0.2 L1 0.2 L0.8 0.6 L0.4 0.6 Z",
        "M0.6 0.2 L0.6 -0.6",
      ];
    case "smuggler":
      return ["M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z", "M0 0.5 L0 -1", "M0 -1 L0.7 -0.5 L0 -0.1 Z", "M-0.9 -0.6 L-0.2 -0.6"];
    case "corsair":
      return ["M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z", "M0 0.5 L0 -1", "M0 -1 L-0.8 -0.3 L0 -0.3 Z", "M-0.9 0.1 L0.9 0.1"];
    case "privateer":
      return [
        "M-1 0.5 L1 0.5 L0.6 0.9 L-0.6 0.9 Z",
        "M-0.4 0.5 L-0.4 -1",
        "M0.4 0.5 L0.4 -0.7",
        "M-0.4 -1 L0.3 -0.5 L-0.4 -0.2 Z",
      ];
    case "rumour":
    default:
      return ["M-0.9 -0.8 L0.9 -0.8 L0.9 0.3 L-0.2 0.3 L-0.6 0.9 L-0.6 0.3 L-0.9 0.3 Z"];
  }
}

export function MarkGlyph({
  kind,
  r = 6,
  stroke = 1,
}: {
  kind: SeaEventKind;
  r?: number;
  stroke?: number;
}) {
  const tone = MARK_TONE[kind] ?? MARK_TONE.rumour;
  return (
    <g transform={`scale(${r})`}>
      {glyphPaths(kind).map((d, i) => (
        <path
          key={i}
          d={d}
          fill={kind === "reef" || kind === "rumour" ? tone : "none"}
          stroke={tone}
          strokeWidth={stroke / r}
          strokeLinecap="round"
          strokeLinejoin="round"
        />
      ))}
    </g>
  );
}

/** The same device on its own, for panels and dialogs. */
export function MarkBadge({ kind, size = 28 }: { kind: SeaEventKind; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="-1.4 -1.4 2.8 2.8" aria-hidden className="shrink-0">
      <circle r={1.35} fill="oklch(0.16 0.03 55)" stroke={MARK_TONE[kind]} strokeWidth={0.06} />
      <MarkGlyph kind={kind} r={1} stroke={0.13} />
    </svg>
  );
}

/** What a mark means to a captain at a glance: coin, danger, or nothing much. */
export type MarkAlert = "loot" | "danger" | "calm";

export const MARK_ALERT: Record<SeaEventKind, MarkAlert> = {
  wreck: "loot",
  derelict: "loot",
  flotsam: "loot",
  merchant: "loot",
  convoy: "loot",
  smuggler: "loot",
  pirate: "danger",
  corsair: "danger",
  privateer: "danger",
  reef: "danger",
  squall: "danger",
  castaways: "calm",
  fishing: "calm",
  whales: "calm",
  rumour: "calm",
  becalmed: "calm",
  patrol: "calm",
};

export const ALERT_TONE: Record<MarkAlert, string> = {
  loot: "oklch(0.86 0.16 90)",
  danger: "oklch(0.62 0.22 25)",
  calm: "oklch(0.72 0.17 150)",
};
