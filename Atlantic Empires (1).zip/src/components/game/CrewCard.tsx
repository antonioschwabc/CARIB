import { useState } from "react";

import { CrewPortrait } from "@/components/game/CrewPortrait";
import {
  FAITH_NOTE,
  POSITION_LABEL,
  POSITION_NOTE,
  POSITION_SKILL,
  SKILL_IDS,
  SKILL_LABEL,
  bestSkill,
  effSkill,
  grade,
} from "@/game/data/crew";
import { TRAIT_MAP, traitSummary } from "@/game/data/traits";
import type { CrewMember, CrewPosition, SkillId } from "@/game/types";

/** One man, as a card. Hover for his full hand of skills, click for everything. */
export function CrewCard({
  m,
  post,
  footer,
  variant = "default",
}: {
  m: CrewMember;
  /** the post he holds aboard, if any; men in the lodgings hold none */
  post?: CrewPosition | undefined;
  footer?: React.ReactNode;
  /** The tavern ledger is darker than the crew tab; use a higher-contrast card there. */
  variant?: "default" | "tavern";
}) {
  const [open, setOpen] = useState(false);
  const key = post ? POSITION_SKILL[post] : bestSkill(m);
  const best = effSkill(m, key);

  // Tavern is a forced-dark wood ledger; force the card into dark-mode tokens
  // so bg-card, text-foreground, etc. read against the tavern rather than the app theme.
  const cardBg = variant === "tavern" ? "dark bg-card" : "bg-secondary/30";

  return (
    <li className={`group relative rounded-sm border border-border ${cardBg} transition-colors hover:border-accent/60`}>
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-expanded={open}
        className="flex w-full items-start gap-3 p-2.5 text-left"
      >
        <CrewPortrait m={m} className="h-16 w-16 shrink-0 rounded-sm" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-baseline gap-x-2">
            <span className="truncate font-serif text-base font-semibold">{m.name}</span>
            <span
              className={`rounded-sm px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wide ${
                post ? "bg-accent/15 text-accent" : "bg-secondary text-muted-foreground"
              }`}
            >
              {post ? POSITION_LABEL[post] : "Unposted"}
            </span>
          </div>
          <p className="text-[11px] text-muted-foreground">
            {m.nationality} · {m.age} years · <span title={FAITH_NOTE[m.faith ?? ""]}>{m.faith ?? "Catholic"}</span>
          </p>

          <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1">
            <div>
              <div className="text-[9px] uppercase tracking-wide text-muted-foreground">{post ? SKILL_LABEL[key] : `Best · ${SKILL_LABEL[key]}`}</div>
              <div className="numeric text-lg font-semibold leading-none">{best}</div>
            </div>
            <div>
              <div className="text-[9px] uppercase tracking-wide text-muted-foreground">Potential</div>
              <div className="numeric text-lg font-semibold leading-none text-accent">{grade(m.potential)}</div>
            </div>
            <div className="min-w-[5rem] flex-1">
              <Meter label="Health" value={m.health} tone="oklch(0.62 0.15 145)" />
              <Meter label="Morale" value={m.morale} tone="oklch(0.68 0.15 70)" />
            </div>
          </div>

          {m.traits.length > 0 && (
            <div className="mt-1.5 flex flex-wrap gap-1">
              {m.traits.map((t) => (
                <TraitChip key={t} name={t} />
              ))}
            </div>
          )}
        </div>
      </button>

      {/* Hover card: every skill he has. */}
      <div className="pointer-events-none absolute left-2 top-full z-30 hidden w-64 rounded-sm border border-border bg-card p-3 shadow-lg group-hover:block">
        <p className="mb-1.5 text-[10px] uppercase tracking-wide text-muted-foreground">All skills</p>
        <dl className="grid grid-cols-2 gap-x-3 gap-y-0.5 text-[11px]">
          {SKILL_IDS.map((s: SkillId) => (
            <div key={s} className="flex justify-between">
              <dt className={s === key ? "text-accent" : "text-muted-foreground"}>{SKILL_LABEL[s]}</dt>
              <dd className="numeric">{effSkill(m, s)}</dd>
            </div>
          ))}
        </dl>
        <p className="mt-2 text-[10px] text-muted-foreground">
          {post ? POSITION_NOTE[post] : "No post aboard. He keeps his berth, eats his share, and mends the faster for the rest."}
        </p>
      </div>

      {open && (
        <div className="space-y-2 border-t border-border px-2.5 pb-2.5 pt-2">
          <dl className="grid gap-1">
            {SKILL_IDS.map((s: SkillId) => {
              const v = effSkill(m, s);
              const raw = m.skills[s];
              return (
                <div key={s}>
                  <div className="flex justify-between text-[11px]">
                    <dt className={s === key ? "font-semibold text-accent" : "text-muted-foreground"}>
                      {SKILL_LABEL[s]}
                    </dt>
                    <dd className="numeric">
                      {v}
                      {v !== raw && <span className="text-muted-foreground"> ({raw} base)</span>}
                      <span className="text-muted-foreground"> · {Math.floor(m.xp?.[s] ?? 0)}/100 xp</span>
                    </dd>
                  </div>
                  <div className="mt-0.5 h-1 overflow-hidden rounded-sm bg-secondary">
                    <div className="h-full bg-accent" style={{ width: `${Math.min(100, v)}%` }} />
                  </div>
                </div>
              );
            })}
          </dl>
          <div className="grid grid-cols-2 gap-2 text-[11px] text-muted-foreground">
            <span>
              Eats <span className="numeric text-foreground">{m.appetite}</span> rations/day at sea
            </span>
            <span>
              <span className="numeric text-foreground">+{Math.round(Math.max(0, (61 - m.age) * 2))}%</span> XP a day
              for his years
            </span>
          </div>
          {m.traits.length > 0 && (
            <ul className="space-y-1">
              {m.traits.map((t) => (
                <li key={t} className="text-[11px]">
                  <span className="font-semibold">{t}</span>{" "}
                  <span className="text-muted-foreground">— {TRAIT_MAP[t]?.note}</span>
                  <span className="numeric ml-1 text-accent">{traitSummary(t).join(", ")}</span>
                </li>
              ))}
            </ul>
          )}
          <p className="text-[11px] italic text-muted-foreground">
            {FAITH_NOTE[m.faith ?? ""] ?? "Keeps his own counsel on matters of heaven."}
          </p>
        </div>
      )}

      {footer && <div className="border-t border-border px-2.5 py-1.5">{footer}</div>}
    </li>
  );
}

function TraitChip({ name }: { name: string }) {
  const t = TRAIT_MAP[name];
  const tone =
    t?.tone === "good"
      ? "border-[oklch(0.62_0.15_145)]/50 text-[oklch(0.66_0.13_145)]"
      : t?.tone === "bad"
        ? "border-destructive/50 text-destructive"
        : "border-border text-muted-foreground";
  return (
    <span
      title={`${t?.note ?? name} (${traitSummary(name).join(", ")})`}
      className={`rounded-full border px-1.5 py-0.5 text-[10px] uppercase tracking-wide ${tone}`}
    >
      {name}
    </span>
  );
}

function Meter({ label, value, tone }: { label: string; value: number; tone: string }) {
  return (
    <div className="text-[9px] uppercase tracking-wide text-muted-foreground">
      <div className="flex justify-between">
        <span>{label}</span>
        <span className="numeric text-foreground">{Math.round(value)}</span>
      </div>
      <div className="mt-0.5 h-1 overflow-hidden rounded-sm bg-secondary">
        <div
          className="h-full"
          style={{ width: `${Math.max(0, Math.min(100, value))}%`, background: tone }}
        />
      </div>
    </div>
  );
}
