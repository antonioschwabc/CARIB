import { BannerFlag } from "@/components/game/BannerFlag";
import { CrewPortrait } from "@/components/game/CrewPortrait";
import { SKILL_IDS, SKILL_LABEL } from "@/game/data/crew";
import { POWER_MAP } from "@/game/data/powers";
import { SHIP_CLASS_MAP } from "@/game/data/ships";
import { COMPONENT_MAP } from "@/game/data/shipParts";
import type { NpcShip, SkillId } from "@/game/types";

/**
 * Another master's ship's company, as far as it can be read from a boat's
 * length away: the figures of a stranger's people are never put to numbers.
 */
export function NpcCrewDialog({ ship, onClose }: { ship: NpcShip; onClose: () => void }) {
  const cls = SHIP_CLASS_MAP[ship.classId];
  const power = ship.power ? POWER_MAP[ship.power] : undefined;
  const cap = ship.captain;

  return (
    <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/80 p-4" onClick={onClose}>
      <div
        className="panel max-h-[85vh] w-full max-w-2xl space-y-4 overflow-y-auto p-5 text-card-foreground"
        onClick={(e) => e.stopPropagation()}
      >
        <header className="flex items-start gap-3 border-b border-border pb-3">
          <BannerFlag banner={ship.banner} className="h-10 w-14 shrink-0" />
          <div className="min-w-0 flex-1">
            <h2 className="font-serif text-2xl font-bold text-accent">{ship.name}</h2>
            <p className="text-xs text-muted-foreground">
              {ship.seen ? (cls?.name ?? "unknown rig") : "rig uncertain"}
              {power ? ` · ${power.adjective} colours` : " · no crown's colours; a free trader"}
              {ship.banner.name ? ` · ${ship.banner.name}` : ""}
            </p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="rounded-sm border border-input px-2 py-1 text-xs hover:bg-secondary"
          >
            Close
          </button>
        </header>

        <section className="flex items-start gap-4">
          <CrewPortrait
            m={{
              id: cap.portraitSeed,
              seed: cap.portraitSeed,
              name: cap.name,
              nationality: cap.nationality,
              age: cap.age,
              traits: [],
            }}
            className="h-24 w-24 shrink-0 rounded-sm"
          />
          <div className="min-w-0 flex-1">
            <p className="text-[11px] uppercase tracking-widest text-muted-foreground">Her captain</p>
            <p className="font-serif text-lg font-semibold">{cap.name}</p>
            <p className="text-xs text-muted-foreground">
              {cap.age} years · {cap.nationality}
            </p>
            <dl className="mt-2 grid gap-1.5 sm:grid-cols-2">
              {SKILL_IDS.map((k: SkillId) => {
                const v = cap.skills[k] ?? 0;
                return (
                  <div key={k}>
                    <dt className="text-[10px] uppercase tracking-wide text-muted-foreground">{SKILL_LABEL[k]}</dt>
                    <dd className="mt-0.5 h-1.5 overflow-hidden rounded-sm bg-secondary">
                      <div className="h-full bg-accent" style={{ width: `${Math.min(100, v)}%` }} />
                    </dd>
                  </div>
                );
              })}
            </dl>
            <p className="mt-1.5 text-[11px] italic text-muted-foreground">
              A stranger's hand is judged by the eye, never by the ledger — you may see how full the
              glass is, not how many measures are in it.
            </p>
          </div>
        </section>

        <section className="grid gap-3 sm:grid-cols-2">
          <div className="rounded-sm border border-border p-3">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Her figures</h3>
            {ship.seen ? (
              <dl className="numeric mt-1.5 grid grid-cols-2 gap-x-3 text-xs">
                <dt className="text-muted-foreground">Hull</dt>
                <dd>
                  {Math.round(ship.hull)} / {ship.maxHull}
                </dd>
                <dt className="text-muted-foreground">Firepower</dt>
                <dd>{Math.round(ship.firepower)}</dd>
                <dt className="text-muted-foreground">Speed</dt>
                <dd>{ship.speed.toFixed(1)} kn</dd>
                <dt className="text-muted-foreground">Helm</dt>
                <dd>{Math.round(ship.maneuver)}</dd>
                {ship.gold !== undefined && (
                  <>
                    <dt className="text-muted-foreground">Purse</dt>
                    <dd>{Math.round(ship.gold)}</dd>
                  </>
                )}
              </dl>
            ) : (
              <p className="mt-1.5 text-xs text-muted-foreground">
                She has never been under your own glass. Close with her and the lookouts will tell you
                more.
              </p>
            )}
            {ship.seen && ship.components.length > 0 && (
              <p className="mt-2 text-[11px] text-muted-foreground">
                Fitted: {ship.components.map((c) => COMPONENT_MAP[c]?.name ?? c).join(", ")}
              </p>
            )}
          </div>

          <div className="rounded-sm border border-border p-3">
            <h3 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
              Her people ({ship.crewNames.length} named)
            </h3>
            <ul className="mt-1.5 space-y-0.5 text-xs">
              {ship.crewNames.map((n) => (
                <li key={n} className="text-muted-foreground">
                  {n}
                </li>
              ))}
            </ul>
          </div>
        </section>
      </div>
    </div>
  );
}
