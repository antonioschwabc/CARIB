import { useRef, useState } from "react";
import { createPortal } from "react-dom";
import { ChevronLeft, ChevronRight } from "lucide-react";

import { activeShip, volumeOf } from "@/game/actions";
import { BannerFlag } from "@/components/game/BannerFlag";
import { PORT_MAP } from "@/game/data/ports";
import { POWERS, POWER_MAP } from "@/game/data/powers";
import { SHIP_CLASS_MAP } from "@/game/data/ships";
import {
  COMPONENT_MAP,
  OPTIONAL_QUARTERS,
  QUARTER_MAP,
  SHIP_REGIONS,
  componentCost,
  componentsForRegion,
  gunCost,
} from "@/game/data/shipParts";
import { POSITION_LABEL, POSITION_SKILL } from "@/game/data/crew";
import { money } from "@/game/sim/util";
import {
  gunPorts,
  overallCondition,
  quartersUsed,
  regionCondition,
  shipStats,
  statBreakdown,
} from "@/game/sim/shipStats";
import { cargoUsed, effectiveSpeed } from "@/game/sim/voyage";
import { ShipSchematic } from "@/components/game/ShipSchematic";
import { useGame } from "@/game/store";
import { BASE_HOLDS, HOLD_TYPES, holdsOf } from "@/game/sim/holds";
import { CATEGORY_LABEL, COMMODITY_MAP } from "@/game/data/commodities";
import type { CrewMember, CrewPosition, Ship, ShipRegion, ShipStatKey } from "@/game/types";

/** Wood, canvas and old parchment: the same hand as the market ledger. */
const WOOD = {
  frame: "oklch(0.30 0.045 45)",
  board: "repeating-linear-gradient(92deg, oklch(0.17 0.022 42) 0 22px, oklch(0.19 0.026 44) 22px 46px)",
  header: "linear-gradient(180deg, oklch(0.34 0.06 48), oklch(0.24 0.04 44) 60%, oklch(0.20 0.03 42))",
  parchment: "linear-gradient(155deg, oklch(0.90 0.035 85), oklch(0.85 0.045 80) 60%, oklch(0.80 0.05 76))",
};
const INK = "oklch(0.26 0.03 55)";
const FAINT = "oklch(0.42 0.03 60)";

const STAT_LABEL: Record<ShipStatKey, string> = {
  hull: "Hull",
  firepower: "Firepower",
  maneuverability: "Maneuverability",
  scouting: "Scouting",
  cargo: "Cargo",
  speed: "Speed",
};

export function ShipPanel({ initialRegion }: { initialRegion?: ShipRegion } = {}) {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  const [region, setRegion] = useState<ShipRegion>(initialRegion ?? "hull");
  if (!ship) return <p className="p-6">You have no ships.</p>;

  const cls = SHIP_CLASS_MAP[ship.classId]!;
  const port = PORT_MAP[ship.portId]!;
  const atSea = !!ship.voyage;
  const crew = state.crew.filter((m) => m.shipId === ship.id);
  const stats = shipStats(ship, crew);
  const banner = ship.banner ?? state.banner;
  const nation = ship.allegiance ? POWER_MAP[ship.allegiance] : undefined;
  const regionInfo = SHIP_REGIONS.find((r) => r.id === region)!;
  const slotsFree = stats.slots - stats.slotsUsed;
  const condition = overallCondition(ship);

  return (
    <div className="space-y-4 p-4">
      {/* ── Her name, her colours, her captain ─────────────────────────── */}
      <section
        className="overflow-hidden rounded-sm border-2 shadow-lg"
        style={{ borderColor: WOOD.frame, background: WOOD.board }}
      >
        <div
          className="flex flex-wrap items-center gap-5 px-5 py-4"
          style={{ background: WOOD.header, borderBottom: `1px solid ${WOOD.frame}` }}
        >
          <BannerFlag banner={banner} className="h-16 w-24 shrink-0" />
          <div className="min-w-52 flex-1">
            <h1 className="text-3xl font-semibold leading-tight text-[oklch(0.93_0.03_84)]">{ship.name}</h1>
            <p className="text-xs uppercase tracking-[0.18em] text-[oklch(0.78_0.05_80)]">
              {cls.name} · {banner.name}
              {nation ? ` · ${nation.adjective} colours` : " · no crown"}
            </p>
          </div>
          <div className="text-right">
            <p className="text-[10px] uppercase tracking-[0.18em] text-[oklch(0.72_0.04_80)]">Master &amp; commander</p>
            <p className="text-lg text-[oklch(0.93_0.03_84)]">{state.player.name}</p>
            <p className="text-[11px] text-[oklch(0.76_0.04_80)]">
              {state.player.nationality} · {state.player.age} years
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 px-5 py-2.5 text-xs text-[oklch(0.80_0.03_82)]">
          <span className="uppercase tracking-wide">
            {atSea ? `At sea → ${PORT_MAP[ship.voyage!.to]!.name}` : `Moored at ${port.name}`}
          </span>
          <label className="ml-auto flex items-center gap-2">
            <span className="uppercase tracking-wide text-[oklch(0.70_0.03_80)]">Sail under</span>
            <select
              value={ship.allegiance ?? ""}
              onChange={(e) =>
                dispatch({ type: "setAllegiance", shipId: ship.id, power: (e.target.value || undefined) as never })
              }
              className="rounded-sm border px-2 py-1 text-xs"
              style={{ borderColor: WOOD.frame, background: WOOD.parchment, color: INK }}
            >
              <option value="">No colours but your own</option>
              {POWERS.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name}
                  {state.letters.includes(p.id) ? " (commissioned)" : " (needs 25 standing)"}
                </option>
              ))}
            </select>
          </label>
        </div>
      </section>

      {/* ── Her statistics, then her plan ──────────────────────────────── */}
      <section
        className="overflow-hidden rounded-sm border-2 shadow-lg"
        style={{ borderColor: WOOD.frame, background: WOOD.board }}
      >
        <div className="grid grid-cols-2 gap-px p-3 sm:grid-cols-4 lg:grid-cols-9" style={{ background: WOOD.board }}>
          <Tile label="Condition" value={`${Math.round(condition)}%`} hint="Mean of every part aboard" />
          <StatTile label="Hull" value={`${stats.hull}`} ship={ship} crew={crew} stat="hull" />
          <StatTile
            label="Firepower"
            value={`${stats.firepower}`}
            ship={ship}
            crew={crew}
            stat="firepower"
            note="Only mounted guns throw metal"
          />
          <StatTile label="Maneuver" value={`${stats.maneuverability}`} ship={ship} crew={crew} stat="maneuverability" />
          <StatTile label="Scouting" value={`${stats.scouting}`} ship={ship} crew={crew} stat="scouting" />
          <StatTile
            label="Cargo"
            value={`${cargoUsed(ship, volumeOf).toFixed(0)}/${stats.cargo} t`}
            ship={ship}
            crew={crew}
            stat="cargo"
          />
          <StatTile
            label="Speed"
            value={`${effectiveSpeed(ship).toFixed(1)} kn`}
            ship={ship}
            crew={crew}
            stat="speed"
            note="Wind and her trim tell on the day's run"
          />
          <Tile label="Hands" value={`${ship.crew} / ${cls.hands}`} hint="Berths in her lodgings" />
          <Tile
            label="Modifications"
            value={`${stats.slotsUsed} / ${stats.slots}`}
            hint="One pool for the whole ship; upgrading a fitted part costs no further slot"
          />
        </div>

        <div className="px-3 pb-3">
          <ShipSchematic ship={ship} region={region} onRegion={setRegion} />
        </div>

        <div
          className="flex flex-wrap items-baseline gap-x-4 gap-y-1 px-4 py-2"
          style={{ borderTop: `1px solid ${WOOD.frame}` }}
        >
          <h2 className="text-lg text-[oklch(0.93_0.03_84)]">{regionInfo.name}</h2>
          <span className="numeric text-xs text-[oklch(0.80_0.05_80)]">
            condition {Math.round(regionCondition(ship, region))}%
          </span>
          <p className="w-full text-xs italic text-[oklch(0.72_0.03_80)]">{regionInfo.note}</p>
        </div>

        <Rail>
          {region === "warehouse" ? (
            <WarehouseCards ship={ship} capacity={stats.cargo} atSea={atSea} canFit={!atSea && port.shipyard > 0} />
          ) : (
            <>
              {region === "ordnance" && <OrdnanceCard ship={ship} stats={stats} atSea={atSea} yard={port.shipyard > 0} />}
              {region === "deck" && (
                <QuarterCards ship={ship} capacity={stats.crewCapacity} atSea={atSea} yard={port.shipyard > 0} />
              )}
              {componentsForRegion(region).map((def) => {
                const fitted = ship.components.find((c) => c.defId === def.id);
                const level = fitted?.level ?? 0;
                const nextCost = componentCost(def, level);
                const maxed = level >= 5;
                const canBuy = !atSea && port.shipyard > 0 && state.cash >= nextCost;
                const gain = def.steps[Math.max(0, level - 1)] ?? 0;
                const nextGain = def.steps[Math.min(4, level)] ?? 0;
                return (
                  <Card
                    key={def.id}
                    fitted={!!fitted}
                    detail={
                      <>
                        <p className="font-semibold">{def.name}</p>
                        <p className="mt-1" style={{ color: FAINT }}>{def.note}</p>
                        <p className="mt-2 text-[11px]">{regionInfo.name} · takes one slot · marks 1 to 5</p>
                        <ul className="numeric mt-2 space-y-0.5 text-[11px]">
                          {def.steps.map((st, i) => (
                            <li
                              key={i}
                              className="flex justify-between"
                              style={{ fontWeight: level === i + 1 ? 700 : 400, opacity: level === i + 1 ? 1 : 0.8 }}
                            >
                              <span>Mark {i + 1}</span>
                              <span>
                                {STAT_LABEL[def.stat]} +{(st * 100).toFixed(1)}% · {money(componentCost(def, i))}
                              </span>
                            </li>
                          ))}
                        </ul>
                        <p className="mt-2 text-[11px]" style={{ color: FAINT }}>
                          {fitted ? `Fitted at mark ${level}.` : "Not fitted."}
                        </p>
                      </>
                    }
                  >
                    <div className="flex items-baseline justify-between gap-2">
                      <span className="text-sm font-semibold" style={{ color: INK }}>
                        {def.name}
                      </span>
                      {fitted && <span className="numeric text-xs" style={{ color: INK }}>mk {level}</span>}
                    </div>
                    <p className="mt-1 text-xs" style={{ color: FAINT }}>
                      {def.note}
                    </p>
                    <p className="numeric mt-2 text-[11px]" style={{ color: INK }}>
                      {STAT_LABEL[def.stat]}
                      {fitted ? ` +${(gain * 100).toFixed(1)}%` : ""}
                      {!maxed && ` → +${(nextGain * 100).toFixed(1)}%`}
                    </p>
                    <div className="mt-auto flex gap-2 pt-3">
                      <Action
                        disabled={maxed || !canBuy || (!fitted && slotsFree <= 0)}
                        onClick={() =>
                          fitted
                            ? dispatch({ type: "upgradeComponent", shipId: ship.id, componentId: fitted.id })
                            : dispatch({ type: "installComponent", shipId: ship.id, defId: def.id })
                        }
                      >
                        {maxed
                          ? "At mark 5"
                          : atSea
                            ? "At sea"
                            : port.shipyard === 0
                              ? "No yard here"
                              : !fitted && slotsFree <= 0
                                ? "No modification slots left"
                                : `${fitted ? "Upgrade" : "Install"} · ${money(nextCost)}`}
                      </Action>
                      {fitted && (
                        <Action
                          ghost
                          disabled={atSea}
                          onClick={() => dispatch({ type: "removeComponent", shipId: ship.id, componentId: fitted.id })}
                        >
                          Strip out
                        </Action>
                      )}
                    </div>
                  </Card>
                );
              })}
            </>
          )}
        </Rail>
      </section>
    </div>
  );
}

/** A page of cards you turn to the right. Turn-arrows sit above the cards. */
function Rail({ children, title }: { children: React.ReactNode; title?: string }) {
  const ref = useRef<HTMLDivElement>(null);
  const page = (dir: 1 | -1) => ref.current?.scrollBy({ left: dir * 300, behavior: "smooth" });
  return (
    <div>
      <div className="flex items-center justify-end gap-2 px-4 pb-1">
        {title && (
          <span className="mr-auto text-[10px] uppercase tracking-[0.16em] text-[oklch(0.72_0.03_80)]">{title}</span>
        )}
        <Turn dir={-1} onClick={() => page(-1)} />
        <Turn dir={1} onClick={() => page(1)} />
      </div>
      <div
        ref={ref}
        className="flex snap-x snap-mandatory gap-3 overflow-x-auto px-4 pb-4 pt-1 [scrollbar-width:thin]"
      >
        {children}
      </div>
    </div>
  );
}

function Turn({ dir, onClick }: { dir: 1 | -1; onClick: () => void }) {
  const Icon = dir === 1 ? ChevronRight : ChevronLeft;
  return (
    <button
      type="button"
      onClick={onClick}
      aria-label={dir === 1 ? "Turn page right" : "Turn page left"}
      className="rounded-full border p-1.5 shadow"
      style={{ borderColor: WOOD.frame, background: WOOD.parchment, color: INK }}
    >
      <Icon className="size-4" />
    </button>
  );
}

function Card({
  children,
  fitted,
  detail,
  onClick,
}: {
  children: React.ReactNode;
  fitted?: boolean;
  /** Flashed out when the (? ) button is hovered. */
  detail?: React.ReactNode;
  onClick?: () => void;
}) {
  return (
    <div className="relative w-64 shrink-0 snap-start">
      <div
        onClick={onClick}
        className={`flex h-full flex-col rounded-sm border-2 p-3 shadow ${onClick ? "cursor-pointer" : ""}`}
        style={{
          borderColor: fitted ? "oklch(0.55 0.12 62)" : WOOD.frame,
          background: WOOD.parchment,
        }}
      >
        {children}
      </div>
      {detail && <DetailButton detail={detail} fitted={fitted} />}
    </div>
  );
}

/** A (? ) button in the card's corner that summons the detail popup on hover.
 *  The popup is rendered fixed so it is never clipped by the scrolling rail. */
function DetailButton({ detail, fitted }: { detail: React.ReactNode; fitted?: boolean | undefined }) {
  const [show, setShow] = useState(false);
  const btnRef = useRef<HTMLButtonElement>(null);
  const [pos, setPos] = useState({ left: 0, top: 0 });

  const open = () => {
    const rect = btnRef.current?.getBoundingClientRect();
    if (rect) {
      const width = 320;
      let left = rect.right - width;
      if (left < 8) left = 8;
      setPos({ left, top: rect.bottom + 6 });
    }
    setShow(true);
  };

  return (
    <>
      <button
        ref={btnRef}
        type="button"
        onMouseEnter={open}
        onMouseLeave={() => setShow(false)}
        onClick={(e) => e.stopPropagation()}
        className="absolute right-2 top-2 flex h-6 w-6 items-center justify-center rounded-full border text-xs font-bold shadow"
        style={{
          borderColor: fitted ? "oklch(0.55 0.12 62)" : WOOD.frame,
          background: WOOD.parchment,
          color: INK,
        }}
        aria-label="Show details"
      >
        ?
      </button>
      {show &&
        createPortal(
          <div
            onMouseEnter={() => setShow(true)}
            onMouseLeave={() => setShow(false)}
            className="fixed z-[100] w-80 rounded-sm border-2 p-3 text-xs shadow-xl"
            style={{ left: pos.left, top: pos.top, borderColor: WOOD.frame, background: WOOD.parchment, color: INK }}
          >
            {detail}
          </div>,
          document.body,
        )}
    </>
  );
}

function Action({
  children,
  onClick,
  disabled,
  ghost,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  ghost?: boolean;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      className="flex-1 rounded-sm border px-2 py-1.5 text-xs disabled:opacity-45"
      style={
        ghost
          ? { borderColor: WOOD.frame, color: INK, background: "transparent" }
          : { borderColor: WOOD.frame, color: "oklch(0.94 0.02 84)", background: WOOD.header }
      }
    >
      {children}
    </button>
  );
}

/** A figure with its reckoning: her timbers, her fittings, and the men aboard. */
function StatTile({
  label,
  value,
  ship,
  crew,
  stat,
  note,
}: {
  label: string;
  value: string;
  ship: Ship;
  crew: CrewMember[];
  stat: ShipStatKey;
  note?: string;
}) {
  const b = statBreakdown(ship, stat, crew);
  const pct = (v: number) => `${v >= 0 ? "+" : ""}${(v * 100).toFixed(1)}%`;
  return (
    <div
      className="group relative rounded-sm border px-2.5 py-2"
      style={{ borderColor: WOOD.frame, background: WOOD.parchment }}
    >
      <div className="text-[10px] uppercase tracking-[0.14em]" style={{ color: FAINT }}>
        {label}
      </div>
      <div className="numeric text-base font-semibold" style={{ color: INK }}>
        {value}
      </div>
      <div
        className="pointer-events-none absolute left-0 top-full z-30 hidden w-56 rounded-sm border-2 p-2 text-[11px] shadow-xl group-hover:block"
        style={{ borderColor: WOOD.frame, background: WOOD.parchment, color: INK }}
      >
        <div className="numeric flex justify-between">
          <span style={{ color: FAINT }}>Bare hull</span>
          <span>{Math.round(b.base * 10) / 10}</span>
        </div>
        <div className="numeric flex justify-between">
          <span style={{ color: FAINT }}>Fittings</span>
          <span>{pct(b.fitted)}</span>
        </div>
        <div className="numeric flex justify-between">
          <span style={{ color: FAINT }}>
            Crew · {b.crewSkill} {b.crewValue}
          </span>
          <span>{pct(b.crew)}</span>
        </div>
        <div
          className="numeric mt-1 flex justify-between border-t pt-1 font-semibold"
          style={{ borderColor: WOOD.frame }}
        >
          <span>Final</span>
          <span>{Math.round(b.total * 10) / 10}</span>
        </div>
        <p className="mt-1 italic" style={{ color: FAINT }}>
          {note ? `${note} · ` : ""}each point of skill lends 0.44%.
        </p>
      </div>
    </div>
  );
}

function Tile({ label, value, hint }: { label: string; value: string; hint?: string }) {
  return (
    <div
      className="rounded-sm border px-2.5 py-2"
      style={{ borderColor: WOOD.frame, background: WOOD.parchment }}
      title={hint}
    >
      <div className="text-[10px] uppercase tracking-[0.14em]" style={{ color: FAINT }}>
        {label}
      </div>
      <div className="numeric text-base font-semibold" style={{ color: INK }}>
        {value}
      </div>
    </div>
  );
}

/** Her guns: what is mounted, at what mark, and how much room is left. */
function OrdnanceCard({
  ship,
  stats,
  atSea,
  yard,
}: {
  ship: Ship;
  stats: ReturnType<typeof shipStats>;
  atSea: boolean;
  yard: boolean;
}) {
  const { dispatch } = useGame();
  const guns = ship.guns ?? [];
  const { ports, free } = gunPorts(ship);
  const mean = guns.length ? guns.reduce((t, m) => t + m, 0) / guns.length : 0;
  const weakest = guns.reduce(
    (best: { index: number; mark: number } | undefined, mark, index) =>
      mark < 5 && (!best || mark < best.mark) ? { index, mark } : best,
    undefined,
  );
  const marks = [1, 2, 3, 4, 5].map((m) => guns.filter((g) => g === m).length);

  return (
    <Card
      detail={
        <>
          <p className="font-semibold">Weight of metal</p>
          <p className="mt-1" style={{ color: FAINT }}>
            Firepower is nothing but the pieces she carries. Guns sit in her gun ports, not in her modification
            slots, and each may be rebored from mark 1 to mark 5.
          </p>
          <ul className="numeric mt-2 space-y-0.5 text-[11px]">
            {marks.map((count, i) =>
              count > 0 ? (
                <li key={i} className="flex justify-between">
                  <span>Mark {i + 1}</span>
                  <span>{count} pieces</span>
                </li>
              ) : null,
            )}
            {guns.length === 0 && <li className="italic">Nothing mounted.</li>}
          </ul>
          <p className="numeric mt-2 text-[11px]">Firepower {stats.firepower}</p>
        </>
      }
    >
      <h3 className="text-sm font-semibold" style={{ color: INK }}>
        The battery
      </h3>
      <p className="numeric mt-1 text-2xl font-semibold" style={{ color: INK }}>
        {guns.length}
        <span className="text-xs"> of {ports} guns</span>
      </p>
      <p className="numeric mt-1 text-[11px]" style={{ color: FAINT }}>
        {guns.length ? `average mark ${mean.toFixed(1)}` : "not a gun aboard her"} · firepower {stats.firepower}
      </p>
      <div className="mt-auto flex flex-col gap-2 pt-3">
        <Action
          disabled={atSea || !yard || free <= 0}
          onClick={() => dispatch({ type: "buyGun", shipId: ship.id })}
        >
          {atSea ? "At sea" : !yard ? "No yard here" : free <= 0 ? "Every port filled" : `Mount a gun · ${money(gunCost(0))}`}
        </Action>
        <Action
          ghost
          disabled={atSea || !yard || !weakest}
          onClick={() => weakest && dispatch({ type: "upgradeGun", shipId: ship.id, index: weakest.index })}
        >
          {weakest ? `Rebore to mark ${weakest.mark + 1} · ${money(gunCost(weakest.mark))}` : "All guns at mark 5"}
        </Action>
        <Action
          ghost
          disabled={atSea || guns.length === 0}
          onClick={() => dispatch({ type: "sellGun", shipId: ship.id, index: guns.length - 1 })}
        >
          Land a gun
        </Action>
      </div>
    </Card>
  );
}

/** The lower deck, reached through the deck of the ship. */
function QuarterCards({
  ship,
  capacity,
  atSea,
  yard,
}: {
  ship: Ship;
  capacity: number;
  atSea: boolean;
  yard: boolean;
}) {
  const { state, dispatch } = useGame();
  const built = quartersUsed(ship);
  return (
    <>
      <Card>
        <h3 className="text-sm font-semibold" style={{ color: INK }}>
          Lower deck
        </h3>
        <p className="numeric mt-1 text-2xl font-semibold" style={{ color: INK }}>
          {built} / {capacity}
        </p>
        <p className="mt-1 text-xs" style={{ color: FAINT }}>
          Quarters built. A post cannot be filled until its quarter stands; the captain's cabin is always aboard.
        </p>
        <p className="mt-auto pt-3 text-[11px] italic" style={{ color: FAINT }}>
          Turn right for the quarters she may carry.
        </p>
      </Card>
      {(() => {
        const cabin = QUARTER_MAP.captain;
        const holder = state.crew.find((m) => m.id === ship.assignments.captain);
        return (
          <Card
            fitted
            detail={
              <>
                <p className="font-semibold">{cabin.name}</p>
                <p className="mt-1" style={{ color: FAINT }}>{cabin.note}</p>
                <p className="mt-2 text-[11px]">Post: {POSITION_LABEL.captain} · skill {POSITION_SKILL.captain}</p>
                <p className="text-[11px]">
                  {holder ? `${holder.name} keeps this cabin.` : "No master aboard."}
                </p>
                <p className="mt-1 text-[11px]">Built into the hull; she costs no lower-deck room.</p>
              </>
            }
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-semibold" style={{ color: INK }}>
                {cabin.name}
              </span>
              <span className="numeric text-xs" style={{ color: INK }}>
                fitted
              </span>
            </div>
            <p className="mt-1 text-xs" style={{ color: FAINT }}>
              {cabin.note}
            </p>
            <p className="mt-2 text-[11px]" style={{ color: INK }}>
              {POSITION_LABEL.captain} ·{" "}
              {holder ? `${holder.name} (${holder.skills[POSITION_SKILL.captain]})` : "no one posted"}
            </p>
            <div className="mt-auto pt-3">
              <Action ghost disabled onClick={() => {}}>
                Always aboard
              </Action>
            </div>
          </Card>
        );
      })()}
      {OPTIONAL_QUARTERS.map((q) => {
        const has = ship.quarters.includes(q.id);
        const holder = state.crew.find((m) => m.id === ship.assignments[q.id]);
        const room = built < capacity;
        return (
          <Card
            key={q.id}
            fitted={has}
            detail={
              <>
                <p className="font-semibold">{q.name}</p>
                <p className="mt-1" style={{ color: FAINT }}>{q.note}</p>
                <p className="mt-2 text-[11px]">Post: {POSITION_LABEL[q.id]} · skill {POSITION_SKILL[q.id]}</p>
                <p className="text-[11px]">
                  {holder ? `${holder.name} is posted here.` : "The berth stands empty."}
                </p>
                <p className="numeric mt-1 text-[11px]">
                  Cost {money(q.price)} · lower deck {built} of {capacity}
                </p>
              </>
            }
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-semibold" style={{ color: INK }}>
                {q.name}
              </span>
              <span className="numeric text-xs" style={{ color: INK }}>
                {money(q.price)}
              </span>
            </div>
            <p className="mt-1 text-xs" style={{ color: FAINT }}>
              {q.note}
            </p>
            <p className="mt-2 text-[11px]" style={{ color: INK }}>
              {POSITION_LABEL[q.id]} ·{" "}
              {holder ? `${holder.name} (${holder.skills[POSITION_SKILL[q.id]]})` : "no one posted"}
            </p>
            <div className="mt-auto pt-3">
              <Action
                ghost={has}
                disabled={atSea || (has ? false : !yard || !room || state.cash < q.price)}
                onClick={() =>
                  dispatch(
                    has
                      ? { type: "removeQuarter", shipId: ship.id, position: q.id as CrewPosition }
                      : { type: "installQuarter", shipId: ship.id, position: q.id as CrewPosition },
                  )
                }
              >
                {has ? "Tear out" : atSea ? "At sea" : !yard ? "No yard here" : !room ? "Lower deck full" : `Build · ${money(q.price)}`}
              </Action>
            </div>
          </Card>
        );
      })}
    </>
  );
}

/** Her stowage: capacity, what is aboard, and which kinds of goods she may carry. */
function WarehouseCards({
  ship,
  capacity,
  atSea,
  canFit,
}: {
  ship: Ship;
  capacity: number;
  atSea: boolean;
  canFit: boolean;
}) {
  const { state, dispatch } = useGame();
  const [manifest, setManifest] = useState(false);
  const fitted = holdsOf(ship);
  const used = cargoUsed(ship, volumeOf);
  const laden = Object.entries(ship.cargo).filter(([, q]) => q > 0);
  const rows = laden
    .map(([cid, q]) => {
      const c = COMMODITY_MAP[cid];
      return {
        id: cid,
        name: c?.name ?? cid,
        category: c ? (CATEGORY_LABEL[c.category] ?? c.category) : "—",
        units: q,
        unit: Math.round(q) === 1 ? (c?.unit ?? "unit") : (c?.unitPlural ?? "units"),
        tons: q * volumeOf(cid),
      };
    })
    .sort((a, b) => b.tons - a.tons);

  return (
    <>
      <Card>
        <h3 className="text-sm font-semibold" style={{ color: INK }}>
          Stowage
        </h3>
        <p className="numeric mt-1 text-2xl font-semibold" style={{ color: INK }}>
          {used.toFixed(1)} / {capacity} t
        </p>
        <div className="mt-2 h-2 w-full rounded-full" style={{ background: "oklch(0.72 0.04 78)" }}>
          <div
            className="h-full rounded-full"
            style={{
              width: `${Math.max(0, Math.min(100, (used / Math.max(1, capacity)) * 100))}%`,
              background: "oklch(0.45 0.11 55)",
            }}
          />
        </div>
        <p className="mt-auto pt-3 text-[11px] italic" style={{ color: FAINT }}>
          Turn right for what she carries and the holds she is fitted with.
        </p>
      </Card>

      <Card
        onClick={() => setManifest(true)}
        detail={
          <>
            <p className="font-semibold">Manifest — {rows.length} entries · {used.toFixed(1)} t</p>
            {rows.length === 0 ? (
              <p className="mt-1 italic" style={{ color: FAINT }}>
                Her hold is empty.
              </p>
            ) : (
              <ul className="numeric mt-2 max-h-56 space-y-0.5 overflow-y-auto text-[11px]">
                {rows.map((r) => (
                  <li key={r.id} className="flex justify-between gap-3">
                    <span className="truncate">
                      {r.name} <span style={{ color: FAINT }}>· {r.category}</span>
                    </span>
                    <span className="shrink-0">
                      {Math.round(r.units)} {r.unit} · {r.tons.toFixed(1)} t
                    </span>
                  </li>
                ))}
              </ul>
            )}
            <p className="mt-2 text-[11px] italic" style={{ color: FAINT }}>
              Click the card for the full ledger of the hold.
            </p>
          </>
        }
      >
        <h3 className="text-sm font-semibold" style={{ color: INK }}>
          Goods aboard
        </h3>
        <p className="numeric mt-1 text-2xl font-semibold" style={{ color: INK }}>
          {rows.length} <span className="text-xs">kinds · {used.toFixed(1)} t</span>
        </p>
        <p className="mt-1 text-xs" style={{ color: FAINT }}>
          {rows.length === 0 ? "Her hold is empty." : "Hover for the manifest, click for the ledger."}
        </p>
        <p className="numeric mt-auto pt-3 text-[11px]" style={{ color: INK }}>
          Heaviest: {rows[0] ? `${rows[0].name} (${rows[0].tons.toFixed(1)} t)` : "—"}
        </p>
      </Card>

      {manifest && <HoldLedger rows={rows} used={used} capacity={capacity} onClose={() => setManifest(false)} />}


      {HOLD_TYPES.map((h) => {
        const base = BASE_HOLDS.includes(h.category);
        const built = fitted.includes(h.category);
        return (
          <Card
            key={h.category}
            fitted={built}
            detail={
              <>
                <p className="font-semibold">{h.name}</p>
                <p className="mt-1" style={{ color: FAINT }}>{h.note}</p>
                <p className="mt-2 text-[11px]">Carries: {CATEGORY_LABEL[h.category]}</p>
                <p className="numeric mt-1 text-[11px]">
                  {base ? "Fitted as built — cannot be torn out." : built ? "Fitted." : `Fitting costs ${money(h.price)}.`}
                </p>
                <ul className="numeric mt-2 space-y-0.5 text-[11px]">
                  {rows.filter((r) => COMMODITY_MAP[r.id]?.category === h.category).map((r) => (
                    <li key={r.id} className="flex justify-between gap-3">
                      <span className="truncate">{r.name}</span>
                      <span>{r.tons.toFixed(1)} t</span>
                    </li>
                  ))}
                  {rows.every((r) => COMMODITY_MAP[r.id]?.category !== h.category) && (
                    <li className="italic" style={{ color: FAINT }}>Nothing of this kind aboard.</li>
                  )}
                </ul>
              </>
            }
          >
            <div className="flex items-baseline justify-between gap-2">
              <span className="text-sm font-semibold" style={{ color: INK }}>
                {h.name}
              </span>
              <span className="numeric text-xs" style={{ color: INK }}>
                {base ? "fitted" : money(h.price)}
              </span>
            </div>
            <p className="mt-1 text-xs" style={{ color: FAINT }}>
              {h.note}
            </p>
            <p className="mt-2 text-[11px]" style={{ color: INK }}>
              Carries: {CATEGORY_LABEL[h.category]}
            </p>
            <div className="mt-auto pt-3">
              {!base && (
                <Action
                  ghost={built}
                  disabled={atSea || (built ? false : !canFit || state.cash < h.price)}
                  onClick={() =>
                    dispatch(
                      built
                        ? { type: "removeHold", shipId: ship.id, category: h.category }
                        : { type: "installHold", shipId: ship.id, category: h.category },
                    )
                  }
                >
                  {built ? "Tear out" : atSea ? "At sea" : !canFit ? "No yard here" : `Fit · ${money(h.price)}`}
                </Action>
              )}
            </div>
          </Card>
        );
      })}
    </>
  );
}

/** The ledger of the hold: every entry, sortable, as the market keeps its books. */
function HoldLedger({
  rows,
  used,
  capacity,
  onClose,
}: {
  rows: { id: string; name: string; category: string; units: number; unit: string; tons: number }[];
  used: number;
  capacity: number;
  onClose: () => void;
}) {
  const [sort, setSort] = useState<"name" | "category" | "units" | "tons">("tons");
  const sorted = [...rows].sort((a, b) =>
    sort === "name" || sort === "category" ? String(a[sort]).localeCompare(String(b[sort])) : Number(b[sort]) - Number(a[sort]),
  );
  const Head = ({ k, label, right }: { k: typeof sort; label: string; right?: boolean }) => (
    <th
      onClick={() => setSort(k)}
      className={`cursor-pointer px-2 py-1 text-[10px] uppercase tracking-[0.14em] ${right ? "text-right" : "text-left"}`}
      style={{ color: sort === k ? INK : FAINT }}
    >
      {label}
    </th>
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={onClose}>
      <div
        onClick={(e) => e.stopPropagation()}
        className="w-full max-w-2xl overflow-hidden rounded-sm border-2 shadow-2xl"
        style={{ borderColor: WOOD.frame, background: WOOD.board }}
      >
        <div
          className="flex items-baseline gap-3 px-4 py-3"
          style={{ background: WOOD.header, borderBottom: `1px solid ${WOOD.frame}` }}
        >
          <h2 className="text-xl text-[oklch(0.93_0.03_84)]">Ledger of the hold</h2>
          <span className="numeric text-xs text-[oklch(0.80_0.05_80)]">
            {used.toFixed(1)} / {capacity} t · {rows.length} entries
          </span>
          <button
            type="button"
            onClick={onClose}
            className="ml-auto rounded-sm border px-3 py-1 text-xs"
            style={{ borderColor: WOOD.frame, background: WOOD.parchment, color: INK }}
          >
            Close the book
          </button>
        </div>
        <div className="max-h-[60vh] overflow-y-auto p-3">
          <table className="w-full rounded-sm" style={{ background: WOOD.parchment }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${WOOD.frame}` }}>
                <Head k="name" label="Good" />
                <Head k="category" label="Kind" />
                <Head k="units" label="Quantity" right />
                <Head k="tons" label="Tonnage" right />
              </tr>
            </thead>
            <tbody>
              {sorted.length === 0 && (
                <tr>
                  <td colSpan={4} className="px-2 py-4 text-center text-xs italic" style={{ color: FAINT }}>
                    Her hold is empty.
                  </td>
                </tr>
              )}
              {sorted.map((r) => (
                <tr key={r.id} style={{ borderTop: `1px solid oklch(0.72 0.04 78)` }}>
                  <td className="px-2 py-1 text-xs" style={{ color: INK }}>{r.name}</td>
                  <td className="px-2 py-1 text-xs" style={{ color: FAINT }}>{r.category}</td>
                  <td className="numeric px-2 py-1 text-right text-xs" style={{ color: INK }}>
                    {Math.round(r.units)} {r.unit}
                  </td>
                  <td className="numeric px-2 py-1 text-right text-xs" style={{ color: INK }}>
                    {r.tons.toFixed(1)} t
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
