import { activeShip, volumeOf } from "@/game/actions";
import { COMMODITY_MAP, unitLabel } from "@/game/data/commodities";
import { PORT_MAP } from "@/game/data/ports";
import { questBlocker, questProgressNote, questTons } from "@/game/sim/quests";
import { money } from "@/game/sim/util";
import { cargoUsed, shipCapacity } from "@/game/sim/voyage";
import { useGame } from "@/game/store";
import type { Quest } from "@/game/types";

export const KIND_LABEL: Record<Quest["kind"], string> = {
  letter: "Letters",
  cargo: "Carriage",
  procure: "Procurement",
};

/**
 * The captain's own book of contracts. Work is taken and discharged at the
 * tavern board; this page only keeps the account of it.
 */
export function QuestsPanel() {
  const { state, dispatch } = useGame();
  const ship = activeShip(state);
  if (!ship) return <p className="p-6">You have no ships.</p>;

  const atSea = !!ship.voyage;
  const port = PORT_MAP[ship.portId]!;
  const board = state.quests.filter((q) => !q.accepted && q.portId === ship.portId);
  const taken = state.quests.filter((q) => q.accepted);
  const freeTons = shipCapacity(ship) - cargoUsed(ship, volumeOf);

  return (
    <div className="grid gap-4 p-4 xl:grid-cols-[1fr_1fr]">
      <section className="panel space-y-3 p-4">
        <header>
          <h2 className="text-lg font-semibold">Posted at {port.name}</h2>
          <p className="text-xs text-muted-foreground">
            The board lives by the tavern door. Take work there; this page is only the account of it.
          </p>
        </header>

        {atSea ? (
          <p className="text-sm text-muted-foreground">No business until she comes to anchor.</p>
        ) : board.length === 0 ? (
          <p className="text-sm text-muted-foreground">The board is bare this week.</p>
        ) : (
          <ul className="space-y-2">
            {board.map((q) => (
              <li key={q.id} className="rounded-sm border border-border p-3">
                <QuestBody q={q} />
                <div className="mt-2 flex items-center justify-between gap-2">
                  <span className="numeric text-xs text-muted-foreground">
                    {money(q.reward)} total{q.advance ? ` · ${money(q.advance)} advance` : ""} · +{q.standing} standing
                  </span>
                  <button
                    type="button"
                    disabled={!!questBlocker(q, ship, freeTons)}
                    title={questBlocker(q, ship, freeTons)}
                    onClick={() => dispatch({ type: "acceptQuest", questId: q.id })}
                    className="rounded-sm bg-primary px-3 py-1 text-sm text-primary-foreground disabled:opacity-40"
                  >
                    {questBlocker(q, ship, freeTons) ?? "Take it"}
                  </button>
                </div>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="panel space-y-3 p-4">
        <h2 className="text-lg font-semibold">Your contracts ({taken.length})</h2>
        {taken.length === 0 ? (
          <p className="text-sm text-muted-foreground">Nothing owed to anyone but the chandler.</p>
        ) : (
          <ul className="space-y-2">
            {taken.map((q) => {
              const here = q.targetPortId === ship.portId && !atSea;
              const short =
                q.kind === "letter" ? 0 : Math.max(0, (q.qty ?? 0) - (q.cid ? (ship.cargo[q.cid] ?? 0) : 0));
              return (
                <li key={q.id} className="rounded-sm border border-border bg-secondary/40 p-3">
                  <QuestBody q={q} note={questProgressNote(state, q)} />
                  <div className="mt-2 flex flex-wrap items-center gap-2">
                    <button
                      type="button"
                      disabled={!here || short > 0}
                      onClick={() => dispatch({ type: "deliverQuest", questId: q.id })}
                      className="rounded-sm bg-primary px-3 py-1 text-sm text-primary-foreground disabled:opacity-40"
                    >
                      {here
                        ? short > 0
                          ? `Short ${unitLabel(q.cid!, short)} of ${COMMODITY_MAP[q.cid!]!.name}`
                          : `Discharge · ${money(q.reward - q.advance)}`
                        : `Carry to ${PORT_MAP[q.targetPortId!]!.name}`}
                    </button>
                    <button
                      type="button"
                      onClick={() => dispatch({ type: "abandonQuest", questId: q.id })}
                      className="ml-auto rounded-sm border border-input px-2 py-1 text-xs"
                    >
                      Abandon
                    </button>
                  </div>
                </li>
              );
            })}
          </ul>
        )}
      </section>
    </div>
  );
}

function QuestBody({ q, note }: { q: Quest; note?: string }) {
  return (
    <div>
      <div className="flex flex-wrap items-baseline gap-2">
        <span className="rounded-full bg-accent/15 px-2 py-0.5 text-[10px] uppercase tracking-wide text-accent">
          {q.black ? "Black work" : KIND_LABEL[q.kind]}
        </span>
        <span className="font-semibold">{q.title}</span>
        <span className="numeric ml-auto text-[11px] text-muted-foreground">
          {note ?? (q.kind === "letter" ? "no hold space" : `${questTons(q).toFixed(1)} t`)}
        </span>
      </div>
      <p className="mt-1 text-xs text-muted-foreground">{q.text}</p>
    </div>
  );
}
