import { useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { useNavigate } from "@tanstack/react-router";
import { ArrowDown, ArrowRight, ArrowUp, Check, Search } from "lucide-react";
import { Line, LineChart, ResponsiveContainer, Tooltip, YAxis } from "recharts";

import { CommodityIcon } from "@/components/game/CommodityIcon";
import { activeShip, dealPrice, volumeOf } from "@/game/actions";
import { CATEGORY_LABEL, COMMODITIES } from "@/game/data/commodities";
import { PORT_MAP } from "@/game/data/ports";
import { permitBlocked } from "@/game/data/permits";
import { priceOf, supplyLabel } from "@/game/sim/economy";
import { canStow, holdNameFor } from "@/game/sim/holds";
import { money } from "@/game/sim/util";
import { cargoUsed, shipCapacity } from "@/game/sim/voyage";
import { useGame } from "@/game/store";
import type { CommodityCategory, MarketState } from "@/game/types";

/** Wood-and-lamp-black palette, the same hand as the tavern ledger. */
const WOOD = {
  frame: "oklch(0.30 0.045 45)",
  board:
    "repeating-linear-gradient(92deg, oklch(0.17 0.022 42) 0 22px, oklch(0.19 0.026 44) 22px 46px)",
  header:
    "linear-gradient(180deg, oklch(0.34 0.06 48), oklch(0.24 0.04 44) 60%, oklch(0.20 0.03 42))",
  parchment:
    "linear-gradient(155deg, oklch(0.90 0.035 85), oklch(0.85 0.045 80) 60%, oklch(0.80 0.05 76))",
};
const INK = "oklch(0.26 0.03 55)";
const FAINT = "oklch(0.42 0.03 60)";

type Move = "up" | "down" | "flat";
type SortKey = "name" | "buy" | "sell" | "supply" | "quay" | "hold";
type Span = 1 | 7 | 30;

/** How the unit price has moved since roughly a week back. */
function weekMove(market: MarketState, cid: string, now: number): { dir: Move; pct: number } {
  const h = market.history[cid] ?? [];
  const past = h[Math.max(0, h.length - 8)] ?? h[0];
  if (!past || past <= 0) return { dir: "flat", pct: 0 };
  const pct = ((now - past) / past) * 100;
  return { dir: pct > 2 ? "up" : pct < -2 ? "down" : "flat", pct };
}

function MoveArrow({ dir, pct }: { dir: Move; pct: number }) {
  if (dir === "flat")
    return <ArrowRight className="inline size-3 align-[-1px]" style={{ color: FAINT }} aria-label="steady" />;
  const up = dir === "up";
  const Icon = up ? ArrowUp : ArrowDown;
  return (
    <span
      className="numeric ml-1 inline-flex items-center gap-0.5 text-[10px]"
      style={{ color: up ? "oklch(0.48 0.15 28)" : "oklch(0.45 0.10 150)" }}
      title={`${up ? "+" : ""}${pct.toFixed(1)}% this week`}
    >
      <Icon className="size-3" />
      {Math.abs(pct).toFixed(0)}%
    </span>
  );
}

export function MarketPanel() {
  const { state, dispatch } = useGame();
  const navigate = useNavigate();
  const ship = activeShip(state);
  const [selected, setSelected] = useState<string>("sugar");
  const [qty, setQty] = useState(10);
  const [query, setQuery] = useState("");
  const [cat, setCat] = useState<CommodityCategory | "all" | "held">("all");
  const [mode, setMode] = useState<"buy" | "sell">("buy");
  const [sort, setSort] = useState<SortKey>("name");
  const [desc, setDesc] = useState(false);
  const [span, setSpan] = useState<Span>(30);

  const port = ship && !ship.voyage ? PORT_MAP[ship.portId] : undefined;
  const market = port ? state.markets[port.id] : undefined;

  const rows = useMemo(() => {
    if (!port || !market || !ship) return [];
    return COMMODITIES.map((c) => {
      const raw = priceOf(state, port.id, c.id, port);
      const deal = dealPrice(state, raw);
      return {
        c,
        p: { ...raw, ...deal },
        stock: Math.floor(market.stock[c.id] ?? 0),
        locked: permitBlocked(state, port.power, c.id),
        stowable: canStow(ship, c.id),
        held: Math.floor(ship.cargo[c.id] ?? 0),
        move: weekMove(market, c.id, raw.unit),
      };
    });
  }, [state, port, market, ship]);

  const history = useMemo(() => {
    const h = market?.history[selected] ?? [];
    const days = span === 1 ? 2 : span + 1;
    return h.slice(-days).map((v, i) => ({ i, price: v }));
  }, [market, selected, span]);

  const leave = (
    <button
      type="button"
      onClick={() => void navigate({ to: "/play/port" })}
      className="rounded-sm border-2 px-4 py-2 text-sm font-semibold"
      style={{
        borderColor: "oklch(0.48 0.08 55)",
        background: "oklch(0.26 0.04 44)",
        color: "oklch(0.90 0.05 80)",
      }}
    >
      Leave the market
    </button>
  );

  if (!ship) return <p className="p-6">You have no ships.</p>;
  if (!port || !market) {
    return (
      <div className="p-4">
        <Board title="At sea" action={leave}>
          <p className="p-6 text-sm" style={{ color: "oklch(0.78 0.03 75)" }}>
            {ship.name} is {ship.voyage ? `${ship.voyage.daysLeft} days from ${PORT_MAP[ship.voyage.to]!.name}` : "at sea"}.
            No market until she comes to anchor.
          </p>
        </Board>
      </div>
    );
  }

  const sel = rows.find((r) => r.c.id === selected) ?? rows[0]!;
  const capacity = shipCapacity(ship);
  const used = cargoUsed(ship, volumeOf);
  const free = Math.max(0, capacity - used);

  const cats = Array.from(new Set(COMMODITIES.map((c) => c.category)));
  const filtered = rows.filter(
    (r) =>
      (mode === "sell" ? r.held > 0 : true) &&
      (cat === "all" || (cat === "held" ? r.held > 0 : r.c.category === cat)) &&
      (query.trim() === "" || r.c.name.toLowerCase().includes(query.toLowerCase())),
  );

  const key = (r: (typeof rows)[number]) =>
    sort === "buy"
      ? r.p.buy
      : sort === "sell"
        ? r.p.sell
        : sort === "supply"
          ? r.p.ratio
          : sort === "quay"
            ? r.stock
            : sort === "hold"
              ? r.held
              : r.c.name;

  const visible = [...filtered].sort((a, b) => {
    const ka = key(a);
    const kb = key(b);
    const cmp = typeof ka === "string" ? ka.localeCompare(kb as string) : (ka as number) - (kb as number);
    return desc ? -cmp : cmp;
  });

  const maxQty = mode === "buy"
    ? sel.stowable
      ? Math.min(Math.floor(state.cash / sel.p.buy), Math.floor(free / sel.c.tons), sel.stock)
      : 0
    : sel.held;

  const canTrade = maxQty >= 1 && !sel.locked;
  const total = mode === "buy" ? qty * sel.p.buy : qty * sel.p.sell;

  const setModeSafe = (next: "buy" | "sell") => {
    setMode(next);
    setQty(1);
    const first = rows.find((r) => (next === "sell" ? r.held > 0 : true));
    if (first && next === "sell" && sel.held === 0) setSelected(first.c.id);
  };

  const chip = (active: boolean) =>
    `rounded-sm border px-2 py-1 text-[11px] transition-colors ${
      active
        ? "border-[oklch(0.62_0.10_60)] bg-[oklch(0.32_0.05_48)] text-[oklch(0.92_0.06_82)]"
        : "border-[oklch(0.34_0.04_45)] bg-[oklch(0.22_0.03_40)] text-[oklch(0.76_0.03_75)] hover:border-[oklch(0.50_0.07_55)]"
    }`;

  const tick = (active: boolean) =>
    `flex items-center justify-center gap-2 rounded-sm border-2 px-6 py-2 text-sm font-semibold transition-colors ${
      active
        ? "border-[oklch(0.62_0.10_60)] bg-[oklch(0.34_0.06_48)] text-[oklch(0.93_0.05_84)]"
        : "border-[oklch(0.34_0.04_45)] bg-[oklch(0.22_0.03_40)] text-[oklch(0.76_0.03_75)] hover:border-[oklch(0.50_0.07_55)]"
    }`;

  const sortHead = (label: string, k: SortKey, align: "left" | "right" = "right") => (
    <th className={`px-2 py-2 text-${align}`}>
      <button
        type="button"
        onClick={() => {
          if (sort === k) setDesc(!desc);
          else {
            setSort(k);
            setDesc(k !== "name");
          }
        }}
        className="uppercase tracking-[0.14em] hover:underline"
      >
        {label}
        {sort === k && <span className="ml-0.5">{desc ? "▾" : "▴"}</span>}
      </button>
    </th>
  );

  return (
    <div className="p-4">
      <Board title={`The exchange at ${port.name}`} action={leave}>
        <div className="space-y-3 p-4">
          <div className="flex flex-wrap items-center gap-2">
            <button type="button" onClick={() => setModeSafe("buy")} className={tick(mode === "buy")}>
              {mode === "buy" && <Check className="size-4" />}
              <span>Buy</span>
            </button>
            <button type="button" onClick={() => setModeSafe("sell")} className={tick(mode === "sell")}>
              {mode === "sell" && <Check className="size-4" />}
              <span>Sell</span>
            </button>
            <span className="numeric ml-auto text-xs" style={{ color: "oklch(0.76 0.04 76)" }}>
              {used.toFixed(1)} / {capacity} tons in the hold
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-1.5">
            <button type="button" onClick={() => setCat("all")} className={chip(cat === "all")}>
              All goods
            </button>
            {cats.map((k) => (
              <button key={k} type="button" onClick={() => setCat(k)} className={chip(cat === k)}>
                {CATEGORY_LABEL[k]}
              </button>
            ))}
            <button type="button" onClick={() => setCat("held")} className={chip(cat === "held")}>
              In hold
            </button>
            <label className="relative ml-auto">
              <Search
                className="pointer-events-none absolute left-2 top-1/2 size-3.5 -translate-y-1/2"
                style={{ color: FAINT }}
              />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search goods"
                aria-label="Search goods"
                className="w-40 rounded-sm border py-1 pl-7 pr-2 text-xs"
                style={{ borderColor: "oklch(0.60 0.05 70)", background: "oklch(0.88 0.04 82)", color: INK }}
              />
            </label>
          </div>

          <div
            className="overflow-y-auto rounded-sm border-2"
            style={{ borderColor: "oklch(0.42 0.06 50)", background: WOOD.parchment, maxHeight: 260 }}
          >
            <table className="w-full text-sm" style={{ color: INK }}>
              <thead
                className="sticky top-0 z-10 text-[10px] uppercase tracking-[0.14em]"
                style={{ background: "oklch(0.78 0.05 76)", color: "oklch(0.32 0.04 55)" }}
              >
                <tr>
                  {sortHead("Commodity", "name", "left")}
                  {sortHead("Buy", "buy")}
                  {sortHead("Sell", "sell")}
                  {sortHead("Supply", "supply", "left")}
                  {sortHead("Quay", "quay")}
                  {sortHead("Hold", "hold")}
                </tr>
              </thead>
              <tbody>
                {visible.map((r) => (
                  <tr
                    key={r.c.id}
                    onClick={() => setSelected(r.c.id)}
                    className="group relative cursor-pointer border-b transition-colors"
                    style={{
                      borderColor: "oklch(0.74 0.04 78)",
                      background: r.c.id === sel.c.id ? "oklch(0.80 0.06 74)" : "transparent",
                    }}
                  >
                    <td className="px-3 py-1.5">
                      <div className="flex items-center gap-2.5">
                        <CommodityIcon id={r.c.id} category={r.c.category} size="sm" />
                        <div className="min-w-0">
                          <div className="flex items-center gap-2">
                            <span className="truncate font-medium">{r.c.name}</span>
                            {r.locked && (
                              <span
                                className="rounded-sm px-1 text-[10px] uppercase"
                                style={{ background: "oklch(0.72 0.07 80)", color: "oklch(0.30 0.06 60)" }}
                              >
                                licence
                              </span>
                            )}
                            {!r.stowable && (
                              <span
                                className="rounded-sm px-1 text-[10px] uppercase"
                                style={{ background: "oklch(0.70 0.06 60)", color: "oklch(0.28 0.05 50)" }}
                              >
                                no hold
                              </span>
                            )}
                            {!r.p.legal && (
                              <span
                                className="rounded-sm px-1 text-[10px] uppercase"
                                style={{ background: "oklch(0.62 0.16 28 / 0.25)", color: "oklch(0.40 0.16 28)" }}
                              >
                                contraband
                              </span>
                            )}
                          </div>
                          <span className="text-[11px]" style={{ color: FAINT }}>
                            {CATEGORY_LABEL[r.c.category]} · {r.c.unit} · {r.c.tons} t
                          </span>
                        </div>
                      </div>
                    </td>
                    <td className="numeric relative whitespace-nowrap px-2 py-1.5 text-right">
                      <span>{money(r.p.buy)}</span>
                      <MoveArrow dir={r.move.dir} pct={r.move.pct} />
                      <PriceMaths steps={r.p.steps} final={money(r.p.buy)} />
                    </td>
                    <td className="numeric relative whitespace-nowrap px-2 py-1.5 text-right">
                      <span>{money(r.p.sell)}</span>
                      <MoveArrow dir={r.move.dir} pct={r.move.pct} />
                      <PriceMaths steps={r.p.steps} final={money(r.p.sell)} sell />
                    </td>
                    <td className="px-2 py-1.5 text-xs">{supplyLabel(r.p.ratio)}</td>
                    <td className="numeric px-2 py-1.5 text-right" style={{ color: FAINT }}>
                      {r.stock}
                    </td>
                    <td className="numeric px-2 py-1.5 text-right">{r.held || "—"}</td>
                  </tr>
                ))}
                {visible.length === 0 && (
                  <tr>
                    <td colSpan={6} className="px-3 py-6 text-center text-sm" style={{ color: FAINT }}>
                      {mode === "sell" ? "Nothing in your hold to sell." : "Nothing of that description on the quay."}
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>

          <div
            className="space-y-4 rounded-sm border-2 p-4"
            style={{ borderColor: "oklch(0.42 0.06 50)", background: WOOD.parchment, color: INK }}
          >
            <div className="flex items-start gap-3">
              <CommodityIcon id={sel.c.id} category={sel.c.category} size="lg" />
              <div className="flex-1">
                <h3 className="font-serif text-lg font-semibold leading-tight">{sel.c.name}</h3>
                <p className="text-[11px] uppercase tracking-wide" style={{ color: FAINT }}>
                  {CATEGORY_LABEL[sel.c.category]} · 1 {sel.c.unit} = {sel.c.tons} t
                </p>
                <p className="mt-1 text-xs italic" style={{ color: FAINT }}>
                  {sel.c.note}
                </p>
              </div>
              <div className="grid w-56 grid-cols-2 gap-2 text-center">
                {(
                  [
                    ["Buy", sel.p.buy],
                    ["Sell", sel.p.sell],
                  ] as const
                ).map(([label, v]) => (
                  <div
                    key={label}
                    className="rounded-sm border px-2 py-1.5"
                    style={{ borderColor: "oklch(0.66 0.05 72)", background: "oklch(0.86 0.04 80)" }}
                  >
                    <div className="text-[10px] uppercase tracking-wide" style={{ color: FAINT }}>
                      {label}
                    </div>
                    <div className="numeric text-base font-semibold">
                      {money(v)}
                      <MoveArrow dir={sel.move.dir} pct={sel.move.pct} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {sel.locked && (
              <p
                className="rounded-sm border px-2 py-1.5 text-xs"
                style={{ borderColor: "oklch(0.55 0.14 28)", background: "oklch(0.62 0.16 28 / 0.15)", color: "oklch(0.38 0.15 28)" }}
              >
                A crown monopoly: {port.name} will not trade {sel.c.name} with you without a licence. Buy one through
                diplomacy with the {sel.locked.power} interest.
              </p>
            )}

            {!sel.stowable && (
              <p
                className="rounded-sm border px-2 py-1.5 text-xs"
                style={{ borderColor: "oklch(0.52 0.10 60)", background: "oklch(0.74 0.08 70 / 0.35)", color: "oklch(0.32 0.07 55)" }}
              >
                {ship.name} has no {holdNameFor(sel.c.id)} fitted, so she cannot stow{" "}
                {CATEGORY_LABEL[sel.c.category].toLowerCase()} goods. Fit one at a shipwright's yard — Ship tab,
                Warehouse.
              </p>
            )}

            <div>
              <div className="flex items-center justify-between">
                <span className="text-[11px] uppercase tracking-wide" style={{ color: FAINT }}>
                  Price at {port.name}
                </span>
                <div className="flex gap-1">
                  {(
                    [
                      [1, "Day"],
                      [7, "Week"],
                      [30, "Month"],
                    ] as const
                  ).map(([v, label]) => (
                    <button
                      key={v}
                      type="button"
                      onClick={() => setSpan(v)}
                      className="rounded-sm border px-2 py-0.5 text-[11px]"
                      style={{
                        borderColor: span === v ? "oklch(0.40 0.08 50)" : "oklch(0.68 0.04 74)",
                        background: span === v ? "oklch(0.80 0.06 74)" : "transparent",
                        color: INK,
                      }}
                    >
                      {label}
                    </button>
                  ))}
                </div>
              </div>
              <div className="mt-1 h-28">
                {history.length > 1 ? (
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={history}>
                      <YAxis hide domain={["dataMin", "dataMax"]} />
                      <Tooltip
                        contentStyle={{
                          background: "oklch(0.93 0.03 86)",
                          border: "1px solid oklch(0.42 0.06 50)",
                          color: INK,
                          fontSize: 12,
                        }}
                        formatter={(v) => money(Number(v))}
                        labelFormatter={() => ""}
                      />
                      <Line type="monotone" dataKey="price" stroke="oklch(0.42 0.12 40)" dot={false} strokeWidth={2} />
                    </LineChart>
                  </ResponsiveContainer>
                ) : (
                  <p className="flex h-full items-center justify-center text-xs" style={{ color: FAINT }}>
                    No price history yet — let some days pass.
                  </p>
                )}
              </div>
            </div>

            <div className="space-y-2 border-t pt-3" style={{ borderColor: "oklch(0.70 0.04 76)" }}>
              <div className="flex items-center justify-between text-xs" style={{ color: FAINT }}>
                <span>Quantity to {mode}</span>
                <span className="numeric">
                  {qty} {qty === 1 ? sel.c.unit : sel.c.unitPlural} · {(qty * sel.c.tons).toFixed(1)} t · {money(total)}
                </span>
              </div>
              <input
                type="range"
                min={0}
                max={Math.max(1, maxQty)}
                value={Math.min(qty, Math.max(1, maxQty))}
                onChange={(e) => setQty(Math.max(1, Number(e.target.value)))}
                disabled={maxQty < 1}
                className="w-full"
                aria-label="Quantity slider"
              />
              <div className="flex items-center justify-between text-[11px]" style={{ color: FAINT }}>
                <span>1 {sel.c.unit}</span>
                <span className="numeric">Max {Math.max(0, maxQty)} {sel.c.unitPlural}</span>
              </div>

              <button
                type="button"
                disabled={!canTrade || qty < 1}
                onClick={() => dispatch({ type: mode, cid: sel.c.id, qty: Math.min(qty, maxQty) })}
                className="w-full rounded-sm border-2 px-4 py-2.5 text-sm font-semibold disabled:opacity-40"
                style={{
                  borderColor: "oklch(0.40 0.06 48)",
                  background: mode === "buy" ? "oklch(0.34 0.06 48)" : "oklch(0.30 0.05 42)",
                  color: "oklch(0.93 0.05 84)",
                }}
              >
                {mode === "buy" ? `Buy ${qty} ${qty === 1 ? sel.c.unit : sel.c.unitPlural} for ${money(total)}` : `Sell ${qty} ${qty === 1 ? sel.c.unit : sel.c.unitPlural} for ${money(total)}`}
              </button>

              <p className="text-[11px]" style={{ color: FAINT }}>
                You hold {sel.held} {sel.c.unitPlural} of {sel.c.name}. {port.name} has {sel.stock} on the quay. {free.toFixed(1)} tons
                free in your hold.
              </p>
            </div>
          </div>
        </div>
      </Board>
    </div>
  );
}

function Board({
  title,
  action,
  children,
}: {
  title: string;
  action: React.ReactNode;
  children: React.ReactNode;
}) {
  return (
    <div
      className="rounded-sm border-4 shadow-2xl"
      style={{ borderColor: WOOD.frame, background: WOOD.board, boxShadow: "0 18px 44px oklch(0.05 0.01 40 / 0.5)" }}
    >
      <header
        className="flex flex-wrap items-center justify-between gap-3 border-b-4 px-4 py-3"
        style={{
          borderColor: "oklch(0.26 0.04 42)",
          background: WOOD.header,
          boxShadow: "inset 0 -3px 0 oklch(0.42 0.08 55 / 0.35)",
        }}
      >
        <h2 className="font-serif text-xl font-semibold tracking-wide text-[oklch(0.92_0.06_82)]">{title}</h2>
        {action}
      </header>
      {children}
    </div>
  );
}

/** The quotation, worked out on the counter so it never looks like a whim. */
function PriceMaths({
  steps,
  final,
  sell,
}: {
  steps: { label: string; text: string }[];
  final: string;
  sell?: boolean;
}) {
  const [at, setAt] = useState<{ x: number; y: number } | null>(null);
  const move = (e: React.MouseEvent) => setAt({ x: e.clientX, y: e.clientY });
  return (
    <>
      <span
        className="absolute inset-0 cursor-help"
        onMouseEnter={move}
        onMouseMove={move}
        onMouseLeave={() => setAt(null)}
      />
      {at &&
        typeof document !== "undefined" &&
        createPortal(
          <div
            className="pointer-events-none fixed z-[9999] w-60 rounded-sm border-2 p-2 text-left text-[11px] shadow-2xl"
            style={{
              left: Math.min(at.x + 14, (typeof window !== "undefined" ? window.innerWidth : 1200) - 252),
              top: Math.min(at.y + 14, (typeof window !== "undefined" ? window.innerHeight : 800) - 200),
              borderColor: "oklch(0.42 0.06 50)",
              background: WOOD.parchment,
              color: INK,
            }}
          >
            {steps.map((st, i) => (
              <div key={i} className="flex justify-between gap-2">
                <span style={{ color: FAINT }}>{st.label}</span>
                <span className="numeric">{st.text}</span>
              </div>
            ))}
            <div
              className="mt-1 flex justify-between border-t pt-1 font-semibold"
              style={{ borderColor: "oklch(0.60 0.05 70)" }}
            >
              <span>{sell ? "Offered for her" : "Asked of you"}</span>
              <span className="numeric">{final}</span>
            </div>
            {sell && (
              <p className="mt-1 italic" style={{ color: FAINT }}>
                The buyer keeps 7% for himself.
              </p>
            )}
          </div>,
          document.body,
        )}
    </>
  );
}

