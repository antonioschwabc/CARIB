import { PORTS, portVisible } from "@/game/data/ports";
import { POWERS, POWER_MAP } from "@/game/data/powers";
import {
  FACTION_TIERS,
  METAL_COLOR,
  PORT_TIERS,
  RANK_LEVELS,
  factionHostile,
  factionStanding,
  infamyLevel,
  infamyRank,
  portBanned,
  portEdge,
  portStandingParts,
  prestigeLevel,
  rankMetal,
  rankProgress,
  rankThreshold,
  reputationRank,
  tierName,
} from "@/game/sim/standing";
import { formatDate, money } from "@/game/sim/util";
import { useGame } from "@/game/store";

/**
 * Three books, plainly kept: what the harbours think, what the crowns think,
 * and what the banner itself is worth.
 */
export function StandingPanel() {
  const { state, dispatch } = useGame();
  const known = PORTS.filter(portVisible).filter(
    (p) => (state.portStanding?.[p.id] ?? 0) !== 0 || state.homePortId === p.id || state.fines?.[p.id],
  ).sort((a, b) => portStandingParts(state, b.id).total - portStandingParts(state, a.id).total);
  const ledger = state.repLedger ?? [];

  return (
    <section className="panel space-y-4 p-4">
      <header>
        <h2 className="text-lg font-semibold">Your name</h2>
        <p className="text-xs text-muted-foreground">
          A harbour keeps its own book on a captain, a crown keeps another, and the banner over your masthead is worth
          what the whole Atlantic says it is.
        </p>
      </header>

      <div className="grid gap-3 sm:grid-cols-2">
        <RankCard
          title="Reputation"
          level={prestigeLevel(state)}
          name={reputationRank(prestigeLevel(state))}
          points={state.prestige ?? 0}
          note="Honest carriage, sound trade and good hulls. Every rank is worth +2 standing with every crown but the black flag."
        />
        <RankCard
          title="Infamy"
          level={infamyLevel(state)}
          name={infamyRank(infamyLevel(state))}
          points={state.infamyPoints ?? 0}
          note="Contraband, black work and blood. Every rank is worth +2 standing with the brotherhood — and frightens everyone else."
        />
      </div>

      <div>
        <h3 className="mb-2 text-sm font-semibold">The crowns</h3>
        <ul className="space-y-2">
          {POWERS.map((p) => {
            const value = factionStanding(state, p.id);
            const base = state.relations[p.id] ?? 0;
            const bonus = value - base;
            return (
              <li key={p.id} className="text-xs">
                <div className="flex items-baseline gap-2">
                  <span className="font-semibold">{p.name}</span>
                  <span className="text-muted-foreground">{tierName(value, FACTION_TIERS)}</span>
                  {factionHostile(state, p.id) && (
                    <span className="rounded-sm bg-destructive px-1 text-[10px] uppercase text-destructive-foreground">
                      hostile
                    </span>
                  )}
                  <span className={`numeric ml-auto ${value < 0 ? "text-loss" : "text-profit"}`}>
                    {value > 0 ? "+" : ""}
                    {value.toFixed(0)}
                  </span>
                </div>
                <Slider value={value} />
                <p className="mt-0.5 text-[10px] text-muted-foreground">
                  Their own book {base > 0 ? "+" : ""}
                  {base.toFixed(0)}
                  {bonus ? `, banner ${bonus > 0 ? "+" : ""}${bonus.toFixed(0)}` : ""} · half of this is felt in every
                  harbour they hold
                </p>
              </li>
            );
          })}
        </ul>
      </div>

      <div>
        <h3 className="mb-2 text-sm font-semibold">The harbours</h3>
        {known.length === 0 ? (
          <p className="text-xs text-muted-foreground">No quay yet knows your face.</p>
        ) : (
          <ul className="space-y-2">
            {known.map((p) => {
              const parts = portStandingParts(state, p.id);
              const edge = portEdge(state, p.id);
              const fine = state.fines?.[p.id];
              return (
                <li key={p.id} className="text-xs">
                  <div className="flex items-baseline gap-2">
                    <span className="font-semibold">{p.name}</span>
                    <span className="text-muted-foreground">{tierName(parts.total, PORT_TIERS)}</span>
                    {state.homePortId === p.id && (
                      <span className="rounded-sm bg-secondary px-1 text-[10px] uppercase">homestead</span>
                    )}
                    {portBanned(state, p.id) && (
                      <span className="rounded-sm bg-destructive px-1 text-[10px] uppercase text-destructive-foreground">
                        closed
                      </span>
                    )}
                    <span className={`numeric ml-auto ${parts.total < 0 ? "text-loss" : "text-profit"}`}>
                      {parts.total > 0 ? "+" : ""}
                      {parts.total.toFixed(0)}
                    </span>
                  </div>
                  <Slider value={parts.total} />
                  <p className="mt-0.5 text-[10px] text-muted-foreground">
                    Quay {parts.own > 0 ? "+" : ""}
                    {parts.own.toFixed(1)} · {POWER_MAP[p.power]!.adjective} crown {parts.crown > 0 ? "+" : ""}
                    {parts.crown.toFixed(0)}
                    {parts.home ? ` · homestead +${parts.home}` : ""} · prices{" "}
                    {edge.price > 0 ? "−" : "+"}
                    {Math.abs(Math.round(edge.price * 100))}% to you · {edge.postings > 0 ? "+" : ""}
                    {edge.postings} postings · {edge.recruits > 0 ? "+" : ""}
                    {edge.recruits} hands
                  </p>
                  {fine ? (
                    <button
                      type="button"
                      disabled={state.cash < fine}
                      onClick={() => dispatch({ type: "payFine", portId: p.id })}
                      className="mt-1 rounded-sm border border-input px-2 py-0.5 text-[11px] disabled:opacity-40"
                    >
                      Pay the fine of {money(fine)}
                    </button>
                  ) : null}
                </li>
              );
            })}
          </ul>
        )}
      </div>

      <div>
        <h3 className="mb-1 text-sm font-semibold">What is said of you</h3>
        {ledger.length === 0 ? (
          <p className="text-xs text-muted-foreground">Nothing yet has been written down against your name.</p>
        ) : (
          <ol className="max-h-52 space-y-1 overflow-auto text-xs">
            {ledger.map((e) => (
              <li key={e.id} className="flex items-baseline gap-2 border-b border-border/40 pb-1">
                <span className="numeric text-[10px] text-muted-foreground">{formatDate(e.day)}</span>
                <span className="flex-1">{e.reason}</span>
                <span className={`numeric ${e.delta < 0 ? "text-loss" : "text-profit"}`}>
                  {e.delta > 0 ? "+" : ""}
                  {e.delta.toFixed(1)}
                </span>
              </li>
            ))}
          </ol>
        )}
      </div>
    </section>
  );
}

function RankCard({
  title,
  level,
  name,
  points,
  note,
}: {
  title: string;
  level: number;
  name: string;
  points: number;
  note: string;
}) {
  const metal = rankMetal(level);
  const next = level >= RANK_LEVELS ? undefined : rankThreshold(level + 1);
  return (
    <div className="rounded-sm border p-3" style={{ borderColor: METAL_COLOR[metal] }}>
      <div className="flex items-baseline gap-2">
        <span className="text-[10px] uppercase tracking-wide text-muted-foreground">{title}</span>
        <span className="numeric ml-auto text-sm" style={{ color: METAL_COLOR[metal] }}>
          {level} / {RANK_LEVELS}
        </span>
      </div>
      <p className="font-semibold" style={{ color: METAL_COLOR[metal] }}>
        {name}
      </p>
      <div className="mt-1 h-1.5 w-full overflow-hidden rounded-full bg-muted">
        <div
          className="h-full"
          style={{ width: `${Math.round(rankProgress(points) * 100)}%`, background: METAL_COLOR[metal] }}
        />
      </div>
      <p className="mt-1 numeric text-[10px] text-muted-foreground">
        {Math.round(points)} {next ? `of ${next} for the next rank` : "— nothing above this"}
      </p>
      <p className="mt-1 text-[10px] text-muted-foreground">{note}</p>
    </div>
  );
}

function Slider({ value }: { value: number }) {
  const pct = ((value + 100) / 200) * 100;
  return (
    <div className="relative mt-1 h-1.5 w-full rounded-full bg-muted">
      <div className="absolute left-1/2 top-[-2px] h-[10px] w-px bg-border" />
      <div
        className="absolute top-0 h-1.5 rounded-full"
        style={{
          left: `${Math.min(50, pct)}%`,
          width: `${Math.abs(pct - 50)}%`,
          background: value < 0 ? "var(--color-destructive)" : "var(--color-accent)",
        }}
      />
    </div>
  );
}
