import { MarkBadge, MARK_NAME } from "@/components/game/MarkIcons";
import { optionsFor, optionOdds, type EncEffects, type EncOption } from "@/game/sim/encounters";
import { coordLabel } from "@/game/sim/position";
import { useGame } from "@/game/store";

const SKILL_LABEL: Record<string, string> = {
  navigation: "Navigation",
  charisma: "Charisma",
  scouting: "Scouting",
  craftsmanship: "Craftsmanship",
  gunnery: "Gunnery",
  logistics: "Logistics",
  cooking: "Cooking",
  medicine: "Medicine",
};

/** A short, honest word on what is at stake either way. */
function stakes(fx: EncEffects | undefined, lost: boolean): string {
  if (!fx) return lost ? "nothing lost" : "nothing gained";
  const bits: string[] = [];
  const range = (r: [number, number], unit: string) =>
    `${Math.round(Math.abs(r[0]))}–${Math.round(Math.abs(r[1]))} ${unit}`;
  if (fx.gold) bits.push(`${lost ? "−" : "+"}${range(fx.gold, "gold")}`);
  if (fx.salvage) bits.push(`${lost ? "−" : "+"}${range(fx.salvage, "salvage")}`);
  if (fx.supplies) bits.push(`${lost ? "−" : "+"}${range(fx.supplies, "stores")}`);
  if (fx.medicine) bits.push(`${lost ? "−" : "+"}${range(fx.medicine, "physic")}`);
  if (fx.hull) bits.push(`−${range(fx.hull, "hull")}`);
  if (fx.sails) bits.push(`−${range(fx.sails, "canvas")}`);
  if (fx.health) bits.push(`−${range(fx.health, "health")}`);
  if (fx.morale) bits.push(`${lost ? "−" : "+"}${range(fx.morale, "temper")}`);
  if (fx.days) bits.push(`${range(fx.days, "days")} on passage`);
  if (fx.recruits) bits.push(`${fx.recruits} hand${fx.recruits > 1 ? "s" : ""}`);
  if (fx.xp) bits.push("experience");
  return bits.join(" · ") || (lost ? "nothing lost" : "nothing gained");
}

export function EncounterDialog() {
  const { state, dispatch } = useGame();
  const enc = state.encounter;
  if (!enc) return null;
  const options = optionsFor(enc.kind);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div
        role="dialog"
        aria-modal="true"
        className="panel w-full max-w-xl space-y-4 p-5 text-card-foreground"
      >
        <header className="flex items-start gap-3 border-b border-border pb-3">
          <MarkBadge kind={enc.kind} size={40} />
          <div className="flex-1">
            <h2 className="font-serif text-xl font-bold text-accent">
              {enc.title ?? MARK_NAME[enc.kind] ?? "A mark on the water"}
            </h2>
            {enc.lat !== undefined && enc.lon !== undefined && (
              <p className="numeric text-[11px] text-muted-foreground">{coordLabel(enc.lat, enc.lon)}</p>
            )}
          </div>
        </header>

        <p className="text-sm leading-relaxed">{enc.text}</p>

        <div className="grid gap-2">
          {options.map((o) => (
            <OptionRow key={o.id} opt={o} onPick={() => dispatch({ type: "encounter", choice: o.id })} />
          ))}
        </div>

        <p className="text-[11px] italic text-muted-foreground">
          The captain must give his word. Nothing here is settled by guns.
        </p>
      </div>
    </div>
  );
}

function OptionRow({ opt, onPick }: { opt: EncOption; onPick: () => void }) {
  const { state } = useGame();
  const odds = optionOdds(state, opt);
  return (
    <button
      type="button"
      onClick={onPick}
      className="rounded-sm border border-input px-3 py-2 text-left transition-colors hover:bg-secondary"
    >
      <div className="flex flex-wrap items-baseline gap-2">
        <span className="text-sm font-medium">{opt.label}</span>
        {odds && (
          <span className="numeric ml-auto text-[11px] text-muted-foreground">
            {SKILL_LABEL[odds.skill]} {odds.score} vs {odds.dc} · {odds.label} ·{" "}
            <span className="text-accent">{Math.round(odds.chance * 100)}%</span> to succeed,{" "}
            {Math.round(odds.failChance * 100)}% to fail
          </span>
        )}
      </div>
      <div className="mt-1 flex flex-wrap gap-x-4 text-[11px] text-muted-foreground">
        <span>Won: {stakes(opt.gain, false)}</span>
        {odds && <span>Lost: {stakes(opt.loss, true)}</span>}
      </div>
    </button>
  );
}
