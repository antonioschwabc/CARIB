import { useEffect, useMemo, useRef, useState } from "react";

import { COASTLINES } from "@/game/data/coastlines";
import { CARIBBEAN_COASTLINES } from "@/game/data/caribbeanCoastlines";
import { PORT_MAP } from "@/game/data/ports";
import { POWER_MAP } from "@/game/data/powers";
import { MAP_REGIONS, REGION_MAP, portsOfRegion, regionOfPort } from "@/game/data/regions";
import { isSea } from "@/game/sim/seagrid";

import { ALERT_TONE, MARK_ALERT, MARK_NAME } from "./MarkIcons";
import type { Destination, Port, SeaEvent } from "@/game/types";

const DEFAULT_W = 1000;
const DEFAULT_H = 640;

/** Client point → viewBox coordinates, correct even when the chart is letterboxed. */
function svgPoint(el: SVGSVGElement, e: { clientX: number; clientY: number }, dims: { w: number; h: number }) {
  const ctm = el.getScreenCTM();
  if (!ctm) {
    const rect = el.getBoundingClientRect();
    return { x: ((e.clientX - rect.left) / rect.width) * dims.w, y: ((e.clientY - rect.top) / rect.height) * dims.h };
  }
  const inv = ctm.inverse();
  return { x: e.clientX * inv.a + e.clientY * inv.c + inv.e, y: e.clientX * inv.b + e.clientY * inv.d + inv.f };
}

function mercY(lat: number) {
  const c = Math.max(-80, Math.min(80, lat));
  return Math.log(Math.tan(Math.PI / 4 + (c * Math.PI) / 360));
}

function invMercY(y: number) {
  return ((2 * Math.atan(Math.exp(y)) - Math.PI / 2) * 180) / Math.PI;
}

/** Mercator projection fitted to a region's bounding box, aspect preserved. */
function makeProjection(
  bbox: [number, number, number, number],
  dims: { w: number; h: number },
  cropToFrame = false,
) {
  const [lon0, lat0, lon1, lat1] = bbox;
  const yTop = mercY(lat1);
  const yBottom = mercY(lat0);
  const x0 = (lon0 * Math.PI) / 180;
  const spanX = ((lon1 - lon0) * Math.PI) / 180;
  const spanY = yTop - yBottom;
  // Caribbean uses a fixed geographic composition and crops overflow at the
  // viewport edge. Other sheets retain their existing fit-to-frame behaviour.
  const scale = cropToFrame
    ? Math.max(dims.w / spanX, dims.h / spanY)
    : Math.min(dims.w / spanX, dims.h / spanY);
  const offX = (dims.w - spanX * scale) / 2;
  const offY = (dims.h - spanY * scale) / 2;
  const project = (lon: number, lat: number) => ({
    x: offX + ((lon * Math.PI) / 180 - x0) * scale,
    y: offY + (yTop - mercY(lat)) * scale,
  });
  const invert = (x: number, y: number) => ({
    lon: (((x - offX) / scale + x0) * 180) / Math.PI,
    lat: invMercY(yTop - (y - offY) / scale),
  });
  return { project, invert, scale };
}

interface Props {
  /** the mark currently shown in the dossier */
  selected: Destination | undefined;
  /** where the ship is right now */
  shipAt: { lat: number; lon: number };
  /** her track, when she is on passage */
  track?: { lat: number; lon: number }[];
  /** the mark her rudder is set for */
  course?: Destination | undefined;
  /** the contract the captain is following, marked on the sheet */
  questMark?: (Destination & { note?: string }) | undefined;
  /** marks the lookouts have raised */
  seaEvents?: SeaEvent[];
  /** how far she sees, in sea miles */
  sightNm?: number;
  onHoverPort?: (id: string | undefined) => void;
  onSelectPort: (id: string) => void;
  /** a mark afloat has been clicked */
  onSelectEvent?: (ev: SeaEvent) => void;
  onSelectSea: (lat: number, lon: number) => void;
  /** right click on water or a harbour: lay the course there at once */
  onSetCourse?: (dest: { lat: number; lon: number; portId?: string }) => void;
  /** changes whenever a hidden harbour is found, so the sheet redraws */
  revealKey?: string;
  /** hulls the lookouts can see today */
  npcShips?: { id: string; lat: number; lon: number; name: string; power?: string; className?: string; toLat?: number; toLon?: number }[];
  /** a hull of another master's has been clicked */
  onSelectNpc?: (id: string) => void;
  /** actions between others, burning down over a week */
  npcBattles?: {
    id: string;
    lat: number;
    lon: number;
    endsDay: number;
    portId?: string;
    /** who is at it, for the captain's glass */
    crews?: { name: string; captain: string; power?: string | undefined; className?: string | undefined }[];
  }[];
  day?: number;
}



const OVERLAYS = [
  { id: "power", label: "Flags" },
  { id: "piracy", label: "Piracy" },
  { id: "prosperity", label: "Prosperity" },
] as const;

export function ChartMap({
  selected,
  shipAt,
  track,
  course,
  questMark,
  seaEvents = [],
  sightNm = 0,
  onHoverPort,
  onSelectPort,
  onSelectEvent,
  onSelectSea,
  onSetCourse,
  revealKey = "",
  npcShips = [],
  onSelectNpc,
  npcBattles = [],
  day = 0,
}: Props) {

  const [region, setRegion] = useState(() => regionOfPort(selected?.portId ?? "havana"));
  const [view, setView] = useState({ x: 0, y: 0, k: 1 });
  const [overlay, setOverlay] = useState<"power" | "piracy" | "prosperity">("power");
  const [overLand, setOverLand] = useState(false);

  const drag = useRef<{ x: number; y: number; ox: number; oy: number; moved: boolean } | null>(null);
  const svgRef = useRef<SVGSVGElement | null>(null);
  const wrapRef = useRef<HTMLDivElement | null>(null);
  const [dims, setDims] = useState({ w: DEFAULT_W, h: DEFAULT_H });

  // Follow a harbour selection onto whichever sheet carries it.
  useEffect(() => {
    if (!selected?.portId) return;
    const r = regionOfPort(selected.portId);
    setRegion((cur) => (portsOfRegion(cur).some((p) => p.id === selected.portId) ? cur : r));
  }, [selected?.portId]);

  useEffect(() => setView({ x: 0, y: 0, k: 1 }), [region]);

  // "Where am I?" — the ledger's position parchment calls the sheet back to the ship.
  const [centerReq, setCenterReq] = useState(0);
  useEffect(() => {
    const onCenter = () => {
      const found = MAP_REGIONS.find(
        (r) =>
          shipAt.lon >= r.bbox[0] && shipAt.lon <= r.bbox[2] && shipAt.lat >= r.bbox[1] && shipAt.lat <= r.bbox[3],
      );
      if (found) setRegion(found.id);
      setCenterReq((n) => n + 1);
    };
    window.addEventListener("carib:center-ship", onCenter);
    return () => window.removeEventListener("carib:center-ship", onCenter);
  }, [shipAt.lat, shipAt.lon]);

  useEffect(() => {
    const el = wrapRef.current;
    if (!el) return;
    const update = () => {
      const rect = el.getBoundingClientRect();
      setDims({ w: Math.max(320, Math.floor(rect.width)), h: Math.max(240, Math.floor(rect.height)) });
    };
    update();
    const ro = new ResizeObserver(update);
    ro.observe(el);
    window.addEventListener("resize", update);
    return () => {
      ro.disconnect();
      window.removeEventListener("resize", update);
    };
  }, []);

  const def = REGION_MAP[region] ?? MAP_REGIONS[0]!;
  /**
   * The Caribbean shows its full geographic frame by default so Veracruz,
   * Venezuela and the Antilles are all visible. Other charts preserve their
   * established open-ocean expansion.
   */
  const viewBbox = useMemo<[number, number, number, number]>(() => {
    const [lon0, lat0, lon1, lat1] = def.bbox;
    if (def.id === "caribbean") return def.bbox;
    const spanY = mercY(lat1) - mercY(lat0);
    const spanX = ((lon1 - lon0) * Math.PI) / 180;
    const wanted = (spanY * dims.w) / dims.h;
    if (wanted <= spanX) {
      // frame is taller than the sheet — grow ocean north and south instead
      const grow = (spanX * dims.h) / dims.w - spanY;
      return [lon0, invMercY(mercY(lat0) - grow / 2), lon1, invMercY(mercY(lat1) + grow / 2)];
    }
    const extraDeg = ((wanted - spanX) * 180) / Math.PI;
    if (def.fill === "w") return [lon0 - extraDeg, lat0, lon1, lat1];
    if (def.fill === "e") return [lon0, lat0, lon1 + extraDeg, lat1];
    return [lon0 - extraDeg / 2, lat0, lon1 + extraDeg / 2, lat1];
  }, [def, dims]);
  const { project, invert } = useMemo(
    () => makeProjection(viewBbox, dims, false),
    [viewBbox, dims, def.id],
  );

  // Bring the ship under the middle of the sheet when the ledger calls for her.
  useEffect(() => {
    if (!centerReq) return;
    const pt = project(shipAt.lon, shipAt.lat);
    setView((v) => {
      const k = Math.max(v.k, 2.2);
      return clampView({ k, x: dims.w / 2 - pt.x * k, y: dims.h / 2 - pt.y * k }, dims);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [centerReq, project, dims.w, dims.h]);

  // The visible Caribbean frame is intentionally drawn from a much larger
  // Natural Earth extract. Continental polygons therefore continue past the
  // crop on every aspect ratio instead of ending at artificial sheet borders.
  const rings = region === "caribbean" ? CARIBBEAN_COASTLINES : (COASTLINES[region] ?? []);

  const { paths, coasts, edgeExtensions } = useMemo(() => {
    // Regional coastline rings are clipped from one world map. Keep their real shape,
    // then extend only the stretches of continent that actually meet a crop edge.
    // This is purely visual: routing continues to use the single global sea grid.
    const [lon0, lat0, lon1, lat1] = def.bbox;
    const eps = 0.05;
    const isCut = ([lon, lat]: [number, number]) =>
      Math.abs(lon - lon0) < eps ||
      Math.abs(lon - lon1) < eps ||
      Math.abs(lat - lat0) < eps ||
      Math.abs(lat - lat1) < eps;
    const paths: string[] = [];
    const coasts: string[] = [];
    const edgeExtensions: { x: number; y: number; width: number; height: number }[] = [];
    const outerNW = project(viewBbox[0], viewBbox[3]);
    const outerSE = project(viewBbox[2], viewBbox[1]);
    for (const ring of rings) {
      let d = "";
      let c = "";
      let pen = false;
      const cuts = { n: [] as number[], s: [] as number[], e: [] as number[], w: [] as number[] };
      for (let i = 0; i < ring.length; i++) {
        const v = ring[i]!;
        const p = project(v[0], v[1]);
        d += `${i === 0 ? "M" : "L"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`;
        if (Math.abs(v[1] - lat1) < eps) cuts.n.push(v[0]);
        if (Math.abs(v[1] - lat0) < eps) cuts.s.push(v[0]);
        if (Math.abs(v[0] - lon1) < eps) cuts.e.push(v[1]);
        if (Math.abs(v[0] - lon0) < eps) cuts.w.push(v[1]);
        // real surveyed coastline only: skip vertices sitting on the sheet cut
        if (isCut(v)) {
          pen = false;
        } else {
          const q = project(v[0], v[1]);
          c += `${pen ? "L" : "M"}${q.x.toFixed(1)} ${q.y.toFixed(1)}`;
          pen = true;
        }
      }
      paths.push(`${d}Z`);
      if (c) coasts.push(c);

      for (const side of ["n", "s", "e", "w"] as const) {
        const values = cuts[side];
        if (values.length < 2) continue;
        const lo = Math.min(...values);
        const hi = Math.max(...values);
        if (side === "n" || side === "s") {
          const a = project(lo, side === "n" ? lat1 : lat0);
          const b = project(hi, side === "n" ? lat1 : lat0);
          const edgeY = side === "n" ? outerNW.y : outerSE.y;
          edgeExtensions.push({ x: Math.min(a.x, b.x), y: Math.min(a.y, edgeY), width: Math.abs(b.x - a.x), height: Math.abs(a.y - edgeY) });
        } else {
          const a = project(side === "e" ? lon1 : lon0, lo);
          const b = project(side === "e" ? lon1 : lon0, hi);
          const edgeX = side === "w" ? outerNW.x : outerSE.x;
          edgeExtensions.push({ x: Math.min(a.x, edgeX), y: Math.min(a.y, b.y), width: Math.abs(a.x - edgeX), height: Math.abs(b.y - a.y) });
        }
      }
    }
    return { paths, coasts, edgeExtensions };
  }, [rings, project, def, viewBbox]);

  const ports = useMemo(() => portsOfRegion(region), [region, revealKey]);

  /** The harbour under the cursor, if one lies within a finger's width of it. */
  const nearestPort = (m: { x: number; y: number }) => {
    let best: { p: Port; dist: number } | undefined;
    for (const p of ports) {
      const pt = project(p.lon, p.lat);
      const dist = Math.hypot(pt.x - m.x, pt.y - m.y);
      if (!best || dist < best.dist) best = { p, dist };
    }
    return best && best.dist < 15 / view.k ? best : undefined;
  };

  /** Every regional sheet is a window onto one continuous Atlantic chart. */
  const navigable = (lat: number, lon: number) => {
    return isSea(lat, lon);
  };

  /**
   * Fit-to-frame projections can leave letterbox bands when the chart and the
   * viewport have different aspect ratios. Those bands are furniture, not
   * geography, and must never be converted into latitude/longitude marks.
   */
  const insideChartSheet = (m: { x: number; y: number }) => {
    const nw = project(viewBbox[0], viewBbox[3]);
    const se = project(viewBbox[2], viewBbox[1]);
    return m.x >= nw.x && m.x <= se.x && m.y >= nw.y && m.y <= se.y;
  };




  // Non-passive wheel zoom anchored at the cursor.
  useEffect(() => {
    const el = svgRef.current;
    if (!el) return;
    const onWheel = (e: WheelEvent) => {
      e.preventDefault();
      const { x: px, y: py } = svgPoint(el, e, dims);
      const dy = e.deltaY * (e.deltaMode === 1 ? 16 : e.deltaMode === 2 ? 100 : 1);
      setView((v) => {
        const k = Math.min(8, Math.max(1, v.k * Math.exp(-dy * 0.0015)));
        const s = k / v.k;
        return clampView({ k, x: px - (px - v.x) * s, y: py - (py - v.y) * s }, dims);
      });
    };
    el.addEventListener("wheel", onWheel, { passive: false });
    return () => el.removeEventListener("wheel", onWheel);
  }, [dims]);

  function markerRadius(p: Port) {
    // A port's standing in the world, read off the chart at a glance.
    return 2.6 + (p.level ?? 2) * 1.15;
  }

  function markerFill(p: Port) {
    if (overlay === "piracy") return `oklch(${0.75 - p.pirateRisk * 0.35} 0.16 35)`;
    if (overlay === "prosperity") return `oklch(${0.45 + p.prosperity * 0.35} 0.13 150)`;
    return POWER_MAP[p.power]!.color;
  }

  const shipPt = project(shipAt.lon, shipAt.lat);
  const trackPts = track && track.length > 1 ? track.map((p) => project(p.lon, p.lat)) : null;
  const coursePt = course ? project(course.lon, course.lat) : null;
  const selPt = selected ? project(selected.lon, selected.lat) : null;
  // She points where she is going, never where she has been: take the first
  // waypoint still ahead of her — nearer the destination than she is — and if
  // there is none, look straight at the destination itself.
  const endPt = coursePt ?? (trackPts ? trackPts[trackPts.length - 1]! : null);
  const distTo = (p: { x: number; y: number }, q: { x: number; y: number }) => Math.hypot(p.x - q.x, p.y - q.y);
  const toGo = endPt ? distTo(shipPt, endPt) : 0;
  const nextPt =
    (endPt
      ? trackPts?.find((p) => distTo(p, shipPt) > 1.5 && distTo(p, endPt) < toGo - 0.5)
      : trackPts?.find((p) => distTo(p, shipPt) > 1.5)) ?? endPt;
  const heading =
    nextPt && distTo(nextPt, shipPt) > 0.5
      ? (Math.atan2(nextPt.y - shipPt.y, nextPt.x - shipPt.x) * 180) / Math.PI
      : -90;

  function toMap(e: { clientX: number; clientY: number }) {
    const { x: px, y: py } = svgPoint(svgRef.current!, e, dims);
    return { x: (px - view.x) / view.k, y: (py - view.y) / view.k };
  }

  return (
    <div
      ref={wrapRef}
      className="relative h-full w-full overflow-hidden"
      onContextMenu={(e) => e.preventDefault()}
    >
      {/* region tabs float over the top-left */}
      <div className="absolute left-2 top-2 z-10 flex flex-wrap gap-1 rounded-sm border border-border/60 bg-background/85 p-1 shadow-sm backdrop-blur">
        {MAP_REGIONS.map((r) => (
          <button
            key={r.id}
            type="button"
            onClick={() => setRegion(r.id)}
            className={`rounded-sm px-2 py-1 text-xs ${
              region === r.id ? "bg-primary text-primary-foreground" : "border border-input"
            }`}
          >
            {r.name}
          </button>
        ))}
      </div>

      {/* overlay toggle floats over the top-right */}
      <div className="absolute right-2 top-2 z-10 flex gap-1 rounded-sm border border-border/60 bg-background/85 p-1 shadow-sm backdrop-blur">
        {OVERLAYS.map((o) => (
          <button
            key={o.id}
            type="button"
            onClick={() => setOverlay(o.id)}
            className={`rounded-sm px-2 py-1 text-xs ${
              overlay === o.id ? "bg-primary text-primary-foreground" : "border border-input"
            }`}
          >
            {o.label}
          </button>
        ))}
      </div>

      <svg
        ref={svgRef}
        viewBox={`0 0 ${dims.w} ${dims.h}`}
        preserveAspectRatio="xMidYMid slice"
        className="block h-full w-full touch-none select-none"
        role="img"
        aria-label={`Chart of the ${def.name}`}
        style={{ cursor: overLand ? "not-allowed" : "crosshair" }}
        onPointerDown={(e) => {
          // Only the left hand of the mouse pans or selects; the right hand lays a course.
          if (e.button !== 0) return;
          if (!insideChartSheet(toMap(e))) return;
          drag.current = { x: e.clientX, y: e.clientY, ox: view.x, oy: view.y, moved: false };
        }}
        onPointerMove={(e) => {
          const d = drag.current;
          if (!d) {
            const m = toMap(e);
            if (!insideChartSheet(m)) {
              onHoverPort?.(undefined);
              setOverLand(true);
              return;
            }
            const near = nearestPort(m);
            onHoverPort?.(near ? near.p.id : undefined);
            const ll = invert(m.x, m.y);
            setOverLand(!near && !navigable(ll.lat, ll.lon));
            return;
          }
          const a = svgPoint(e.currentTarget, { clientX: d.x, clientY: d.y }, dims);
          const b = svgPoint(e.currentTarget, e, dims);
          const sx = b.x - a.x;
          const sy = b.y - a.y;
          if (!d.moved && Math.hypot(sx, sy) < 4) return;
          if (!d.moved) {
            d.moved = true;
            e.currentTarget.setPointerCapture(e.pointerId);
          }
          setView((v) => clampView({ ...v, x: d.ox + sx, y: d.oy + sy }, dims));
        }}
        onContextMenu={(e) => {
          e.preventDefault();
          if (!onSetCourse) return;
          const m = toMap(e);
          if (!insideChartSheet(m)) return;
          const near = nearestPort(m);
          if (near) {
            onSetCourse({ lat: near.p.lat, lon: near.p.lon, portId: near.p.id });
            return;
          }
          const ll = invert(m.x, m.y);
          // Dry ground takes no keel: only water may be laid a course for.
          if (!navigable(ll.lat, ll.lon)) return;
          onSetCourse({ lat: ll.lat, lon: ll.lon });
        }}
        onPointerUp={(e) => {
          const d = drag.current;
          drag.current = null;
          if (e.button !== 0) return;
          if (!d || d.moved) return;
          const m = toMap(e);
          if (!insideChartSheet(m)) return;
          // Nearest harbour within a finger's width wins; otherwise it is open water.
          const near = nearestPort(m);
          if (near) {
            onSelectPort(near.p.id);
            return;
          }
          const ll = invert(m.x, m.y);
          // Land is not a mark: it cannot be selected, sounded, or sailed to.
          if (!navigable(ll.lat, ll.lon)) return;
          onSelectSea(ll.lat, ll.lon);
        }}
        onPointerLeave={() => {
          drag.current = null;
          setOverLand(false);
          onHoverPort?.(undefined);
        }}

      >
        <defs>
          <linearGradient id="sea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.42 0.07 233)" />
            <stop offset="100%" stopColor="oklch(0.31 0.07 250)" />
          </linearGradient>
          <linearGradient id="terrain" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="oklch(0.66 0.09 132)" />
            <stop offset="65%" stopColor="oklch(0.58 0.08 118)" />
            <stop offset="100%" stopColor="oklch(0.68 0.07 92)" />
          </linearGradient>
          <filter id="shelf" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="6" />
          </filter>
          <filter id="shoal" x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="14" />
          </filter>
          <pattern id="swell" width="26" height="26" patternUnits="userSpaceOnUse">
            <path d="M0 18 q6.5 -6 13 0 t13 0" fill="none" stroke="oklch(0.55 0.05 235)" strokeWidth="0.7" opacity="0.35" />
          </pattern>
          <pattern id="parchment" width="34" height="34" patternUnits="userSpaceOnUse">
            <rect width="34" height="34" fill="oklch(0.86 0.045 85)" />
            <path d="M-8 8 L8 -8 M0 34 L34 0 M26 42 L42 26" stroke="oklch(0.79 0.05 80)" strokeWidth="1" opacity="0.55" />
            <circle cx="9" cy="22" r="1.1" fill="oklch(0.75 0.05 74)" opacity="0.5" />
            <circle cx="25" cy="11" r="0.9" fill="oklch(0.75 0.05 74)" opacity="0.45" />
          </pattern>
          <clipPath id="chart-frame">
            <rect x="0" y="0" width={dims.w} height={dims.h} />
          </clipPath>
          <clipPath id="land-clip">
            {paths.map((d, i) => (
              <path key={`c${i}`} d={d} />
            ))}
          </clipPath>
        </defs>

        <g clipPath="url(#chart-frame)">
          <rect width={dims.w} height={dims.h} fill="url(#sea)" />
          <rect width={dims.w} height={dims.h} fill="url(#swell)" />

          <g transform={`translate(${view.x} ${view.y}) scale(${view.k})`}>
            {/* soundings: the far bank, then the shelf, then the shoal water */}
            <g filter="url(#shoal)" opacity="0.35">
              {paths.map((d, i) => (
                <path key={`b${i}`} d={d} fill="oklch(0.5 0.07 225)" stroke="oklch(0.52 0.07 222)" strokeWidth={22} />
              ))}
            </g>
            <g filter="url(#shelf)" opacity="0.5">
              {paths.map((d, i) => (
                <path key={`s${i}`} d={d} fill="oklch(0.55 0.08 220)" stroke="oklch(0.6 0.08 215)" strokeWidth={8} />
              ))}
            </g>

            {/* interiors read as uncharted parchment; only the surveyed coastal band is drawn as land */}
            {edgeExtensions.map((r, i) => (
              <rect key={`edge-land-${i}`} {...r} fill="url(#parchment)" />
            ))}
            {paths.map((d, i) => (
              <path key={`p${i}`} d={d} fill="url(#parchment)" />
            ))}
            <g clipPath="url(#land-clip)">
              {coasts.map((d, i) => (
                <path
                  key={`f${i}`}
                  d={d}
                  fill="none"
                  stroke="oklch(0.7 0.07 105)"
                  strokeWidth={46}
                  strokeLinejoin="round"
                  opacity="0.4"
                />
              ))}
              {coasts.map((d, i) => (
                <path key={`t${i}`} d={d} fill="none" stroke="url(#terrain)" strokeWidth={26} strokeLinejoin="round" />
              ))}
            </g>
            {coasts.map((d, i) => (
              <path
                key={`l${i}`}
                d={d}
                fill="none"
                stroke="oklch(0.42 0.06 95)"
                strokeWidth={0.7 / view.k}
                strokeLinejoin="round"
              />
            ))}

            {(def.seas ?? []).map((sea) => {
              const pt = project(sea.lon, sea.lat);
              return (
                <text
                  key={sea.name}
                  x={pt.x}
                  y={pt.y}
                  textAnchor="middle"
                  fontSize={(sea.size ?? 12) / Math.sqrt(view.k)}
                  fill="oklch(0.88 0.03 220)"
                  opacity={0.45}
                  letterSpacing={(sea.size ?? 12) > 14 ? 4 : 1.5}
                  className="pointer-events-none select-none font-serif italic"
                >
                  {sea.name}
                </text>
              );
            })}

            {/* The destination mark. The actual course is the routed water track below. */}
            {coursePt && (
              <>
                <g className="pointer-events-none" transform={`translate(${coursePt.x} ${coursePt.y})`}>
                  <circle r={7 / view.k} fill="none" stroke="oklch(0.92 0.13 85)" strokeWidth={1.4 / view.k} />
                  <path
                    d={`M${-10 / view.k} 0 H${10 / view.k} M0 ${-10 / view.k} V${10 / view.k}`}
                    stroke="oklch(0.92 0.13 85)"
                    strokeWidth={1 / view.k}
                  />
                </g>
              </>
            )}

            {trackPts && (
              <path
                d={trackPts.map((p, i) => `${i === 0 ? "M" : "L"}${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join("")}
                stroke="oklch(0.9 0.1 85)"
                strokeWidth={1.6 / view.k}
                strokeDasharray={`${6 / view.k} ${5 / view.k}`}
                fill="none"
                className="pointer-events-none"
              />
            )}

            {/* the selected mark, when it is bare water */}
            {selPt && !selected?.portId && (
              <circle
                cx={selPt.x}
                cy={selPt.y}
                r={9 / view.k}
                fill="none"
                stroke="oklch(0.95 0.02 90)"
                strokeWidth={1.4 / view.k}
                strokeDasharray={`${3 / view.k} ${3 / view.k}`}
                className="pointer-events-none"
              />
            )}

            {ports.map((p) => {
              const pt = project(p.lon, p.lat);
              const r = markerRadius(p) / Math.sqrt(view.k);
              const active = p.id === selected?.portId;
              return (
                <g key={p.id} transform={`translate(${pt.x} ${pt.y})`} className="pointer-events-none">
                  <circle
                    r={r}
                    fill={markerFill(p)}
                    stroke={active ? "oklch(0.97 0.02 90)" : "oklch(0.22 0.02 60)"}
                    strokeWidth={(active ? 2 : 1) / view.k}
                  >
                    <title>{`${p.name} — ${POWER_MAP[p.power]!.name}`}</title>
                  </circle>
                  <text
                    x={r + 3 / view.k}
                    y={3 / view.k}
                    fontSize={11 / view.k}
                    fill="oklch(0.96 0.02 90)"
                    stroke="oklch(0.2 0.03 250)"
                    strokeWidth={2.5 / view.k}
                    paintOrder="stroke"
                  >
                    {p.name}
                  </text>
                </g>
              );
            })}

            {/* the contract the captain is following */}
            {questMark && (() => {
              const qp = project(questMark.lon, questMark.lat);
              const qr = 13 / Math.sqrt(view.k);
              return (
                <g transform={`translate(${qp.x} ${qp.y})`} className="pointer-events-none">
                  <circle r={qr} fill="none" stroke="oklch(0.88 0.16 90)" strokeWidth={2 / view.k} strokeDasharray={`${5 / view.k} ${3 / view.k}`} />
                  <circle r={qr * 1.7} fill="none" stroke="oklch(0.88 0.16 90)" strokeOpacity={0.45} strokeWidth={1 / view.k} />
                  <text
                    y={-qr * 2.1}
                    textAnchor="middle"
                    fontSize={9 / Math.sqrt(view.k)}
                    fill="oklch(0.93 0.14 90)"
                    style={{ paintOrder: "stroke", stroke: "oklch(0.14 0.03 55)", strokeWidth: 3 / view.k }}
                  >
                    {questMark.note ?? `Contract · ${questMark.label}`}
                  </text>
                </g>
              );
            })()}

            {/* what the lookouts can see from the masthead */}
            {sightNm > 0 && (
              <circle
                cx={shipPt.x}
                cy={shipPt.y}
                r={Math.abs(project(shipAt.lon, shipAt.lat + sightNm / 60).y - shipPt.y)}
                fill="oklch(0.85 0.09 200)"
                fillOpacity={0.07}
                stroke="oklch(0.88 0.08 200)"
                strokeOpacity={0.4}
                strokeWidth={1 / view.k}
                strokeDasharray={`${4 / view.k} ${4 / view.k}`}
                className="pointer-events-none"
              />
            )}

            {/* other men's hulls, seen from our own masthead */}
            {npcShips.map((n) => {
              const pt = project(n.lon, n.lat);
              const k = 1 / view.k;
              const tone = n.power
                ? ((POWER_MAP as Record<string, { color: string }>)[n.power]?.color ?? "oklch(0.85 0.05 90)")
                : "oklch(0.72 0.17 150)";
              const size = /galleon|frigate/i.test(n.className ?? "")
                ? 1.25
                : /brig/i.test(n.className ?? "")
                  ? 1
                  : 0.82;
              // Point her the way she is steering.
              const to = project(n.toLon ?? n.lon, n.toLat ?? n.lat);
              const head = (Math.atan2(to.y - pt.y, to.x - pt.x) * 180) / Math.PI + 90;
              return (
                <g
                  key={n.id}
                  transform={`translate(${pt.x} ${pt.y}) scale(${k * size})`}
                  className="cursor-pointer"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectNpc?.(n.id);
                  }}
                >
                  <circle r={13} fill={tone} opacity={0.12} />
                  <path
                    transform={`rotate(${head})`}
                    d="M0 -11 L7 8 L0 3.5 L-7 8 Z"
                    fill={tone}
                    stroke="oklch(0.20 0.03 60)"
                    strokeWidth={1.1}
                  />
                  <text
                    y={-15}
                    textAnchor="middle"
                    fontSize={8}
                    fill={tone}
                    style={{ paintOrder: "stroke", stroke: "oklch(0.14 0.03 55)", strokeWidth: 3 }}
                  >
                    {n.name}
                  </text>
                  <title>{`${n.name} — click for her company`}</title>
                </g>
              );
            })}

            {/* actions being fought by others */}
            {npcBattles.map((b) => {
              const pt = project(b.lon, b.lat);
              const k = 1 / view.k;
              return (
                <g key={b.id} transform={`translate(${pt.x} ${pt.y}) scale(${k})`} className="cursor-help">
                  <circle r={12} fill="transparent" />
                  <title>
                    {[
                      b.portId ? "An action against a shore battery" : "An action at sea",
                      `${Math.max(1, b.endsDay - day)} day(s) yet in the settling`,
                      ...(b.crews?.length
                        ? b.crews.map(
                            (c) =>
                              `${c.name}${c.className ? ` (${c.className})` : ""} — Captain ${c.captain}${
                                c.power ? `, ${c.power} colours` : ", a free trader"
                              }`,
                          )
                        : ["Too far off to make out her colours"]),
                    ].join("\n")}
                  </title>
                  <path
                    d="M-8 -8 L8 8 M8 -8 L-8 8"
                    stroke="oklch(0.72 0.20 28)"
                    strokeWidth={3}
                    strokeLinecap="round"
                    style={{ paintOrder: "stroke" }}
                    pointerEvents="none"
                  />
                  <text
                    y={-12}
                    textAnchor="middle"
                    fontSize={8}
                    fill="oklch(0.85 0.14 30)"
                    style={{ paintOrder: "stroke", stroke: "oklch(0.14 0.03 55)", strokeWidth: 3 }}
                  >
                    {b.portId ? "Shore action" : "Action"} · {Math.max(1, b.endsDay - day)}d
                  </text>
                </g>
              );
            })}

            {/* marks afloat: wrecks, sails, weather, gossip */}
            {seaEvents.map((ev) => {
              const pt = project(ev.lon, ev.lat);
              const k = 1 / view.k;
              const tone = ALERT_TONE[MARK_ALERT[ev.kind]];
              const chosen = selected && !selected.portId && Math.abs(selected.lat - ev.lat) < 0.05 && Math.abs(selected.lon - ev.lon) < 0.05;
              return (
                <g
                  key={ev.id}
                  transform={`translate(${pt.x} ${pt.y}) scale(${k})`}
                  className="cursor-pointer"
                  onPointerDown={(e) => e.stopPropagation()}
                  onClick={(e) => {
                    e.stopPropagation();
                    onSelectEvent?.(ev);
                  }}
                >
                  <circle r={9} fill="oklch(0.16 0.03 55)" fillOpacity={0.6} stroke={tone} strokeWidth={chosen ? 2 : 1} />
                  <text
                    y={4.5}
                    textAnchor="middle"
                    fontSize={13}
                    fontWeight={700}
                    fill={tone}
                    className="select-none font-serif"
                  >
                    !
                  </text>
                  <title>{`${MARK_NAME[ev.kind]} — ${ev.title}: ${ev.text}`}</title>
                </g>
              );
            })}

            {/* the ship herself */}
            <g
              data-ship=""
              className="pointer-events-none"
              transform={`translate(${shipPt.x} ${shipPt.y}) rotate(${heading + 90}) scale(${1 / view.k})`}
            >
              <circle r={13} fill="oklch(0.70 0.19 305)" opacity={0.18} />
              <path
                d="M0 -13 L8 9 L0 4 L-8 9 Z"
                fill="oklch(0.72 0.20 305)"
                stroke="oklch(0.25 0.04 60)"
                strokeWidth={1.2}
              />
            </g>

            {/* the sheet ends at its stated bounds — beyond is off the chart */}
            {(() => {
              const a = project(viewBbox[0], viewBbox[3]);
              const b = project(viewBbox[2], viewBbox[1]);
              const F = 6000;
              return (
                <path
                  className="pointer-events-none"
                  fillRule="evenodd"
                  fill="oklch(0.18 0.02 60)"
                  d={`M${-F} ${-F}H${F}V${F}H${-F}Z M${a.x} ${a.y}H${b.x}V${b.y}H${a.x}Z`}
                />
              );
            })()}
          </g>


          <text
            x={dims.w / 2}
            y={26}
            textAnchor="middle"
            fontSize={13}
            letterSpacing={6}
            fill="oklch(0.82 0.03 90)"
            opacity={0.45}
            className="pointer-events-none select-none font-serif italic"
          >
            {def.name.toUpperCase()}
          </text>
        </g>
      </svg>

      {/* the sheets join at the edges */}
      {(def.links ?? []).map((l) => (
        <button
          key={l.side + l.regionId}
          type="button"
          onClick={() => setRegion(l.regionId)}
          className={`absolute rounded-sm border border-[oklch(0.6_0.08_80)]/50 bg-background/80 px-2 py-1 text-[11px] backdrop-blur transition-colors hover:bg-secondary ${
            l.side === "n"
              ? "left-1/2 top-2 -translate-x-1/2"
              : l.side === "s"
                ? "bottom-2 left-1/2 -translate-x-1/2"
                : l.side === "e"
                  ? "right-2 top-1/2 -translate-y-1/2"
                  : "left-2 top-1/2 -translate-y-1/2"
          }`}
        >
          {l.side === "n" ? "▲" : l.side === "s" ? "▼" : l.side === "e" ? "▶" : "◀"} {l.label}
        </button>
      ))}

      {/* zoom controls */}
      <div className="absolute bottom-2 right-2 flex gap-1">
        {[
          { label: "+", fn: () => setView((v) => zoomAt(v, 1.4, dims)) },
          { label: "−", fn: () => setView((v) => zoomAt(v, 1 / 1.4, dims)) },
          { label: "Reset", fn: () => setView({ x: 0, y: 0, k: 1 }) },
        ].map((b) => (
          <button
            key={b.label}
            type="button"
            onClick={b.fn}
            className="rounded-sm border border-input bg-background/80 px-2 py-1 text-xs backdrop-blur"
          >
            {b.label}
          </button>
        ))}
      </div>
    </div>
  );
}

type View = { x: number; y: number; k: number };

/** The chart has edges: you may only pan into what the zoom has pushed off-screen. */
function clampView(v: View, dims: { w: number; h: number }): View {
  const maxX = 0;
  const minX = dims.w - dims.w * v.k;
  const maxY = 0;
  const minY = dims.h - dims.h * v.k;
  return {
    k: v.k,
    x: Math.min(maxX, Math.max(minX, v.x)),
    y: Math.min(maxY, Math.max(minY, v.y)),
  };
}

function zoomAt(v: View, f: number, dims: { w: number; h: number }) {
  const k = Math.min(8, Math.max(1, v.k * f));
  const s = k / v.k;
  const cx = dims.w / 2;
  const cy = dims.h / 2;
  return clampView({ k, x: cx - (cx - v.x) * s, y: cy - (cy - v.y) * s }, dims);
}
