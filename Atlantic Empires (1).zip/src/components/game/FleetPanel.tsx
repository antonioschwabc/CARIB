import { useState } from "react";

import { NpcCrewDialog } from "@/components/game/NpcCrewDialog";
import type { NpcShip } from "@/game/types";

import { BannerFlag } from "@/components/game/BannerFlag";
import { POWER_MAP } from "@/game/data/powers";
import { effectiveGuns } from "@/game/sim/voyage";
import { activeShip } from "@/game/actions";
import { PORT_MAP } from "@/game/data/ports";
import { SHIP_CLASSES, SHIP_CLASS_MAP } from "@/game/data/ships";
import { money } from "@/game/sim/util";
import { useGame } from "@/game/store";

export function FleetPanel() {
  const { state, dispatch } = useGame();
  const [mockClass, setMockClass] = useState(SHIP_CLASSES[0]!.id);
  const [mockCount, setMockCount] = useState(1);
  const [mockFoe, setMockFoe] = useState("ship");
  const [tab, setTab] = useState<"mine" | "factions">("mine");
  const ship = activeShip(state);
  const port = ship ? PORT_MAP[ship.portId]! : undefined;
  const canBuy = !!port && port.shipyard > 0 && !ship?.voyage;
  const canMock = !!ship && !ship.voyage && !state.combat;

  return (
    <div className="p-4">
      <div className="mb-3 flex gap-2">
        {(["mine", "factions"] as const).map((t) => (
          <button
            key={t}
            type="button"
            onClick={() => setTab(t)}
            className={`rounded-sm border px-3 py-1 text-xs ${tab === t ? "border-accent bg-secondary/70" : "border-input"}`}
          >
            {t === "mine" ? "Your fleet" : "Faction squadrons"}
          </button>
        ))}
      </div>
      {tab === "factions" ? <FactionFleets /> : <MyFleet />}
    </div>
  );

  function MyFleet() {
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <section className="panel p-4">
        <h2 className="mb-3 font-semibold">Your fleet</h2>
        <ul className="space-y-2">
          {state.ships.map((s) => {
            const cls = SHIP_CLASS_MAP[s.classId]!;
            return (
              <li
                key={s.id}
                className={`rounded-sm border p-3 ${s.id === state.activeShipId ? "border-accent bg-secondary/60" : "border-border"}`}
              >
                <div className="flex items-baseline justify-between gap-2">
                  <BannerFlag banner={s.banner ?? state.banner} className="h-6 w-8 shrink-0 self-center" />
                  <input
                    className="w-40 bg-transparent font-semibold outline-none"
                    value={s.name}
                    onChange={(e) => dispatch({ type: "renameShip", shipId: s.id, name: e.target.value })}
                    aria-label="Ship name"
                  />
                  <span className="text-xs text-muted-foreground">{cls.name}</span>
                </div>
                <p className="numeric mt-1 text-xs text-muted-foreground">
                  {s.voyage
                    ? `At sea — ${s.voyage.daysLeft}d to ${PORT_MAP[s.voyage.to]!.name}`
                    : PORT_MAP[s.portId]!.name}
                  {" · "}hull {Math.round(s.hull)}% · crew {s.crew} · {effectiveGuns(s)} guns
                  {s.allegiance ? ` · ${POWER_MAP[s.allegiance].adjective} colours` : ""}
                </p>
                <div className="mt-2 flex gap-2">
                  <button
                    type="button"
                    onClick={() => dispatch({ type: "selectShip", shipId: s.id })}
                    disabled={s.id === state.activeShipId}
                    className="rounded-sm border border-input px-2 py-1 text-xs disabled:opacity-40"
                  >
                    Take command
                  </button>
                  <button
                    type="button"
                    onClick={() => dispatch({ type: "sellShip", shipId: s.id })}
                    disabled={state.ships.length <= 1 || !!s.voyage}
                    className="rounded-sm border border-input px-2 py-1 text-xs disabled:opacity-40"
                  >
                    Sell out of the fleet
                  </button>
                </div>
              </li>
            );
          })}
        </ul>

        <div className="mt-4 rounded-sm border border-border p-3">
          <h3 className="font-semibold">Combat mockery</h3>
          <p className="mt-0.5 text-xs text-muted-foreground">
            Fight a phantom of any class to test the build. The hull, the men and the purse are in no
            true danger — nothing carries over.
          </p>
          <div className="mt-2 flex items-center gap-2">
            <select
              value={mockClass}
              onChange={(e) => setMockClass(e.target.value)}
              disabled={mockFoe !== "ship"}
              className="rounded-sm border border-input bg-background px-2 py-1 text-xs"
              aria-label="Phantom class"
            >
              {SHIP_CLASSES.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
            <select
              value={mockFoe}
              onChange={(e) => setMockFoe(e.target.value)}
              className="rounded-sm border border-input bg-background px-2 py-1 text-xs"
              aria-label="What to fight"
            >
              <option value="ship">Phantom sail</option>
              {[1, 2, 3, 4, 5].map((lv) => (
                <option key={lv} value={`fort${lv}`}>
                  Shore fort · level {lv}
                </option>
              ))}
            </select>
            <select
              value={mockCount}
              onChange={(e) => setMockCount(Number(e.target.value))}
              disabled={mockFoe !== "ship"}
              className="rounded-sm border border-input bg-background px-2 py-1 text-xs"
              aria-label="How many phantoms"
            >
              {[1, 2, 3, 4, 5, 6].map((n) => (
                <option key={n} value={n}>
                  {n} sail
                </option>
              ))}
            </select>
            <button
              type="button"
              disabled={!canMock}
              onClick={() =>
                dispatch(
                  mockFoe === "ship"
                    ? { type: "mockBattle", classId: mockClass, count: mockCount }
                    : { type: "mockBattle", classId: mockClass, fortLevel: Number(mockFoe.slice(4)) },
                )
              }
              className="rounded-sm bg-primary px-3 py-1 text-xs text-primary-foreground disabled:opacity-40"
            >
              Beat to quarters
            </button>
            {ship?.voyage && <span className="text-[11px] text-muted-foreground">Not while at sea.</span>}
          </div>
        </div>
      </section>

      <section className="panel p-4">
        <h2 className="mb-1 font-semibold">Ships for sale</h2>
        <p className="mb-3 text-xs text-muted-foreground">
          {canBuy ? `Offered at ${port!.name}.` : "You must be in harbour at a port with a yard."}
        </p>
        <ul className="space-y-2">
          {SHIP_CLASSES.map((c) => (
            <li key={c.id} className="rounded-sm border border-border p-3">
              <div className="flex items-baseline justify-between">
                <span className="font-semibold">{c.name}</span>
                <span className="numeric text-sm">{money(c.price)}</span>
              </div>
              <p className="numeric text-xs text-muted-foreground">
                {c.cargo} t · {c.speed} km/h · {c.firepower} firepower · {c.hands} hands · {money(c.upkeep)}/day
              </p>
              <p className="mt-1 text-xs text-muted-foreground">{c.note}</p>
              <button
                type="button"
                disabled={!canBuy || state.cash < c.price}
                onClick={() => dispatch({ type: "buyShip", classId: c.id })}
                className="mt-2 rounded-sm bg-primary px-3 py-1 text-xs text-primary-foreground disabled:opacity-40"
              >
                Purchase
              </button>
            </li>
          ))}
        </ul>
      </section>
    </div>
  );
  }
}

/** The crowns' squadrons, as far as the coffee-houses know them. */
function FactionFleets() {
  const { state } = useGame();
  const [open, setOpen] = useState<NpcShip | undefined>();
  const ships = state.npcShips ?? [];
  const fleets = state.npcFleets ?? [];
  // The Brethren keep no register: only a man of the black flag hears of them.
  const brother =
    (state.relations?.["pirate"] ?? -70) > 0 || state.ships.some((s) => s.allegiance === "pirate");

  const shown = fleets.filter((f) => f.power !== "pirate" || brother);
  if (!shown.length) return <p className="text-sm text-muted-foreground">No word of any squadron yet.</p>;

  return (
    <div className="grid gap-4 lg:grid-cols-2">
      {shown.map((fleet) => {
        const own = ships.filter((s) => s.fleetId === fleet.id);
        return (
          <section key={fleet.id} className="panel p-4">
            <div className="flex items-baseline justify-between gap-2">
              <h2 className="font-semibold">{fleet.name}</h2>
              <span className="text-xs text-muted-foreground">{POWER_MAP[fleet.power]!.adjective}</span>
            </div>
            <ul className="mt-2 space-y-2">
              {own.length === 0 && (
                <li className="text-xs text-muted-foreground">Swept from the sea. Not a sail left of her.</li>
              )}
              {own.map((s) => (
                <li
                  key={s.id}
                  onClick={() => setOpen(s)}
                  className="cursor-pointer rounded-sm border border-border p-2 transition-colors hover:border-accent/60 hover:bg-secondary/40"
                >
                  <div className="flex items-baseline justify-between gap-2">
                    <BannerFlag banner={s.banner} className="h-5 w-7 shrink-0 self-center" />
                    <span className="font-semibold">{s.name}</span>
                    <span className="text-xs text-muted-foreground">
                      {s.seen ? SHIP_CLASS_MAP[s.classId]?.name : "rig unknown"}
                    </span>
                  </div>
                  <p className="numeric mt-1 text-xs text-muted-foreground">
                    Captain {s.captain.name}, {s.captain.nationality}, {s.captain.age}
                    {s.seen
                      ? ` · hull ${Math.round(s.hull)}/${s.maxHull} · ${s.firepower} firepower · ${s.crewNames.length} named hands`
                      : " · her figures are not known to you"}
                  </p>
                  {s.seen && s.components.length > 0 && (
                    <p className="mt-0.5 text-[11px] text-muted-foreground">
                      Fitted: {s.components.join(", ")}
                    </p>
                  )}
                </li>
              ))}
            </ul>
          </section>
        );
      })}

      <section className="panel p-4">
        <h2 className="font-semibold">Free traders</h2>
        <p className="mt-0.5 text-xs text-muted-foreground">
          Independent masters, beholden to nobody, running their own accounts.
        </p>
        <ul className="mt-2 space-y-2">
          {ships.filter((s) => !s.power).map((s) => (
            <li
              key={s.id}
              onClick={() => setOpen(s)}
              className="cursor-pointer rounded-sm border border-border p-2 transition-colors hover:border-accent/60 hover:bg-secondary/40"
            >
              <div className="flex items-baseline justify-between gap-2">
                <BannerFlag banner={s.banner} className="h-5 w-7 shrink-0 self-center" />
                <span className="font-semibold">{s.name}</span>
                <span className="text-xs text-muted-foreground">{s.captain.nationality}</span>
              </div>
              <p className="numeric mt-1 text-xs text-muted-foreground">
                Captain {s.captain.name}
                {s.seen ? ` · ${SHIP_CLASS_MAP[s.classId]?.name} · purse ${Math.round(s.gold ?? 0)} gold` : " · never yet under your glass"}
              </p>
            </li>
          ))}
        </ul>
      </section>

      {open && <NpcCrewDialog ship={open} onClose={() => setOpen(undefined)} />}
    </div>
  );
}
