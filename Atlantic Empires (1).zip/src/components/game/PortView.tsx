import { useMemo } from "react";

import { POWER_MAP } from "@/game/data/powers";
import { fortificationOf } from "@/game/sim/portIntel";
import { rng } from "@/game/sim/util";
import type { Port } from "@/game/types";

/** A deterministic 2D prospect of the harbour, drawn from the port's own numbers. */
export function PortView({ port }: { port: Port }) {
  const scene = useMemo(() => {
    const seed = [...port.id].reduce((a, c) => a * 31 + c.charCodeAt(0), 7) >>> 0;
    const rand = rng(seed);
    const fort = fortificationOf(port);
    const houses = Math.round(6 + Math.min(26, Math.log10(Math.max(500, port.population)) * 7));
    const buildings = Array.from({ length: houses }, (_, i) => {
      const w = 12 + rand() * 20;
      const h = 12 + rand() * (22 + port.prosperity * 30);
      return {
        key: i,
        x: 18 + rand() * 364,
        w,
        h,
        roof: rand() < 0.5,
        tower: rand() < 0.12 + port.prosperity * 0.1,
      };
    }).sort((a, b) => a.h - b.h);
    const ships = Array.from({ length: 1 + Math.round(rand() * 3 + port.prosperity * 2) }, (_, i) => ({
      key: i,
      x: 30 + rand() * 340,
      y: 132 + rand() * 34,
      s: 0.6 + rand() * 0.7,
    }));
    const palms = Math.abs(port.lat) < 27 ? Array.from({ length: 3 }, (_, i) => ({ key: i, x: 12 + rand() * 380 })) : [];
    return { fort, buildings, ships, palms };
  }, [port]);

  const flag = POWER_MAP[port.power]!.color;
  const tropical = Math.abs(port.lat) < 27;

  return (
    <svg
      viewBox="0 0 400 180"
      className="w-full rounded-sm border border-border"
      role="img"
      aria-label={`A prospect of ${port.name}`}
    >
      <defs>
        <linearGradient id="pv-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={tropical ? "oklch(0.78 0.07 240)" : "oklch(0.7 0.04 250)"} />
          <stop offset="100%" stopColor={tropical ? "oklch(0.9 0.06 80)" : "oklch(0.82 0.03 250)"} />
        </linearGradient>
        <linearGradient id="pv-sea" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="oklch(0.55 0.09 220)" />
          <stop offset="100%" stopColor="oklch(0.4 0.08 240)" />
        </linearGradient>
      </defs>

      <rect width="400" height="180" fill="url(#pv-sky)" />
      {/* hills behind the town */}
      <path d="M0 96 q60 -34 120 -6 q50 -30 110 -2 q60 -26 170 4 V180 H0Z" fill="oklch(0.52 0.07 128)" opacity="0.8" />
      <path d="M0 108 q80 -20 160 2 q90 -18 240 6 V180 H0Z" fill="oklch(0.6 0.08 118)" />

      {/* town */}
      {scene.buildings.map((b) => (
        <g key={b.key}>
          <rect x={b.x} y={126 - b.h} width={b.w} height={b.h} fill="oklch(0.85 0.03 85)" stroke="oklch(0.45 0.03 70)" strokeWidth="0.6" />
          {b.roof && (
            <path d={`M${b.x - 2} ${126 - b.h} L${b.x + b.w / 2} ${126 - b.h - 8} L${b.x + b.w + 2} ${126 - b.h}Z`} fill="oklch(0.52 0.11 40)" />
          )}
          {b.tower && <rect x={b.x + b.w / 2 - 2} y={126 - b.h - 16} width="4" height="16" fill="oklch(0.8 0.03 85)" />}
        </g>
      ))}

      {/* fortification, scaled to the defences */}
      <g transform="translate(300 0)">
        <rect x="0" y={126 - 22 - scene.fort.score * 26} width={40 + scene.fort.score * 46} height={22 + scene.fort.score * 26} fill="oklch(0.72 0.02 80)" stroke="oklch(0.4 0.02 70)" strokeWidth="0.8" />
        {Array.from({ length: Math.round(3 + scene.fort.score * 6) }, (_, i) => (
          <rect
            key={i}
            x={4 + i * 9}
            y={126 - 22 - scene.fort.score * 26 - 5}
            width="5"
            height="5"
            fill="oklch(0.72 0.02 80)"
          />
        ))}
        <line x1="6" y1={126 - 22 - scene.fort.score * 26 - 5} x2="6" y2={100 - scene.fort.score * 30} stroke="oklch(0.35 0.02 70)" strokeWidth="1" />
        <rect x="6" y={100 - scene.fort.score * 30} width="16" height="9" fill={flag} />
      </g>

      {scene.palms.map((p) => (
        <g key={p.key} transform={`translate(${p.x} 126)`}>
          <path d="M0 0 q-2 -12 1 -20" stroke="oklch(0.42 0.05 70)" strokeWidth="2" fill="none" />
          <path d="M1 -20 q-10 -4 -14 2 M1 -20 q10 -5 14 1 M1 -20 q-3 -9 -9 -11 M1 -20 q5 -9 11 -10" stroke="oklch(0.5 0.11 140)" strokeWidth="2" fill="none" />
        </g>
      ))}

      {/* water */}
      <rect x="0" y="126" width="400" height="54" fill="url(#pv-sea)" />
      {[134, 146, 158, 170].map((y) => (
        <path
          key={y}
          d={`M0 ${y} q12 -3 24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0 t24 0`}
          stroke="oklch(0.72 0.05 225)"
          strokeWidth="0.7"
          fill="none"
          opacity="0.45"
        />
      ))}

      {/* shipping at anchor */}
      {scene.ships.map((s) => (
        <g key={s.key} transform={`translate(${s.x} ${s.y}) scale(${s.s})`}>
          <path d="M-14 0 q14 8 28 0Z" fill="oklch(0.35 0.04 60)" />
          <line x1="0" y1="0" x2="0" y2="-22" stroke="oklch(0.4 0.04 60)" strokeWidth="1.4" />
          <path d="M1 -21 q11 8 0 15Z" fill="oklch(0.94 0.02 85)" />
          <path d="M-1 -21 q-9 7 0 13Z" fill="oklch(0.9 0.02 85)" />
        </g>
      ))}
    </svg>
  );
}
