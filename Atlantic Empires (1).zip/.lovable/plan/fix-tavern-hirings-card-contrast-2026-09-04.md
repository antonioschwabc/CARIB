# Fix tavern hirings card contrast

## Problem
The character cards shown in **Tavern → Hirings** have a `bg-secondary/30` background that looks too bright against the dark rusted-wood tavern ledger, making the text hard to read. The same `CrewCard` component is reused on the Crew tab, where the current styling is acceptable.

## Plan
1. Add an optional `variant` prop to `CrewCard` (`"default" | "tavern"`).
2. In `"tavern"` variant:
   - Use a darker, nearly-opaque card background (`bg-card` / `bg-[oklch(0.22_0.025_45)]`).
   - Keep border subtle but readable.
   - Ensure all text meets contrast: names and labels in `text-secondary-foreground` / `text-foreground`, muted details in `text-muted-foreground`.
   - Preserve the existing hover skill popup and expanded detail view styling.
3. Update `TavernScreen.tsx` `Hirings` to render `<CrewCard variant="tavern" … />`.
4. Leave the default Crew-tab variant unchanged.
5. Run `bunx tsgo --noEmit` and a quick browser check of the tavern hirings screen.

## Files to edit
- `src/components/game/CrewCard.tsx`
- `src/components/game/TavernScreen.tsx`
