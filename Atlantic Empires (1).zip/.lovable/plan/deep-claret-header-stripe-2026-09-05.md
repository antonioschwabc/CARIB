# Deep claret header stripe

Rebuild the top HUD of `/play` to match the chosen "Deep claret stripe" preview: a half-height, edge-to-edge wine-leather stripe with a thin red ribbon drape left of the CARIB title and a single line of text-only ledger figures. All icons, pills, gauges and buttons leave the header.

## What the new header looks like

```text
│ ┃ CARIB   DATE 12 OCT 1667 · CAPT AMBROSE HALE · SHIP WAYFARER · POS HAVANA ·
│           COND 73% · MORALE 62% · GOLD 850 · DEBT 200 · RAT 24 · MED 8 · SALV 15
├──────────────────────────────────────────────────────────────────────────────
│  Chart   Port   Crew   Ship   Fleet   Diplomacy   Finance   Journal   (unchanged)
```

- ~40px tall stripe, deep claret leather (`~#320a0a` dark oxblood, subtle grain), flush to both screen edges — no side borders.
- Thin red-leather ribbon (`w-1.5`, darker red `#631212`) hangs from the very top edge at the left, ending at the CARIB baseline. Decorative only for now — it will become the theme-switch button later, so it gets an unobtrusive wrapper ready for that.
- `CARIB` wordmark in brass (`#c5b358`), serif small caps, letterspaced, linking back to `/` as today.
- One dense horizontal line of small-caps figures: DATE, CAPT, SHIP, POS, COND, MORALE, GOLD, DEBT, RAT, MED, SALV — brass/parchment ink, tabular numerals, subtle `|` dividers. Values stay live from game state (condition %, morale %, gold, debt, rations with daily burn, medicine, salvage, position label).
- Gold/debt keep their gold/red tones; low rations tint red.
- The nav tab bar below stays exactly as it is.

## What moves out of the header (nothing is lost)

- **Continue / Skip Time buttons** → relocate to a small floating cluster at the bottom-right of the main game area (same dispatch actions), so time control stays one click away on every tab.
- **SET COURSE / Rudder menu** → same floating cluster, above the time buttons.
- **Save ledger + journal icon** → the drape area stays clean; save/journal links move into the floating cluster as small text links ("Ledger", "Journal").
- All painted icon images (`HudArt` usages), gauges, pills and hover panels in the header are removed. The detailed breakdowns (hull regions, morale list, stores) already live on the Ship tab, so no information is lost — only the hover tooltips in the header go away.

## Implementation

- Rewrite the header block of `src/routes/play.tsx`: replace the brown gradient header with the claret stripe (`h-10`, leather background + grain via CSS), ribbon drape, wordmark, and a new `Figures` row component replacing `Ledger`/`Gauge`/`Pill`/`StoreChip` usage.
- Add a `FloatingControls` component (Rudder menu, Continue, Skip Time, Ledger/Journal links) fixed at the bottom-right of `<main>`.
- Remove now-unused imports/helpers from `play.tsx`; `HudArt` stays (used elsewhere).
- Keep everything in the existing design tokens/oklch palette where practical; the claret/ribbon colours match the chosen prototype.
- Verify: `tsgo` typecheck, build log clean, and a Playwright screenshot of `/play` showing the new stripe.

## Not in scope

- Theme switching (the drape is decorative only, per your instruction).
- Changes to tabs, map, or any game logic.
