# A flag that actually flies

The banner is still a square of cloth with a torn edge stuck on it. It should read as a flag caught in a sea breeze, painted into a maritime oil canvas: curved, tapering, snapping at the fly, with clean strong colours.

## What changes

**Shape — no more block.** The cloth silhouette gets built from real wind curves instead of a rectangle with notches:
- The hoist edge stays taut against the pole, slightly bowed.
- Top and bottom edges travel as opposing S-curves, so the cloth billows out, dips, and lifts again — the outline itself shows the wave, not just the shading.
- The fly is longer than the hoist and rides higher, tapering into two or three wind-torn tongues of cloth that trail off, with irregular splits between them and loose threads at the tips.
- No straight vertical fly edge anywhere.

**Colours — clean, not damp.** The heavy grime, sun-bleach wash, brown varnish film and dark corner vignette come off. What remains is what an oil painter would actually put down: strong local colour, warm light on the crests of the folds, cool shadow in the troughs. The cloth reads bright and saturated with depth from light, not from dirt.

**Painted, not printed.** The charge and divisions follow the cloth: they curve and compress across the folds, are cut off where the cloth turns away, and get the same light and shadow as the field, so nothing looks like a flat decal pasted on a wave.

**Wear that fits a working ship.** A few small shot holes and worn seams near the fly and foot, subtle, plus the ragged tongues — enough to say "this has been at sea", not "this is destroyed".

**Pole and staff.** Keeps the oak staff and brass finial, with the cloth lashed at the hoist and the topmost corner pulled taut, the lower corners freer.

## Technical notes

- Work stays inside `src/components/game/BannerFlag.tsx`, `hoisted` mode only; the compact rectangular banner used in lists and on ships is untouched.
- Replace the static `RAGGED` outline with a generated silhouette path (bezier top/bottom edges plus shredded fly tongues), and drive the field/charge through a matching non-linear warp so the design curves with the cloth.
- Remove the `-grime`, `-wear`, `-varnish` overlays and the flat brown film; keep and retune the fold gradients as light/shadow layers, and keep a light canvas-tooth texture at low opacity.
- Keep colours, pattern, charge and layout inputs exactly as they are, so every existing flag customisation still works.
