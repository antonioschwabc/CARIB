# Future: Reuse the flag generator for other ships and factions

## Context
The banner/flag generator in `src/components/game/BannerFlag.tsx` is currently used only for the player's colours during character creation. It accepts a `Banner` object (colors, pattern, icon, layout) and can therefore be driven procedurally for any ship or faction.

## Goal
Later in development, reuse this same generator to create flags for:
- NPC ships and captains
- Factions and nations
- Trading houses and companies

## Requirements
- Generate deterministic `Banner` objects from seeds such as ship id, captain name, nationality, or faction identity.
- Support both national banners and personal/trading-house banners on NPC ships, mirroring the player's system.
- Preserve the plain, rectangular flag style so all flags in the world share one consistent visual language.
- Avoid adding one-off custom flag renderers; extend the existing `BannerFlag` component instead.

## Out of scope for now
No implementation work yet. This plan is only a record for when ship/faction flag generation becomes relevant.
