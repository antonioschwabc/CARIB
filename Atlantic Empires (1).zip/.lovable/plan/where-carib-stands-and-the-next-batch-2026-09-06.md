# Where CARIB stands, and the next batch

## Already built

- Crew pay: signing fees and weekly wages now curve steeply with skill; high-skill hands are rare; the tavern shows about five candidates.
- Debt: roughly 5% a month, with a repayment slider in Finance.
- Port levels 1-5 by historical weight, with bigger dots on the chart for bigger ports.
- Spain yellow, England red, Denmark and Copenhagen removed.
- Starting-purse slider at creation (capped at a tenth of the hull price, added to the debt).
- Battle speed 1x / 2x / 3x, and a chosen number of enemies in the mock battle.
- Rectangular historical faction flags, draped over the top-right of every port view.
- Faction trade policy: Spanish bullion tariff plus a rotating monthly farm-goods tariff, Portuguese farm tariff, cheap naval stores and dear investment, English monthly relief on a manufactured good, dear military goods, cheap investment, French monthly luxury/spirits tariff. Opinion penalties by culture and faith; pirates start at -70; a Dutch start needs no permits but pays 8%.
- Three hidden pirate harbours generated fresh each save (a level 2 Caribbean capital, one on the Colonies coast, one in Africa) with their own names and markets, found by the lookout's range.
- Faction-to-faction standing: historical starting figures, a circular relations web in Diplomacy, monthly dispatch events in the journal, war at -50, alliance at +50, and a yearly drift back to the status quo.
- A dev save option at creation with a Dev tab.

## Confirmed bug

The Dev "reveal every black harbour" button does nothing: the cheat action was declared but never handled in the game reducer, and the chart's port list is only recomputed when the region changes, so a newly found harbour would not appear until you switch charts. Both are fixed in this batch.

## This batch

1. Fix reveal: handle the dev cheats properly (harbours, coin, prestige, infamy, permits, debt), and make the chart, the helm's "set course" list and every other port list update the moment a harbour becomes known — whether found by the lookout, by a black-market contract, or by the dev button.
2. Port level actually matters: number, difficulty and payout of contracts; number and quality of tavern hands; market stock depth; quality of parts sold at the yard.
3. The Shipwright's Yard becomes a real place: a small counter for naval and military goods (cheaper than market, thin supply), a parts market where components are cargo of one ton each and can be bought and sold, and the ship schematic moved here for fitting and upgrading. The Ship tab becomes view-and-plan only, fitting parts you already own.
4. Crew and hull significance: each of the eight skills lifts a matching ship figure by skill/2.25 percent after the base figures (navigation to speed and handling, gunnery to firepower, logistics to hold, and so on, always in the helpful direction); smaller hulls handle better while bulkier hulls make better long passages; captains take no wage.
5. Finance stripped back: no taking loans or buying investments there, only the earnings and debts you already hold.

## Left for later batches (in order)

- World fleets: five AI ships per faction with named captains, crews and fitted parts, patrols from their capital, lookout-range engagements, seven-day battles marked on the chart, losses that stick, one new hull a year scaled to the faction's ports.
- Five independent merchants with good or bad trading heads, bankruptcy and a yearly top-up.
- Port assaults: a fort with a Defensiveness figure and heavy guns, the Pillaged aftermath, and change of ownership at level 2 or below.
- Battle looks: proper top-down hulls that never overlap, smooth turning, cascading broadsides, and eight to twelve lively sea backdrops with weather and time of day.
- Component crafting with goods recipes and the Carpenter's Workshop.
- Capital institutions (Lisbon academy, Wisselbank, Royal Dockyard, Nantes exchange, Casa de Contratación) and permits bought only at a capital.
- Letters of marque at +50, sailing under a crown's flag, and fleet orders (follow me / trade for me).
- Painted headers for tavern, market and yard, plus more contract kinds.

## Technical notes

- Add the missing `devCheat` case to the reducer in `src/game/actions.ts`, calling `setRevealedPorts` through `hydrateWorld` after mutating `knownPorts`; widen `ChartMap`'s `ports` memo to depend on `state.knownPorts`.
- Port level effects hook into `src/game/sim/quests.ts`, `src/game/data/crew.ts` (roster size/quality), `src/game/sim/economy.ts` (`demandDepth`), and the yard's part catalogue.
- Yard work lives in `YardPanel.tsx` with a new components-as-cargo item type; `ShipPanel.tsx` loses its purchase paths.
- Crew boons applied in `src/game/sim/shipStats.ts` after base archetype figures; archetype scouting/speed/handling spreads adjusted in `src/game/data/ships.ts`.
- Save schema bumps to 17 with normalisation for existing saves.
