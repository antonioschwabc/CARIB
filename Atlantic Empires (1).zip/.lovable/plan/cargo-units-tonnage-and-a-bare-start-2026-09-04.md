# Cargo units, tonnage, and a bare start

## The problem

Every good is counted in "units" that each weigh a fixed amount of hold space, and water was set at 1.2 tons per unit. Starting the player with 20 water and 10 salt beef therefore loaded 36 tons into a sloop that lifts 20 — the hold showed 36/20 and no trading was possible.

## What changes

**1. Each good gets its own unit name, weight converted to tons**

Goods are bought and sold in their historical unit (cask, barrel, hogshead, bale, bolt, chest, bar, sack, pipe, crate), and each unit has a sensible weight in tons used for the hold. Examples of the standard:

```text
Fresh Water     1 cask       0.20 t
Salt Beef       1 barrel     0.14 t
Flour           1 barrel     0.12 t
Salt Cod        1 barrel     0.12 t
Muscovado Sugar 1 hogshead   0.50 t
Tobacco         1 hogshead   0.45 t
Rum / Wine      1 pipe       0.45 t
Woollen Cloth   1 bale       0.15 t
Muskets         1 chest      0.10 t
Gunpowder       1 half-barrel 0.05 t
Silver Specie   1 chest      0.03 t
Pearls          1 casket     0.01 t
```

Rule of thumb: bulk staples land between 0.1 and 0.5 t per unit, manufactures around 0.1 t, precious goods under 0.05 t. A 20-ton sloop then carries roughly 40 hogsheads of sugar or 100 casks of water — believable numbers instead of "20 tons of water".

Prices stay per unit and are re-scaled alongside the new unit sizes so a hold-full of sugar is worth about what it was before; market supply figures scale the same way.

**2. The market and hold speak in both**

Listings and the selected-good panel show the unit name and its weight ("cask · 0.20 t"), the slider counts units, and the hold readout stays in tons with a running total.

**3. A bare start**

New captains begin with an empty hold, no gold, and the vessel debt already running. First business is finding coin: tavern postings, a rumour, or a cargo on credit. The opening screen and the port dossier make that plain so the start does not read as a bug.

**4. Existing saves**

Old saves have their cargo quantities converted to the new units and any over-capacity hold trimmed to fit, so nobody loads into a broken 36/20 hold.

## Technical notes

- `Commodity` gains `unit` (singular label), `unitPlural`, and `tons` replacing the current `volume`; `src/game/data/commodities.ts` is retuned across all goods with `base` prices rescaled to the new unit size.
- `volumeOf` in `src/game/actions.ts` returns tons per unit; `cargoUsed`/`shipCapacity` in `src/game/sim/voyage.ts` keep working unchanged.
- Starting state in `src/game/state.ts`: `starter.cargo = {}`, cash 0, debt untouched; bought-ship stores in `actions.ts` sized by hold, not crew.
- Store consumption in `src/game/sim/stores.ts` rebalanced to the new unit sizes so provisions last a sensible number of days.
- Unit labels surface in `MarketPanel.tsx`, `ShipPanel.tsx` warehouse, and tavern barter.
- Save normalization in `src/game/save.ts` converts legacy quantities and clamps overloaded holds; schema bumped to 13.
