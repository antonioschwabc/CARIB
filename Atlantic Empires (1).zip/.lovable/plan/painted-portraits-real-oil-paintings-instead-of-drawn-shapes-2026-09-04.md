# Painted Portraits: Real Oil Paintings Instead of Drawn Shapes

Not a limitation — the current busts are hand-drawn shapes. This replaces them with real 17th-century Dutch Golden Age oil-painting portraits, painted ahead of time and matched to each character.

## The idea

I paint a library of 48 portraits covering the meaningful combinations of the character parameters the game already tracks, save each one with a written description of who it depicts, and then every character in the game is matched to the closest-fitting painting.

## What gets painted (48 portraits)

Coverage grid: 7 nationalities (English, French, Spanish, Dutch, Portuguese, Irish, Creole) plus a weathered "old salt" set, crossed with:

- Age band: young (16–28), prime (29–44), elder (45–60)
- Sex: man / woman
- Station flavour: rough sailor, seasoned officer, learned man (surgeon/cook/quartermaster look)

All in one locked style: three-quarter bust, chiaroscuro from upper left, dark atmospheric ground, period linen collar and coat, muted earth/ochre/navy/deep red, visible brushwork and canvas weave. No cartoon, no glossy digital look, no photorealism.

## How matching works

Each painting is stored with tags: nationality, age band, sex, station flavour, plus a short description line. When a character needs a portrait, the game scores every painting against that character (nationality weighted heaviest, then age band, then sex, then station/post) and picks the best fit; ties break on the character's fixed portrait seed so the same person always shows the same face. Characters with no post fall back to the sailor flavour.

The player's own portrait uses the same matcher, and "Paint him again" re-rolls the seed to shuffle among the equally-good matches.

## What stays the same

- Character data, traits, skills, ages, cultures, faiths — untouched.
- Portrait seeds keep working; rolling a name still does not change the face.
- Flags keep the current painted-cloth heraldic style, which already matches this visual language.

## Technical notes

- Portraits generated as image files into `src/assets/portraits/`, sized for bust display, imported as normal ES module assets.
- New `src/game/data/portraits.ts` holds the tagged catalogue (file import, nationality, ageBand, sex, flavour, description) and a `pickPortrait(character)` scoring function.
- `CrewPortrait.tsx` becomes an image component with a painted frame/vignette overlay, keeping its existing props (`seed`, size) so `CrewCard`, `CrewPanel` and `new.tsx` need no changes beyond styling.
- The old procedural SVG generator is removed once the library renders everywhere.

## Trade-offs

With 48 paintings and a large crew, faces will repeat occasionally — matching keeps repeats plausible (same culture, age and role) rather than jarring. A later "commission a unique portrait" option can be added on top if you want one-of-a-kind faces for key characters.
