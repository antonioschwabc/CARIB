# Cannons, slots and berths

Three fixes: give every ship class real cannons, stop mod slots from being shown per-part, and shrink the crew a hull can lodge.

## 1. Cannons per ship class

Each class gets two new numbers: the guns she comes with, and the most she can ever carry.

```text
Class         Default guns   Max guns   Base firepower per gun (mark 1)
Sloop              4             6              5
Brigantine         8            12              5
Brig              12            15              5
Galleon           20            25              5
Frigate           15            20              6
```

- Guns become their own thing with their own gun-port capacity, separate from modification slots — mounting cannons no longer eats a mod slot.
- Every gun has a mark 1-5 like other parts; higher marks throw more metal.
- Firepower = number of guns mounted x their marks x gunner skill, so a ship with her default battery shows a sensible firepower instead of 0.
- Any ship the player already owns (and every ship bought or started with) is given her class default battery at mark 1, so the current save stops showing 0 firepower.
- The Ordnance card and the schematic gun ports read from this: "12 of 20 guns, average mark 1".

## 2. Modification slots are one shared pool

Today every part card says "4 slots free of 4", which reads as if each region had its own four. It is one pool for the whole ship.

- The slot counter moves to the ship header, next to the other stats: "Modifications 1 / 4".
- Region cards no longer print a slot count; a fit button that would exceed the pool is disabled with the reason "No modification slots left on this hull".
- Quarters and guns keep their own separate counters (quarters against the lower deck, guns against gun ports).
- Upgrading a fitted part costs no extra slot: one part = one slot, whether it sits at mark 1 or mark 5.

## 3. Berths

Hands a hull can lodge becomes exactly double her optional crew quarters.

```text
Class         Quarters   Berths (was rated hands)
Sloop            2            4        (was 16)
Brigantine       4            8        (was 40)
Brig             5           10        (was 55)
Galleon          7           14        (was 170)
Frigate          7           14        (was 130)
```

Wages, provisions eaten, combat strength and speed penalties all scale off this smaller number, so upkeep and consumption drop with it.

## Technical notes

- `src/game/types.ts` / `src/game/data/ships.ts`: add `guns` (default) and `gunPorts` (max) to `ShipClass`; set `hands = crewCapacity * 2`.
- `src/game/types.ts` / save: add `ship.guns: { level: number }[]` (or a count + mark list); `src/game/save.ts` normalizes old saves by seeding the class default battery when the field is absent.
- `src/game/sim/shipStats.ts`: `gunRating()` reads `ship.guns` instead of firepower components; `lodgings()` returns `cls.hands`; keep `slots`/`slotsUsed` counting only non-gun components.
- `src/game/data/shipParts.ts`: the three gun-mount components stay as ordnance *upgrades* (carriages, magazine, shot locker style) and no longer act as the guns themselves.
- `src/game/actions.ts`: new `buyGun` / `upgradeGun` / `sellGun` yard actions bounded by `gunPorts`; new/bought ships seeded with default guns; crew seeding clamped to the new `hands`.
- `src/components/game/ShipPanel.tsx` and `ShipSchematic.tsx`: header slot tile, region cards without slot text, ordnance card showing guns mounted / ports and marks.
